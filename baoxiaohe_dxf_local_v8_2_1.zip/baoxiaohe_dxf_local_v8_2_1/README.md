# v8.2

See **README_FIXES_V8_2.md** for this update, upgrade instructions and verification limits.

---

# v7.1 开盒动画按钮修复

修复对象：`/render/template/:id?draft=...` 渲染页的开盒动画入口。
旧版的按钮是 disabled 占位；新版已在同一页面接入本地折叠引擎，不再要求跳转到工作台。

## 已修复

- 点击“开盒动画”直接播放，盖板、插舌和防尘翼绕折痕运动。
- 暂停 / 播放 / 重播，0-100% 进度拖动，合上盒盖。
- 保留当前草稿的六面贴图、图片和尺寸，不修改原草稿。
- 静态 / 360° / 开盒切换。开盒模式下 PNG 导出当前开盖姿态，WebM 导出开盒动画，不会误导出闭合立方体。
- 缺少后端、尺寸不支持、请求超时会显示错误并允许重试，不伪装成功。

## 已有项目：安全补丁

先停止旧服务，备份项目和数据库。解压补丁，在补丁目录执行：

```bash
python3 apply_patch.py --target "/path/to/your/project"
# DRY_RUN_OK 后再执行：
python3 apply_patch.py --target "/path/to/your/project" --apply
```

支持之前提供的 v5.1、v5.2、v6 和两种 v7 完整工程。按文件 SHA-256 判断版本，不按文件夹名猜测。自行修改过的待更新代码会触发冲突并停止，请手动合并，不要强制覆盖。

补丁不修改 `.env`、`runtime/`、用户上传文件和数据库。被替换的代码备份到 `.bxh-backups/`。旧版未有本地结构引擎时，补丁会补入相应模块和依赖，必须重启后端。

```bash
cd /path/to/your/project
# 使用该项目原来的虚拟环境
python3 -m pip install -r requirements.txt
python3 server.py
```

重新打开原页面，Mac 按 Cmd+Shift+R，Windows 按 Ctrl+F5。只刷新不安装补丁不会修复 disabled 占位。

## 完整工程单独测试

```bash
cd baoxiaohe_rebuild_v7_1
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

打开 `http://127.0.0.1:8088/render/template/16835`，或由编辑器保存草稿后进入 3D 预览。不要同时启动两个占用 8088 的服务。新目录不会自动复制旧数据库。

## 验证范围

155 项 Python 测试、48 项 JavaScript 测试、30 项专项页面检查通过。页面检查是离线 Chromium + 本地 FastAPI TestClient，不是用户电脑上的端到端验收。本环境浏览器 URL 导航被管理策略拦截，GPU WebGL 路径未验证。

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest tests -q
npm run check
npm run test:js
npm run test:opening
```

## 限制

当前渲染页使用“双端插口盒”示例结构，不是每个模板的原始生产刀版。长 40-500mm，宽 25-350mm，高 20-500mm；超出范围会报错，不会悄悄改大小。胶口、插舌等新增区域用底色；渲染页导出的 WebM 为最大 1024px 长边的预览视频，录制时不要关闭页面。这是功能缺陷修复，不代表整站已达到 1:1 生产验收。
