# v8.1 Mac / Windows 浏览器兼容修复

基于上一版 DXF Local v8。本次是兼容性补丁，不是重做网站。

## 文件选择窗口

在 `/cad` 点击“导入CAD文件”后，先显示导入弹窗；再点击虚线框中的“点击选择”，才打开系统文件窗口。

- 重复选择同一 DXF 可再次触发导入。
- JSON 选择控件保留在页面中，不再使用脱离 DOM 的临时控件。
- 选择文件直接在用户点击时触发，不等待网络请求。
- 取消不会清空已导入的刀模或图层；解码失败后可重试。
- 图片同时使用扩展名提示和内容验证，不仅依赖 File.type。
- 浏览器拒绝打开时显示错误，不绕过安全限制。

## 其他已修复项目

弹窗内 Delete/Backspace 不再误删背后图层；CAD 接入 Ctrl+S / Command+S；录像按实际能力选择 WebM/MP4；滚轮单位归一化；旧浏览器能力缺失时提示升级；渲染任务跨进程 JSON 读写明确 UTF-8。

## 更新现有 v8

先停止服务并备份项目和数据库。在补丁目录运行：

Windows PowerShell:
```powershell
python .\apply_patch.py --target "D:\baoxiaohe"
# Only after DRY_RUN_OK:
python .\apply_patch.py --target "D:\baoxiaohe" --apply
```

macOS / Linux:
```bash
python3 apply_patch.py --target "/path/to/your/v8"
# Only after DRY_RUN_OK:
python3 apply_patch.py --target "/path/to/your/v8" --apply
```

目标是包含 `server.py` 的原项目目录。补丁验证文件 SHA-256，冲突时停止，不强行覆盖。不要用它直接更新 v7.1。

使用原有 Compose 项目和数据卷重建：
```bash
docker compose up -d --build --force-recreate web
```
**不要使用 `down -v`。** 更新后强制刷新：Windows Ctrl+Shift+R，Mac Command+Shift+R。

## 验证范围

199 Python tests; 110 JavaScript tests; 45 compatibility component checks; 37 filechooser-boundary checks; 25 existing CAD regression checks. Groups overlap. See `evidence/browser_compat_v8_1/`.

使用 Linux Chromium 运行本地代码和本地 API，文件选择测试拦截真实 filechooser 事件。没有运行 Windows/macOS 原生文件窗口，不等于目标系统真机验收。GPU、Safari、Edge、真实中文输入法、Docker 构建和正式部署仍需验证。

Native browser URL navigation in this environment was blocked. Tests use authored about:blank components and an in-process FastAPI client, not a proxy around that restriction. Media tests encoded actual WebM and MP4 with Linux Chromium; forcing MP4-only advertisement is not a Safari test.

## Windows 真机检查

1. 用 Chrome/Edge 打开 `/cad`，点导入，再点虚线框，确认出现系统文件窗口。
2. 取消后重选，同一个 DXF 选两次，包含中文文件名和大写 .DXF。
3. 导入 PNG/JPG，取消后再试，检查图层不丢失。
4. 打开 JSON 项目；弹窗打开时按 Delete，确认背后图层不变。

若系统窗口仍不出现，需根据真机错误区分浏览器策略、扩展、旧缓存或系统文件对话框问题，不建议关闭系统安全功能。

保留原样：Docker 端口、认证、数据库、模板数据、DXF 几何与折叠算法、CSS 布局。不需要网站账号、密码或外部云服务。
