# DXF decoding hotfix / v8.2.1

This is a scoped update to DXF Local v8.2, not a new production certification.
The particular DXF that triggered the user's message was not provided.
Reproductions and tests use authored fixtures. No website login or external
service was used, and the user's running deployment was not accessed.

已修复 UTF-8 BOM、CR 换行和旧版 DXF 默认编码兼容问题。新增“文件编码”选择，更改后需重新解析。未改动渲染、尺寸视图、Docker 和数据库。仍需要你报错的原始 DXF 才能确认该文件的具体原因。

## Findings and fix

The old parse_dxf catch block combined UnicodeDecodeError, invalid DXF header,
and malformed group-code/section errors into the same generic encoding message.
Reproduced failure cases now accepted without geometry repair:
- UTF-8 BOM preceding the first group code;
- CR-only DXF record endings (LF and CRLF remain supported);
- legacy text DXF without DWGCODEPAGE, using its documented cp1252 default.

The decoder now uses ezdxf metadata detection rather than a regex limited to the
first 64 KiB. R2007+ uses UTF-8. Legacy files use the declared codepage, with the
documented cp1252 fallback. Normalization warnings and the selected encoding are
visible in the import dialog. The original byte hash is retained.

The import dialog now has a File encoding field: Auto, UTF-8, GBK, Big5,
Western cp1252, Japanese cp932 and Korean cp949. Auto is the default. Use an
explicit encoding only when the originating application's encoding is known;
a codec that accepts bytes does NOT prove that layer names are correct.
Changing the encoding invalidates old previews and in-flight responses.

Unknown units must be selected explicitly. This also avoids an ezdxf synthesized
HEADER default from silently assigning metres to headerless R12 drawings.
Nothing rescales geometry as part of text decoding.

No errors='ignore', replacement of undecodable bytes, arbitrary codec guessing,
or automatic DXF structural repair is performed. Binary DXF, DWG, PDF/ZIP,
UTF-16/UTF-32 and corrupt records produce separate actionable errors.
Existing size/geometry limits remain. Unsupported CAD entities and manufacturing
limits have NOT been expanded by this patch.

## Apply to the existing v8.2 directory

Stop the service and back up code and databases. Unzip the patch, then run:

```powershell
python apply_patch.py --target "D:\baoxiaohe"
# Only after DRY_RUN_OK:
python apply_patch.py --target "D:\baoxiaohe" --apply
```

macOS/Linux: use python3 and your actual project path. Target the existing folder
containing server.py. Hash conflicts stop the update. Code files are backed up;
.env, database files, catalog data, Docker/network configuration, authentication,
CSS, viewport sizes and rendering algorithms are not changed.

Rebuild using the SAME existing Compose project and data volume:

```sh
docker compose up -d --build --force-recreate web
```

Do not use down -v. For native Python, restart the existing server.py process.
No dependency changes. Hard-refresh the browser (Ctrl+Shift+R on Windows,
Command+Shift+R on macOS). Go to /cad and import again. Start with Auto.
If the source is known to be legacy Chinese GBK and Auto fails or names are wrong,
select GBK (ANSI_936), parse again, check layer names/millimetres, then confirm.

## Tests actually run

- 41 new encoding/container/API tests passed.
- Entire Python test suite: 259 passed (includes the above 41).
- Existing JavaScript test suite: 125 passed; JS syntax check passed.
- 16 scoped Chromium checks passed, including real filechooser interception,
  backend codec selection, import, and stale-response rejection on codec changes.
  The browser document is assembled from authored files in about:blank, and
  FastAPI runs through TestClient; this is NOT native URL E2E or Windows/Mac OS,
  Safari/Edge/GPU verification. No attempt is made to bypass navigation policy.
- Patch dry-run/apply/idempotence/conflict checks: see the separate evidence file.

The original source DXF is still needed to confirm THIS user's failure. A
successful decode is not proof of correct topology, folding, or production fit.
Keep the source file and verify dimensions and roles before manufacture.

## Primary references

https://ezdxf.readthedocs.io/en/stable/dxfinternals/fileencoding.html
https://ezdxf.readthedocs.io/en/stable/drawing/management.html
https://ezdxf.readthedocs.io/en/stable/drawing/recover.html
