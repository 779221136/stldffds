# DXF Local Upgrade v8 / DXF 刀模与智能编辑

已根据上传的 9 页 PDF 文字与配图修改部署包。新增 DXF 导入、本地刀模库、图文编辑和折叠渲染。这是可验收的本地功能升级，不是全部工业刀模的生产认证。

“本地”指你部署 Python / Docker 服务的机器：浏览器会把文件发给你自己的服务，不发给包小盒或外部云服务。不需要官网账号或 API Key。

## 1. Start / 启动

```bash
cd baoxiaohe_dxf_local_v8
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

Open `http://127.0.0.1:8088/cad`. The existing templates page, editor and renderer are retained. The templates navigation and old editor now have a `导入CAD文件` entry. In Windows use `.venv\Scripts\activate` and `python`.

Docker: keep your existing Compose project and data volume, then run `docker compose up -d --build --force-recreate web`. **Do not use `down -v`.** The uploaded Compose port publishing, firewall behavior, `.env` and authentication logic are not reset. A full distribution contains `.env.example`, not your private `.env`; preserve your existing configuration. The only runtime requirement change is `Shapely>=2.1,<3` for constrained, hole-aware triangulation.

The full application still has its previous release blockers (SMS/OAuth, payment, ICC and manufacturing validation). This module does not imply those services are ready. Do not expose development authentication to the Internet.

## 2. Workflow / 使用流程

1. `导入CAD文件` -> select or drag an ASCII DXF, confirm units and curve tolerance, click parse. Unitless drawings require an explicit unit. Sample files in `examples/dxf/` are authored test fixtures, NOT official-site models or factory-approved dielines.
2. Review the preview and every layer/colour mapping. Blue CUT, red CREASE, purple PERF; unassigned paths remain explicit and block DXF export until classified. Names take priority over colour heuristics. Unsupported entities are listed, not silently presented as complete imports.
3. `线条编辑` lets you select a stroke or path ID, edit its endpoints/radius/angles and choose cut/crease/perforation/guide/ignore. `应用拆线清理` explicitly converts curves to tolerance-controlled polylines, snaps endpoints, removes duplicates and nodes intersections; preserve the original DXF externally. Structure Undo returns the previous geometry.
4. `生成3D展盒` derives real faces and hinge axes. Resolve any topology diagnostics. Choose a root and each hinge's fold angle, opening increment and timing; confirm them. Folding/opening sliders and play controls update the actual geometry. Opening is disabled until at least one nonzero opening increment is specified. A flat drawing cannot uniquely define a fold assembly.
5. `图文排版` adds text, image, rectangle, local QR or CODE128 artwork. Existing drag-sort layers and undo/redo are reused. For net movement choose `刀模独立图层`, unlock it in the parameter panel, apply, then drag. Numeric placement/rotation/scale changes the separate net layer, not manufacturing dimensions. Use XY resize for actual millimetre scaling. Text/artwork stays independent of the structural layer.
6. `保存模型` persists the complete editable CAD document to your own SQLite library. Specify a name, comma-separated tags and virtual folder path (`Project/Category/Box`). Load by click or drag from `本地刀模库`. Concurrent updates are rejected with 409; save a copy or reload. Saving is explicit, not silent automatic cloud saving.
7. Export a **project JSON backup** for portable editing, structural DXF/SVG for geometry review, or artwork SVG (physical units, RGB preview). Submit PNG or animation to `本地后台渲染` for actual local CPU output. The Python service must remain running for background jobs. No external render farm is used.

## 3. Persistent local data

- CAD library: `cad-library.sqlite` beside `BAOXIAOHE_DB` (Docker default `/data/cad-library.sqlite`). No existing tables or catalog records are overwritten.
- Rendering: the pre-existing local render directory and owner-specific queue remain in use. Completed files default to the original 24-hour retention rules. Download them promptly.
- Signed-in **local** users keep an account-linked library across sign-ins. Anonymous libraries are bound to the HttpOnly local session cookie. Clearing that cookie does not automatically recover anonymous content; export project JSON and back up the data volume. Logging in does not silently merge another session's library.
- Virtual folders support five nonempty levels; moving a model is done by saving its folder path. Empty folders, shared-team ACLs and collaborative editing are not implemented.
- Structural source name, format, units and SHA-256 are saved; the normalized editable primitives are saved. The untouched original DXF byte stream is **not** archived by the library. Keep the source file as the original record.

## 4. Limits / 边界

不支持从任意 DXF 唯一推断长宽高、折叠方向和纸厚补偿。未通过工厂打样、碰撞仿真、印前色彩管理验收。

| Area | Actual boundary |
|---|---|
| DXF | ASCII DXF; declared/manual units; 5 MiB; 4000 primitives; 16000 preview segments; 100 faces; bounded intersection complexity; no DWG, binary DXF, arbitrary spline/ellipse/3D entities |
| Geometry | Native LINE/ARC/CIRCLE preserved for structural export; curve meshing is approximate at the declared sagitta tolerance |
| Fold | Straight crease adjacency **tree** only. Open slits, disconnected nets, cycles and ambiguous structure block 3D. No collision, self-locking-bottom solver, elastic deformation or automatic assembly constraints |
| Parameters | XY geometry scaling, line roles, bleed guide, material tag, display thickness. No generic three-parameter L/W/H solver. Fold allowance is an explicit process note, NOT a calibrated production offset |
| Graphics | Existing text/rect/image layer types and barcodes in CAD mode; not all features of the original website editor |
| Render | Existing WebGL and Canvas software preview; local CPU depth-buffer output. No Three.js added, no photorealistic path tracing; GPU path still needs real-device verification |
| Output | Structural DXF/SVG and editable JSON; RGB artwork SVG. No new production PDF/ICC/PDF-X/spot plates or factory certification |

## 5. Verification

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest tests -q
npm run test:js
npm run check
python3 tools/acceptance_cad_v8.py
```

Observed: **197 Python tests, 61 JavaScript tests, 25 scoped browser checks passed**, plus JS syntax. **16 patch/package safety checks passed**, including exact-baseline apply, no-op dry-run, rollback after an injected write failure, conflict rejection and idempotent reapply. Browser checks use authored local code in offline Chromium and real in-process FastAPI actions, **not native URL E2E**. An ordinary local `Page.goto` attempt returned `ERR_BLOCKED_BY_ADMINISTRATOR`; this limitation was not bypassed. WebGL is unavailable in this environment; software preview and actual local worker output were tested. Docker build, real AutoCAD files supplied by your factory, user-server deployment, load/recovery, print production and pixel-perfect original-site parity were NOT validated.

The supplied baseline had one stale test requiring loopback-only access despite your previously requested Docker public binding. It failed on the unchanged baseline too. The test now expects published hosts to work and still verifies cross-origin rejection; production network configuration was not changed. Evidence is in `evidence/dxf_v8/original_network_test.log`.

## 6. PDF traceability and sources

See `PDF_REQUIREMENTS_V8.json` and `AUDIT_DXF_V8.html`. Requirements were read from all 9 rendered PDF pages, not just hidden/repeated extracted text. Main references: p4 import wizard; p5 topology and folded preview; p6 library; p7 artwork integration; p8 parameter panel; p9 parser/render architecture.

Public reference used for gaps: https://help.baoxiaohe.com/archives/1947/index.html (DXF line classification and import constraints). Technical references: ezdxf LWPolyline docs and Shapely polygonize_full documentation. No website account was logged in and no official templates were downloaded. The provided account credentials were not written into any file.
