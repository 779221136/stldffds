# v7 LOCAL APIs (existing v6 APIs remain below)

All `/api/local` endpoints are loopback-only and same-origin. Open the local
workbench or GET `/api/local/capabilities` first; it sets the HttpOnly local
job-owner cookie. This is NOT the existing SMS/production account system.

| Endpoint | Behavior |
|---|---|
| GET /api/local/capabilities | Local formats, limits, cloud=false; init owner cookie |
| POST /api/local/structure | StructureSpec -> canonical panels/cut/creases/bleed/hinges |
| POST /api/local/dieline/svg | Millimetre engineering-draft SVG |
| POST /api/local/dieline/dxf | Layered R2010 ASCII DXF, mm, engineering draft |
| POST /api/local/project/validate | Validated LocalRenderRequest fields, no task creation |
| POST /api/local/jobs | 202 queued task; never a placeholder image |
| GET /api/local/jobs | Current local session's jobs |
| GET /api/local/jobs/{id} | queued/running/succeeded/failed/cancelled + progress |
| GET /api/local/jobs/{id}/result | Owner-only completed binary file |
| POST /api/local/jobs/{id}/cancel | Cancel queued or running work |
| DELETE /api/local/jobs/{id} | Delete terminal record and files |

POST/DELETE requests require application/json (including `{}` for cancellation).
Unknown jobs and other owners' IDs return 404; incomplete files return 409;
removed successful output returns 410. Payload/geometry errors return 422,
queue limits 429, unavailable FFmpeg video 503. Transparency with MP4/WebM is
422; select PNG or frame ZIP. Task states do not report success before a real
file exists. Legacy `/api/render/jobs` is still an unconfigured CLOUD endpoint;
new local UI deliberately uses `/api/local/jobs` instead.

See LocalRenderRequest in app/local_raster.py and StructureSpec in
app/structure.py for exact validated fields and bounds. Animation <=1024px,
<=120 frames. PNG <=4096px. Embedded panel images only, no outbound fetch.

---

# v6 API integration and storage contracts

## Unchanged service boundaries

This app is a local FastAPI/SQLite implementation. Default sessions are HttpOnly cookies. Production SMS/OAuth, membership, payments and factory services are deliberately not implemented. Never upload live keys/cookies. Third-party integrations require their own authentication, permission, retry, signature, reconciliation and audit implementation.

## Retry-safe design saves

`POST /api/designs` accepts `name`, `kind`, `source_id`, `payload`, plus `id` and `version` when updating. Send `Idempotency-Key: <8..128 ASCII letters/digits/_.:->` per operation. Reuse the EXACT request and key after a lost response. New content needs a new key.

A transaction checks owner, replay receipt and expected version, writes the design and snapshot, then commits a receipt. Replaying an accepted request within 24 hours returns the original result. Reusing its key with a different body returns 409. A stale design version returns 409 without overwriting. A semantic no-op does not increase the version.

24-hour receipt retention is finite: do not blindly replay an old CREATE after that window. A production integration must define reconciliation for longer outages. Local cache failures are surfaced; localStorage is not a reliable large-asset database.

## History

- `GET /api/designs/{id}/versions`: latest 50 metadata snapshots, owner-only.
- `GET /api/designs/{id}/versions/{version}`: owner-only full snapshot.
- `POST /api/designs/{id}/restore` with `{ "version": 3, "expected_version": 8 }`: restores snapshot 3 as a NEW revision 9 if the current revision is still 8.
- Missing/not-owned resources return 404. Version conflicts return 409. Deleting a design cascades its snapshots and save receipts.

SQLite tables: `design_revisions` and `design_save_receipts`. Existing current versions are backfilled during migration; unavailable earlier versions are not fabricated. Each checkpoint stores a full JSON payload, including embedded images, so storage grows with document size. This is not a deduplicated object store or a collaborative version graph.

## Catalog and actual documents

`GET /api/catalog/meta` adds `model_options` (per-kind category/count/type/unknown flags) and `available_sorts`.
`new` uses `created_at`; `uses` uses `use_count` or `uses`; `popular` explicitly uses `views`. Missing metrics are disabled in the UI. `model_bindings` may be supplied by a deployment with provenance; the bundled 360010 mapping is SAMPLE taxonomy only.

`GET /api/templates/{id}/document` and `GET /api/models/{id}/document` load a deployment's `design_payload`. They do not download original assets or extract a remote editor document.

The schema supports only `geometry: "six-face-box"` and objects `text`, `rect`, `image`. Missing document returns `available:false`. Invalid schema/unsupported geometry returns 422. `document_access` defaults to `authenticated`; explicit `public` makes it public. Unimplemented paid/member access returns 501, rather than granting free access. Regular list/detail APIs strip `design_payload` and expose only `has_design_document`.

An integration fixture is in `evidence/v6/typography-fixture.json`. To test a catalog document, add its contents under a test row's `design_payload` and choose access policy explicitly. Do not replace a real catalog blindly. No original source documents are included.

## Typography and PDF

New text may set `wrap:true`. The editor measures lines and serializes `textLines`. Joining those lines must exactly preserve source text (excluding hard line breaks); the API rejects hidden text substitution. Wrapped horizontal text requires saved line layout for preview export. Legacy non-wrapped text keeps its behavior.

RGB preview generation uses the stored lines but still relies on installed fonts. This is NOT deterministic professional typesetting, ICC color management or print-production validation. Original carton topology, GLB, DXF and PSD/AI/PDF editing imports remain unsupported.

## Operational constraints

Back up SQLite before migration. Test the copy first. Default service listens only on 127.0.0.1. Do not deploy development sign-in publicly. TLS, WAF/rate limiting, distributed sessions, queues, object storage, HA, billing reconciliation, load testing and restore drills are not delivered as verified capabilities.
