# v8.2 导入与渲染修复

已修复上轮复现问题，并小幅放大预览区。未修改你电脑上正在运行的服务，应用补丁或安装完整工程后才会生效。

## 修复范围

### 上传单位和精度

修改单位或曲线精度后，旧预览立即失效；必须重新解析才能确认导入。

mm 改 cm 后重解析，真正保存 600mm，不再保存旧的 60mm。

### 快速更换文件

解析与确认使用独立请求版本；旧成功、失败或结束回调不能覆盖新选择。

控制 A 延迟 1.2 秒，先完成 B；最终导入 B-90mm.dxf。关闭弹窗后旧请求也不再生效。

### DXF 导出再导入

GUIDE / REFERENCE / CONSTRUCTION 图层按参考线识别，名称映射优先于颜色推断。

导出 DXF 再导入可直接展盒，不需手动重分类。

### 视频参数

动画选项联动限制到 1024px / 120 帧；MP4/WebM 自动关闭透明背景。静帧 4K PNG 不受影响。

保留后端配额，不再让用户选到必然被拒绝的 4K 视频组合。

### 渲染任务列表

进入 CAD 或重开模型时自动读取任务，增加刷新按钮及有限次数失败重试。

同一会话重开页面后可下载已完成结果；原有用户隔离和文件保留期不变。

### 闭合盒面条纹

CPU 深度比较统一为 Float64；软件预览改为逐像素深度缓冲。闭合后的共面重叠面片使用显示层间距。

纯色盒盖测试区域从 3 种交替颜色恢复为 1 种；导出刀线、原始路径、铰链运动不改动。

## 视图调整

1440 x 1000 CSS pixels 下的实测：

| 区域 | v8.1 | v8.2 |
|---|---|---|
| CAD 3D | 281 x 212 | 321 x 244 |
| 结构工作台预览 | 804 x 360 | 804 x 405 |
| 原编辑器小预览 | 243 x 245 | 243 x 276 |
| 渲染主视图 | 910 x 682.5 | 960 x 720 |

手机 CAD 3D 预览高度从 280 增加到 310px。不改刀模毫米尺寸、相机默认缩放或导出像素。

## 更新

仅适用于 DXF Local v8.1。先停止服务，备份代码与数据库；在补丁目录运行：

```bash
python3 apply_patch.py --target "/path/to/existing-project"
# Only after DRY_RUN_OK:
python3 apply_patch.py --target "/path/to/existing-project" --apply
```

Windows PowerShell 将 python3 换成 python，目标例如 `D:\baoxiaohe`。目标应为包含 server.py 的目录。发现自定义文件冲突会停止，不强行覆盖。

回到原部署目录，沿用原 Compose 项目名和数据卷：

```bash
docker compose up -d --build --force-recreate web
```

**不要执行 down -v。** 直接 Python 部署则沿用原虚拟环境重启 `python3 server.py`。浏览器强制刷新：Windows Ctrl+Shift+R；Mac Command+Shift+R。

## 完整工程单独试运行

```bash
cd baoxiaohe_dxf_local_v8_2
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

Windows: `.venv\Scripts\Activate.ps1`，然后使用 python。打开 `http://127.0.0.1:8088/cad`。不要在新目录意外创建新 Compose 项目后认为旧数据丢失；保留现有数据卷。

## 测试

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest tests -q
npm run test:js
npm run check
python3 tools/acceptance_fixes_v8_2.py
python3 tools/acceptance_http_v8_2.py
```

218 Python tests; 125 JavaScript tests; 38 新功能组件检查；25 CAD 回归；37 文件选择检查；48 真实 HTTP 测试。组之间有重叠，不相加作为功能数量。

组件检查使用 Linux Chromium about:blank 中的本地代码与进程内 FastAPI；不是原生完整 E2E。本轮尝试原生 URL 导航仍被 ERR_BLOCKED_BY_ADMINISTRATOR 阻止，未绕过。独立 HTTP 测试启动本地服务和真实工作进程，生成并解码 4K PNG、MP4、WebM和帧序列，检查重启后数据保留及权限隔离。

## 不变与边界

Docker/公网端口配置、认证、数据库、模板数据、输出配额不变，未连接官网或外部云服务。

面片层次仅为渲染提案（较大面片在外），不是碰撞求解或纸厚生产补偿。法向相反、结构模糊的重叠仍需手动确认折叠方向。未完成工厂打样、原生 Windows/macOS、GPU、Docker 构建验收。

详细报告：`AUDIT_FIXES_V8_2.html`；实测记录：`evidence/fixes_v8_2/`。
