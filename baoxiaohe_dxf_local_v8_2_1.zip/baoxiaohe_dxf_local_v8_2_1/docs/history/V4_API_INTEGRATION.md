# v4 API contracts and missing integrations

## Boundary
This is an audited development rebuild, not the original service's API implementation. No credentials or internal API URLs from the original site are used. Adding provider keys to an environment file is not sufficient to implement a missing integration.

## Implemented endpoints

| Endpoint | Behavior |
|---|---|
| GET /api/health | version, environment, truthful capabilities, production_ready:false |
| GET /api/catalog/meta | actual sample counts; payments_configured:false |
| GET /api/templates, /api/models | q, filters, sort, page, page_size (1..100); items/total/page/pages |
| GET /api/templates/:id, /api/models/:id | sample item/related; 404 for unknown IDs |
| POST /api/auth/sms/send | development-only random challenge; expires in 300s; resend after 60s |
| POST /api/auth/sms/login | consumes challenge, max 5 failed attempts, HttpOnly session |
| POST /api/auth/logout | deletes server session |
| GET/PATCH /api/me | current user / validated display name |
| GET/POST /api/favorites | authenticated owner; source/kind validation |
| DELETE /api/favorites/:kind/:id | authenticated removal |
| GET /api/designs, /api/designs/:id | only current user's design payloads |
| POST /api/designs | create with no id; update with id+version; stale 409; absent/foreign 404 |
| DELETE /api/designs/:id | ownership enforced |
| POST /api/preflight | valid dimensions, effective image DPI/font size, unsupported craft/color warnings |
| POST /api/exports/pdf | mode print/structure, color_mode RGB; explicit preview headers; CMYK returns 501 |
| GET /api/tools/qrcode.svg | generated local QR SVG with quiet zone |
| GET /api/tools/barcode.svg | CODE128, CODE39, EAN8, EAN13; charset/checksum validation |
| POST /api/print/quote | bounded specs, sample Decimal pricing; estimate_only:true |
| POST /api/print/orders | auth required; total recalculated; optional Idempotency-Key |
| GET /api/account/orders | current user's estimate records |
| POST /api/render/jobs | 501: no cloud job is pretended to exist |
| GET /api/render/jobs/:id | 404: no placeholder completion |

All mutating /api requests, including DELETE, require `Content-Type: application/json` and a JSON body (`{}` is sufficient for empty requests). The server rejects untrusted Origin values and limits request bodies to 12 MiB. The served file roots are ONLY `/src` and `/assets`; project/runtime/config files are never static downloads.

## Design payload
```json
{
  "schemaVersion": 4,
  "geometry": "six-face-box",
  "box": {"length": 120, "width": 80, "height": 180},
  "bg": "#eee8dc",
  "accent": "#115f73",
  "objects": [{"id":"title","type":"text","x":600,"y":280,"w":150,"h":60,"text":"PACKAGING","fontSize":24,"fill":"#173546"}]
}
```
Coordinates use the 1180x760 shared artwork viewBox. `src/geometry.js` and `app/domain.py` share the same dimensions and face placement. See these modules for the formulas; this topology is not a production carton net.

Images are self-contained base64 PNG/JPEG (5 MiB, 25MP max) or restricted SVG (1 MiB). Remote image URLs, scripts, event handlers, DTDs, external SVG references and inline SVG CSS are rejected. This restricted importer is not identical to the original site's SVG feature set. Server-generated barcode styles are normalized into safe attributes before returning them.

Successful save returns `id`, `version`, `updated_at`. Store the cloud id separately from the browser draft id. Preserve local edits if a version conflict or network failure occurs. Mutation success must not be inferred from localStorage writes.

## Missing production integrations

SMS/OAuth: implement a real provider, server-side verification, abuse protection, account binding and recovery. ENV=production currently refuses sign-in with 503. Keep credentials only in your deployment secret store.

Payments/membership: server-created price/order, verified signed callbacks, transactional idempotency, entitlements, refunds and reconciliation. There is no active payment link or real subscription grant in this build.

Assets: approved template metadata/images, model geometry/UV maps/materials, private asset storage, signed uploads, antivirus/format validation, retention and rights management. Do not point the browser at private storage credentials.

Geometry/rendering: true carton constraints, glue/tuck flaps and tolerances, DXF/GLB parsing, fold hierarchy/animation, PBR materials and lighting, server jobs/queue/GPU workers/result storage. Browser PNG is NOT a completed cloud rendering job.

Printing: factory-backed pricing, ICC-managed CMYK/PDF-X, finishing plates, proofs, payments, production and delivery state machines. Current RGB previews and estimated order totals cannot be sent to production as an approved dieline/order.

Team/AI: real org membership and roles, projects/versions/invitations/private files; configured model provider or local model, job limits, safety and license policies. Existing heuristic palette generation is not AI generation.

## Operations still required
TLS and trusted reverse-proxy configuration, rate limits, session lifecycle monitoring, backups/restore drills, migrations under concurrency, transaction/load tests, dependency scanning and licensing review. Docker/Nginx files are examples, not evidence of a tested production deployment.
