# v5.1 图层排序修改说明

## 问题

v5 的图层面板只支持选中、显隐和锁定，上下调序依赖属性面板按钮，没有拖拽排序。

## 修改文件

| File | Change |
|---|---|
| `src/layer_order.js` | Immutable reorder algorithm and explicit visual/painter index conversion. |
| `src/layer_panel.js` | Pointer sorting, drag preview, insertion line, auto-scroll, cancellation, keyboard navigation, accessibility status and lifecycle cleanup. |
| `src/editor_engine.js` | One `reorderLayer` commit path for history, canvas repaint, preview notification and serialization; lock enforcement for both buttons and drag. |
| `src/app.js` | New panel integration and cleanup; keep inherited visibility/select/lock hooks. |
| `assets/styles.css` | Drag handles, state styles, colored shape thumbnails, focus and pointer interaction areas. |
| `app/main.py` | Version metadata updated to 5.1.0 only; no API contract change. |
| `tests/layer_order.test.mjs` | Unit tests including 22,140 exhaustive move combinations for stack sizes 1-40. |
| `tools/audit_layers_browser.py` | Focused editor integration tests with local API persistence and screenshots. |
| `package.json` | New test scripts and version 5.1.0. |

## 交互语义

列表顺序是前到后，存储数组仍是后到前。拖动过程只显示落点，松手时提交一次数据变更，所以一次撤销可完整撤回。原位放下、拖出区域或取消不产生伪修改。

锁定图层不能被主动拖动或用按钮改层级；其他未锁定图层仍可以跨过它，锁定不代表固定排序槽位。本次没有新增多选批量排序或嵌套分组。

修复了拖动后的合成 click 和用户新一次点击混淆的问题，新的 pointerdown 会清除上次拖放的点击抑制，避免排序按钮偶尔不响应。

## 原站参考的范围

Official public reference: https://help.baoxiaohe.com/support/archives/733/
It documents layer locking and upward/downward stacking. The current authenticated editor's exact drag thresholds, animation and pixels were not observable here; this release implements the user's requested behavior independently, not a claim of recovered private code or verified pixel parity.

## 测试证据

See `evidence/layers-v5.1/TEST_SUMMARY.json`, `browser-results.json`, `unit-tests.txt`, `pytest.txt`, and the screenshots. The additional inherited broad-browser run timed out after 23 passing checks and is deliberately excluded from the full pass count. Original full-site production blockers are unchanged.
