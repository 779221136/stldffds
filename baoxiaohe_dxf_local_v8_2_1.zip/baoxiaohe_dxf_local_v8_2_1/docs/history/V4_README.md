# 包小盒重建工程 v4：审计修正版

**这是可运行的开发验收版，不是原站 1:1 生产级完成版。**

不需要你提供原站源码、密钥、Cookie 或数据库。本项目不连接原站私有服务，也不会发送短信、扣费或下单生产。

本轮修复：验证码校验、静态文件泄露、设计保存与权限、真实分页、六面贴图、按像素导出、PDF 图文与中文字体、视觉差异计算。详见 `AUDIT_V4.md` 和 `AUDIT_V4.html`。

## 1. 本地运行

Python 3.11+ is recommended (this release was tested on Python 3.13). Node is only needed for JavaScript syntax checks; there is no npm build step.

```bash
cd baoxiaohe_rebuild_v4
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

Open `http://127.0.0.1:8088/templates`. The server binds to loopback by default. Do not expose development authentication to the public Internet.

On Windows, activate `.venv\Scripts\activate` and use `python` instead of `python3`.

登录页点击“获取测试码”，会生成一次性六位本地码。不再使用固定 `8888`，不会发送真实短信。

### Native PDF dependencies

CairoSVG requires a native Cairo library. Chinese PDF previews need **fontconfig** and an installed **Noto Sans CJK SC** font. No font files are included in this ZIP.

Debian/Ubuntu:
```bash
sudo apt-get update
sudo apt-get install libcairo2 fontconfig fonts-noto-cjk
```

macOS (Homebrew):
```bash
brew install cairo fontconfig
```
Install Noto Sans CJK SC locally through the official font distribution or an approved system package. Verify with `fc-match "Noto Sans CJK SC"`. Alternatively, set `PDF_CJK_FONT` to the exact family name of an already installed CJK font. The exporter fails clearly if the font is unavailable; it does not silently export square missing-glyph boxes. macOS and Windows have not been end-to-end tested in this environment.

### Docker alternative

The Docker recipe installs native dependencies at build time; the project does not redistribute font files.

```bash
ENV=development docker compose up --build
```

Default Compose mode is `production`, where SMS/OAuth sign-in is intentionally unavailable and returns 503 until a real implementation is connected. The host port remains bound to `127.0.0.1` in either mode. **The Docker build, TLS deployment and load behavior were not executed in this audit.**

## 2. 本轮验证

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest tests -q
npm run check
# Run after starting the development server:
python3 tests/smoke_api.py
```

Audit results: **44 API/tool tests passed**, JavaScript syntax passed, development smoke test passed. **26 offline Chromium interaction checks passed**, including real localhost API calls and Canvas 2D software exports. See `evidence/` for the exact scope, outputs and package versions.

The environment blocked ordinary browser URL navigation and did not provide WebGL. The offline harness injects authored code into `about:blank` and adapts history, localStorage and fetch; it does not bypass restrictions or access the original site. These checks are **not** a claim of native full-stack browser E2E parity, GPU validation, or pixel-perfect comparison.

Optional reproducible offline interaction audit (server running):
```bash
CHROMIUM_PATH=/usr/bin/chromium python3 tools/offline_browser_audit.py
```

The harness creates throwaway development accounts and estimate records in your local test database. Use a separate database with `BAOXIAOHE_DB` for acceptance testing. It never contacts an external API provider.

## 3. 视觉比对在你本机运行

```bash
python3 tools/visual_regression.py \
  --reference https://www.baoxiaohe.com \
  --candidate http://127.0.0.1:8088 \
  --routes /templates /models /templates/25987 /models/74 \
  --viewport 1440x1100 --output visual-report
```

Screenshots and reports stay on your computer. No source code or credentials need to be uploaded. If the original page is blocked, challenged or stuck at Loading, the report marks the comparison **UNVERIFIED**, not 0% different. Pixel percentages are image differences, not feature-completeness percentages.

## 4. 当前功能范围

| Area | Implemented | Important limitation |
|---|---|---|
| Catalog | API search, filtering, sorting, pagination; metadata detail pages | 20 template and 12 model samples; schematic imagery, not original asset library |
| Editing | Six-face artwork, drag, resize, rotate, multiline text, layers, lock/hide, undo/redo, image fit/flip, QR/barcodes | One six-face box visualization; no true parametric carton/dieline production engine |
| Persistence | Authenticated designs, owner isolation, version conflicts, favorites, profiles, estimate orders | SQLite development store, browser drafts; no distributed HA or team collaboration |
| Rendering | Full artwork atlas, six-face UV geometry, presets, lighting, background, PNG, WebM | WebGL path needs GPU validation; tested software fallback is a projected, tessellated preview, not photorealistic cloud rendering |
| PNG | 1024/2048/3072/4096-pixel long edge, aspect-aware, alpha | High-resolution image dimensions are not a guarantee of source-artwork detail |
| PDF | RGB text/image/shape preview; physical page size; CJK fallback; explicit preflight | No ICC, CMYK, PDF/X, spot plates, manufacturing tabs or tolerances |
| Transactions | Server-calculated sample estimates; idempotent estimate records | No payment, delivery commitment, factory order, invoicing or logistics |
| Other services | Honest disabled state / heuristic demo labels | No real SMS, OAuth, membership, GLB/DXF upload, team roles or AI generation |

## 5. 数据与迁移

`runtime/catalog.json` is sample metadata. `src/data.js` retains the matching sample metadata for detail/editor entry points. Importing a full new catalog requires updating the data integration layer; it is not an asset sync system.

Database files are created locally and are not shipped. v4 adds a design version column when missing and revokes old v3 sessions on the one-time auth-version migration. Back up an old database using SQLite's backup API before trying it with this version. Start with a fresh test database; do not point this build at a production database.

v3 browser localStorage keys are left untouched; they are not automatically imported. v4 browser drafts are per-account. On cloud version conflict, the local draft remains and the API returns 409 rather than overwriting someone else's version.

The plain Python launcher reads exported environment variables; it does **not** automatically read `.env`. Docker Compose does. Do not commit or send real `.env`, OAuth secrets, SMS keys, database passwords or production cookies.

See `API_INTEGRATION.md` for endpoint contracts and `PRODUCTION_STATUS.md` for release blockers.
