# v5 API 变更

## GET /api/templates

支持 q, page, page_size(1-100), sort(all/new/popular/uses/price_asc/price_desc)。
筛选：type, model(编号或子类), industry, style, use, material, channel, price(all/free/member_free/paid)。
未知价格为 null，不计入免费结果；价格排序将未知值放最后。
更新时间优先用 created_at，缺失时用 ID 稳定排序，这不能证明原站排序一致。

## GET /api/models

支持 q, page, page_size, sort(all/new/popular/uses), type, model, material, printable。

## GET /api/catalog/meta

返回实际数据条数、分类、数据范围、封面字段统计、付款状态。元数据标志不是资产真实性或商用授权证明。

## GET /api/readiness

当前返回 production_ready=false, parity_verified=false 和阻断项。
`tools/check_release.py` 在上线条件未满足时以 exit code 2 结束。

## 模板资源字段

```json
{"price":null,"member_price":null,"currency":"CNY","author":null,
 "thumbnail":null,"gallery":[],"channels":[],"created_at":null}
```

作者格式为 `{"name":"...","official":false}`。资源路径必须是 `/assets/media/...` 下的 PNG/JPEG/WebP/SVG，空值显示缺失状态。
模型另有 `dieline_thumbnail`。此字段是缩略图，不是可生产的刀版数据。

登录、设计保存、估价与预览导出的既有合约见 `docs/history/V4_API_INTEGRATION.md`。设计画布 zoom 最小值现为 0.08，用于窄视口的自适应。
