# Production status - v4

**NOT production-ready. NOT a 1:1 recreation.**

Verified: 44 API/tool regression cases, JavaScript parse check, local development smoke flow, 26 offline Chromium interaction checks using the actual local API and software Canvas renderer. Evidence is bundled.

Not verified: original live site's rendered page/pixel match, native browser navigation/cookie behavior in a normal deployment, GPU WebGL output, OS/browser matrix, Docker build, TLS, real production load or external services.

## Release blockers

- Original assets and complete catalog absent (20 template/12 model samples only).
- Only one six-face visualization primitive; no manufacturing carton engine, proper tabs/allowances, actual GLB/DXF/folding pipeline.
- No ICC/CMYK/PDF-X, separations, spot colors, print validation or factory proof signoff. RGB PDFs are previews.
- No real SMS/WeChat OAuth, paid membership, payment callbacks, invoicing, logistics or production orders.
- No cloud render workers, photorealistic material/scene parity, private team storage/roles, real AI generation.
- No production traffic, security certification, recovery or HA validation.

## Important corrections to earlier claims

The old visual diff could report 0% for opaque white versus black images because of an RGBA alpha-channel bounding-box error. v4 compares RGB and tests the white/black fixture (100% different). This does not establish any original-site similarity percentage.

The original browser visits were blocked by the execution environment. Error/loading pages are invalid references and are now marked UNVERIFIED. No pixel-parity score has been produced for this site.

The old backend accepted arbitrary SMS codes in production, served root files, accepted a client-chosen order total, claimed success for nonexistent design updates, and fabricated completed cloud render jobs with placeholder SVGs. These are findings about the rebuild, not the original website. Corresponding behaviors are fixed or explicitly unavailable in v4.

v4's software preview is a real six-face projection of the artwork atlas, not a CSS placeholder. It is nevertheless only a tessellated display preview; it is not a GPU or cloud-rendering quality claim. GPU WebGL remains to be tested on an enabled device.
