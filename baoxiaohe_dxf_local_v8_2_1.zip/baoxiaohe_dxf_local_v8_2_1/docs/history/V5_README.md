# 包小盒重建 v5：功能与界面差异修正

**目标是原站 1:1 生产级重建；当前交付未达到该验收标准。**
本版是已修改、可本地运行的开发验收工程，不是原站源码或完成版。
无需上传私有源码、Cookie、.env、数据库、密钥。不会发短信、扣费或下单生产。

## 安装与启动

Python 3.11+；本轮使用 Python 3.13。Node 仅用于 JavaScript 语法检查。

```bash
cd baoxiaohe_rebuild_v5
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

打开 `http://127.0.0.1:8088/templates`。Windows 使用 `.venv\Scripts\activate` 激活，并将 python3 改为 python。
服务默认仅监听本机，请勿将开发登录模式暴露到公网。
登录页会生成一次性六位测试码，不发真实短信。生产模式下短信未接通时返回 503。

### PDF 预览依赖

需要 Cairo、fontconfig 和本机中文字体。ZIP 不包含字体文件。

```bash
# Debian / Ubuntu
sudo apt-get install libcairo2 fontconfig fonts-noto-cjk
# macOS
brew install cairo fontconfig
```

macOS 还需自行从官方或系统软件包安装 Noto Sans CJK SC。可用 `fc-match "Noto Sans CJK SC"` 检查，或将现有中文字体名称设为 `PDF_CJK_FONT`。macOS/Windows 未在本环境做端到端测试。

## 本版修改

- 模板目录增加模型、材质、渠道、价格筛选合约；连动筛选、已选条件、清空、分页跳转、每页条数。
- 价格和会员价分开建模；未知价格不等于免费，未知作者不等于官方。
- 详情、编辑、渲染深链接从后端取资源，不再仅依赖前端写死的 ID。
- 封面、图库、刀版缩略图字段支持本地资源路径，本包未同步原站素材。
- 保留模型详情的通用 3D/2D 预览，明确标明不是真实盒型与生产刀版。
- 编辑器默认适应画布，Ctrl/Cmd+0 重置，支持空格拖动平移；修复自适应导致的高度收缩。
- 修复软件 WebM 录制偶发空帧，显式提交画布帧并验证有效输出。
- 手机导航、焦点样式、卡片非法嵌套交互、详情独立标题、无效 ID 返回 HTTP 404。
- 增加 `/api/readiness` 和发布检查脚本；当前结果为 `BLOCKED`。

## 测试

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest tests -q
npm run check
# 服务启动后
python3 tests/smoke_api.py
python3 tools/check_release.py --output release-check.json
```

发布检查当前应返回 exit code 2，表示生产与 1:1 验收存在阻断项，不是脚本损坏。

本轮 API/工具测试 77 项通过，新增离线 Chromium 交互测试 19 项通过。原 26 项离线浏览器基线回归也已在 v5 重新通过，两组测试覆盖有重叠，不能解读为 45 项不同产品能力。详细记录在 `evidence/`。

```bash
# Chromium 已安装后；请使用独立测试数据库
CHROMIUM_PATH=/usr/bin/chromium AUDIT_OUTPUT=offline-audit python3 tools/audit_v5_browser.py
```

离线测试将本项目代码注入 about:blank，适配 history/localStorage/fetch，调用真实本地 API；不是原生浏览器端到端测试，不访问原站，不绕过网络限制。
测试会创建本地临时账户、设计与估价记录，不要对生产数据库运行。

## 你本机的原站视觉基线

```bash
python3 tools/visual_regression.py \
  --reference https://www.baoxiaohe.com \
  --candidate http://127.0.0.1:8088 \
  --routes /templates /models /templates/25987 /models/74 \
  --viewport 1440x1100 --output visual-report
```

截图与报告仅保存在本机，不要上传私有信息。页面被阻止或只有 Loading 时标为 UNVERIFIED。
像素差异不是功能完成率，也不能证明生产能力。

## 数据与部署限制

`runtime/catalog.json` 仍为 20 模板 / 12 模型样本，无原图、无原始刀版、无原设计图层。
可用 `BAOXIAOHE_CATALOG=/absolute/path/catalog.json` 指定本机目录数据，但这不是原站全量同步或素材导入系统。
本版不会自动抓取原站私有 API。图片字段只接受 `/assets/media/` 下的本地路径，不分发字体文件。
SQLite 数据库不随包分发，使用 `BAOXIAOHE_DB` 指定测试数据库。Python 启动器不会自动读取 .env，请用环境变量。
Docker、TLS、压测、灾复、完整安全审计、GPU 路径均未完成正式验收。查看 `PRODUCTION_STATUS.md` 与 `AUDIT_V5.html`。
