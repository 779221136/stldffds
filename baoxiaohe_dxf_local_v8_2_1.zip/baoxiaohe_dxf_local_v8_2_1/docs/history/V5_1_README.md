# 包小盒重建工程 v5.1：图层拖拽排序更新

本版基于你提供的 v5 ZIP 修改，不连接原站私有服务，不需要原站源码或密钥。
**这是图层排序功能更新，不是全站 1:1 生产验收完成版。**

## 本次功能

- 右侧图层列表支持手柄拖动；鼠标也可拖动图层名称。
- 插入线、浮动卡片、选中状态、形状颜色缩略图、长列表边缘自动滚动。
- 列表顶部对应画布最前面；置顶、置底、上移、下移使用同一套排序数据。
- 一次放下对应一次撤销；Esc、拖出列表放下或触控取消不改变层级。
- 排序保存到设计稿，重新打开仍保持；2D、共享贴图和 PNG 画面使用相同层级。
- 已锁定的图层需先解锁再排序；隐藏图层可排序且保持隐藏。

## 启动

```bash
cd baoxiaohe_rebuild_v5_1
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

Open `http://127.0.0.1:8088/design/template/25987`.
Windows: `.venv\Scripts\activate`, then use `python` instead of `python3`.

Python 3.11+ is recommended. Node is only needed for JavaScript checks/tests, not runtime.
The default server binds to loopback. Development authentication returns a local test code; it does not send SMS.
Do not expose development authentication to the public Internet.

## 怎么用

在编辑器右侧“图层”中，按住名称左边的六点手柄，上下拖动到蓝色插入线后松手。
越靠上的图层越靠前。拖动只改变叠放顺序，不改变元素坐标、尺寸或旋转角度。

Keyboard: focus a drag handle with Tab, then use ArrowUp/ArrowDown or Home/End.
Alt+ArrowUp/ArrowDown/Home/End also work while focused on a row button.
Ctrl/Cmd+Z undoes a completed move; Ctrl/Cmd+Shift+Z redoes it. Esc cancels a pending pointer drag.
On touchscreens, drag the handle; swipe the name area to scroll the list normally.
The existing mobile editor layout limitations remain; touch input was emulated on the desktop layout, not validated on physical mobile devices.

## 测试

```bash
python3 -m pip install -r requirements-dev.txt
npm run check
npm run test:layers
python3 -m pytest tests -q
# Start the development server with a throwaway database before browser tests:
# BAOXIAOHE_DB=/tmp/bxh-test.sqlite python3 server.py
CHROMIUM_PATH=/usr/bin/chromium npm run test:layers:browser
python3 tests/smoke_api.py
```

Actual results: **10 layer-order unit tests, 20 focused offline browser checks, 77 Python regressions**, JavaScript syntax check and development smoke passed.
One existing Pillow deprecation warning remains. The additional inherited all-feature browser baseline run was interrupted in its mobile section after 23 completed checks; it is not counted as fully passed.
The focused browser tests use the authored offline harness with actual local API calls because native browser URL navigation is blocked in this environment. GPU WebGL, Safari/Firefox, physical touchscreens, production load and original-site pixel parity are not verified.
See `evidence/layers-v5.1/TEST_SUMMARY.json` and `AUDIT_LAYERS.html`.

## 升级与兼容

The design schema is unchanged: `payload.objects` is ordered bottom-to-top. Old v5 designs load without conversion. No database migration is introduced by this update. Use a backup and a separate test database before trying existing data.
Do not overwrite your local `.env`, databases, assets or deployment secrets. If you have local source modifications, merge the updated files rather than blindly overwriting them.
No third-party drag-and-drop library, CDN request or telemetry is added. This update does not connect to baoxiaohe.com private APIs.

## 未改变的生产限制

Sample catalog and schematic models, a six-face box rather than the full carton engine, RGB preview PDF rather than print-ready PDF, and unavailable real SMS/OAuth/payment/cloud-rendering services remain unchanged. Read `PRODUCTION_STATUS.md`.
For existing PDF previews, install native Cairo, fontconfig and an approved local CJK font as described in `docs/history/V5_README.md`. No font files are redistributed in this project.
