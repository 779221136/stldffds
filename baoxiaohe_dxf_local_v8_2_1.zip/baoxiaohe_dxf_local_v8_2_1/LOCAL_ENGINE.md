# Architecture of the local geometry / animation / output chain

Browser -> POST /api/local/structure -> canonical `local-carton/1` JSON ->
2D net + hierarchical browser poses -> POST /api/local/jobs -> local worker
-> PNG / frames ZIP / MP4 / WebM -> private loopback download.

`app/structure.py` is the structure source of truth. All polygon coordinates
are flat sheet millimetres. Every non-root panel declares a parent, a shared
hinge segment, closed angle, folding interval, opening delta and release
interval. Forward kinematics multiplies the parent's transform by a rotation
about that segment. Staged smoothstep intervals change angles, not face sizes.

The printed face orientation follows flat-sheet coordinates. SVG/DXF use the
same polygon union contour as the preview, not a second guessed net. ezdxf writes R2010 DXF with explicit mm units and the export is round-trip audited. Shapely
unions the panels, checks flat area overlap, and creates an actual outline
offset for the bleed guide. A crease edge is NOT exported as a cut edge.

`src/structure_math.js` mirrors the transforms. A regression compares all 13
panel positions at 12 Python/JS poses to tolerance 1e-7 mm. Other tests check
hinge endpoints, rigid panel lengths, closed extents and lid-only opening.
The CPU and browser triangle meshes include visual extrusion and explicit
inset/outset of flaps to avoid z-fighting; hinge/reference geometry remains
idealised. These offsets are NOT physical fit or crease compensation.

`src/structure_studio.js` keeps the new local project separate from old editor
objects. Editor artwork is cropped per legacy face into embedded PNG textures.
The original object file is not rewritten. Editable vector transfer back from
this studio is NOT implemented. Project import validates dimensions, finite
camera values, known panels, embedded raster formats, total image bytes and
pixel count. Remote image URLs, executable scripts and filesystem paths are
not accepted as artwork.

`app/local_raster.py` generates textured front/back/edge triangles, rotates the
camera, performs orthographic projection and depth-buffer rasterisation in
64-row blocks. Material appearance is simple diffuse shading. It does not use
Blender or any cloud API. Output resolution is limited independently from
texture resolution. A high pixel count is not a photorealism claim.

`app/local_jobs.py` owns a single-worker queue. An opaque local cookie scopes
jobs; no production or SMS identity is assumed. SQLite transactions claim work;
worker subprocesses have a wall-time limit. Pending input and intermediate
frames are removed after execution. Restart explicitly fails interrupted
running work. Download/cancel/delete all enforce the same owner. There is no
outbound URL fetch, user-supplied executable command, or public runtime mount.

`app/local_worker.py` exports single images or renders deterministic frame
sequences. PNG sequence archives contain frames and fps metadata. MP4/WebM
encoding uses a local FFmpeg executable with fixed arguments and no shell.
Current opaque codec formats: H.264/yuv420p and VP9/yuv420p. Alpha video is not
implemented; transparent PNG sequence output is the supported alternative.
