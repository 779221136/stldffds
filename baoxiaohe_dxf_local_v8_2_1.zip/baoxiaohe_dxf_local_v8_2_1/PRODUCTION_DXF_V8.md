# DXF v8 production acceptance status

Overall release: **BLOCKED for unrestricted manufacturing / original-site 1:1 parity**.

The new local CAD import, library, artwork integration and hinge-preview workflow is implemented and tested within declared limits. It supersedes previous notes that no DXF import exists. It does not supersede other existing production blockers.

Open blockers: representative real factory DXF corpus, unsupported entity/assembly types, independent constrained L/W/H reconstruction, calibrated material/fold allowances, collision and self-locking assemblies, production PDF/ICC, external-service features already absent from the base, native browser E2E, GPU verification, Docker build and load/backup-recovery certification. The cloud model library and new render/parse operations run on the user's deployment host instead; this is not a claim that unrelated AI/payment/OAuth features were replaced.

See README_DXF_V8.md for exact limits and evidence scope.
