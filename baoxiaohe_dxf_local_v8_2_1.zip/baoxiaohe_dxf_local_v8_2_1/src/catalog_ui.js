import {api} from './api.js';
import {categories} from './data.js';
import {catalogState,rememberItems} from './catalog_client.js';

const ALL='\u5168\u90e8';
const labels={type:'\u7c7b\u578b',model:'\u6a21\u578b',industry:'\u884c\u4e1a',style:'\u98ce\u683c',material:'\u6750\u8d28',use:'\u7528\u9014',channel:'\u6e20\u9053',price:'\u4ef7\u683c',printable:'\u5370\u5237'};
const priceNames={all:ALL,free:'\u514d\u8d39',member_free:'\u4f1a\u5458\u514d\u8d39',paid:'\u4ed8\u8d39'};
const money=v=>new Intl.NumberFormat('zh-CN',{maximumFractionDigits:2}).format(v);
const priced=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
const safeAsset=v=>typeof v==='string'&&/^\/assets\/media\/[a-zA-Z0-9_./-]+\.(png|jpe?g|webp|svg)$/i.test(v)&&!v.split('/').includes('..')&&!v.includes('//');
export function priceMarkup(item,esc) {
  if(!priced(item.price))return '<span class="price-unknown">\u4ef7\u683c\u672a\u540c\u6b65</span>';
  return `<span class="catalog-price">\u00a5 ${money(item.price)}<small> \u8d77/\u6a21\u677f\u4ef7\u683c</small></span>${priced(item.member_price)?`<span class="member-price">\u4f1a\u5458\u4e13\u4eab \u00a5${money(item.member_price)}\u8d77</span>`:''}`;
}
export function mediaMarkup(item,ctx,view='3d') {
  const path=view==='2d'?item.dieline_thumbnail:item.thumbnail;
  if(safeAsset(path))return `<img class="catalog-image" src="${ctx.esc(path)}" alt="${ctx.esc(item.title)}" loading="lazy" decoding="async" data-catalog-image>`;
  if(view==='2d')return '<div class="asset-missing"><span aria-hidden="true">\u25a7</span><b>\u5200\u7248\u8d44\u6e90\u672a\u540c\u6b65</b><small>\u4e0d\u7528\u901a\u7528\u76d2\u4f53\u5192\u5145\u771f\u5b9e\u5200\u7248</small></div>';
  return ctx.visual(item);
}
export function templateMarkup(t,ctx) {
  const {esc,store}=ctx,author=t.author;
  const attribution=author?`<span class="official"><i>${esc((author.name||'?').slice(0,1))}</i>${esc(author.name)}${author.official===true?'<em>\u5b98\u65b9</em>':''}</span>`:'<span class="unknown-author">\u4f5c\u8005\u672a\u540c\u6b65</span>';
  return `<article class="item-card v5-item" data-item-id="${t.id}"><div class="card-visual"><a class="card-cover-link" data-link href="/templates/${t.id}" aria-label="${esc(t.title)}">${mediaMarkup(t,ctx)}</a>${t.price===0?'<span class="badge free">\u514d\u8d39</span>':''}<div class="hover-ops"><button data-render-template="${t.id}">\u53bb\u6e32\u67d3</button><button data-design-template="${t.id}" class="primary">\u7f16\u8f91\u6a21\u677f</button></div></div><div class="card-body"><a data-link href="/templates/${t.id}" class="card-title" title="${esc(t.title)}">${esc(t.title)}</a><div class="template-pricing">${priceMarkup(t,esc)}</div><div class="card-meta">${attribution}<button class="fav ${store.isFavorite('templates',t.id)?'on':''}" aria-label="\u6536\u85cf ${esc(t.title)}" aria-pressed="${store.isFavorite('templates',t.id)}" data-fav="templates:${t.id}">\u2661</button></div></div></article>`;
}
export function modelMarkup(m,ctx,view='3d') {
  return `<article class="item-card model-card v5-item" data-item-id="${m.id}"><div class="card-visual"><a class="card-cover-link" data-link href="/models/${m.id}" aria-label="${ctx.esc(m.title)}">${mediaMarkup(m,ctx,view)}</a><span class="model-size-label">${ctx.esc(m.sizes)}</span><div class="hover-ops"><button data-render-model="${m.id}">\u53bb\u6e32\u67d3</button><button data-design-model="${m.id}" class="primary">\u521b\u5efa\u8bbe\u8ba1</button></div></div><div class="card-body"><a data-link href="/models/${m.id}" class="card-title">${ctx.esc(m.title)}</a><div class="model-sub"><b>${ctx.esc(m.code)}</b><span>${ctx.esc(m.sub||m.type)}</span></div><div class="chips mini">${(m.materials||[]).map(x=>`<span>${ctx.esc(x)}</span>`).join('')}</div></div></article>`;
}
export function bindMedia(root=document) {
  root.querySelectorAll('[data-catalog-image]').forEach(img=>{
    const failed=()=>{const el=document.createElement('div');el.className='asset-missing';el.textContent='\u56fe\u7247\u52a0\u8f7d\u5931\u8d25';img.replaceWith(el);};
    img.addEventListener('error',failed,{once:true});if(img.complete&&!img.naturalWidth)failed();
  });
}
export function mountCatalog(kind,ctx) {
  const {esc,shell,bindCards,dispose}=ctx,isTemplate=kind==='templates',query=new URLSearchParams(location.search);
  const keys=isTemplate?['type','model','industry','style','material','use','channel','price']:['type','model','material','printable'];
  const pageSize=Number(query.get('page_size'));
  const state={q:query.get('q')||'',page:Math.max(1,Number(query.get('page'))||1),page_size:[10,20,40,60].includes(pageSize)?pageSize:10,sort:['all','new','popular','uses','price_asc','price_desc'].includes(query.get('sort'))?query.get('sort'):'all',view:query.get('view')==='2d'?'2d':'3d'};
  for(const k of keys)state[k]=query.get(k)||ALL;
  if(state.price==='all')state.price=ALL;
  if(!isTemplate&&state.sort.startsWith('price_'))state.sort='all';
  let active=true,epoch=0,current=[],abort=null,advanced=false;
  dispose(()=>{active=false;epoch++;abort?.abort();});
  shell(`<section class="catalog-head v5-catalog-head"><div class="page-width"><div class="catalog-title"><h1>${isTemplate?'\u6a21\u677f\u4e2d\u5fc3':'\u76d2\u578b/\u6a21\u578b\u5e93'}</h1><form class="catalog-search" id="catalogForm" role="search"><input id="catalogQuery" value="${esc(state.q)}" placeholder="\u641c\u7d22\u6a21\u677f\u3001\u76d2\u578b\u6216\u7f16\u53f7" aria-label="\u641c\u7d22\u76ee\u5f55"><button id="catalogSearch" class="btn primary">\u641c\u7d22</button></form></div><div class="catalog-scope" role="note">\u672c\u5730\u9a8c\u6536\u7248\u00b7\u5f53\u524d\u4e3a\u6837\u672c\u6570\u636e\uff1b\u539f\u56fe\u3001\u4ef7\u683c\u4e0e\u6388\u6743\u5c1a\u672a\u540c\u6b65</div><div id="filters" class="filter-box catalog-filter-compact"></div><button id="toggleAdvanced" class="filter-toggle" aria-expanded="false" aria-controls="filters">\u66f4\u591a\u7b5b\u9009</button><div id="selectedFilters" class="selected-filters" aria-label="\u5df2\u9009\u6761\u4ef6"></div></div></section><section class="page-width results"><div class="results-top"><div class="sort-tabs" role="group" aria-label="\u6392\u5e8f"><button data-sort="all">\u7efc\u5408\u6392\u5e8f</button><button data-sort="new">\u6700\u65b0\u53d1\u5e03</button><button data-sort="uses">\u6700\u591a\u4f7f\u7528</button><button data-sort="popular">\u6d4f\u89c8\u70ed\u5ea6</button></div><div class="catalog-tools">${!isTemplate?'<div class="catalog-view" role="group" aria-label="\u5217\u8868\u89c6\u56fe"><button data-view="3d">3D</button><button data-view="2d">2D</button></div>':''}<label class="page-size-label"><select id="pageSize" aria-label="\u6bcf\u9875\u6761\u6570">${[10,20,40,60].map(n=>`<option value="${n}" ${n===state.page_size?'selected':''}>${n}\u6761/\u9875</option>`).join('')}</select></label><span id="count" class="count" role="status"></span></div></div><div id="catalogGrid" class="cards-grid five" aria-live="polite"></div><nav id="catalogPager" class="pager" aria-label="\u5206\u9875"></nav></section>`);
  const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
  const groups=categories.modelGroups||{};
  const modelOptions=()=> (catalogState.meta?.model_options?.[kind]||[]).filter(o=>state.type===ALL||o.types.includes(state.type));
  const modelValues=()=>[ALL,...modelOptions().map(o=>o.value),...(state.model!==ALL?[state.model]:[])].filter((v,i,a)=>a.indexOf(v)===i);
  const options=k=>({type:isTemplate?categories.templateTypes:categories.modelTypes,model:modelValues(),industry:categories.industries,style:categories.styles,material:categories.materials,use:categories.uses,channel:categories.channels,price:[ALL,'free','member_free'],printable:[ALL,'true','false']}[k]||[ALL]);
  const display=(k,v)=>k==='model'&&v!==ALL?`${modelOptions().find(o=>o.value===v)?.label||v}${modelOptions().find(o=>o.value===v)?.unclassified?' (\u7c7b\u522b\u672a\u540c\u6b65)':''}`:k==='price'?(priceNames[v]||v):k==='printable'?(v==='true'?'\u53ef\u5370\u5237':v==='false'?'\u4e0d\u53ef\u5370\u5237':v):v;
  function filters() {
    $('#filters').innerHTML=keys.map(k=>`<div class="filter-row ${keys.indexOf(k)>=3?'advanced-filter':''}" ${keys.indexOf(k)>=3&&!advanced?'hidden':''}><span>${labels[k]}:</span><div>${options(k).map(v=>`<button data-filter="${k}|${esc(v)}" class="${state[k]===v?'active':''}" aria-pressed="${state[k]===v}">${esc(display(k,v))}</button>`).join('')}${options(k).length===1?'<small class="filter-unavailable">\u7c7b\u522b\u6570\u636e\u672a\u540c\u6b65</small>':''}</div></div>`).join('');
    const selected=keys.filter(k=>state[k]!==ALL);
    $('#selectedFilters').innerHTML=(state.q?`<button data-clear-q>\u641c\u7d22: ${esc(state.q)} \u00d7</button>`:'')+selected.map(k=>`<button data-clear="${k}">${labels[k]}: ${esc(display(k,state[k]))} \u00d7</button>`).join('')+(selected.length||state.q?'<button class="clear-all" id="clearFilters">\u6e05\u7a7a\u7b5b\u9009</button>':'');
    $$('[data-filter]').forEach(b=>b.onclick=()=>{const [k,v]=b.dataset.filter.split('|');state[k]=v;if(k==='type')state.model=ALL;state.page=1;draw(true);});
    $$('[data-clear]').forEach(b=>b.onclick=()=>{state[b.dataset.clear]=ALL;if(b.dataset.clear==='type')state.model=ALL;state.page=1;draw(true);});
    const reset=$('#clearFilters');if(reset)reset.onclick=()=>{for(const k of keys)state[k]=ALL;state.q='';$('#catalogQuery').value='';state.page=1;draw(true);};
    const cq=$('[data-clear-q]');if(cq)cq.onclick=()=>{state.q='';$('#catalogQuery').value='';state.page=1;draw(true);};
    $$('[data-sort]').forEach(b=>{const on=b.dataset.sort===state.sort;const available=catalogState.meta?.available_sorts?.[kind];b.disabled=!!available&&!available.includes(b.dataset.sort);b.title=b.disabled?'\u5f53\u524d\u6570\u636e\u672a\u63d0\u4f9b\u5bf9\u5e94\u6392\u5e8f\u6307\u6807':'';b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
    $$('[data-view]').forEach(b=>{const on=b.dataset.view===state.view;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
  }
  function parameters(){const p={page:state.page,page_size:state.page_size,sort:state.sort};if(state.q)p.q=state.q;for(const k of keys)if(state[k]!==ALL)p[k]=state[k];return p;}
  function url(push=false){const p=new URLSearchParams(parameters());if(!isTemplate)p.set('view',state.view);const target=`/${kind}?${p}`;if(push&&location.pathname+location.search!==target)history.pushState({},'',target);else history.replaceState({},'',target);}
  function cards(){const grid=$('#catalogGrid');grid.innerHTML=current.length?current.map(x=>isTemplate?templateMarkup(x,ctx):modelMarkup(x,ctx,state.view)).join(''):'<div class="catalog-empty"><h3>\u6ca1\u6709\u5339\u914d\u7ed3\u679c</h3><p>\u672a\u540c\u6b65\u7684\u4ef7\u683c\u4e0d\u4f1a\u88ab\u5f53\u6210\u514d\u8d39\uff0c\u8bf7\u8c03\u6574\u7b5b\u9009\u3002</p></div>';bindCards();bindMedia(grid);}
  function pager(result) {
    const set=new Set([1,result.pages]);for(let p=Math.max(1,result.page-2);p<=Math.min(result.pages,result.page+2);p++)set.add(p);
    let prev=0;const pages=[...set].sort((a,b)=>a-b).map(p=>{const gap=p-prev>1?'<span class="pager-gap">\u2026</span>':'';prev=p;return gap+`<button data-page="${p}" class="${p===result.page?'active':''}" ${p===result.page?'aria-current="page"':''}>${p}</button>`;}).join('');
    $('#catalogPager').innerHTML=`<button data-page="${result.page-1}" ${result.page===1?'disabled':''}>\u4e0a\u4e00\u9875</button>${pages}<button data-page="${result.page+1}" ${result.page===result.pages?'disabled':''}>\u4e0b\u4e00\u9875</button><form id="jumpForm"><label>\u8df3\u81f3 <input id="jumpPage" type="number" min="1" max="${result.pages}" value="${result.page}" aria-label="\u9875\u7801"></label><button>\u786e\u5b9a</button></form>`;
    $$('[data-page]').forEach(b=>b.onclick=()=>{state.page=+b.dataset.page;draw(true);});
    $('#jumpForm').onsubmit=e=>{e.preventDefault();const value=Number($('#jumpPage').value);if(!Number.isInteger(value)||value<1||value>result.pages)return;state.page=value;draw(true);};
  }
  async function draw(push=false) {
    const requestEpoch=++epoch;filters();url(push);$('#catalogGrid').setAttribute('aria-busy','true');$('#count').textContent='\u52a0\u8f7d\u4e2d\u2026';$('#catalogPager').innerHTML='';
    $('#catalogGrid').innerHTML=Array.from({length:Math.min(state.page_size,10)},()=>'<div class="catalog-skeleton" aria-hidden="true"><div></div><i></i><i></i></div>').join('');
    try {
      const result=await api[kind](parameters());if(!active||requestEpoch!==epoch)return;
      state.page=result.page;current=result.items;rememberItems(kind,result.items);url(false);cards();pager(result);
      $('#count').textContent=`${result.total}\u6761 \u00b7 ${result.page}/${result.pages}\u9875`;
    }catch(error){if(!active||requestEpoch!==epoch)return;$('#catalogGrid').innerHTML=`<div class="catalog-empty"><p>\u52a0\u8f7d\u5931\u8d25: ${esc(error.message)}</p><button id="retryCatalog" class="btn ghost">\u91cd\u8bd5</button></div>`;$('#count').textContent='\u52a0\u8f7d\u5931\u8d25';$('#retryCatalog').onclick=()=>draw(false);}
    finally{if(active&&requestEpoch===epoch)$('#catalogGrid').setAttribute('aria-busy','false');}
  }
  $('#toggleAdvanced').onclick=()=>{advanced=!advanced;$('#toggleAdvanced').setAttribute('aria-expanded',String(advanced));$('#toggleAdvanced').textContent=advanced?'\u6536\u8d77\u7b5b\u9009':'\u66f4\u591a\u7b5b\u9009';filters();};
  if(keys.length<=3)$('#toggleAdvanced').hidden=true;
  $('#catalogForm').onsubmit=e=>{e.preventDefault();state.q=$('#catalogQuery').value.trim();state.page=1;draw(true);};
  $('#pageSize').onchange=e=>{state.page_size=+e.target.value;state.page=1;draw(true);};
  $$('[data-sort]').forEach(b=>b.onclick=()=>{state.sort=b.dataset.sort;state.page=1;draw(true);});
  $$('[data-view]').forEach(b=>b.onclick=()=>{state.view=b.dataset.view;filters();url(true);if($('#catalogGrid').getAttribute('aria-busy')!=='true')cards();});
  draw(false);
}
