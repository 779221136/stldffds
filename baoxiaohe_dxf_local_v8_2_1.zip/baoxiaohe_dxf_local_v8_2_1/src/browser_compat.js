/** Shared capability-based compatibility. No user-agent sniffing or external services. */
export function isComposingEvent(event) {
  return !!(event?.isComposing || event?.keyCode === 229);
}
export function isEditableTarget(target) {
  return !!(target && (['INPUT','TEXTAREA','SELECT'].includes(target.tagName) || target.isContentEditable || target.closest?.('[role="textbox"]')));
}
export function hasBlockingDialog(doc = globalThis.document) {
  if (!doc?.querySelectorAll) return false;
  return [...doc.querySelectorAll('.cad-modal-backdrop,.app-modal-backdrop,[role="dialog"][aria-modal="true"],dialog[open]')]
    .some(el => !el.hidden && !el.closest?.('[hidden],[aria-hidden="true"]') && (!el.getClientRects || el.getClientRects().length > 0));
}
export function blockEditorShortcut(event, doc = globalThis.document) {
  return !!(event.defaultPrevented || isComposingEvent(event) || hasBlockingDialog(doc) ||
    isEditableTarget(event.target) || isEditableTarget(doc?.activeElement));
}
/** Keep native text editing and button activation INSIDE a modal. */
export function modalKeydown(event, wrap, close) {
  event.stopPropagation();
  if (isComposingEvent(event)) return;
  if (event.key === 'Escape') { event.preventDefault(); close(); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault(); return; // No nested save dialogs or browser Save Page.
  }
  if (event.key !== 'Tab') return;
  const items = [...wrap.querySelectorAll('button,input,select,textarea,a[href],[tabindex]')]
    .filter(el => !el.disabled && el.tabIndex >= 0 && !el.closest('[hidden],[inert]') && el.getClientRects().length);
  const first = items[0], last = items[items.length - 1], active = wrap.ownerDocument.activeElement;
  if (!first) { event.preventDefault(); return; }
  if (event.shiftKey && (active === first || !items.includes(active))) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && (active === last || !items.includes(active))) { event.preventDefault(); first.focus(); }
}
/** Convert pixel/line/page deltas before applying the existing zoom sensitivity. */
export function wheelPixels(event, {lineHeight = 16, pageHeight = 800, limit = 240} = {}) {
  // Read mode FIRST: Firefox may adjust returned units when deltaMode is accessed.
  const mode = event.deltaMode, raw = Number(event.deltaY);
  if (!Number.isFinite(raw)) return 0;
  const line = Number.isFinite(lineHeight) && lineHeight > 0 ? lineHeight : 16;
  const page = Number.isFinite(pageHeight) && pageHeight > 0 ? pageHeight : 800;
  const pixels = raw * (mode === 1 ? line : mode === 2 ? page : 1);
  return Math.max(-limit, Math.min(limit, pixels));
}
export function wheelDelta(event, element) {
  let lineHeight = 16;
  try { const n = parseFloat(getComputedStyle(element).lineHeight); if (n > 0) lineHeight = n; } catch {}
  return wheelPixels(event, {lineHeight, pageHeight: element?.clientHeight || 800});
}
const VIDEO_TYPES = ['video/webm;codecs=vp8','video/webm;codecs=vp9','video/webm',
  'video/mp4;codecs=avc1.42E01E','video/mp4;codecs=avc1.424028','video/mp4'];
export function createVideoRecorder(stream, options = {}, Recorder = globalThis.MediaRecorder) {
  const error = () => new Error('\u5f53\u524d\u6d4f\u89c8\u5668\u65e0\u6cd5\u5f55\u5236 WebM/MP4\uff0c\u8bf7\u4f7f\u7528\u5200\u7248\u5de5\u4f5c\u53f0\u7684\u672c\u5730\u540e\u53f0\u89c6\u9891\u6216\u5e27\u5e8f\u5217\u5bfc\u51fa\u3002');
  if (typeof Recorder !== 'function' || typeof Recorder.isTypeSupported !== 'function') throw error();
  for (const mimeType of VIDEO_TYPES) {
    try {
      if (Recorder.isTypeSupported(mimeType)) return new Recorder(stream, {...options, mimeType});
    } catch { /* Some engines advertise a codec whose encoder is unavailable. Try the next. */ }
  }
  throw error();
}
export function videoExtension(blob) {
  const type = String(blob?.type || '').toLowerCase().split(';')[0].trim();
  if (type === 'video/webm') return 'webm';
  if (type === 'video/mp4') return 'mp4';
  throw new Error('Unsupported recorded video container: ' + type);
}
export function recordedVideo(parts, recorder) {
  // Preserve the encoder's ACTUAL container, never relabel MP4 as WebM.
  const type = parts.find(p => p.size && p.type)?.type || recorder.mimeType;
  const blob = new Blob(parts, {type});
  videoExtension(blob); // Reject unexpected/unknown containers rather than mislabel them.
  return blob;
}
export function rasterMime(bytes) {
  const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (b.length >= 8 && [137,80,78,71,13,10,26,10].every((v,i) => b[i] === v)) return 'image/png';
  if (b.length >= 3 && b[0] === 255 && b[1] === 216 && b[2] === 255) return 'image/jpeg';
  return null;
}
