/** Local preview rasterisation with real per-pixel depth, including intersecting
 * triangles. Same orthographic UV and lighting rules as app/local_raster.py.
 * No GPU, network or DOM needed; callers cache decoded texture ImageData.
 */
const rgb=color=>[1,3,5].map(i=>parseInt(color.slice(i,i+2),16));
const channel=x=>Math.max(0,Math.min(255,Math.floor(x)));
export function rasterizeProjected(projected,width,height,view,appearance={},textures=new Map()){
  if(!Number.isInteger(width)||!Number.isInteger(height)||Math.min(width,height)<1||Math.max(width,height)>4096)throw Error('Invalid software preview size');
  const pixels=new Uint8ClampedArray(width*height*4),depth=new Float64Array(width*height);depth.fill(-Infinity);
  const exterior=rgb(appearance.exterior||'#f9f5ef'),interior=rgb(appearance.interior||'#e8ddc9');
  if(!view.transparent){const bg=rgb(view.background||'#edf0f4');for(let k=0;k<pixels.length;k+=4){pixels[k]=bg[0];pixels[k+1]=bg[1];pixels[k+2]=bg[2];pixels[k+3]=255;}}
  const epsilon=Math.max(1e-9,projected.radius*1e-9);
  for(const t of projected.triangles){
    const [a,b,c]=t.screen,den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
    if(Math.abs(den)<1e-9)continue;
    const x0=Math.max(0,Math.floor(Math.min(a[0],b[0],c[0]))),x1=Math.min(width,Math.ceil(Math.max(a[0],b[0],c[0]))+1);
    const y0=Math.max(0,Math.floor(Math.min(a[1],b[1],c[1]))),y1=Math.min(height,Math.ceil(Math.max(a[1],b[1],c[1]))+1);
    const tex=t.side==='front'?textures.get(t.panel):null,base=t.side==='front'?exterior:interior,shade=t.shade*(t.side==='edge'?.88:1);
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const A=((b[1]-c[1])*(x+.5-c[0])+(c[0]-b[0])*(y+.5-c[1]))/den;
      const B=((c[1]-a[1])*(x+.5-c[0])+(a[0]-c[0])*(y+.5-c[1]))/den,C=1-A-B;
      if(A< -1e-7||B< -1e-7||C< -1e-7)continue;
      const z=A*t.q[0][2]+B*t.q[1][2]+C*t.q[2][2],index=y*width+x;
      if(z<=depth[index]+epsilon)continue;
      const dest=index*4;
      if(tex){
        const u=A*t.uv[0][0]+B*t.uv[1][0]+C*t.uv[2][0],v=A*t.uv[0][1]+B*t.uv[1][1]+C*t.uv[2][1];
        const tx=Math.max(0,Math.min(tex.width-1,Math.round(u*(tex.width-1)))),ty=Math.max(0,Math.min(tex.height-1,Math.round(v*(tex.height-1))));
        const src=(ty*tex.width+tx)*4,alpha=tex.data[src+3]/255;
        for(let k=0;k<3;k++)pixels[dest+k]=channel((tex.data[src+k]*alpha+base[k]*(1-alpha))*shade);
      }else for(let k=0;k<3;k++)pixels[dest+k]=channel(base[k]*shade);
      pixels[dest+3]=255;depth[index]=z;
    }
  }
  return pixels;
}
