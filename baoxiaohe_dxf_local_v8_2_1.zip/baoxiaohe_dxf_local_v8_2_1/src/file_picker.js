/** Open native file inputs synchronously from a user click/key, without networking.
 * This is deliberately NOT showOpenFilePicker (no HTTPS-only filesystem API).
 * Never bypass an activation/security denial or infer a user's local file path.
 */
export const IMAGE_ACCEPT = '.png,.jpg,.jpeg,.svg,image/png,image/jpeg,image/svg+xml';
export const RASTER_ACCEPT = '.png,.jpg,.jpeg,image/png,image/jpeg';
export function openFileInput(input, onError = () => {}) {
  try {
    if (!input || input.type !== 'file' || !input.isConnected || input.disabled) {
      throw new Error('\u6587\u4ef6\u9009\u62e9\u63a7\u4ef6\u672a\u5c31\u7eea\uff0c\u8bf7\u91cd\u65b0\u6253\u5f00\u5bfc\u5165\u9762\u677f\u3002');
    }
    const activation = input.ownerDocument?.defaultView?.navigator?.userActivation;
    if (activation && !activation.isActive) {
      throw new Error('\u8bf7\u76f4\u63a5\u70b9\u51fb\u201c\u9009\u62e9\u6587\u4ef6\u201d\u6216\u6309\u56de\u8f66\u91cd\u8bd5\uff1b\u6d4f\u89c8\u5668\u9700\u8981\u7528\u6237\u64cd\u4f5c\u624d\u80fd\u6253\u5f00\u6587\u4ef6\u7a97\u53e3\u3002');
    }
    // Reset before every attempt so choosing the same source file is a new selection.
    input.value = '';
    if (typeof input.showPicker === 'function') {
      try { input.showPicker(); return true; }
      catch (error) {
        if (error.name !== 'NotSupportedError') throw error;
        // Older implementations may expose showPicker but not implement file inputs.
      }
    }
    input.click(); // Synchronous, no await, Promise, timeout or synthetic activation.
    return true;
  } catch (error) {
    const suffix = error?.name === 'NotAllowedError' || error?.name === 'SecurityError'
      ? '\u6d4f\u89c8\u5668\u672a\u5141\u8bb8\u6253\u5f00\u6587\u4ef6\u7a97\u53e3\uff0c\u8bf7\u76f4\u63a5\u70b9\u51fb\u91cd\u8bd5\u6216\u68c0\u67e5\u6d4f\u89c8\u5668\u7b56\u7565\u3002'
      : error.message;
    onError(new Error(suffix));
    return false;
  }
}
/** Capture the File BEFORE any await, then clear even if decoding later fails.
 * An empty/cancel selection leaves the current design/model unchanged.
 */
export function takeSelectedFile(input) {
  const file = input?.files?.[0] || null;
  if (input) input.value = '';
  return file;
}
