export const NAV = [
  ['模板中心','/templates'],['盒型/模型库','/models'],['会员中心','/member'],['小批量印刷','/print'],['国际版','https://www.pacdora.com']
];

export const templates = [
  {id:25987,title:'香水礼盒天地盒包装设计',type:'精装盒',industry:'日常用品',style:['文艺','简洁','清新','扁平'],use:['外包装','销售包装'],material:'铜版纸',model:'360010',pro:false,shape:'gift',views:9835,c:['#eadfcd','#b8a181','#4b4138','#f7f2eb'],tags:['包装样机','化妆品','香水','简约风','纸盒']},
  {id:8900,title:'曲奇饼干纸盒包装设计',type:'纸盒',industry:'食品饮料',style:['休闲','文艺','简洁','卡通','清新','时尚','扁平'],use:['外包装'],material:'白卡纸',model:'103012',pro:true,shape:'box',views:8129,c:['#f1b15c','#d7663e','#fff7e9','#ffdca6'],tags:['烘焙曲奇','零食包装','创意饼干','纸盒']},
  {id:16835,title:'儿童玩具模型纸盒包装设计',type:'纸盒',industry:'日常用品',style:['休闲','简洁','卡通'],use:['外包装','存储包装','销售包装'],material:'白卡纸',model:'102010',pro:false,shape:'box',views:7762,c:['#79c9ea','#ffcf66','#173d59','#dff5ff'],tags:['母婴儿童','卡通风','儿童玩具','纸盒']},
  {id:14439,title:'中国白酒酒瓶包装设计',type:'瓶子',industry:'食品饮料',style:['休闲','简洁','传统','中国风','商务'],use:['外包装','销售包装'],material:'陶瓷',model:'500080',pro:false,shape:'bottle',views:13762,c:['#f1efe6','#9d1f1f','#8a6b42','#fff'],tags:['白酒','酒瓶','中国风','中外名酒']},
  {id:12708,title:'塔罗牌纸盒包装设计',type:'纸盒',industry:'生活服务',style:['休闲','简洁','复古','商务','手绘'],use:['外包装','存储包装','销售包装'],material:'白卡纸',model:'100010',pro:false,shape:'box',views:9022,c:['#16172d','#d3b779','#5b4e88','#f5ebd2'],tags:['塔罗牌','复古','纸盒','双插盒']},
  {id:20438,title:'假睫毛纸盒包装设计',type:'纸盒',industry:'生活服务',style:['休闲','简洁','时尚'],use:['外包装','销售包装'],material:'白卡纸',model:'100010',pro:false,shape:'box',views:11230,c:['#f4d4df','#fff','#2a2024','#e6b1c1'],tags:['美容美妆','美妆品','假睫毛','纸盒']},
  {id:25040,title:'隐形眼镜纸盒包装设计',type:'纸盒',industry:'生活服务',style:['休闲','简洁'],use:['外包装','销售包装'],material:'白卡纸',model:'100010',pro:false,shape:'box',views:10443,c:['#e7f6ff','#84c7e7','#28475b','#fff'],tags:['美容美妆','美瞳','隐形眼镜','纸盒']},
  {id:4542,title:'香烟包装',type:'纸盒',industry:'日常用品',style:['简洁','商务'],use:['外包装','销售包装'],material:'白卡纸',model:'112401',pro:false,shape:'box',views:5536,c:['#272c35','#b5a273','#f4ead1','#e5e5e5'],tags:['生活日用','翻盖盒','商务风','纸盒']},
  {id:4090,title:'袜子礼盒包装盒',type:'精装盒',industry:'日常用品',style:['文艺','简洁','清新'],use:['外包装','销售包装','装饰性包装'],material:'白卡纸',model:'160010',pro:true,shape:'gift',views:6188,c:['#d7d1c5','#4d7180','#253d45','#f2eee6'],tags:['服饰箱包','天地盒','袜子礼盒','纸盒']},
  {id:31001,title:'东方茶韵茶叶礼盒包装设计',type:'精装盒',industry:'食品饮料',style:['中国风','商务','简洁'],use:['外包装','销售包装'],material:'特种纸',model:'360020',pro:true,shape:'gift',views:8881,c:['#264a3b','#c5a66f','#f6eedf','#e2ddcf'],tags:['茶叶','国风','礼盒','食品饮料']},
  {id:31002,title:'手冲精品咖啡豆自立袋包装',type:'软包装',industry:'食品饮料',style:['简洁','文艺'],use:['外包装','销售包装','跨境电商'],material:'复合膜',model:'510010',pro:false,shape:'pouch',views:7310,c:['#34302a','#b59b73','#fff','#e8e0d3'],tags:['咖啡','自立袋','软包装']},
  {id:31003,title:'儿童水果软糖包装设计',type:'软包装',industry:'食品饮料',style:['卡通','清新'],use:['外包装','销售包装'],material:'复合膜',model:'510011',pro:true,shape:'pouch',views:6992,c:['#ff936f','#ffd75d','#5b4f3b','#fff0dd'],tags:['水果软糖','卡通','零食']},
  {id:31004,title:'植物精华护肤品包装设计',type:'纸盒',industry:'美容美妆',style:['简洁','清新'],use:['外包装','销售包装','跨境电商'],material:'白卡纸',model:'100010',pro:true,shape:'box',views:11940,c:['#b9cdbb','#eef0e8','#4f6251','#f7faf4'],tags:['护肤品','植物精华','美容美妆']},
  {id:31005,title:'天然洗护瓶贴标签包装设计',type:'瓶贴',industry:'日常用品',style:['清新','简洁'],use:['外包装','销售包装'],material:'不干胶',model:'620010',pro:false,shape:'bottle',views:6450,c:['#759579','#c5dcc8','#39503c','#f0f6eb'],tags:['洗护','瓶贴','标签']},
  {id:31006,title:'潮玩盲盒系列包装设计',type:'纸盒',industry:'文化创意',style:['卡通','时尚','手绘'],use:['外包装','销售包装','跨境电商'],material:'白卡纸',model:'100010',pro:true,shape:'box',views:13220,c:['#8157d6','#ffca4c','#fff','#e8ddff'],tags:['潮玩','盲盒','卡通']},
  {id:31007,title:'谷物早餐纸盒包装设计',type:'纸盒',industry:'食品饮料',style:['简洁','清新'],use:['外包装','销售包装'],material:'白卡纸',model:'103015',pro:false,shape:'box',views:5988,c:['#f0e3bc','#8fb355','#6c4c2c','#fff9ec'],tags:['早餐','谷物','食品']},
  {id:31008,title:'花香蜡烛纸罐包装设计',type:'罐子',industry:'日常用品',style:['文艺','清新'],use:['外包装','销售包装'],material:'纸罐',model:'602800',pro:false,shape:'can',views:7031,c:['#ecd9e7','#c0a5bd','#574451','#fff'],tags:['香薰','蜡烛','纸罐']},
  {id:31009,title:'坚果礼盒包装设计',type:'精装盒',industry:'食品饮料',style:['商务','简洁'],use:['外包装','销售包装'],material:'铜版纸',model:'360010',pro:true,shape:'gift',views:8312,c:['#6a3d26','#d0ae78','#f7ead8','#422719'],tags:['坚果','礼盒','食品']},
  {id:31010,title:'宠物零食自立袋包装设计',type:'软包装',industry:'日常用品',style:['卡通','简洁'],use:['外包装','销售包装','跨境电商'],material:'复合膜',model:'510010',pro:false,shape:'pouch',views:7702,c:['#edca76','#334d51','#fff','#efe5c7'],tags:['宠物','零食','自立袋']},
  {id:31011,title:'高端红酒礼盒包装设计',type:'精装盒',industry:'食品饮料',style:['商务','简洁'],use:['外包装','销售包装'],material:'特种纸',model:'361010',pro:true,shape:'gift',views:9120,c:['#301821','#9e7650','#f0e0ce','#fff'],tags:['红酒','礼盒','高端']}
];

export const models = [
  {id:74,code:'102012',title:'锁扣扣底盒',type:'纸盒',sub:'扣底盒',printable:true,free:true,sizes:'可修改尺寸',materials:['白卡纸','瓦楞纸'],shape:'box',uses:12890,c:['#f0e6d6','#a77e48','#fff','#4f3c28']},
  {id:1666,code:'362011',title:'全包精品抽屉礼盒',type:'精装盒',sub:'抽屉盒',printable:true,free:true,sizes:'可修改尺寸',materials:['铜版纸','特种纸'],shape:'drawer',uses:9531,c:['#ddd3c8','#5d4a3f','#f6eee7','#a98e74']},
  {id:732,code:'501280',title:'润喉糖医药保健铝盒包装模型',type:'罐子',sub:'金属罐',printable:false,free:true,sizes:'1种固定尺寸',materials:['哑光金属','油光金属'],shape:'can',uses:6570,c:['#cfd3d6','#586269','#fff','#9ca4aa']},
  {id:2756,code:'602800',title:'生活日用圆筒收纳纸盒包装模型',type:'罐子',sub:'纸罐',printable:true,free:true,sizes:'可修改尺寸',materials:['白卡纸'],shape:'can',uses:7621,c:['#e6d6c8','#957159','#fff','#c2a48d']},
  {id:676,code:'501110',title:'奶粉食品饮料铝罐包装模型',type:'罐子',sub:'金属罐',printable:false,free:true,sizes:'3种固定尺寸',materials:['哑光金属','油光金属'],shape:'can',uses:10912,c:['#d7d9da','#8d9396','#fff','#adb0b2']},
  {id:220010,code:'220010',title:'手提袋',type:'手提袋',sub:'手提袋',printable:true,free:true,sizes:'可修改尺寸',materials:['白卡纸','瓦楞纸'],shape:'bag',uses:20832,c:['#efe4d2','#b48b52','#fff','#6b5031']},
  {id:220011,code:'220011',title:'正痕手提袋',type:'手提袋',sub:'手提袋',printable:true,free:true,sizes:'可修改尺寸',materials:['瓦楞纸','白卡纸'],shape:'bag',uses:16822,c:['#e5dfd2','#5c706a','#fff','#8d9d96']},
  {id:501000,code:'501000',title:'液体饮料食品饮料塑料瓶包装模型4',type:'瓶子',sub:'塑料瓶',printable:false,free:true,sizes:'3种固定尺寸',materials:['油光塑料'],shape:'bottle',uses:11003,c:['#e4eff4','#a4cadc','#fff','#4d7d92']},
  {id:516920,code:'516920',title:'个护健康面部护理粉底棒包装模型',type:'其他',sub:'个护模型',printable:false,free:true,sizes:'1种固定尺寸',materials:['塑料'],shape:'bottle',uses:5169,c:['#e9dfd6','#c8afa1','#fff','#6e5e55']},
  {id:102013,code:'102013',title:'开窗扣底盒',type:'纸盒',sub:'扣底盒',printable:true,free:true,sizes:'可修改尺寸',materials:['白卡纸','瓦楞纸'],shape:'box',uses:14011,c:['#f2eadd','#c9ab83','#fff','#725b3d']},
  {id:103010,code:'103010',title:'后开扣底盒',type:'纸盒',sub:'扣底盒',printable:true,free:true,sizes:'可修改尺寸',materials:['白卡纸'],shape:'box',uses:12110,c:['#e8e3dc','#909c92','#fff','#4c5850']},
  {id:361010,code:'361010',title:'翻盖精品礼盒',type:'精装盒',sub:'翻盖盒',printable:true,free:true,sizes:'可修改尺寸',materials:['铜版纸','特种纸'],shape:'gift',uses:15510,c:['#ded6ce','#755d50','#fff','#b29c90']}
];

export const scenes = [
  {id:1,title:'玻璃瓶专属场景',shape:'bottle',c:['#dce5e8','#9eb2b8','#ffffff','#536269']},
  {id:2,title:'简约风食品饮料绿色几何台面场景',shape:'can',c:['#dfe9df','#9bbd9e','#fff','#536b55']},
  {id:3,title:'简约风纸盒绿色几何台面场景',shape:'box',c:['#e4eee1','#a8bf9c','#fff','#4f6549']},
  {id:4,title:'中国风手提袋绿色桌面场景',shape:'bag',c:['#dde6d6','#879d79','#fff','#4c5a43']}
];

export const categories = {
  templateTypes:['全部','纸盒','精装盒','纸袋','软包装','瓶贴','瓶子','罐子','其他'],
  industries:['全部','食品饮料','日常用品','美容美妆','母婴儿童','文化创意','生活服务','服饰箱包'],
  styles:['全部','简洁','清新','卡通','时尚','文艺','手绘','商务','中国风','传统','复古'],
  uses:['全部','外包装','销售包装','存储包装','运输包装','跨境电商','装饰性包装'],
  modelTypes:['全部','纸盒','精装盒','手提袋','封套/卡片/文件','纸箱','软包装','内衬','瓶子','展示盒/架','罐子','异形盒','杯/桶/碗/盒/管','其他']
};

export const pricing = [
 {name:'\u793a\u4f8b\u6a21\u677f',price:'20 / 12',desc:'\u6a21\u677f / \u6a21\u578b\u5143\u6570\u636e',features:['\u670d\u52a1\u7aef\u641c\u7d22\u4e0e\u5206\u9875','\u975e\u539f\u7ad9\u5b8c\u6574\u8d44\u4ea7\u5e93'],cta:'\u529f\u80fd\u8303\u56f4'},
 {name:'\u672c\u5730\u8bbe\u8ba1',price:'RGB / PNG',desc:'\u516d\u9762\u76d2\u4f53\u5c55\u793a\u9884\u89c8',features:['\u6587\u5b57\u3001\u56fe\u7247\u3001\u56fe\u5c42','1K-4K PNG / RGB PDF \u9884\u89c8'],cta:'\u529f\u80fd\u8303\u56f4'},
 {name:'\u751f\u4ea7\u670d\u52a1',price:'\u672a\u63a5\u5165',desc:'\u4e0d\u662f\u751f\u4ea7\u7ea7 1:1 \u5b8c\u6210\u7248',features:['\u652f\u4ed8\u3001\u5370\u5237\u3001\u4e91\u6e32\u67d3\u672a\u63a5\u5165','\u56e2\u961f\u6743\u9650\u548c\u771f\u5b9e AI \u672a\u5b9e\u73b0'],cta:'\u529f\u80fd\u8303\u56f4'}
];
