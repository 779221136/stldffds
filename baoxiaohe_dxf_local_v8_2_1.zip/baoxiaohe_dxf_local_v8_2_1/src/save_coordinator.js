/** Single-flight autosave. Acknowledgments never mark newer edits as saved.
 * Pending operation + idempotency key are persisted BEFORE each network write.
 * No credential is stored here. Server authorization remains mandatory.
 */
const copy = value => structuredClone(value);
export const saveFingerprint = request => JSON.stringify({
  name:request.name, kind:request.kind, source_id:request.source_id, payload:request.payload
});
const newKey=()=>globalThis.crypto?.randomUUID?.()||`save-${Date.now()}-${Math.random().toString(36).slice(2)}`;

export function createSaveCoordinator({read,writeLocal,send,onAck=()=>{},onStatus=()=>{},
  canRemote=()=>true,initialPending=null,delay=1200,localDelay=250,maxWait=8000,retryBase=1500}) {
  let pending=initialPending?copy(initialPending):null;
  let dirty=!!pending,running=null,timer=null,localTimer=null,stopped=false,blocked=null;
  let firstDirty=0,retries=0,lastSaved=null,lastStatus={state:'idle'};
  function status(state,extra={}) {
    lastStatus={state,dirty,...extra};
    if(!stopped)onStatus(lastStatus);
  }
  function persist() {
    try {writeLocal(copy(read()),{dirty,pending:pending?copy(pending):null});return true;}
    catch(error){status('storage_error',{error});return false;}
  }
  function clearTimers(){clearTimeout(timer);clearTimeout(localTimer);timer=localTimer=null;}
  function schedule(ms=delay) {
    if(stopped||blocked||running)return;
    clearTimeout(timer);
    const elapsed=firstDirty?Date.now()-firstDirty:0;
    // Backoff is not overridden by maxWait (otherwise an outage causes a tight loop).
    const wait=retries?ms:Math.min(ms,Math.max(0,maxWait-elapsed));
    timer=setTimeout(()=>{timer=null;void flush(false);},wait);
  }
  function changed() {
    if(stopped)return;
    dirty=true;if(!firstDirty)firstDirty=Date.now();
    if(!blocked)status(running?'saving':'dirty');
    clearTimeout(localTimer);localTimer=setTimeout(persist,localDelay);
    schedule();
  }
  function flush(force=true) {
    clearTimers();
    if(stopped)return Promise.resolve({ok:false,reason:'disposed'});
    if(blocked){persist();return Promise.resolve({ok:false,reason:blocked});}
    if(running)return running.then(result=>result.ok&&force&&(dirty||pending)&&!blocked?flush(false):result);
    if(!dirty&&!pending&&!force)return Promise.resolve({ok:true,unchanged:true});
    if(force)dirty=true;
    const work=async()=>{
      const localStored=persist();
      if(!canRemote()){
        if(!localStored)return {ok:false,reason:'local-storage'};
        dirty=false;pending=null;firstDirty=0;persist();status('local');
        return {ok:true,local:true};
      }
      const request=copy(read()),fingerprint=saveFingerprint(request);
      if(!pending&&fingerprint===lastSaved){dirty=false;firstDirty=0;persist();status('saved',{version:request.version});return {ok:true,unchanged:true};}
      if(!pending)pending={key:newKey(),request,fingerprint};
      const operation=pending;
      // Persist the exact request, not just a key: a response can be lost and the
      // user can edit again before reloading. Retrying must use the same body.
      persist();status('saving');
      try {
        const result=await send(copy(operation.request),operation.key);
        dirty=saveFingerprint(read())!==operation.fingerprint;
        lastSaved=operation.fingerprint;pending=null;retries=0;firstDirty=dirty?Date.now():0;
        try {onAck(result,operation.request,dirty);}
        catch(error){blocked='local_ack';status('saved_no_backup',{version:result.version,error});return {ok:true,result,localAckFailed:true};}
        const stored=persist();
        if(!dirty)status(stored?'saved':'saved_no_backup',{version:result.version});
        else status('dirty',{version:result.version});
        return {ok:true,result,dirty};
      } catch(error) {
        dirty=true;retries++;
        if(error.status===409)blocked='conflict';
        else if([401,403].includes(error.status))blocked='auth';
        else if([400,404,410,413,422].includes(error.status))blocked='rejected';
        else if(retries>=5)blocked='network';
        persist();status(blocked||'retry',{error,attempt:retries});
        return {ok:false,error,reason:blocked||'retry'};
      }
    };
    running=work().finally(()=>{
      running=null;
      if(!stopped&&!blocked&&(dirty||pending))schedule(retries?Math.min(retryBase*2**(retries-1),30000):delay);
    });
    return running;
  }
  function retry(){if(blocked==='network')blocked=null;if(!blocked){retries=0;return flush(false);}return Promise.resolve({ok:false,reason:blocked});}
  function discard(){clearTimers();dirty=false;pending=null;blocked=null;firstDirty=0;}
  if(pending)schedule(0);
  return {changed,flush,retry,discard,persist,
    getState:()=>({...lastStatus,dirty,inFlight:!!running,blocked,pending:!!pending}),
    dispose(){if(dirty||pending)persist();stopped=true;clearTimers();}
  };
}
