import {blockEditorShortcut,isComposingEvent} from './browser_compat.js';
import {esc, color} from './artwork.js';

const icons = {
  grip: '<circle cx="8" cy="5" r="1.3"/><circle cx="14" cy="5" r="1.3"/><circle cx="8" cy="11" r="1.3"/><circle cx="14" cy="11" r="1.3"/><circle cx="8" cy="17" r="1.3"/><circle cx="14" cy="17" r="1.3"/>',
  eye: '<path d="M2 11s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6Z"/><circle cx="11" cy="11" r="2.5"/>',
  hidden: '<path d="m3 3 16 16M9 5.2C16 3.5 20 11 20 11a17 17 0 0 1-3.1 3.7M6 6.6A17 17 0 0 0 2 11s3.5 6 9 6a10 10 0 0 0 3.2-.5"/>',
  lock: '<rect x="5" y="9" width="12" height="10" rx="2"/><path d="M7 9V6a4 4 0 0 1 8 0v3M11 13v2"/>',
  unlock: '<rect x="5" y="9" width="12" height="10" rx="2"/><path d="M7 9V6a4 4 0 0 1 7.6-1.8M11 13v2"/>',
  text: '<path d="M4 5V3h14v2M11 3v16M7 19h8"/>',
  rect: '<rect x="4" y="4" width="14" height="14" rx="2"/>',
  image: '<rect x="3" y="3" width="16" height="16" rx="2"/><circle cx="8" cy="8" r="1.5"/><path d="m3 16 5-5 4 4 3-3 4 4"/>'
};
const icon = name => `<svg viewBox="0 0 22 22" aria-hidden="true" focusable="false" ${name === 'grip' ? 'fill="currentColor"' : 'fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"'}>${icons[name] || icons.rect}</svg>`;
const label = o => String(o.name || (o.type === 'text' ? o.text : o.type === 'image' ? '\u56fe\u7247' : '\u5f62\u72b6') || '\u672a\u547d\u540d\u56fe\u5c42').replace(/\s+/g, ' ').slice(0, 100);
const thumbnail = o => o.type === 'rect'
  ? `<svg viewBox="0 0 22 22" aria-hidden="true"><rect x="3" y="3" width="16" height="16" rx="3" fill="${color(o.fill)}"/></svg>`
  : icon(o.type);
let panelSequence = 0;

/** Pointer-event sorting works with mouse, pen and touch without dependencies.
 * The model is committed only on drop; cancellation never changes artwork.
 * Existing data-layer-select/visibility/lock hooks are retained for automation.
 */
export function createLayerPanel({mount, editor}) {
  const root = typeof mount === 'string' ? document.querySelector(mount) : mount;
  if (!root || !editor) throw new Error('Layer panel requires a mount and editor');
  const hintId = `layer-sort-hint-${++panelSequence}`;
  root.classList.add('layer-sort-panel');
  root.innerHTML = `<div class="layer-panel-heading"><strong>\u56fe\u5c42</strong><span data-layer-count></span></div>
    <p id="${hintId}" class="layer-sort-hint">\u62d6\u52a8\u624b\u67c4\u6392\u5e8f\uff0c\u8d8a\u9760\u4e0a\u8d8a\u9760\u524d</p>
    <div class="layer-stack-actions" role="group" aria-label="\u56fe\u5c42\u6392\u5e8f">
      <button type="button" data-layer-action="top" title="Alt+Home">\u7f6e\u9876</button>
      <button type="button" data-layer-action="up" title="Alt+\u2191">\u4e0a\u79fb</button>
      <button type="button" data-layer-action="down" title="Alt+\u2193">\u4e0b\u79fb</button>
      <button type="button" data-layer-action="bottom" title="Alt+End">\u7f6e\u5e95</button>
    </div>
    <div class="layer-sort-list" role="list" aria-label="\u56fe\u5c42\uff08\u4ece\u9876\u5230\u5e95\uff09" aria-describedby="${hintId}"></div>
    <p class="layer-keyboard-hint">\u805a\u7126\u624b\u67c4\u540e\u53ef\u7528 \u2191\u2193 / Home / End \u8c03\u5e8f\uff1bEsc \u53d6\u6d88\u62d6\u52a8</p>
    <div class="layer-sort-status" role="status" aria-live="polite" aria-atomic="true"></div>`;
  const list = root.querySelector('.layer-sort-list');
  const status = root.querySelector('.layer-sort-status');
  let drag = null, frame = 0, disposed = false, suppressedUntil = 0, pendingRefresh = false;
  const rows = () => [...list.querySelectorAll('[data-layer-row]')];
  const rowFor = id => rows().find(row => row.dataset.layerRow === id);
  const announce = text => { status.textContent = text; };
  const selectedId = () => editor.getSelected()?.id;

  function focusLayer(id, kind = 'handle', scroll = false) {
    const row = rowFor(id), button = row?.querySelector(`[data-layer-${kind}]`);
    button?.focus({preventScroll: true});
    if (scroll && row) {
      if (row.offsetTop < list.scrollTop) list.scrollTop = row.offsetTop - 4;
      else if (row.offsetTop + row.offsetHeight > list.scrollTop + list.clientHeight)
        list.scrollTop = row.offsetTop + row.offsetHeight - list.clientHeight + 4;
    }
  }
  function refresh() {
    if (disposed) return;
    if (drag) { pendingRefresh = true; return; }
    const focused = document.activeElement;
    const focusId = focused?.closest('[data-layer-row]')?.dataset.layerRow;
    const focusKind = ['handle', 'select', 'visibility', 'lock'].find(k => focused?.hasAttribute(`data-layer-${k}`));
    const objects = editor.getObjects().reverse(), id = selectedId(), scroll = list.scrollTop;
    root.querySelector('[data-layer-count]').textContent = `${objects.length} \u4e2a`;
    list.innerHTML = objects.length ? objects.map((o, i) => `<div data-layer-row="${esc(o.id)}" role="listitem" aria-posinset="${i + 1}" aria-setsize="${objects.length}" class="v4-layer sortable-layer${id === o.id ? ' selected' : ''}${o.hidden ? ' is-hidden' : ''}${o.locked ? ' is-locked' : ''}">
      <button type="button" class="layer-drag-handle" data-layer-handle="${esc(o.id)}" ${o.locked ? 'disabled' : ''} aria-label="${esc(o.locked ? '\u5df2\u9501\u5b9a\uff0c\u8bf7\u5148\u89e3\u9501' : '\u62d6\u52a8\u6392\u5e8f\uff1a' + label(o))}" aria-describedby="${hintId}" title="${o.locked ? '\u5148\u89e3\u9501\u518d\u6392\u5e8f' : '\u62d6\u52a8\u8c03\u6574\u56fe\u5c42\u987a\u5e8f'}">${icon('grip')}</button>
      <button type="button" class="layer-select-button" data-layer-select="${esc(o.id)}" aria-pressed="${id === o.id}" title="${esc(label(o))}"><span class="layer-type-icon">${thumbnail(o)}</span><span class="layer-label">${esc(label(o))}</span></button>
      <button type="button" class="layer-icon-button" data-layer-visibility="${esc(o.id)}" aria-pressed="${!!o.hidden}" aria-label="${o.hidden ? '\u663e\u793a' : '\u9690\u85cf'}\u56fe\u5c42\uff1a${esc(label(o))}" title="${o.hidden ? '\u663e\u793a' : '\u9690\u85cf'}">${icon(o.hidden ? 'hidden' : 'eye')}</button>
      <button type="button" class="layer-icon-button" data-layer-lock="${esc(o.id)}" aria-pressed="${!!o.locked}" aria-label="${o.locked ? '\u89e3\u9501' : '\u9501\u5b9a'}\u56fe\u5c42\uff1a${esc(label(o))}" title="${o.locked ? '\u89e3\u9501' : '\u9501\u5b9a'}">${icon(o.locked ? 'lock' : 'unlock')}</button>
    </div>`).join('') : '<p class="layer-empty">\u8fd8\u6ca1\u6709\u56fe\u5c42\uff0c\u6dfb\u52a0\u6587\u5b57\u3001\u56fe\u7247\u6216\u5f62\u72b6\u5f00\u59cb\u8bbe\u8ba1</p>';
    list.scrollTop = scroll;
    const pos = objects.findIndex(o => o.id === id), locked = objects[pos]?.locked;
    root.querySelectorAll('[data-layer-action]').forEach(button => {
      const towardTop = ['top', 'up'].includes(button.dataset.layerAction);
      button.disabled = pos < 0 || !!locked || (towardTop ? pos === 0 : pos === objects.length - 1);
    });
    if (focusId && focusKind) focusLayer(focusId, focusKind);
    pendingRefresh = false;
  }

  function move(id, index, kind = 'handle') {
    const before = editor.getObjects().find(o => o.id === id);
    if (!before) return;
    if (before.locked) { announce('\u56fe\u5c42\u5df2\u9501\u5b9a\uff0c\u8bf7\u5148\u89e3\u9501\u518d\u6392\u5e8f'); return; }
    const count = editor.getObjects().length;
    const changed = editor.reorderLayer(id, Math.max(0, Math.min(count - 1, index)));
    refresh();
    if (changed) announce(`${label(before)}\uff1a\u5df2\u79fb\u81f3\u7b2c ${index + 1} / ${count} \u5c42`);
    focusLayer(id, kind, true);
  }
  function act(action, id = selectedId()) {
    const objects = editor.getObjects().reverse(), index = objects.findIndex(o => o.id === id);
    if (index < 0) return;
    const target = {top: 0, up: index - 1, down: index + 1, bottom: objects.length - 1}[action];
    if (target !== undefined) move(id, target);
  }
  function click(e) {
    if (e.detail && performance.now() < suppressedUntil) { e.preventDefault(); e.stopPropagation(); return; }
    const b = e.target.closest('button');
    if (!b || !root.contains(b) || b.disabled) return;
    const {layerAction, layerSelect, layerHandle, layerVisibility, layerLock} = b.dataset;
    if (layerAction) { act(layerAction); return; }
    const id = layerSelect || layerHandle || layerVisibility || layerLock;
    if (!id) return;
    editor.selectObject(id);
    if (layerVisibility) editor.updateSelected({hidden: !editor.getSelected().hidden});
    if (layerLock) editor.updateSelected({locked: !editor.getSelected().locked});
    refresh();
    focusLayer(id, layerVisibility ? 'visibility' : layerLock ? 'lock' : layerHandle ? 'handle' : 'select');
  }

  function pointerDown(e) {
    suppressedUntil = 0;
    if (disposed || drag || e.button !== 0 || e.isPrimary === false) return;
    const b = e.target.closest('[data-layer-handle], [data-layer-select]');
    if (!b || !list.contains(b) || b.disabled) return;
    // On touchscreens the name scrolls normally; only the handle grabs a layer.
    if (e.pointerType === 'touch' && !b.hasAttribute('data-layer-handle')) return;
    const id = b.dataset.layerHandle || b.dataset.layerSelect;
    const objects = editor.getObjects().reverse(), object = objects.find(o => o.id === id);
    if (!object || object.locked) return;
    e.preventDefault();
    const row = b.closest('[data-layer-row]'), box = row.getBoundingClientRect();
    drag = {id, pointer: e.pointerId, startX: e.clientX, startY: e.clientY, x: e.clientX, y: e.clientY,
      source: row, name: label(object), initialOrder: objects.map(o => o.id), initialIndex: objects.indexOf(object),
      kind: b.hasAttribute('data-layer-handle') ? 'handle' : 'select',
      offsetY: e.clientY - box.top, active: false, valid: false, target: objects.indexOf(object), ghost: null, marker: null};
    b.focus({preventScroll: true});
    list.setPointerCapture?.(e.pointerId);
    editor.selectObject(id); // refresh is deferred while a pointer owns the list.
    rows().forEach(r => {r.classList.toggle('selected', r === row);r.querySelector('[data-layer-select]').setAttribute('aria-pressed', String(r === row));});
  }
  function beginDrag() {
    drag.active = true;
    drag.source.classList.add('is-dragging');
    root.classList.add('is-sorting');
    const ghost = document.createElement('div');
    ghost.className = 'layer-drag-ghost';ghost.setAttribute('aria-hidden', 'true');
    ghost.innerHTML = `${icon('grip')}<span>${esc(drag.name)}</span><small>\u79fb\u52a8\u56fe\u5c42</small>`;
    document.body.append(ghost);drag.ghost = ghost;
    const marker = document.createElement('div');marker.className = 'layer-drop-indicator';marker.setAttribute('aria-hidden', 'true');
    list.append(marker);drag.marker = marker;
    announce('\u62d6\u52a8\u4e2d\uff0c\u677e\u5f00\u786e\u8ba4\uff1bEsc \u53d6\u6d88');
    frame = requestAnimationFrame(tick);
  }
  function updateTarget() {
    if (!drag?.active) return;
    const rect = list.getBoundingClientRect();
    drag.valid = drag.x >= rect.left && drag.x <= rect.right && drag.y >= rect.top - 4 && drag.y <= rect.bottom + 4;
    drag.ghost.style.width = `${Math.max(120, rect.width - 12)}px`;
    drag.ghost.style.left = `${Math.max(4, Math.min(innerWidth - rect.width, rect.left + 10))}px`;
    drag.ghost.style.top = `${Math.max(2, Math.min(innerHeight - 46, drag.y - drag.offsetY))}px`;
    drag.ghost.classList.toggle('invalid-drop', !drag.valid);
    drag.marker.hidden = !drag.valid;
    if (!drag.valid) return;
    const others = rows().filter(row => row.dataset.layerRow !== drag.id);
    const slot = others.findIndex(row => {const b = row.getBoundingClientRect();return drag.y < b.top + b.height / 2;});
    drag.target = slot < 0 ? others.length : slot;
    const before = others[drag.target], last = others[others.length - 1];
    const top = before ? before.offsetTop - 3 : last ? last.offsetTop + last.offsetHeight + 3 : 4;
    drag.marker.style.top = `${top}px`;
    drag.marker.classList.toggle('no-change', drag.target === drag.initialIndex);
    drag.ghost.querySelector('small').textContent = `\u7b2c ${drag.target + 1} / ${drag.initialOrder.length} \u5c42`;
  }
  function tick() {
    if (!drag?.active || disposed) return;
    const r = list.getBoundingClientRect(), edge = 36;
    if (drag.x >= r.left && drag.x <= r.right && drag.y >= r.top - 4 && drag.y <= r.bottom + 4) {
      const top = Math.max(0, (r.top + edge - drag.y) / edge);
      const bottom = Math.max(0, (drag.y - (r.bottom - edge)) / edge);
      list.scrollTop += (bottom - top) * 10;
    }
    updateTarget();frame = requestAnimationFrame(tick);
  }
  function pointerMove(e) {
    if (!drag || e.pointerId !== drag.pointer) return;
    drag.x = e.clientX;drag.y = e.clientY;
    if (!drag.active && Math.hypot(drag.x - drag.startX, drag.y - drag.startY) < 5) return;
    if (e.cancelable) e.preventDefault();
    if (!drag.active) beginDrag();
    updateTarget();
  }
  function finish(commit, message = '') {
    if (!drag) return;
    const d = drag;drag = null;cancelAnimationFrame(frame);frame = 0;
    if (list.hasPointerCapture?.(d.pointer)) list.releasePointerCapture(d.pointer);
    d.source.classList.remove('is-dragging');root.classList.remove('is-sorting');
    d.ghost?.remove();d.marker?.remove();
    suppressedUntil = performance.now() + 350;
    if (disposed) return;
    const sameOrder = JSON.stringify(editor.getObjects().reverse().map(o => o.id)) === JSON.stringify(d.initialOrder);
    if (commit && d.active && d.valid && sameOrder) move(d.id, d.target, d.kind);
    else {refresh();focusLayer(d.id, d.kind);if (d.active) announce(message || '\u5df2\u53d6\u6d88\u6392\u5e8f\uff0c\u56fe\u5c42\u987a\u5e8f\u672a\u6539\u53d8');}
    if (pendingRefresh) refresh();
  }
  function pointerUp(e) { if (drag && e.pointerId === drag.pointer) {drag.x = e.clientX;drag.y = e.clientY;updateTarget();finish(true);} }
  function pointerCancel(e) { if (drag && e.pointerId === drag.pointer) finish(false); }
  function blur() { finish(false); }
  function escape(e) {
    if (!drag || isComposingEvent(e)) return;
    // Do not let editor-global shortcuts change the document mid-drag.
    if (e.key === 'Escape') {e.preventDefault();e.stopImmediatePropagation();finish(false);}
    else if (['Delete', 'Backspace', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key) || e.ctrlKey || e.metaKey) {e.preventDefault();e.stopImmediatePropagation();}
  }
  function keydown(e) {
    if (blockEditorShortcut(e)) return;
    const row = e.target.closest('[data-layer-row]'), handle = e.target.closest('[data-layer-handle]');
    if (row && (handle || e.altKey) && ['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(e.key)) {
      e.preventDefault();e.stopPropagation();
      const action = {ArrowUp: 'up', ArrowDown: 'down', Home: 'top', End: 'bottom'}[e.key];
      act(action, row.dataset.layerRow);
    } else if (e.key === ' ' && e.target.closest('button')) {
      e.stopPropagation(); // Retain native button activation, not canvas panning.
    }
  }
  // Suppress the synthetic click after drop, never a fresh user's press.
  const pointerIntent = () => { suppressedUntil = 0; };
  root.addEventListener('pointerdown', pointerIntent, true);
  root.addEventListener('click', click, true);
  root.addEventListener('keydown', keydown);
  list.addEventListener('pointerdown', pointerDown);
  list.addEventListener('lostpointercapture', pointerCancel);
  window.addEventListener('pointermove', pointerMove, {passive: false});
  window.addEventListener('pointerup', pointerUp);
  window.addEventListener('pointercancel', pointerCancel);
  window.addEventListener('blur', blur);
  window.addEventListener('keydown', escape, true);
  refresh();
  return {refresh, destroy() {
    disposed = true;finish(false);cancelAnimationFrame(frame);
    root.removeEventListener('pointerdown', pointerIntent, true);
    root.removeEventListener('click', click, true);root.removeEventListener('keydown', keydown);
    list.removeEventListener('pointerdown', pointerDown);list.removeEventListener('lostpointercapture', pointerCancel);
    window.removeEventListener('pointermove', pointerMove);window.removeEventListener('pointerup', pointerUp);
    window.removeEventListener('pointercancel', pointerCancel);window.removeEventListener('blur', blur);window.removeEventListener('keydown', escape, true);
  }};
}
