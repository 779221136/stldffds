/** Browser-measured wrapping, preserved as explicit lines in a saved document.
 * RGB preview export consumes those lines; font metrics still depend on deployment.
 */
let context=null;
const cache=new Map();
const graphemes=text=>globalThis.Intl?.Segmenter?
  [...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(text)].map(x=>x.segment):Array.from(text);
export function wrapMeasured(text,width,measure) {
  const lines=[];
  for(const paragraph of String(text??'').replace(/\r\n?/g,'\n').split('\n')) {
    let line='';
    for(const ch of graphemes(paragraph)) {
      const next=line+ch;
      if(line && measure(next)>width) {
        const spaces=[...line.matchAll(/\s/g)];
        const split=spaces.length?spaces.at(-1).index+1:0;
        if(split>0 && split<line.length){lines.push(line.slice(0,split));line=line.slice(split)+ch;}
        else {lines.push(line);line=ch;}
      } else line=next;
    }
    lines.push(line);
  }
  return lines;
}
export function layoutLines(object) {
  const text=String(object.text||'').replace(/\r\n?/g,'\n');
  if(!object.wrap||object.vertical)return text.split('\n');
  const key=JSON.stringify([text,object.w,object.fontFamily,object.fontSize,object.fontWeight,object.fontStyle,object.letterSpacing]);
  if(cache.has(key))return cache.get(key).slice();
  if(!context&&typeof document!=='undefined')context=document.createElement('canvas').getContext('2d');
  if(!context)return object.textLines?.slice()||text.split('\n');
  const family=String(object.fontFamily||'Arial').replace(/["\\\n\r]/g,'');
  context.font=`${object.fontStyle==='italic'?'italic':'normal'} ${object.fontWeight||500} ${object.fontSize||28}px "${family}", sans-serif`;
  const spacing=Number(object.letterSpacing)||0;
  const lines=wrapMeasured(text,Math.max(1,Number(object.w)||100),s=>context.measureText(s).width+Math.max(0,Array.from(s).length-1)*spacing);
  cache.set(key,lines);if(cache.size>128)cache.delete(cache.keys().next().value);
  return lines.slice();
}
export const textHeight=o=>Math.max(0,layoutLines(o).length-1)*(o.fontSize||28)*(o.lineHeight||1.2)+(o.fontSize||28);
