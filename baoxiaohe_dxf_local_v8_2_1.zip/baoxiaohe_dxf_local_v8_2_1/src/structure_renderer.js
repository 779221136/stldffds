import {rasterizeProjected} from './structure_raster.js';
import {wheelDelta} from './browser_compat.js';
import {projected,clamp} from './structure_math.js';
const rgb=c=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));
const tint=(c,s)=>`rgb(${rgb(c).map(x=>Math.round(clamp(x*s,0,255))).join(',')})`;
function program(gl){
  const sources=[`attribute vec3 aP;attribute vec2 aUV;attribute float aS;varying vec2 vUV;varying float vS;void main(){gl_Position=vec4(aP,1.0);vUV=aUV;vS=aS;}`,
    `precision mediump float;varying vec2 vUV;varying float vS;uniform sampler2D uT;uniform vec3 uBase;uniform float uUse;void main(){vec4 tex=texture2D(uT,vUV);vec3 col=mix(uBase,tex.rgb,tex.a*uUse);gl_FragColor=vec4(clamp(col*vS,0.0,1.0),1.0);}`];
  const p=gl.createProgram();for(let i=0;i<2;i++){const s=gl.createShader(i?gl.FRAGMENT_SHADER:gl.VERTEX_SHADER);gl.shaderSource(s,sources[i]);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));gl.attachShader(p,s);gl.deleteShader(s);}gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p;
}
export function createStructureRenderer(root,onView){
  root.innerHTML='<canvas aria-label="Local folding geometry preview"></canvas>';
  let canvas=root.querySelector('canvas'),gl=canvas.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:true,premultipliedAlpha:false}),prog=null;
  try{if(gl)prog=program(gl);}catch{gl=null;canvas.replaceWith(canvas=Object.assign(document.createElement('canvas'),{ariaLabel:'Local folding preview'}));}
  const ctx=gl?null:canvas.getContext('2d');if(!ctx&&!gl)throw Error('Canvas is unavailable');
  const gpuTextures=new Map(),images=new Map(),pixelTextures=new Map();let model=null,view=null,appearance={},disposed=false,generation=0,drag=null;
  const buffer=gl?.createBuffer();
  function makeTexture(image){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);return t;}
  const blank=document.createElement('canvas');blank.width=blank.height=1;const fallback=gl?makeTexture(blank):null;
  async function setTextures(textures){const seq=++generation;const loaded=await Promise.all(Object.entries(textures).map(async([id,src])=>{if(!/^data:image\/(png|jpeg);base64,/.test(src))throw Error('Embedded PNG/JPEG required');const img=new Image();img.src=src;await img.decode();return [id,img];}));if(disposed||seq!==generation)return;
    images.clear();pixelTextures.clear();for(const t of gpuTextures.values())gl?.deleteTexture(t);gpuTextures.clear();for(const [id,img]of loaded){images.set(id,img);if(gl)gpuTextures.set(id,makeTexture(img));else{const c=document.createElement('canvas');c.width=img.width;c.height=img.height;const c2=c.getContext('2d');c2.drawImage(img,0,0);pixelTextures.set(id,c2.getImageData(0,0,c.width,c.height));}}draw();}
  function draw(size={}){if(disposed||!model||!view)return;
    const r=root.getBoundingClientRect(),dpr=Math.min(2,devicePixelRatio||1);canvas.width=size.width||Math.max(1,Math.round(r.width*dpr));canvas.height=size.height||Math.max(1,Math.round(r.height*dpr));
    const w=canvas.width,h=canvas.height,P=projected(model,view,w,h),ext=appearance.exterior||'#f9f5ef',inside=appearance.interior||'#e8ddc9';
    if(gl){
      gl.viewport(0,0,w,h);gl.clearColor(...rgb(view.background).map(x=>x/255),view.transparent?0:1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.useProgram(prog);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
      for(const t of P.triangles){const data=[];t.screen.forEach((a,i)=>data.push(a[0]/w*2-1,1-a[1]/h*2,-t.q[i][2]/(P.radius*2),...t.uv[i],t.shade*(t.side==='edge'?.88:1)));gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.DYNAMIC_DRAW);
        for(const [name,size,offset] of [['aP',3,0],['aUV',2,12],['aS',1,20]]){const loc=gl.getAttribLocation(prog,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,24,offset);}
        const texture=t.side==='front'?gpuTextures.get(t.panel):null;gl.bindTexture(gl.TEXTURE_2D,texture||fallback);gl.uniform1f(gl.getUniformLocation(prog,'uUse'),texture?1:0);gl.uniform3fv(gl.getUniformLocation(prog,'uBase'),rgb(t.side==='front'?ext:inside).map(x=>x/255));gl.drawArrays(gl.TRIANGLES,0,3);
      }
    }else{
      // A depth-buffered preview avoids painter-order artifacts on overlapping
      // lid/dust panels and shows the same layering as the local worker.
      const pixels=rasterizeProjected(P,w,h,view,{exterior:ext,interior:inside},pixelTextures);
      ctx.putImageData(new ImageData(pixels,w,h),0,0);
    }
  }
  canvas.addEventListener('pointerdown',e=>{drag={id:e.pointerId,x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(!drag||!view)return;view={...view,yaw:((view.yaw+(e.clientX-drag.x)*.45+540)%360)-180,pitch:clamp(view.pitch+(e.clientY-drag.y)*.35,-85,85)};drag.x=e.clientX;drag.y=e.clientY;onView?.(view);draw();});
  canvas.addEventListener('pointerup',()=>drag=null);canvas.addEventListener('pointercancel',()=>drag=null);
  canvas.addEventListener('wheel',e=>{if(!view)return;e.preventDefault();view={...view,zoom:clamp(view.zoom*Math.exp(-wheelDelta(e,canvas)*.001),.3,2)};onView?.(view);draw();},{passive:false});
  const observer=new ResizeObserver(draw);observer.observe(root);
  return {canvas,capture(width,height){if(disposed)throw Error('Renderer disposed');if(!Number.isInteger(width)||!Number.isInteger(height)||Math.min(width,height)<1||Math.max(width,height)>4096)throw Error('Invalid capture dimensions');if(gl&&Math.max(width,height)>gl.getParameter(gl.MAX_RENDERBUFFER_SIZE))throw Error('GPU export resolution exceeded');try{draw({width,height});const out=document.createElement('canvas');out.width=width;out.height=height;out.getContext('2d').drawImage(canvas,0,0);return out;}finally{draw();}},engine:gl?'WebGL':'Canvas 2D (preview only)',setModel(m){model=m;draw();},setView(v,a){view={...v};appearance=a;draw();},setTextures,draw,
    destroy(){disposed=true;observer.disconnect();images.clear();pixelTextures.clear();if(gl){for(const t of gpuTextures.values())gl.deleteTexture(t);gl.deleteTexture(fallback);gl.deleteBuffer(buffer);gl.deleteProgram(prog);}root.innerHTML='';}};
}
