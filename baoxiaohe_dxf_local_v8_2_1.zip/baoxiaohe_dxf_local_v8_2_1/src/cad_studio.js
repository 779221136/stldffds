import {createRequestGate} from './request_gate.js';
import {normalizeCadRenderOptions} from './cad_render_options.js';
import {openFileInput,takeSelectedFile,IMAGE_ACCEPT,RASTER_ACCEPT} from './file_picker.js';
import {isComposingEvent,hasBlockingDialog,modalKeydown} from './browser_compat.js';
import {T} from './cad_i18n.js';
import {copy,roleColor,placementMatrix,inverseMatrix,pathD,polygonD,pathBounds,fittedPlacement,canvasPanelLayout} from './cad_geometry.js';
import {esc,objectMarkup,fileToImage,svgToCanvas} from './artwork.js';
import {createPackagingEditor} from './editor_engine.js';
import {createLayerPanel} from './layer_panel.js';
import {createStructureRenderer} from './structure_renderer.js';

const roles=Object.keys(roleColor),API='/api/local/cad';
const str=v=>String(v??''),num=v=>Number.isFinite(Number(v))?Number(v):0;
const option=(v,t,selected)=>`<option value="${esc(v)}"${v===selected?' selected':''}>${esc(t)}</option>`;
const choices=(values,selected)=>values.map(v=>option(v,T[v]||v,selected)).join('');
const field=(label,html)=>`<label class="cad-field"><span>${label}</span>${html}</label>`;
const input=(name,value,type='number',extra='')=>`<input data-param="${name}" type="${type}" value="${esc(value)}" ${extra}>`;
const roleSelect=(attr,selected)=>`<select ${attr}>${choices(roles,selected)}</select>`;
const pathString=p=>pathD(p);
function thumbnail(paths){const b=pathBounds(paths),w=b[2]-b[0],h=b[3]-b[1],pad=Math.max(w,h)*.07+1;return `<svg viewBox="${b[0]-pad} ${-b[3]-pad} ${w+pad*2} ${h+pad*2}" xmlns="http://www.w3.org/2000/svg" aria-label="DXF"><g fill="none" stroke-linecap="round">${paths.filter(p=>p.role!=='ignore').map(p=>`<path d="${pathString(p)}" stroke="${roleColor[p.role]}" stroke-width="${Math.max(w,h)/450}"/>`).join('')}</g></svg>`;}
function blobDownload(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),3000);}
async function jsonFetch(path,body,method){const r=await fetch(path,{method:method||(body===undefined?'GET':'POST'),credentials:'same-origin',headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});if(!r.ok){let text;try{const j=await r.json();text=Array.isArray(j.detail)?j.detail.map(x=>`${x.loc?.join('.')}: ${x.msg}`).join('; '):j.detail||j.error?.message;}catch{text=await r.text();}const e=Error(text||`HTTP ${r.status}`);e.status=r.status;throw e;}return r;}
const api=async(path,body,method)=>(await jsonFetch(API+path,body,method)).json();
const toBase64=bytes=>{let s='';for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(s);};

export function mountCadStudio({mount,onBack=()=>{},payload=null}){
  const root=typeof mount==='string'?document.querySelector(mount):mount;
  let doc=null,analysis=null,editor=null,layers=null,renderer=null,destroyed=false,dirty=false,busy=false,mode='draw',selectedPath=null,selectedHinge=null,libraryId=null,version=null,folder='',tags=[],geomHistory=[],epoch=0,geometryEpoch=0,documentEpoch=0,anTimer=0,textureTimer=0,texEpoch=0,frame=0,playing=null,modelReady=false,jobTimer=0,modal=null,modalController=null,modalReturnFocus=null,netDrag=null;
  const jobsGate=createRequestGate();let jobsRetry=0;
  let storageNote=T.session,incoming=payload?.objects?copy(payload.objects):null,view={fold:0,opening:0,yaw:-25,pitch:18,zoom:1,light:1,background:'#edf0f4',transparent:false,framing:'pose'};
  root.className='cad-app';
  root.innerHTML=`<header class="cad-top"><button data-back class="cad-brand">${T.back}</button><div class="cad-title"><strong>${T.title}</strong><small>${T.local} / ${T.noCloud}</small></div><span data-save-status role="status">${T.new}</span><div class="cad-top-actions"><button data-import class="primary">${T.import}<small>${T.dxf}</small></button><button data-library>${T.library}</button><button data-save disabled>${T.save}</button><button data-export disabled>${T.export}</button></div></header>
  <nav class="cad-mobile-tabs">${['canvas','structure','props','preview'].map(k=>`<button data-tab="${k}">${T[k]}</button>`).join('')}</nav>
  <div class="cad-message" data-message role="status" hidden></div>
  <section class="cad-empty"><div class="cad-empty-icon">DXF</div><h1>${T.empty}</h1><p>${T.emptyNote}</p><button data-empty-import class="primary">${T.import}</button><button data-example>${T.example}</button><button data-json-open>${T.openJson}</button><p class="cad-fine">${T.importNote}</p></section>
  <input type="file" data-json-file accept=".json,application/json" hidden><div class="cad-workspace" hidden data-tab-active="canvas"><aside class="cad-left"><div class="cad-mode-tabs"><button data-mode="draw" class="active">${T.draw}</button><button data-mode="lines">${T.editLines}</button><button data-mode="net">${T.placement}</button></div><div class="cad-tools">${['text','shape','image','barcode','qr'].map(k=>`<button data-add="${k}">${T[k]}</button>`).join('')}</div><input hidden type="file" data-image accept="${IMAGE_ACCEPT}"><section class="cad-geometry-tools"><h3>${T.mapping}</h3><div data-groups></div><div class="cad-row"><button data-clean>${T.split}</button></div><label class="cad-field"><span>${T.selectLine}</span><select data-path><option value="">--</option></select></label><div data-path-props></div><button data-add-line>${T.manual}</button></section><div data-layer-panel></div></aside>
  <section class="cad-canvas-wrap"><div class="cad-canvas-heading"><input data-name value="DXF" maxlength="120" aria-label="${T.name}"><span data-summary></span><button data-geom-undo disabled>${T.undoGeom}</button><button data-fit>${T.fit}</button></div><div data-editor class="cad-editor"></div><footer class="cad-canvas-footer"><span class="cad-dot cut"></span>${T.cut}<span class="cad-dot crease"></span>${T.crease}<span class="cad-dot perf"></span>${T.perf}<span data-units>mm</span><button data-analysis>${T.generate}</button></footer></section>
  <aside class="cad-right"><section class="cad-preview-card"><div class="cad-section-title"><strong>${T.preview}</strong><span data-engine></span></div><div class="cad-render-host" data-render></div><div class="cad-preview-block" data-preview-block>${T.blocked}</div><div class="cad-preview-sliders">${field(T.fold,'<input type="range" data-fold min="0" max="1" step=".01" value="0">')}${field(T.opening,'<input type="range" data-opening min="0" max="1" step=".01" value="0">')}</div><div class="cad-row"><button data-play="fold">${T.play} ${T.fold}</button><button data-play="open">${T.play} ${T.opening}</button><button data-stop>${T.pause}</button></div><p class="cad-fine">${T.previewNote}</p></section>
  <div class="cad-prop-tabs"><button data-right-tab="params" class="active">${T.param}</button><button data-right-tab="object">${T.props}</button></div><section data-params class="cad-params"></section><section data-object-props class="cad-object" hidden></section><details open class="cad-report"><summary>${T.diagnostics}</summary><div data-diagnostics></div></details><section class="cad-local-render"><h3>${T.localRender}</h3><div class="cad-fields">${field(T.format,`<select data-format>${choices(['png','frames','mp4','webm'],'png')}</select>`)}${field(T.longEdge,`<select data-edge>${choices(['256','512','1024','2048','4096'],'1024')}</select>`)}${field(T.aspect,`<select data-aspect>${choices(['1:1','4:3','3:4','16:9','9:16'],'4:3')}</select>`)}${field(T.motion,`<select data-motion>${choices(['fold','open','rotate'],'fold')}</select>`)}${field(T.seconds,'<input data-seconds type="number" min="1" max="6" value="3">')}${field(T.bg,'<input data-bg type="color" value="#edf0f4">')}${field(T.light,'<input data-light type="range" min=".2" max="1.8" step=".05" value="1">')}<label><input data-transparent type="checkbox">${T.transparent}</label></div><button data-submit class="primary">${T.submit}</button><p class="cad-fine" data-render-hint role="status"></p><button data-refresh-jobs>${T.jobs} / \u5237\u65b0</button><div data-jobs role="status"></div></section></aside></div>`;
  const $=s=>root.querySelector(s),$$=s=>[...root.querySelectorAll(s)];
  const status=text=>{if(!destroyed)$('[data-save-status]').textContent=text;};
  function message(text,error=false){if(destroyed)return;const el=$('[data-message]');el.hidden=!text;el.textContent=text;el.classList.toggle('error',error);}
  function changed(geometry=false){dirty=true;epoch++;status(T.dirty);if(geometry){geometryEpoch++;modelReady=false;showBlocked(T.loading);scheduleAnalyze();}else scheduleTextures();}
  function snapshot(){if(editor)doc.objects=editor.serialize().objects;return copy(doc);}
  function remember(){if(!doc)return;const old=snapshot();old.objects=[];geomHistory.push(old);if(geomHistory.length>25)geomHistory.shift();$('[data-geom-undo]').disabled=false;}
  function run(fn){return async(...args)=>{try{await ready;return await fn(...args);}catch(e){message(e.message,true);}};}
  const ready=jsonFetch('/api/local/capabilities').then(()=>api('/capabilities')).then(c=>{if(c.library_scope==='local-account')storageNote='\u6a21\u578b\u5e93\u4fdd\u5b58\u5728\u672c\u5730\u78c1\u76d8\uff0c\u4e0e\u5f53\u524d\u672c\u5730\u8d26\u53f7\u5173\u8054\u3002\u8bf7\u5b9a\u671f\u5907\u4efd\u6570\u636e\u5377\u548c\u9879\u76eeJSON\u3002';return c;}).catch(e=>{message(e.message,true);throw e;});
  ready.catch(()=>{});
  ready.then(()=>refreshJobs()).catch(()=>{});
  function rawShape(f){return polygonD(f.polygon)+f.holes.map(h=>polygonD(h)).join('');}
  function artContent(state,{interactive=false}={}){return state.objects.filter(o=>!o.hidden).map(o=>objectMarkup(o,{interactive})).join('');}
  function canvasBase(){if(!doc.placement.visible||!analysis?.faces)return'';return `<g transform="matrix(${placementMatrix(doc.placement).join(' ')})" pointer-events="none">${analysis.faces.map(f=>`<path d="${rawShape(f)}" fill="${doc.background}" fill-rule="evenodd"/>`).join('')}</g>`;}
  function guides(state){
    if(!doc.placement.visible)return'';
    const s=doc.placement.scale,ps=doc.paths.filter(p=>p.role!=='ignore');
    return `<g transform="matrix(${placementMatrix(doc.placement).join(' ')})">${ps.map(p=>`<path d="${pathD(p)}" stroke="${roleColor[p.role]}" stroke-width="${(selectedPath===p.id?2.6:1)/s}" ${p.role==='crease'||p.role==='perf'?`stroke-dasharray="${4/s} ${3/s}"`:''} fill="none" pointer-events="none"/>${mode==='lines'?`<path data-cad-path="${p.id}" d="${pathD(p)}" stroke="transparent" stroke-width="${12/s}" fill="none" pointer-events="stroke"/>`:''}`).join('')}${state.showBleed?(analysis?.bleed||[]).map(r=>`<path d="${polygonD(r)}" fill="none" stroke="#2ea174" stroke-width="${.9/s}" stroke-dasharray="${3/s} ${2/s}" pointer-events="none"/>`).join(''):''}</g>`;
  }
  function designSVG(state){return `<svg xmlns="http://www.w3.org/2000/svg" width="${1180/doc.placement.scale}mm" height="${760/doc.placement.scale}mm" viewBox="0 0 1180 760"><title>${esc(doc.name)} - RGB artwork preview</title>${canvasBase()}${artContent(state)}${guides({...state,showBleed:true})}</svg>`;}
  function setupEditor(){
    layers?.destroy();editor?.destroy();renderer?.destroy();layers=editor=renderer=null;
    const adapter={label:T.scope,layout:()=>canvasPanelLayout(doc,analysis),artwork:(s,o)=>canvasBase()+artContent(s,o),guides,exportSVG:designSVG,
      pointerMove:(e,p)=>{if(!netDrag)return false;doc.placement.x=netDrag.x+p.x-netDrag.pt.x;doc.placement.y=netDrag.y+p.y-netDrag.pt.y;netDrag.moved=true;editor.refreshGeometry();return true;},
      pointerUp:()=>{if(!netDrag)return false;const moved=netDrag.moved;netDrag=null;if(moved){changed();params();}return true;},
      pointerDown:(e,pt)=>{if(mode==='net'&&!doc.placement.locked){remember();netDrag={x:doc.placement.x,y:doc.placement.y,pt,moved:false};e.currentTarget.setPointerCapture(e.pointerId);return true;}const id=e.target.closest('[data-cad-path]')?.dataset.cadPath;if(mode==='lines'&&id){selectedPath=id;$('[data-path]').value=id;pathProps();editor?.refreshGeometry();return true;}return false;}};
    editor=createPackagingEditor({mount:$('[data-editor]'),initial:{schemaVersion:4,objects:doc.objects,bg:doc.background},adapter,
      onChange:s=>{doc.objects=s.objects;changed();layers?.refresh();},onSelection:o=>{objectProps(o);layers?.refresh();}});
    layers=createLayerPanel({mount:$('[data-layer-panel]'),editor});
    renderer=createStructureRenderer($('[data-render]'),v=>view=v);$('[data-engine]').textContent=renderer.engine;
    renderer.setView(view,{exterior:doc.background,interior:'#e8ddc9'});
    if(analysis?.model){renderer.setModel(analysis.model);modelReady=true;}
    $('input[data-name]').value=doc.name;root.dataset.hasDoc='true';
  }
  function acceptDocument(next,info=null,record=null){
    stop();doc=copy(next);analysis=info;selectedPath=null;selectedHinge=null;epoch++;geometryEpoch++;documentEpoch++;geomHistory=[];
    libraryId=record?.id||null;version=record?.version||null;folder=record?.folder||'';tags=record?.tags||[];
    $('.cad-empty').hidden=true;$('.cad-workspace').hidden=false;$('[data-save]').disabled=false;$('[data-export]').disabled=false;
    dirty=!record;status(record?`${T.saved} v${version}`:T.dirty);$('[data-geom-undo]').disabled=true;
    setupEditor();refreshLeft();params();scheduleAnalyze(0);message('');
    run(refreshJobs)();
  }
  function scheduleAnalyze(delay=250){clearTimeout(anTimer);anTimer=setTimeout(()=>run(analyzeNow)(),delay);}
  function showBlocked(text){$('[data-preview-block]').hidden=false;$('[data-preview-block]').textContent=text;$('[data-submit]').disabled=true;$('[data-fold]').disabled=true;$('[data-opening]').disabled=true;$$('[data-play]').forEach(b=>b.disabled=true);}
  async function analyzeNow(){
    if(!doc||destroyed)return;const current=geometryEpoch;showBlocked(T.loading);const res=await api('/analyze',snapshot());
    if(destroyed||current!==geometryEpoch)return;
    analysis=res;modelReady=res.foldable;$('[data-summary]').textContent=`${res.stats.paths} ${T.path} / ${res.stats.faces} ${T.faces} / ${res.stats.hinges} ${T.hingeCount}`;
    $('[data-diagnostics]').innerHTML=`${res.errors.map(e=>`<p class="cad-error">${esc(e)}</p>`).join('')}${res.warnings.map(e=>`<p class="cad-warning">${esc(e)}</p>`).join('')}<p class="cad-fine">${res.angles_confirmed?T.confirmed:T.notConfirmed} / ${esc(JSON.stringify(res.stats))}</p>`;
    editor?.refreshGeometry();
    if(res.model){renderer.setModel(res.model);renderer.setView(view,{exterior:doc.background,interior:'#e8ddc9'});$('[data-preview-block]').hidden=true;$('[data-submit]').disabled=false;$('[data-fold]').disabled=false;const hasOpen=res.hinges.some(h=>Math.abs(h.openAngle)>.001);$('[data-opening]').disabled=!hasOpen;$$('[data-play]').forEach(b=>b.disabled=b.dataset.play==='open'&&!hasOpen);scheduleTextures();}
    else showBlocked(T.blocked);
    refreshHinges();syncRenderOptions();
  }
  function scheduleTextures(){clearTimeout(textureTimer);textureTimer=setTimeout(()=>run(updateTextures)(),220);}
  async function textures(){
    if(!modelReady||!analysis?.model)return{};const m=inverseMatrix(placementMatrix(doc.placement)),state=editor.serialize(),arts=artContent(state);const out={};
    // Baking through the inverse placement keeps artwork registered after moving/rotating the net.
    const edge=analysis.model.panels.length>40?256:384;
    for(const p of analysis.model.panels){const[x0,y0,x1,y1]=p.bounds,w=x1-x0,h=y1-y0;
      const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${edge}" height="${edge}" viewBox="${x0} ${y0} ${w} ${h}" preserveAspectRatio="none"><rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="${doc.background}"/><g transform="matrix(${m.join(' ')})">${arts}</g></svg>`;
      const c=await svgToCanvas(svg,edge,edge);out[p.id]=c.toDataURL('image/png');
    }return out;
  }
  async function updateTextures(){if(!doc||!modelReady||!renderer)return;const seq=++texEpoch,current=epoch,out=await textures();if(destroyed||seq!==texEpoch||current!==epoch)return;await renderer.setTextures(out);}
  function refreshLeft(){
    const groups=new Map();doc.paths.forEach(p=>{if(!groups.has(p.group))groups.set(p.group,{group:p.group,label:p.layer,color:p.color,roles:new Set(),count:0});const g=groups.get(p.group);g.roles.add(p.role);g.count++;});
    $('[data-groups]').innerHTML=[...groups.values()].map(g=>`<label class="cad-map-row"><span title="${esc(g.group)}">${esc(g.label)} <small>ACI ${g.color} / ${g.count}</small></span>${roleSelect(`data-map="${esc(g.group)}"`,g.roles.size===1?[...g.roles][0]:'unassigned')}</label>`).join('');
    $$('[data-map]').forEach(e=>e.onchange=()=>{remember();doc.paths.filter(p=>p.group===e.dataset.map).forEach(p=>p.role=e.value);changed(true);refreshLeft();editor.refreshGeometry();});
    $('[data-path]').innerHTML='<option value="">--</option>'+doc.paths.map(p=>option(p.id,`${p.id} ${p.type} ${T[p.role]}`,selectedPath)).join('');pathProps();
  }
  function pathProps(){
    const p=doc.paths.find(p=>p.id===selectedPath);if(!p){$('[data-path-props]').innerHTML='';return;}
    const xy=(k,label)=>`<div class="cad-fields">${field(label+' X',`<input type="number" data-pathkey="${k}.0" value="${p[k][0]}" step=".01">`)}${field(label+' Y',`<input type="number" data-pathkey="${k}.1" value="${p[k][1]}" step=".01">`)}</div>`;
    $('[data-path-props]').innerHTML=`<h4>${p.id} / ${p.type}</h4>${field(T.path,roleSelect('data-line-role',p.role))}${p.type==='LINE'?xy('a',T.startPoint)+xy('b',T.endPoint):xy('center',T.center)+field(T.radius,`<input data-pathkey="radius" type="number" step=".01" min=".001" value="${p.radius}">`)+(p.type==='ARC'?field(T.from,`<input data-pathkey="start" type="number" value="${p.start}">`)+field(T.sweep,`<input data-pathkey="sweep" type="number" min=".001" max="360" value="${p.sweep}">`):'')}<button data-path-apply>${T.apply}</button>`;
    $('[data-path-apply]').onclick=run(async()=>{const before=snapshot(),next=copy(p);$$('[data-pathkey]').forEach(el=>{const[k,j]=el.dataset.pathkey.split('.');if(j!==undefined)next[k][Number(j)]=num(el.value);else next[k]=num(el.value);});next.role=$('[data-line-role]').value;
      const candidate=snapshot();candidate.paths=candidate.paths.map(x=>x.id===p.id?next:x);await api('/validate',candidate);geomHistory.push(before);doc.paths=candidate.paths;changed(true);refreshLeft();editor.refreshGeometry();$('[data-geom-undo]').disabled=false;});
  }
  function params(){if(!doc)return;const o=doc.options,p=doc.placement,b=pathBounds(doc.paths);
    $('[data-params]').innerHTML=`<h3>${T.param}</h3><div class="cad-fields">${field(T.material,`<select data-option="material">${['paperboard','kraft','corrugated'].map((v,i)=>option(v,[T.paper,T.kraft,T.corrugated][i],o.material)).join('')}</select>`)}${field(T.thickness+' mm',`<input data-option="thickness" type="number" value="${o.thickness}" min="0" max="5" step=".05">`)}${field(T.bleed+' mm',`<input data-option="bleed" type="number" value="${o.bleed}" min="0" max="20" step=".1">`)}${field(T.allowance+' mm',`<input data-option="fold_allowance" type="number" value="${o.fold_allowance}" min="-10" max="10" step=".1">`)}${field(T.precision+' mm',`<input data-option="curve_tolerance" type="number" value="${o.curve_tolerance}" min=".005" max="1" step=".005">`)}${field(T.snap+' mm',`<input data-option="snap_tolerance" type="number" value="${o.snap_tolerance}" min="0" max=".5" step=".01">`)}</div><button data-apply-options>${T.apply}</button><p class="cad-fine">${T.materialNote}</p>
    <details><summary>${T.resize}</summary><div class="cad-fields">${field(T.width+' mm','<input data-resize-x type="number" min=".01" step=".01" value="'+(b[2]-b[0]).toFixed(3)+'">')}${field(T.height+' mm','<input data-resize-y type="number" min=".01" step=".01" value="'+(b[3]-b[1]).toFixed(3)+'">')}</div><label><input data-uniform type="checkbox" checked>${T.uniform}</label><button data-resize>${T.apply}</button><p class="cad-fine">${T.resizeNote}</p></details>
    <details><summary>${T.placement}</summary><div class="cad-fields">${field('X',input('x',p.x))}${field('Y',input('y',p.y))}${field(T.angle,input('rotation',p.rotation))}${field(T.scale,input('scale',p.scale,'number','step=".01" min=".0001"'))}</div><label><input data-net-lock type="checkbox" ${p.locked?'checked':''}>\u9501\u5b9a</label><label><input data-net-visible type="checkbox" ${p.visible?'checked':''}>${T.visible}</label><button data-placement>${T.apply}</button><p class="cad-fine">px / mm; ${T.scope}</p></details><details open><summary>${T.hinges}</summary><div data-hinge-props></div></details>`;
    $('[data-apply-options]').onclick=run(async()=>{const next=snapshot();$$('[data-option]').forEach(el=>next.options[el.dataset.option]=el.dataset.option==='material'?el.value:num(el.value));await api('/validate',next);remember();doc.options=next.options;changed(true);});
    $('[data-placement]').onclick=run(async()=>{const next=snapshot();$$('[data-param]').forEach(el=>next.placement[el.dataset.param]=num(el.value));next.placement.visible=$('[data-net-visible]').checked;next.placement.locked=$('[data-net-lock]').checked;await api('/validate',next);remember();doc.placement=next.placement;changed();editor.refreshGeometry();});
    $('[data-resize-x]').onchange=()=>{if($('[data-uniform]').checked)$('[data-resize-y]').value=(num($('[data-resize-x]').value)*(b[3]-b[1])/(b[2]-b[0])).toFixed(4);};
    $('[data-resize-y]').onchange=()=>{if($('[data-uniform]').checked)$('[data-resize-x]').value=(num($('[data-resize-y]').value)*(b[2]-b[0])/(b[3]-b[1])).toFixed(4);};
    $('[data-resize]').onclick=run(async()=>{const sx=num($('[data-resize-x]').value)/(b[2]-b[0]),sy=$('[data-uniform]').checked?sx:num($('[data-resize-y]').value)/(b[3]-b[1]),res=await api('/scale',{document:snapshot(),x:sx,y:sy});remember();doc=res.document;doc.placement=fittedPlacement(doc.paths);changed(true);refreshLeft();params();editor.refreshGeometry();});refreshHinges();
  }
  function refreshHinges(){const host=$('[data-hinge-props]');if(!host||!analysis)return;
    selectedHinge=analysis.hinges.some(h=>h.id===selectedHinge)?selectedHinge:analysis.hinges[0]?.id;const h=analysis.hinges.find(h=>h.id===selectedHinge);
    host.innerHTML=field(T.root,`<select data-root>${analysis.faces.map((f,i)=>option(f.id,`${i+1}: ${f.id}`,analysis.root)).join('')}</select>`)+(!h?`<p class="cad-fine">${T.blocked}</p>`:field(T.hinge,`<select data-hinge>${analysis.hinges.map((x,i)=>option(x.id,`${i+1}: ${x.child}`,h.id)).join('')}</select>`)+`<div class="cad-fields">${field(T.foldAngle,`<input data-hangle type="number" min="-180" max="180" value="${h.angle}">`)}${field(T.openAngle,`<input data-hopen type="number" min="-180" max="180" value="${h.openAngle}">`)}${field(T.from,`<input data-hstart type="number" min="0" max=".99" step=".05" value="${h.stage[0]}">`)}${field(T.to,`<input data-hend type="number" min=".01" max="1" step=".05" value="${h.stage[1]}">`)}</div><button data-happly>${T.apply}</button><button data-hconfirm>${T.confirmAngles}</button><p class="cad-fine">${analysis.angles_confirmed?T.confirmed:T.notConfirmed}</p>`);
    $('[data-root]').onchange=()=>{remember();doc.options.root=$('[data-root]').value;doc.hinges={};changed(true);};
    if(h){$('[data-hinge]').onchange=()=>{selectedHinge=$('[data-hinge]').value;refreshHinges();};$('[data-happly]').onclick=run(async()=>{const next=snapshot();next.hinges[h.id]={angle:num($('[data-hangle]').value),openAngle:num($('[data-hopen]').value),stage:[num($('[data-hstart]').value),num($('[data-hend]').value)],confirmed:true};await api('/validate',next);remember();doc.hinges=next.hinges;changed(true);});
      $('[data-hconfirm]').onclick=()=>{remember();for(const h of analysis.hinges)doc.hinges[h.id]={angle:h.angle,openAngle:h.openAngle,stage:h.stage,confirmed:true};changed(true);};}
  }
  let objectId=null;
  function objectProps(o){
    const host=$('[data-object-props]');if(!o){host.innerHTML=`<p class="cad-fine">${T.propertiesHint}</p>`;objectId=null;return;}
    if(objectId===o.id&&host.querySelector('[data-obj]')){for(const el of host.querySelectorAll('[data-obj]')){if(el!==document.activeElement){if(el.type==='checkbox')el.checked=!!o[el.dataset.obj];else el.value=o[el.dataset.obj]??'';}}return;}
    objectId=o.id;host.innerHTML=`<h3>${T.props}</h3>${field(T.objectName,`<input data-obj="name" value="${esc(o.name||'')}" maxlength="100">`)}${o.type==='text'?field(T.text,`<textarea data-obj="text">${esc(o.text)}</textarea>`):''}<div class="cad-fields">${['x','y','w','h','rotation','opacity'].map(k=>field({w:T.width,h:T.height,rotation:T.angle,opacity:T.opacity}[k]||k,`<input data-obj="${k}" type="number" step="${k==='opacity'?'.05':'1'}" value="${o[k]??(k==='opacity'?1:0)}">`)).join('')}${o.type==='text'?field(T.fontSize,`<input data-obj="fontSize" type="number" min="1" max="500" value="${o.fontSize||24}">`):''}${o.type!=='image'?field(T.color,`<input data-obj="fill" type="color" value="${o.fill||'#222222'}">`):''}</div>${o.type==='text'?`<div class="cad-row"><button data-bold><b>B</b></button><button data-italic><i>I</i></button><select data-obj="align">${choices(['left','center','right'],o.align||'center')}</select></div>`:o.type==='image'?`<label><input data-obj="flipX" type="checkbox" ${o.flipX?'checked':''}>${T.flipX}</label><label><input data-obj="flipY" type="checkbox" ${o.flipY?'checked':''}>${T.flipY}</label>`:''}<div class="cad-row"><button data-object-copy>${T.copy}</button><button data-object-delete>${T.delete}</button></div>`;
    host.querySelectorAll('[data-obj]').forEach(el=>el.onchange=()=>editor.updateSelected({[el.dataset.obj]:el.type==='checkbox'?el.checked:el.type==='number'?num(el.value):el.value}));
    if(host.querySelector('[data-bold]')){host.querySelector('[data-bold]').onclick=()=>editor.updateSelected({fontWeight:editor.getSelected().fontWeight===700?400:700});host.querySelector('[data-italic]').onclick=()=>editor.updateSelected({italic:!editor.getSelected().italic});}
    host.querySelector('[data-object-copy]').onclick=()=>editor.duplicateSelected();host.querySelector('[data-object-delete]').onclick=()=>editor.removeSelected();
  }
  function dialog(title,body,wide=false){
    closeDialog();modalReturnFocus=document.activeElement;const wrap=document.createElement('div');wrap.className='cad-modal-backdrop';wrap.innerHTML=`<section class="cad-modal ${wide?'wide':''}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><h2>${title}</h2><button data-modal-close aria-label="${T.close}">\u00d7</button></header><div class="cad-modal-body">${body}</div><p class="cad-modal-error" role="alert" hidden></p></section>`;
    root.append(wrap);modal=wrap;const controller=new AbortController();modalController=controller;wrap.querySelector('[data-modal-close]').onclick=closeDialog;
    wrap.addEventListener('click',e=>{if(e.target===wrap)closeDialog();});
    wrap.addEventListener('keydown',e=>modalKeydown(e,wrap,closeDialog));wrap.querySelector('button')?.focus();
    const M=s=>wrap.querySelector(s),err=e=>{M('.cad-modal-error').hidden=false;M('.cad-modal-error').textContent=e.message||str(e);};
    return{wrap,M,err,valid:()=>modal===wrap&&!controller.signal.aborted};
  }
  function closeDialog(){const back=modalReturnFocus;modalController?.abort();modal?.remove();modal=null;modalController=null;modalReturnFocus=null;if(!destroyed&&back?.isConnected)back.focus({preventScroll:true});}
  function importDialog(file=null){
    let selected=null,parsed=null,confirmation=0;
    const gate=createRequestGate();
    const D=dialog(T.import,`<div class="cad-steps"><strong>${T.step1}</strong><span>${T.step2}</span><span>${T.step3}</span></div><div class="cad-drop" data-drop tabindex="0" role="button"><b>DXF</b><strong>${T.drop}</strong><p data-filename>${T.importNote}</p><input type="file" data-file accept=".dxf" hidden></div><div class="cad-fields">${field(T.unit,`<select data-unit>${option('auto',T.auto,'auto')}${choices(['mm','cm','m','in'],'auto')}</select>`)}${field(T.precision+' mm','<input type="number" data-tolerance value=".08" min=".005" max="1" step=".005">')}${field(T.encoding,`<select data-encoding aria-label="${T.encoding}">${option('auto',T.encodingAuto,'auto')}${['utf-8','gbk','cp950','cp1252','cp932','cp949'].map((v,i)=>option(v,['UTF-8','GBK (ANSI_936)','Big5 (ANSI_950)','Western (ANSI_1252)','Japanese (ANSI_932)','Korean (ANSI_949)'][i],'auto')).join('')}</select>`) }</div><button class="primary" data-parse>${T.next}</button><p class="cad-fine" data-import-state role="status"></p><div data-import-preview hidden></div>`,true);
    const{M,err,valid}=D;
    function invalidate(){
      gate.invalidate();confirmation++;parsed=null;
      const preview=M('[data-import-preview]');preview.hidden=true;preview.replaceChildren();
      M('[data-parse]').disabled=false;M('.cad-modal-error').hidden=true;
      M('[data-import-state]').textContent='\u6587\u4ef6\u6216\u53c2\u6570\u5df2\u53d8\u66f4\uff0c\u8bf7\u91cd\u65b0\u89e3\u6790\u4e0e\u9884\u89c8\u3002';
    }
    function setFile(f){
      if(!f)return;invalidate();selected=null;M('[data-filename]').textContent=f.name;
      if(!/\.dxf$/i.test(f.name)){err(Error('DXF only'));return;}
      if(f.size>5*1024*1024){err(Error('DXF exceeds 5 MiB'));return;}selected=f;
    }
    M('[data-file]').onchange=e=>setFile(takeSelectedFile(e.target));
    const pick=()=>openFileInput(M('[data-file]'),err);
    M('[data-drop]').onclick=pick;M('[data-file]').onclick=e=>e.stopPropagation();
    M('[data-drop]').onkeydown=e=>{if(!isComposingEvent(e)&&(e.key==='Enter'||e.key===' ')){e.preventDefault();if(!e.repeat)pick();}};
    M('[data-drop]').ondragover=e=>{e.preventDefault();M('[data-drop]').classList.add('over');};
    M('[data-drop]').ondragleave=()=>M('[data-drop]').classList.remove('over');
    M('[data-drop]').ondrop=e=>{e.preventDefault();M('[data-drop]').classList.remove('over');setFile(e.dataTransfer.files[0]);};
    // Any parameter edit invalidates the old preview, even while a request is in flight.
    for(const attr of ['data-unit','data-tolerance','data-encoding']){
      M('['+attr+']').addEventListener('input',invalidate);
      M('['+attr+']').addEventListener('change',invalidate);
    }
    M('[data-parse]').onclick=async()=>{
      if(!selected){err(Error(T.choose));return;}
      if(!M('[data-tolerance]').reportValidity())return;
      const source=selected,unit=M('[data-unit]').value,tolerance=num(M('[data-tolerance]').value),encoding=M('[data-encoding]').value;
      const ticket=gate.begin();confirmation++;parsed=null;
      M('[data-parse]').disabled=true;M('.cad-modal-error').hidden=true;
      M('[data-import-preview]').hidden=true;M('[data-import-preview]').replaceChildren();
      M('[data-import-state]').textContent=T.loading;
      const current=()=>valid()&&gate.isCurrent(ticket);
      try{
        await ready;if(!current())return;
        const bytes=new Uint8Array(await source.arrayBuffer());if(!current())return;
        const result=await api('/import',{filename:source.name,data:toBase64(bytes),unit,encoding,curve_tolerance:tolerance});
        if(!current())return;parsed=result;
        M('[data-import-state]').textContent=source.name+' / '+result.document.source_unit+' / '+tolerance+' mm'+(result.encoding_info?' / '+result.encoding_info.encoding:'');
        const div=M('[data-import-preview]');div.hidden=false;
        div.innerHTML=`<div class="cad-import-columns"><div class="cad-import-drawing">${thumbnail(result.document.paths)}</div><section><h3>${T.mapping}</h3>${result.groups.map(g=>`<label class="cad-map-row"><span>${esc(g.layer)} / ACI ${g.color}<small>${g.count} ${T.path}</small></span>${roleSelect(`data-import-map="${esc(g.group)}"`,g.role)}</label>`).join('')}<p class="cad-fine">${esc(JSON.stringify(result.stats))}</p></section></div><div data-import-warnings>${result.warnings.map(w=>`<p class="cad-warning">${esc(w)}</p>`).join('')}</div><button data-import-confirm class="primary">${T.confirmImport}</button>`;
        const confirmButton=M('[data-import-confirm]');
        for(const el of div.querySelectorAll('[data-import-map]'))el.onchange=()=>{confirmation++;confirmButton.disabled=false;};
        confirmButton.onclick=async()=>{
          if(!current()||parsed!==result)return;
          if(dirty&&!confirm(T.replace))return;
          const commit=++confirmation;confirmButton.disabled=true;
          try{
            const candidate=copy(result.document);
            for(const el of div.querySelectorAll('[data-import-map]'))candidate.paths.filter(p=>p.group===el.dataset.importMap).forEach(p=>p.role=el.value);
            if(incoming)candidate.objects=copy(incoming);
            const validated=await api('/validate',candidate);
            if(!current()||commit!==confirmation)return;
            closeDialog();incoming=null;acceptDocument(validated.document);
          }catch(e){if(current()&&commit===confirmation)err(e);}
          finally{if(current()&&commit===confirmation)confirmButton.disabled=false;}
        };
      }catch(e){if(current()){M('[data-import-state]').textContent='';err(e);}}
      finally{if(current())M('[data-parse]').disabled=false;}
    };
    if(file)setFile(file);
  }
  async function openExample(){if(dirty&&!confirm(T.replace))return;const r=await jsonFetch('/api/local/dieline/dxf',{kind:'tuck',length:100,width:65,height:140}),text=await r.text();const f=new File([text],'local-example-tuck.dxf',{type:'application/dxf'});importDialog(f);}
  async function openJSON(file){if(file.size>10*1024*1024)throw Error('Project exceeds 10 MiB');const value=JSON.parse(await file.text());if(dirty&&!confirm(T.replace))return;const next=await api('/validate',value);acceptDocument(next.document);}
  function chooseJSON(){openFileInput($('[data-json-file]'),e=>message(e.message,true));}
  function saveDialog(asCopy=false){
    if(!doc)return;const{M,err,valid}=dialog(T.save,`${field(T.name,'<input data-save-name maxlength="120" value="'+esc(doc.name)+'">')}${field(T.folder,'<input data-save-folder maxlength="240" value="'+esc(folder)+'" placeholder="Project / Category">')}${field(T.tags,'<input data-save-tags value="'+esc(tags.join(', '))+'" placeholder="tag1, tag2">')}<p class="cad-fine">${storageNote}</p><div class="cad-row"><button data-confirm-save class="primary">${asCopy?T.saveCopy:T.save}</button>${libraryId&&!asCopy?`<button data-save-new>${T.saveCopy}</button>`:''}</div>`);
    const submit=async(forceCopy=false)=>{try{M('[data-confirm-save]').disabled=true;const data=snapshot();data.name=M('[data-save-name]').value.trim();const f=M('[data-save-folder]').value.trim(),ts=M('[data-save-tags]').value.split(',').map(x=>x.trim()).filter(Boolean),mid=forceCopy||asCopy?null:libraryId,current=epoch,docSeq=documentEpoch;
      const record=await api('/library'+(mid?'/'+mid:''),{document:data,folder:f,tags:ts,expected_version:mid?version:null},mid?'PUT':'POST');
      if(destroyed||docSeq!==documentEpoch)return;libraryId=record.id;version=record.version;folder=record.folder;tags=record.tags;
      if(epoch===current){doc.name=record.document.name;$('[data-name]').value=doc.name;dirty=false;status(`${T.saved} v${version}`);}else status(T.dirty);
      if(valid())closeDialog();message(T.saved+' / '+record.id);
    }catch(e){if(valid()){err(e);M('[data-confirm-save]').disabled=false;}}};M('[data-confirm-save]').onclick=()=>submit();if(M('[data-save-new]'))M('[data-save-new]').onclick=()=>submit(true);
  }
  function libraryDialog(){
    const{M,err,valid}=dialog(T.library,`<div class="cad-library-tools"><input data-lib-search placeholder="${T.search}"><select data-lib-folder><option value="">${T.all}</option></select><button data-lib-go>${T.search}</button><button data-lib-json>${T.openJson}</button></div><p class="cad-fine">${storageNote}</p><div data-lib-grid class="cad-lib-grid"></div><div class="cad-row"><button data-lib-prev>${T.prev}</button><span data-lib-page></span><button data-lib-next>${T.more}</button></div>`,true);
    let page=1,seq=0;async function load(){try{await ready;const id=++seq,data=await api('/library?'+new URLSearchParams({q:M('[data-lib-search]').value,folder:M('[data-lib-folder]').value,page:str(page),page_size:'12'}));if(!valid()||id!==seq)return;
      const selected=M('[data-lib-folder]').value;M('[data-lib-folder]').innerHTML=option('',T.all,selected)+data.folders.map(f=>option(f,f,selected)).join('');
      M('[data-lib-page]').textContent=`${page} / ${Math.max(1,Math.ceil(data.total/12))} (${data.total})`;M('[data-lib-prev]').disabled=page<=1;M('[data-lib-next]').disabled=page*12>=data.total;
      M('[data-lib-grid]').innerHTML=data.items.length?data.items.map(r=>`<article class="cad-lib-card" draggable="true" data-lib-id="${r.id}" data-version="${r.version}"><div class="cad-lib-thumb">${thumbnail(r.thumbnail_paths)}</div><b>${esc(r.name)}</b><small>${esc(r.folder)} / v${r.version} / ${r.path_count} ${T.path}</small><small>${r.tags.map(esc).join(' / ')}</small><div class="cad-row"><button data-lib-load="${r.id}">${T.load}</button><button data-lib-delete="${r.id}" data-version="${r.version}">${T.delete}</button></div></article>`).join(''):`<p>${T.emptyLib}</p>`;
      M('[data-lib-grid]').querySelectorAll('[data-lib-load]').forEach(b=>b.onclick=()=>loadRecord(b.dataset.libLoad,err));
      M('[data-lib-grid]').querySelectorAll('[data-lib-delete]').forEach(b=>b.onclick=async()=>{if(!confirm(T.delete+'?'))return;try{await api('/library/'+b.dataset.libDelete+'?version='+b.dataset.version,{},'DELETE');await load();}catch(e){err(e);}});
      M('[data-lib-grid]').querySelectorAll('[data-lib-id]').forEach(card=>card.ondragstart=e=>{e.dataTransfer.setData('application/x-bxh-cad',card.dataset.libId);e.dataTransfer.effectAllowed='copy';setTimeout(()=>{if(valid())closeDialog();},150);});
    }catch(e){if(valid())err(e);}}
    M('[data-lib-go]').onclick=()=>{page=1;load();};M('[data-lib-search]').onkeydown=e=>{if(e.key==='Enter'){page=1;load();}};M('[data-lib-folder]').onchange=()=>{page=1;load();};M('[data-lib-prev]').onclick=()=>{page--;load();};M('[data-lib-next]').onclick=()=>{page++;load();};M('[data-lib-json]').onclick=()=>{closeDialog();chooseJSON();};load();
  }
  async function loadRecord(id,onError=e=>message(e.message,true)){try{if(dirty&&!confirm(T.replace))return;const record=await api('/library/'+encodeURIComponent(id));if(destroyed)return;closeDialog();acceptDocument(record.document,null,record);}catch(e){onError(e);}}
  function exportDialog(){if(!doc)return;const{M,err,valid}=dialog(T.export,`<p class="cad-fine">${T.scope}</p><div class="cad-export-grid"><button data-out="json">${T.json}</button><button data-out="dxf">${T.dxfExport}</button><button data-out="svg">${T.structSvg}</button><button data-out="artwork">${T.svg}</button></div>`);
    for(const b of M('.cad-export-grid').querySelectorAll('button'))b.onclick=async()=>{try{b.disabled=true;const kind=b.dataset.out;if(kind==='json'){const d=await api('/validate',snapshot());blobDownload(new Blob([JSON.stringify(d.document,null,2)],{type:'application/json'}),'dieline-project.json');}else if(kind==='artwork')blobDownload(new Blob([editor.exportSVG()],{type:'image/svg+xml'}),'dieline-artwork-preview.svg');else{const r=await jsonFetch(API+'/export/'+kind,snapshot());blobDownload(await r.blob(),'dieline-review.'+kind);}}catch(e){if(valid())err(e);}finally{if(valid())b.disabled=false;}};
  }
  function stop(){cancelAnimationFrame(frame);frame=0;playing=null;}
  function play(type){stop();if(!modelReady)return;playing=type;const start=performance.now();view.framing='motion';function step(now){if(destroyed||!modelReady||playing!==type)return;const t=Math.min(1,(now-start)/3000);if(type==='fold'){view.fold=t;view.opening=0;}else{view.fold=1;view.opening=t;}$('[data-fold]').value=view.fold;$('[data-opening]').value=view.opening;renderer.setView(view,{exterior:doc.background,interior:'#e8ddc9'});if(t<1)frame=requestAnimationFrame(step);else stop();}frame=requestAnimationFrame(step);}
  function syncRenderOptions(){
    const values=normalizeCadRenderOptions({format:$('[data-format]').value,long_edge:num($('[data-edge]').value),seconds:num($('[data-seconds]').value),fps:12,transparent:$('[data-transparent]').checked});
    for(const op of $('[data-edge]').options)op.disabled=values.animation&&Number(op.value)>1024;
    $('[data-edge]').value=String(values.long_edge);$('[data-seconds]').value=String(values.seconds);
    $('[data-seconds]').max=String(values.maxSeconds);$('[data-seconds]').disabled=!values.animation;
    $('[data-motion]').disabled=!values.animation;
    $('[data-transparent]').disabled=!values.allowTransparency;$('[data-transparent]').checked=values.transparent;
    view.transparent=values.transparent;
    const openOption=$('[data-motion] option[value="open"]');
    const hasOpening=Boolean(analysis?.hinges?.some(h=>Math.abs(h.openAngle)>1e-5));
    openOption.disabled=!hasOpening;
    if(!hasOpening&&$('[data-motion]').value==='open')$('[data-motion]').value='fold';
    $('[data-render-hint]').textContent=values.animation
      ? '\u52a8\u753b\u957f\u8fb9\u4e0d\u8d85\u8fc7 1024px\uff0c\u6700\u591a 120 \u5e27\u3002'+(values.allowTransparency?'\u900f\u660e\u52a8\u753b\u5bfc\u51fa PNG \u5e27\u5e8f\u5217\u3002':'MP4 / WebM \u4f7f\u7528\u4e0d\u900f\u660e\u80cc\u666f\u3002')
      : '\u9759\u6001 PNG \u652f\u6301\u900f\u660e\u80cc\u666f\uff0c\u957f\u8fb9\u6700\u9ad8 4096px\u3002';
    if(renderer)renderer.setView(view,{exterior:doc?.background,interior:'#e8ddc9'});
    return values;
  }
  async function submitJob(){
    if(!doc||!modelReady)throw Error(T.blocked);stop();
    const opts=syncRenderOptions(),current=epoch,d=snapshot(),savedView=copy(view);
    const aspect=$('[data-aspect]').value,motion=$('[data-motion]').value;
    $('[data-submit]').disabled=true;
    try{
      const tex=await textures();if(destroyed||current!==epoch)throw Error(T.returnLatest);
      const req={cad_document:d,textures:tex,view:savedView,exterior:d.background,format:opts.format,long_edge:opts.long_edge,aspect,motion,seconds:opts.seconds,fps:opts.fps};
      const job=await api('/jobs',req);message(T.jobs+' / '+job.id);await refreshJobs();
    }finally{if(!destroyed)$('[data-submit]').disabled=!modelReady;}
  }
  async function refreshJobs(){
    if(destroyed)return;clearTimeout(jobTimer);const ticket=jobsGate.begin();
    const current=()=>!destroyed&&jobsGate.isCurrent(ticket);
    try{
      const r=await jsonFetch('/api/local/jobs'),data=await r.json();if(!current())return;jobsRetry=0;
      $('[data-jobs]').innerHTML=data.items.length?data.items.slice(0,8).map(j=>`<div class="cad-job" data-job="${esc(j.id)}"><strong>${esc(j.id.slice(0,8))} / ${esc(j.format)}</strong><small>${esc(j.status)} ${Number(j.progress)||0}%</small>${j.error?`<p class="cad-error">${esc(j.error)}</p>`:''}${j.download?`<a href="${esc(j.download)}" download>${T.download}</a>`:''}${['running','queued'].includes(j.status)?`<button data-cancel-job="${esc(j.id)}">${T.cancel}</button>`:`<button data-delete-job="${esc(j.id)}">${T.delete}</button>`}</div>`).join(''):'<p class="cad-fine">\u5f53\u524d\u4f1a\u8bdd\u6682\u65e0\u672c\u5730\u6e32\u67d3\u4efb\u52a1\u3002</p>';
      $$('[data-cancel-job]').forEach(b=>b.onclick=run(async()=>{await jsonFetch('/api/local/jobs/'+b.dataset.cancelJob+'/cancel',{});await refreshJobs();}));
      $$('[data-delete-job]').forEach(b=>b.onclick=run(async()=>{await jsonFetch('/api/local/jobs/'+b.dataset.deleteJob,{},'DELETE');await refreshJobs();}));
      if(data.items.some(j=>['running','queued'].includes(j.status)))jobTimer=setTimeout(refreshJobs,900);
    }catch(e){
      if(!current())return;
      $('[data-jobs]').innerHTML=`<p class="cad-error">${esc(e.message)} / \u8bf7\u5237\u65b0\u4efb\u52a1\u5217\u8868</p>`;
      if(++jobsRetry<=3)jobTimer=setTimeout(refreshJobs,Math.min(8000,1000*2**jobsRetry));
    }
  }
  $('[data-back]').onclick=()=>{if(!dirty||confirm(T.replace)){onBack();}};
  $('[data-import]').onclick=()=>importDialog();$('[data-empty-import]').onclick=()=>importDialog();$('[data-example]').onclick=run(openExample);$('[data-json-open]').onclick=chooseJSON;
  $('[data-json-file]').onchange=e=>{const file=takeSelectedFile(e.target);if(file)run(()=>openJSON(file))();};
  $('[data-library]').onclick=libraryDialog;$('[data-save]').onclick=()=>saveDialog();$('[data-export]').onclick=exportDialog;
  $('[data-name]').onchange=e=>{if(doc){doc.name=e.target.value.trim()||'DXF';changed();}};
  $('[data-analysis]').onclick=run(analyzeNow);$('[data-fit]').onclick=()=>{if(doc){remember();doc.placement=fittedPlacement(doc.paths);changed();params();editor.refreshGeometry();editor.fitToView();}};
  $('[data-clean]').onclick=run(async()=>{if(!confirm(T.splitWarning))return;const r=await api('/cleanup',snapshot());remember();doc=r.document;changed(true);refreshLeft();params();editor.refreshGeometry();});
  $('[data-geom-undo]').onclick=()=>{const previous=geomHistory.pop();if(!previous)return;previous.objects=editor.serialize().objects;doc=previous;changed(true);refreshLeft();params();editor.refreshGeometry();$('[data-geom-undo]').disabled=!geomHistory.length;};
  $('[data-path]').onchange=e=>{selectedPath=e.target.value;pathProps();editor?.refreshGeometry();};
  $('[data-add-line]').onclick=()=>{if(!doc)return;remember();const id='manual_'+Date.now();doc.paths.push({id,type:'LINE',role:'unassigned',layer:'MANUAL',group:'MANUAL|7',color:7,source:'manual',a:[0,0],b:[10,0],center:[0,0],radius:1,start:0,sweep:90});selectedPath=id;changed(true);refreshLeft();editor.refreshGeometry();};
  $$('[data-mode]').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;$$('[data-mode]').forEach(el=>el.classList.toggle('active',el===b));root.dataset.mode=mode;if(mode==='net'){$('[data-right-tab="params"]').click();const detail=$('[data-placement]')?.closest('details');if(detail)detail.open=true;}editor?.refreshGeometry();});
  $$('[data-tab]').forEach(b=>b.onclick=()=>{$('.cad-workspace').dataset.tabActive=b.dataset.tab;setTimeout(()=>{editor?.fitToView();renderer?.draw();},20);});
  $$('[data-right-tab]').forEach(b=>b.onclick=()=>{$('[data-params]').hidden=b.dataset.rightTab!=='params';$('[data-object-props]').hidden=b.dataset.rightTab!=='object';$$('[data-right-tab]').forEach(el=>el.classList.toggle('active',el===b));});
  $$('[data-add]').forEach(b=>b.onclick=()=>{if(!editor)return;mode='draw';root.dataset.mode=mode;$$('[data-mode]').forEach(el=>el.classList.toggle('active',el.dataset.mode===mode));const k=b.dataset.add;
    if(k==='image'){openFileInput($('[data-image]'),e=>message(e.message,true));return;}
    run(async()=>{if(k==='text')editor.addText(T.text);else if(k==='shape')editor.addRect();else{const value=prompt(T[k],k==='barcode'?'123456789012':'LOCAL-DESIGN');if(value===null)return;const url=k==='qr'?'/api/tools/qrcode.svg?value=':'/api/tools/barcode.svg?symbology=CODE128&value=';const r=await jsonFetch(url+encodeURIComponent(value)),svg=await r.text();editor.addImage('data:image/svg+xml;base64,'+toBase64(new TextEncoder().encode(svg)));}
    $('[data-right-tab="object"]').click();})();});
  $('[data-image]').onchange=e=>{const f=takeSelectedFile(e.target),targetEditor=editor,docSeq=documentEpoch;if(!f)return;run(async()=>{const src=await fileToImage(f);if(destroyed||documentEpoch!==docSeq||editor!==targetEditor)return;editor.addImage(typeof src==='string'?src:src.src);$('[data-right-tab="object"]').click();})();};
  for(const [attr,k]of [['data-fold','fold'],['data-opening','opening']])$('['+attr+']').oninput=e=>{stop();view[k]=num(e.target.value);view.framing='pose';renderer?.setView(view,{exterior:doc.background,interior:'#e8ddc9'});};
  $$('[data-play]').forEach(b=>b.onclick=()=>play(b.dataset.play));$('[data-stop]').onclick=stop;
  $('[data-light]').oninput=e=>{view.light=num(e.target.value);renderer?.setView(view,{exterior:doc?.background,interior:'#e8ddc9'});};$('[data-bg]').oninput=e=>{view.background=e.target.value;renderer?.setView(view,{exterior:doc?.background,interior:'#e8ddc9'});};$('[data-transparent]').onchange=syncRenderOptions;
  $('[data-submit]').onclick=run(submitJob);
  for(const attr of ['data-format','data-edge','data-seconds'])$('['+attr+']').onchange=syncRenderOptions;
  $('[data-refresh-jobs]').onclick=run(refreshJobs);
  syncRenderOptions();
  root.addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('application/x-bxh-cad'))e.preventDefault();});root.addEventListener('drop',e=>{const id=e.dataTransfer.getData('application/x-bxh-cad');if(id){e.preventDefault();run(()=>loadRecord(id))();}});
  const saveKey=e=>{
    if(destroyed||e.defaultPrevented||isComposingEvent(e)||e.altKey||!(e.ctrlKey||e.metaKey)||e.key.toLowerCase()!=='s')return;
    e.preventDefault();
    if(e.repeat||hasBlockingDialog()||!doc)return;
    // Commit a focused text/number field BEFORE snapshotting it in the save dialog.
    const active=document.activeElement;if(root.contains(active))active.blur?.();
    saveDialog();
  };
  window.addEventListener('keydown',saveKey);
  const beforeUnload=e=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',beforeUnload);
  return{destroy(){destroyed=true;jobsGate.invalidate();stop();closeDialog();clearTimeout(anTimer);clearTimeout(textureTimer);clearTimeout(jobTimer);layers?.destroy();editor?.destroy();renderer?.destroy();window.removeEventListener('beforeunload',beforeUnload);window.removeEventListener('keydown',saveKey);root.innerHTML='';}};
}
