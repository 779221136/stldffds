import {templates,models,categories} from './data.js';
import {api} from './api.js';
export const catalogState={meta:null,detail:null};
export function rememberItems(kind,items) {
  const list=kind==='templates'?templates:models;
  for(const item of items){const index=list.findIndex(x=>x.id===item.id);if(index<0)list.push(item);else list[index]=item;}
}
export async function initializeCatalog() {
  const [meta,t,m]=await Promise.all([api.meta(),api.templates({page_size:20}),api.models({page_size:20})]);
  templates.splice(0,templates.length,...t.items);models.splice(0,models.length,...m.items);
  Object.assign(categories,meta.categories);catalogState.meta=meta;return meta;
}
export async function loadSource(kind,id) {
  const plural=kind==='template'||kind==='templates'?'templates':'models';
  const result=await (plural==='templates'?api.template(id):api.model(id));
  rememberItems(plural,[result.item,...(result.related||[])]);return result;
}
