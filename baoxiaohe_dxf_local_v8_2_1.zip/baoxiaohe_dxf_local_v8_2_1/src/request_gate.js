/** Reject stale asynchronous results without relying on network cancellation. */
export function createRequestGate(){
  let revision=0;
  return {
    begin(){return ++revision;},
    invalidate(){++revision;},
    isCurrent(ticket){return ticket===revision;}
  };
}
