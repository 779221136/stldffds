import {wheelDelta,createVideoRecorder,recordedVideo} from './browser_compat.js';
import {createBoxCanvasRenderer} from './canvas_renderer.js';
import {getBoxLayout,normalizeBox} from './geometry.js';
import {artworkSVG,svgToCanvas} from './artwork.js';

const identity=()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
export function multiply(a,b) {const o=new Array(16).fill(0);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];return o;}
const perspective=(fov,aspect,near,far)=>{const f=1/Math.tan(fov/2),nf=1/(near-far);return[f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0];};
const translate=z=>{const a=identity();a[14]=z;return a;};
const rotX=a=>{const c=Math.cos(a),s=Math.sin(a);return[1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1];};
const rotY=a=>{const c=Math.cos(a),s=Math.sin(a);return[c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1];};
const rgb=(h='#eeeeee')=>{const match=/^#([0-9a-f]{6})$/i.exec(h);return match?[0,2,4].map(i=>parseInt(match[1].slice(i,i+2),16)/255):[.9,.9,.9];};
const presets={rightFront:[16,-30],front:[0,0],leftFront:[16,30],topRight:[50,-30],top:[90,0],topLeft:[50,30]};
const ratios={'16:9':16/9,'9:16':9/16,'4:3':4/3,'3:4':3/4,'1:1':1};
function shader(gl,type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;}
function makeProgram(gl,vs,fs){const p=gl.createProgram(),v=shader(gl,gl.VERTEX_SHADER,vs),f=shader(gl,gl.FRAGMENT_SHADER,fs);gl.attachShader(p,v);gl.attachShader(p,f);gl.linkProgram(p);gl.deleteShader(v);gl.deleteShader(f);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));return p;}

export function createBoxWebGLRenderer({mount,colors=['#eeeeee','#cccccc','#ffffff','#333333'],box={},background='#f2f3f5',onRotation=()=>{}}) {
  const root=typeof mount==='string'?document.querySelector(mount):mount;if(!root)throw new Error('Renderer mount not found');
  root.innerHTML='<canvas class="webgl-canvas" aria-label="\u516d\u9762\u5305\u88c5 3D \u9884\u89c8"></canvas><div class="webgl-hint">\u62d6\u52a8\u65cb\u8f6c \u00b7 \u6eda\u8f6e\u7f29\u653e</div>';
  const canvas=root.querySelector('canvas');
  const gl=canvas.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:true,premultipliedAlpha:false});
  if(!gl) return createBoxCanvasRenderer({mount:root,colors,box,background,onRotation});
  const prog=makeProgram(gl,`attribute vec3 aPos;attribute vec3 aNormal;attribute vec2 aUV;uniform mat4 uMVP;uniform mat4 uModel;varying vec2 vUV;varying vec3 vNormal;void main(){gl_Position=uMVP*vec4(aPos,1.0);vUV=aUV;vNormal=mat3(uModel)*aNormal;}`,
    `precision mediump float;varying vec2 vUV;varying vec3 vNormal;uniform sampler2D uTexture;uniform vec3 uLightDirection;uniform float uBrightness;void main(){vec4 tex=texture2D(uTexture,vUV);float d=max(dot(normalize(vNormal),normalize(uLightDirection)),0.0);vec3 color=tex.rgb*(0.70+0.30*d)*uBrightness;gl_FragColor=vec4(clamp(color,0.0,1.0),1.0);}`);
  const pos=gl.getAttribLocation(prog,'aPos'),normal=gl.getAttribLocation(prog,'aNormal'),uv=gl.getAttribLocation(prog,'aUV');
  const mvp=gl.getUniformLocation(prog,'uMVP'),model=gl.getUniformLocation(prog,'uModel'),ld=gl.getUniformLocation(prog,'uLightDirection'),brightness=gl.getUniformLocation(prog,'uBrightness');
  const buffer=gl.createBuffer(),texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([240,235,227,255]));
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  const state={rx:16*Math.PI/180,ry:-30*Math.PI/180,zoom:3.8,box:normalizeBox(box),colors:[...colors],background,transparent:false,light:1,lightRotation:30,lightHeight:55,aspect:'4:3',autoRotate:false};
  let destroyed=false,raf=0,anim=0,lastTs=0,drag=null,bgImage=null,generation=0,pending=Promise.resolve(),lastDesign=null,recording=null;
  const baseDesign=()=>({box:state.box,bg:state.colors[0],accent:state.colors[1],objects:[]});

  function vertices() {
    const b=state.box,div=Math.max(b.length,b.width,b.height),x=b.length/div,y=b.height/div,z=b.width/div;
    const faces={
      front:{p:[[-x,y,z],[x,y,z],[x,-y,z],[-x,-y,z]],n:[0,0,1]},
      back:{p:[[x,y,-z],[-x,y,-z],[-x,-y,-z],[x,-y,-z]],n:[0,0,-1]},
      left:{p:[[-x,y,-z],[-x,y,z],[-x,-y,z],[-x,-y,-z]],n:[-1,0,0]},
      right:{p:[[x,y,z],[x,y,-z],[x,-y,-z],[x,-y,z]],n:[1,0,0]},
      top:{p:[[-x,y,-z],[x,y,-z],[x,y,z],[-x,y,z]],n:[0,1,0]},
      bottom:{p:[[-x,-y,z],[x,-y,z],[x,-y,-z],[-x,-y,-z]],n:[0,-1,0]}};
    const panels=getBoxLayout(b).panels,out=[];
    for(const [name,face] of Object.entries(faces)) {
      const r=panels[name],u0=r.x/1180,u1=(r.x+r.w)/1180,v0=1-r.y/760,v1=1-(r.y+r.h)/760;
      const uvmap=[[u0,v0],[u1,v0],[u1,v1],[u0,v1]];
      for(const i of [0,3,2,0,2,1])out.push(...face.p[i],...face.n,...uvmap[i]);
    }
    return new Float32Array(out);
  }
  function fitCanvas() {
    const rect=root.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);
    const w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round((rect.height||rect.width/(ratios[state.aspect]||4/3))*dpr));
    if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;
  }
  function draw({resize=true}={}) {
    if(destroyed)return;raf=0;if(resize)fitCanvas();gl.viewport(0,0,canvas.width,canvas.height);
    const bg=rgb(state.background);gl.clearColor(...bg,state.transparent||bgImage?0:1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.useProgram(prog);
    gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,vertices(),gl.DYNAMIC_DRAW);
    for(const [at,size,offset] of [[pos,3,0],[normal,3,12],[uv,2,24]]){gl.enableVertexAttribArray(at);gl.vertexAttribPointer(at,size,gl.FLOAT,false,32,offset);}
    const aspect=canvas.width/canvas.height,M=multiply(rotX(state.rx),rotY(state.ry));
    const distance=state.zoom*Math.max(1,1/aspect),V=translate(-distance),P=perspective(Math.PI/4,aspect,.1,100);
    gl.uniformMatrix4fv(mvp,false,new Float32Array(multiply(P,multiply(V,M))));gl.uniformMatrix4fv(model,false,new Float32Array(M));
    const a=state.lightRotation*Math.PI/180,h=state.lightHeight/100;
    gl.uniform3f(ld,Math.sin(a),h*2,Math.cos(a));gl.uniform1f(brightness,state.light);
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.uniform1i(gl.getUniformLocation(prog,'uTexture'),0);
    gl.drawArrays(gl.TRIANGLES,0,36);
  }
  function requestDraw(){if(!destroyed&&!raf)raf=requestAnimationFrame(()=>draw());}
  function upload(c){if(destroyed)return;gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);requestDraw();}
  function setDesign(payload) {
    if(destroyed)return Promise.resolve();lastDesign=structuredClone(payload);state.box=normalizeBox(payload.box);
    const epoch=++generation;
    pending=svgToCanvas(artworkSVG(lastDesign),2048,Math.round(2048*760/1180)).then(c=>{if(epoch===generation)upload(c);});
    pending.catch(()=>{});return pending;
  }
  async function ready(){let p;do{p=pending;await p;}while(p!==pending);if(destroyed)throw new Error('Renderer was destroyed');}
  function animate(ts){if(!state.autoRotate||destroyed){anim=0;return;}if(lastTs)state.ry+=(ts-lastTs)*.0004;lastTs=ts;draw();onRotation(state.rx,state.ry);anim=requestAnimationFrame(animate);}
  function setAutoRotate(v){state.autoRotate=!!v;if(state.autoRotate&&!anim){lastTs=0;anim=requestAnimationFrame(animate);}else if(!state.autoRotate&&anim){cancelAnimationFrame(anim);anim=0;lastTs=0;}}
  function setAspect(v){if(ratios[v])state.aspect=v;root.style.aspectRatio=String(ratios[state.aspect]);root.style.setProperty('--render-aspect',String(ratios[state.aspect]));requestDraw();}
  function drawComposite(ctx,w,h){ctx.clearRect(0,0,w,h);if(bgImage&&!state.transparent){const factor=Math.max(w/bgImage.width,h/bgImage.height),bw=bgImage.width*factor,bh=bgImage.height*factor;ctx.drawImage(bgImage,(w-bw)/2,(h-bh)/2,bw,bh);}ctx.drawImage(canvas,0,0,w,h);}
  async function exportPNG({quality='1k',aspect=state.aspect}={}) {
    await ready();const edge={'1k':1024,'2k':2048,'3k':3072,'4k':4096}[String(quality).toLowerCase()];
    if(!edge)throw new Error('Unsupported PNG resolution');const ratio=ratios[aspect]||ratios[state.aspect];
    const w=ratio>=1?edge:Math.round(edge*ratio),h=ratio>=1?Math.round(edge/ratio):edge;
    const max=Math.min(gl.getParameter(gl.MAX_RENDERBUFFER_SIZE),gl.getParameter(gl.MAX_TEXTURE_SIZE));
    if(w>max||h>max)throw new Error(`GPU limit ${max}px cannot produce this size`);
    // Re-rasterize the full artwork for the selected output size, not a viewport screenshot.
    const oldAuto=state.autoRotate;setAutoRotate(false);
    try {
      const texWidth=Math.min(max,Math.max(2048,edge));
      upload(await svgToCanvas(artworkSVG(lastDesign||baseDesign()),texWidth,Math.round(texWidth*760/1180)));
      if(raf){cancelAnimationFrame(raf);raf=0;}canvas.width=w;canvas.height=h;draw({resize:false});
      const output=document.createElement('canvas');output.width=w;output.height=h;
      drawComposite(output.getContext('2d'),w,h);return output.toDataURL('image/png');
    } finally {draw();setAutoRotate(oldAuto);}
  }
  async function recordWebM(seconds=4) {
    await ready();if(recording)throw new Error('Recording already in progress');
    const out=document.createElement('canvas');out.width=1024;out.height=Math.round(1024/(ratios[state.aspect]||4/3));
    const ctx=out.getContext('2d');if(!out.captureStream)throw new Error('Canvas recording unavailable');
    // Prime before capture so the first encoder frame is not blank.
    draw();drawComposite(ctx,out.width,out.height);
    const stream=out.captureStream(30),chunks=[],old=state.autoRotate,oldRY=state.ry;
    let rec;try{rec=createVideoRecorder(stream);}catch(error){stream.getTracks().forEach(t=>t.stop());throw error;}
    setAutoRotate(true);
    return new Promise((resolve,reject)=>{
      const duration=Math.min(15,Math.max(1,Number(seconds)||4))*1000;
      let copyRaf=0,done=false,watchdog=0,frames=0;
      const clean=()=>{cancelAnimationFrame(copyRaf);clearTimeout(watchdog);stream.getTracks().forEach(t=>t.stop());recording=null;state.ry=oldRY;setAutoRotate(old);requestDraw();};
      const fail=error=>{if(done)return;done=true;try{if(rec.state!=='inactive')rec.stop();}catch{}clean();reject(error);};
      rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
      rec.onerror=e=>fail(e.error||new Error('Video recording failed'));
      rec.onstop=()=>{if(done)return;done=true;clean();try{const blob=recordedVideo(chunks,rec);if(destroyed||frames<2||blob.size<500)throw new Error('No usable video frames');resolve(blob);}catch(error){reject(error);}};
      rec.onstart=()=>{const stopAt=performance.now()+duration;const copy=()=>{if(done)return;if(destroyed){fail(new Error('Renderer destroyed during recording'));return;}try{draw();drawComposite(ctx,out.width,out.height);stream.getVideoTracks()[0]?.requestFrame?.();frames++;if(performance.now()>=stopAt&&frames>=2){if(rec.state!=='inactive')rec.stop();return;}copyRaf=requestAnimationFrame(copy);}catch(error){fail(error);}};copy();};
      recording=rec;watchdog=setTimeout(()=>fail(new Error('Video capture timed out')),duration+15000);
      try{rec.start(200);stream.getVideoTracks()[0]?.requestFrame?.();}catch(error){fail(error);}
    });
  }
  canvas.addEventListener('pointerdown',e=>{setAutoRotate(false);canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,rx:state.rx,ry:state.ry};});
  canvas.addEventListener('pointermove',e=>{if(!drag)return;state.rx=Math.max(-Math.PI/2,Math.min(Math.PI/2,drag.rx+(e.clientY-drag.y)*.008));state.ry=drag.ry+(e.clientX-drag.x)*.008;onRotation(state.rx,state.ry);requestDraw();});
  const stopDrag=()=>{drag=null;};canvas.addEventListener('pointerup',stopDrag);canvas.addEventListener('pointercancel',stopDrag);
  canvas.addEventListener('wheel',e=>{e.preventDefault();state.zoom=Math.max(2.5,Math.min(8,state.zoom+wheelDelta(e,canvas)*.004));requestDraw();},{passive:false});
  const ro=new ResizeObserver(requestDraw);ro.observe(root);setAspect(state.aspect);setDesign(baseDesign());
  return {available:true,engine:'webgl',canvas,ready,setDesign,exportPNG,recordWebM,recordVideo:recordWebM,setAspect,setAutoRotate,
    setPreset(name){const p=presets[name];if(p){state.rx=p[0]*Math.PI/180;state.ry=p[1]*Math.PI/180;requestDraw();}},
    setRotation(rx,ry){state.rx=Number(rx)*Math.PI/180;state.ry=Number(ry)*Math.PI/180;requestDraw();},
    setLight(v){state.light=Math.max(.35,Math.min(1.5,Number(v)||1));requestDraw();},
    setLightRotation(v){state.lightRotation=Number(v)||0;requestDraw();},setLightHeight(v){state.lightHeight=Number(v)||0;requestDraw();},
    setBox(b){state.box=normalizeBox({...state.box,...b});setDesign({...lastDesign,box:state.box});},
    setColors(c){state.colors=[...c];setDesign({...lastDesign,bg:c[0],accent:c[1],box:state.box});},
    setBackground(c){state.background=c;state.transparent=false;bgImage=null;root.style.backgroundImage='none';root.style.backgroundColor=c;requestDraw();},
    setTransparent(v=true){state.transparent=!!v;if(v){bgImage=null;root.style.backgroundImage='none';root.style.backgroundColor='transparent';}requestDraw();},
    async setBackgroundImage(data){if(!/^data:image\/(png|jpeg);base64,/.test(data))throw new Error('Background must be a local PNG or JPEG');const img=new Image();img.src=data;await img.decode();if(destroyed)return;bgImage=img;state.transparent=false;root.style.backgroundImage=`url("${data}")`;root.style.backgroundSize='cover';root.style.backgroundPosition='center';requestDraw();},
    destroy(){destroyed=true;generation++;setAutoRotate(false);if(raf)cancelAnimationFrame(raf);if(recording?.state!=='inactive')recording?.stop();ro.disconnect();gl.deleteBuffer(buffer);gl.deleteTexture(texture);gl.deleteProgram(prog);gl.getExtension('WEBGL_lose_context')?.loseContext();}
  };
}
