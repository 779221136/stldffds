/* ES5 intentionally: this script must run before unsupported module syntax/APIs. */
(function (win, doc) {
  'use strict';
  var missing = [];
  function need(ok, name) { if (!ok) missing.push(name); }
  need('noModule' in doc.createElement('script'), 'JavaScript modules');
  need(typeof win.structuredClone === 'function', 'structuredClone');
  need(typeof Array.prototype.at === 'function', 'Array.at');
  need(typeof win.ResizeObserver === 'function', 'ResizeObserver');
  need(typeof win.PointerEvent === 'function', 'PointerEvent');
  need(typeof win.fetch === 'function' && typeof win.Promise === 'function', 'Fetch / Promise');
  need(typeof win.AbortController === 'function', 'AbortController');
  need(typeof win.TextEncoder === 'function' && typeof win.TextDecoder === 'function', 'TextEncoder / TextDecoder');
  need(typeof win.Blob === 'function' && typeof win.Blob.prototype.arrayBuffer === 'function' && typeof win.Blob.prototype.text === 'function', 'Blob readers');
  need(typeof win.Image === 'function' && typeof win.Image.prototype.decode === 'function', 'Image.decode');
  need(typeof Object.fromEntries === 'function', 'Object.fromEntries');
  function message(title, detail) {
    var root = doc.getElementById('app'), box = doc.createElement('section'), h = doc.createElement('h1'), text = doc.createElement('p');
    box.id = 'browser-compatibility-message';box.setAttribute('role', 'alert');
    box.style.cssText = 'max-width:760px;margin:48px auto;padding:24px;font:16px/1.8 system-ui,sans-serif;background:#fff;border:1px solid #ddd;border-radius:12px';
    h.textContent = title;text.textContent = detail;box.appendChild(h);box.appendChild(text);
    root.textContent = '';root.appendChild(box);
  }
  if (missing.length) {
    message('\u5f53\u524d\u6d4f\u89c8\u5668\u7f3a\u5c11\u7f16\u8f91\u5668\u6240\u9700\u80fd\u529b',
      '\u7f3a\u5c11\uff1a' + missing.join(', ') + '\u3002\u8bf7\u66f4\u65b0 Safari / Chrome / Edge / Firefox \u540e\u91cd\u8bd5\u3002\u672c\u6b21\u672a\u52a0\u8f7d\u7f16\u8f91\u5668\uff0c\u4e0d\u4f1a\u6539\u5199\u670d\u52a1\u5668\u5df2\u4fdd\u5b58\u7684\u6587\u4ef6\u3002');
    return;
  }
  var script = doc.createElement('script');script.type = 'module';script.src = '/src/app.js?v=8.1-browser-compat';
  script.onerror = function () { message('\u7f16\u8f91\u5668\u811a\u672c\u52a0\u8f7d\u5931\u8d25', '\u8bf7\u68c0\u67e5\u662f\u5426\u5b89\u88c5\u4e86\u5b8c\u6574\u8865\u4e01\uff0c\u5e76\u5728\u91cd\u542f\u670d\u52a1\u540e\u5f3a\u5236\u5237\u65b0\u9875\u9762\u3002'); };
  doc.body.appendChild(script);
}(window, document));
