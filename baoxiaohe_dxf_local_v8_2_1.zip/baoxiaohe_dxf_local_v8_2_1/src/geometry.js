/** Canonical six-face display net. This is NOT a manufacturable die-cut layout. */
export const FACE_NAMES = {back:'\u80cc\u9762',left:'\u5de6\u4fa7',front:'\u6b63\u9762',right:'\u53f3\u4fa7',top:'\u9876\u9762',bottom:'\u5e95\u9762'};
export const VIEWBOX = {width:1180,height:760};
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function normalizeBox(box={}) {
  const val=(x,d,a,b)=>clamp(Number.isFinite(Number(x))?Number(x):d,a,b);
  return {length:val(box.length,120,30,500),width:val(box.width,80,20,400),height:val(box.height,180,30,600)};
}
export function getBoxLayout(box={}) {
  const {length:L,width:W,height:H}=normalizeBox(box);
  const scale=Math.min(920/(2*(L+W)),600/(H+2*W),2);
  const x=(1180-2*(L+W)*scale)/2, y=(760-(H+2*W)*scale)/2;
  const panel=(a,b,w,h)=>({x:x+a*scale,y:y+b*scale,w:w*scale,h:h*scale});
  return {scale,x,y,w:2*(L+W)*scale,h:(H+2*W)*scale,
    panels:{back:panel(0,W,L,H),left:panel(L,W,W,H),front:panel(L+W,W,L,H),right:panel(2*L+W,W,W,H),top:panel(L+W,0,L,W),bottom:panel(L+W,W+H,L,W)}};
}
export function faceAt(box,x,y) {
  return Object.entries(getBoxLayout(box).panels).find(([,p])=>x>=p.x&&x<=p.x+p.w&&y>=p.y&&y<=p.y+p.h)?.[0]||'front';
}
export function rectMarkup(p,extra='') {return `<rect x="${p.x}" y="${p.y}" width="${p.w}" height="${p.h}" ${extra}/>`;}
export function netGuideMarkup(box,{safe=false,bleed=false,labels=true}={}) {
  const g=getBoxLayout(box),s=g.scale,f=g.panels.front;
  let text=Object.entries(g.panels).map(([name,p])=>rectMarkup(p,`fill="none" stroke="#3274e0" stroke-width="1.2"`)+(labels?`<text x="${p.x+5}" y="${p.y+15}" font-size="11" fill="#617080" pointer-events="none">${FACE_NAMES[name]}</text>`:'')).join('');
  for(const name of ['back','left','front']) {const p=g.panels[name];text+=`<path d="M${p.x+p.w},${p.y}v${p.h}" stroke="#eb5555" stroke-dasharray="6 4" fill="none"/>`;}
  for(const yy of [f.y,f.y+f.h]) text+=`<path d="M${f.x},${yy}h${f.w}" stroke="#eb5555" stroke-dasharray="6 4" fill="none"/>`;
  if(safe) text+=Object.values(g.panels).map(p=>rectMarkup({x:p.x+4*s,y:p.y+4*s,w:Math.max(1,p.w-8*s),h:Math.max(1,p.h-8*s)},'fill="none" stroke="#bd8c38" stroke-dasharray="3 3"')).join('');
  // These are visual margin guides; no promise of a production bleed contour.
  if(bleed) text+=rectMarkup({x:g.x-3*s,y:g.y-3*s,w:g.w+6*s,h:g.h+6*s},'fill="none" stroke="#32a066" stroke-dasharray="6 4"');
  return text;
}
