/** Mirror the local CAD worker's existing resource limits; never increase quotas. */
export function normalizeCadRenderOptions(value={}){
  const format=['png','frames','mp4','webm'].includes(value.format)?value.format:'png';
  const animation=format!=='png',allowTransparency=!['mp4','webm'].includes(format);
  const fps=Math.min(24,Math.max(6,Math.round(Number(value.fps)||12)));
  const maxSeconds=animation?Math.min(6,Math.floor(120/fps)):6;
  const seconds=Math.min(maxSeconds,Math.max(1,Math.round(Number(value.seconds)||3)));
  let long_edge=[256,512,1024,2048,3072,4096].includes(Number(value.long_edge))?Number(value.long_edge):1024;
  if(animation)long_edge=Math.min(1024,long_edge);
  return {format,animation,allowTransparency,long_edge,fps,seconds,maxSeconds,transparent:allowTransparency&&Boolean(value.transparent)};
}
