import {openFileInput,takeSelectedFile,IMAGE_ACCEPT,RASTER_ACCEPT} from './file_picker.js';
import {isComposingEvent,hasBlockingDialog,modalKeydown,videoExtension} from './browser_compat.js';
import {mountCadStudio} from './cad_studio.js';
import {createRenderPreview} from './render_opening.js';
import {mountStructureStudio} from './structure_studio.js';
import {mountCatalog,templateMarkup,modelMarkup,bindMedia} from './catalog_ui.js';
import {initializeCatalog,loadSource,catalogState} from './catalog_client.js';
import {mountDetail} from './detail_ui.js';
import {NAV,templates,models,scenes,categories,pricing} from './data.js';
import {store} from './store.js';
import {api} from './api.js';
import {createPackagingEditor} from './editor_engine.js';
import {createLayerPanel} from './layer_panel.js';
import {createSaveCoordinator} from './save_coordinator.js';
import {createBoxWebGLRenderer} from './webgl_renderer.js';
import {fileToImage,artworkSVG} from './artwork.js';
import {getBoxLayout} from './geometry.js';

let routeDisposers=[],routeSequence=0;
let structureTransfer=null,cadTransfer=null;
const catalogContext=()=>({esc,shell,visual,store,bindCards,toast,createBoxWebGLRenderer,defaultPayload,blueprintSVG,dispose:fn=>routeDisposers.push(fn)});
const app=document.querySelector('#app');
const toastRoot=document.querySelector('#toast-root');
const $=(sel,root=document)=>root.querySelector(sel);
const $$=(sel,root=document)=>[...root.querySelectorAll(sel)];
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const fmt=n=>new Intl.NumberFormat('zh-CN').format(n);

function toast(msg){
  toastRoot.innerHTML=`<div class="toast show">${esc(msg)}</div>`;
  setTimeout(()=>toastRoot.innerHTML='',1800);
}
function nav(path){history.pushState({},'',path);render();scrollTo({top:0,behavior:'instant'});}
window.addEventListener('popstate',render);
document.addEventListener('click',e=>{
  const a=e.target.closest('a[data-link]');
  if(a&&!e.defaultPrevented&&e.button===0&&!e.metaKey&&!e.ctrlKey&&!e.shiftKey&&!e.altKey&&a.target!=='_blank'){e.preventDefault();nav(a.getAttribute('href'));}
});

function icon(name){
  const icons={search:'⌕',heart:'♡',user:'◉',arrow:'→',box:'◇',spark:'✦',upload:'⇧',download:'⇩',save:'✓',cube:'⬡',print:'▣'};
  return `<span class="icon">${icons[name]||'•'}</span>`;
}
function header(){
  const path=location.pathname; const state=store.get();
  return `<header class="site-header"><div class="header-inner">
    <a data-link href="/" class="brand"><span class="brand-cube"><i></i></span><b>包小盒</b></a>
    <nav class="main-nav">${NAV.map(([t,u])=>u.startsWith('http')?`<a href="${u}" target="_blank">${t}</a>`:`<a data-link href="${u}" class="${path.startsWith(u)?'active':''}">${t}</a>`).join('')}</nav>
    <div class="top-search"><input id="globalSearch" placeholder="搜索包装模板/盒型"/><button data-global-search>${icon('search')}</button></div>
    <button class="mobile-nav-toggle" id="navToggle" aria-label="\u6253\u5f00\u5bfc\u822a" aria-controls="mobileNav" aria-expanded="false">&#9776;</button><div class="top-actions"><a data-link href="/cad" class="plain">\u5bfc\u5165CAD\u6587\u4ef6 <small>DXF</small></a><a data-link href="/account" class="plain">我的设计</a><span class="sep"></span>${state.user?`<a data-link href="/account" class="user-pill">${esc(state.user.name||state.user.phone)}</a>`:`<a data-link href="/login" class="login-link">注册/登录</a>`}</div>
  </div><nav id="mobileNav" class="mobile-nav" hidden>${NAV.map(([t,u])=>u.startsWith('http')?`<a href="${u}" target="_blank" rel="noopener noreferrer">${t}</a>`:`<a data-link href="${u}">${t}</a>`).join('')}</nav></header>`;
}
function footer(){
  return `<footer class="site-footer"><div class="footer-inner">
    <div><a data-link href="/" class="brand footer-brand"><span class="brand-cube"><i></i></span><b>包小盒</b></a><p>简单、智能、高效、美好</p></div>
    <div><h4>包小盒系列产品</h4><a data-link href="/">个人版</a><a href="https://www.pacdora.com" target="_blank">国际版 Pacdora</a><a data-link href="/print">印刷报价</a><a data-link href="/ai-design">AI智能设计</a></div>
    <div><h4>服务</h4><span>帮助中心</span><span>公益及教育机构优惠</span><span>反馈与建议</span><span>安全白皮书</span></div>
    <div><h4>关于</h4><span>关于我们</span><span>工作机会</span><span>平台服务协议</span><span>隐私政策</span></div>
    <div><h4>联系我们</h4><b class="phone">400 886 9050</b><span>服务时间：9:00-18:00</span></div>
  </div><div class="copyright">Copyright © 2026 杭州片段网络科技有限公司 All right reserved.</div></footer>`;
}
function shell(content,opts={}){
  app.innerHTML=`${opts.header===false?'':header()}<main class="${opts.mainClass||''}">${content}</main>${opts.footer===false?'':footer()}${opts.float===false?'':floatTools()}`;
  const toggle=$('#navToggle');if(toggle)toggle.onclick=()=>{const menu=$('#mobileNav'),expanded=toggle.getAttribute('aria-expanded')==='true';toggle.setAttribute('aria-expanded',String(!expanded));menu.hidden=expanded;};
  const gs=$('[data-global-search]'); if(gs) gs.onclick=()=>{const q=$('#globalSearch').value.trim();nav('/templates'+(q?`?q=${encodeURIComponent(q)}`:''));};
  const gi=$('#globalSearch'); if(gi) gi.onkeydown=e=>{if(e.key==='Enter')gs.click()};
}
function floatTools(){return `<aside class="float-tools"><button data-customer>◉<small>客服</small></button><button data-feedback>✎<small>反馈</small></button><button onclick="scrollTo({top:0,behavior:'smooth'})">↑<small>顶部</small></button></aside>`}
function visual(item,size='normal'){
  const c=item?.c||['#eee','#aaa','#fff','#333'];
  return `<div class="mock-scene ${size}" style="--bg1:${c[2]};--bg2:${c[0]};--p1:${c[0]};--p2:${c[1]};--ink:${c[3]}"><div class="pkg ${item.shape||'box'}" data-label="${esc((item.title||'PACK').slice(0,9))}"></div><span class="sample-label">\u793a\u610f</span></div>`;
}
function templateCard(t){return templateMarkup(t,catalogContext());}
function modelCard(m){return modelMarkup(m,catalogContext());}
function bindCards(){
  $$('[data-fav]').forEach(b=>b.onclick=async e=>{e.preventDefault();e.stopPropagation();if(!store.get().user){toast('\u8bf7\u5148\u767b\u5f55\u518d\u6536\u85cf');return;}const [kind,value]=b.dataset.fav.split(':');const id=Number(value),on=!store.isFavorite(kind,id);b.disabled=true;try{if(on)await api.favorite(kind,id);else await api.unfavorite(kind,id);store.setFavorite(kind,id,on);b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on));toast(on?'\u5df2\u540c\u6b65\u6536\u85cf':'\u5df2\u53d6\u6d88\u6536\u85cf');}catch(error){toast(error.message);}finally{b.disabled=false;}});
  for(const [attr,route,kind] of [['render-template','render','template'],['design-template','design','template'],['render-model','render','model'],['design-model','design','model']]) $$(`[data-${attr}]`).forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();nav(`/${route}/${kind}/${b.getAttribute('data-'+attr)}`);});
}

function homePage(){
  shell(`<section class="hero"><div class="hero-copy"><span class="eyebrow">PACKAGING DESIGN · 3D MOCKUP</span><h1>让包装设计<br/>从想法到落地更简单</h1><p>2D 设计、3D 高清渲染、包装盒型与模板、小批量印刷，一站完成。</p><div class="hero-actions"><a data-link href="/templates" class="btn primary lg">开始设计</a><a data-link href="/models" class="btn ghost lg">浏览模型库</a></div><div class="hero-stats"><b>${fmt(catalogState.meta?.template_count??templates.length)}<small>包装模板</small></b><b>${fmt(catalogState.meta?.model_count??models.length)}<small>盒型/模型</small></b><b>4K<small>高清渲染</small></b></div></div><div class="hero-art"><div class="art-orbit one"></div><div class="art-orbit two"></div>${visual(templates[0],'hero-v')}</div></section>
  <section class="home-section"><div class="section-title"><div><span>盒型 / 模型库</span><h2>${fmt(catalogState.meta?.model_count??models.length)} 款盒型可选</h2></div><a data-link href="/models">查看更多 →</a></div><div class="cards-grid five">${models.slice(0,5).map(modelCard).join('')}</div></section>
  <section class="home-section alt"><div class="section-title"><div><span>模板中心</span><h2>${fmt(catalogState.meta?.template_count??templates.length)} 款模板可选</h2></div><a data-link href="/templates">查看更多 →</a></div><div class="cards-grid five">${templates.slice(0,5).map(templateCard).join('')}</div></section>
  <section class="home-section"><div class="section-title"><div><span>3D 场景棚拍</span><h2>一键复用虚拟棚拍，快速出图</h2></div><a data-link href="/render/template/25987">立即体验 →</a></div><div class="cards-grid four">${scenes.map(s=>`<article class="scene-card">${visual(s)}<h3>${esc(s.title)}</h3><a data-link href="/render/template/25987">去渲染</a></article>`).join('')}</div></section>
  <section class="feature-dark"><div class="feature-dark-copy"><span>2D设计 + 3D动画</span><h2>所见即所得的包装工作流</h2><p>在线编辑画面，实时预览包装成型效果；尺寸、材质、设计方案与渲染记录统一管理。</p><a data-link href="/design/model/74" class="btn white">立即体验</a></div><div class="feature-editor"><div class="fake-toolbar">文件&nbsp;&nbsp; 编辑&nbsp;&nbsp; 视图 <b>100%</b></div><div class="fake-canvas"><div class="dieline"><span></span><span></span><span></span><span></span></div><div class="preview-mini">${visual(templates[0]||{title:'',c:['#eee','#bbb','#fff','#333']})}</div></div></div></section>
  <section class="home-section"><div class="section-title center"><div><span>功能范围</span><h2>当前可用能力与待完成项</h2></div></div><div class="price-grid">${pricing.map(priceCard).join('')}</div></section>`);
  bindCards(); bindPricing();
}
function priceCard(p){return `<article class="price-card ${p.featured?'featured':''}">${p.featured?'<div class="popular">推荐</div>':''}<h3>${p.name}</h3><div class="price">${p.price}</div><p>${p.desc}</p><ul>${p.features.map(x=>`<li>✓ ${esc(x)}</li>`).join('')}</ul><button class="btn ${p.featured?'primary':'ghost'} full" data-plan="${p.name}">${p.cta}</button></article>`}
function bindPricing(){$$('[data-plan]').forEach(b=>b.onclick=()=>toast('\u4f1a\u5458\u652f\u4ed8\u672a\u63a5\u5165\uff0c\u4e0d\u4f1a\u6263\u8d39\u6216\u6388\u4e88\u6f14\u793a\u6743\u9650'));}

function filterPage(kind){mountCatalog(kind,catalogContext());}

function filterRow(key,label,vals){return `<div class="filter-row"><span>${label}</span><div>${vals.map((v,i)=>`<button data-filter="${key}|${v}" class="${i===0?'active':''}">${v}</button>`).join('')}</div></div>`}

function templateDetail(id){mountDetail('templates',catalogState.detail,catalogContext());}

function chipList(arr){return arr.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}

function modelDetail(id){mountDetail('models',catalogState.detail,catalogContext());}

function blueprintSVG(m){return artworkSVG({...defaultPayload(m),objects:[]},{guides:true});}

function memberPage(){shell(`<section class="page-width v4-capabilities"><h1>\u4f1a\u5458\u4e0e\u652f\u4ed8</h1><p>\u672c\u7248\u672a\u63a5\u5165\u652f\u4ed8\u3001\u4f1a\u5458\u6743\u76ca\u3001\u5546\u7528\u7d20\u6750\u6388\u6743\u6216\u53d1\u7968\u670d\u52a1\u3002</p><p>\u5f53\u524d\u53ef\u6d4b\u8bd5\u6a21\u677f\u6d4f\u89c8\u3001\u516d\u9762\u8bbe\u8ba1\u3001\u56fe\u7247\u5bfc\u51fa\u548c RGB PDF \u9884\u89c8\uff0c\u4e0d\u4f1a\u6263\u8d39\u6216\u4f2a\u9020\u4ed8\u8d39\u6743\u9650\u3002</p><button class="btn ghost" disabled>\u652f\u4ed8\u670d\u52a1\uff08\u672a\u914d\u7f6e\uff09</button></section>`);}

function loginPage() {
  shell(`<section class="v4-auth page-width"><div class="v4-auth-card"><h1>\u767b\u5f55\u8d26\u6237</h1><p class="muted">\u5f00\u53d1\u6a21\u5f0f\u4ec5\u751f\u6210\u672c\u5730\u6d4b\u8bd5\u7801\uff0c\u4e0d\u4f1a\u53d1\u9001\u771f\u5b9e\u77ed\u4fe1\u3002\u751f\u4ea7\u77ed\u4fe1\u670d\u52a1\u672a\u914d\u7f6e\u65f6\u5c06\u7981\u6b62\u767b\u5f55\u3002</p><form id="loginForm"><label>\u624b\u673a\u53f7<input id="loginPhone" inputmode="tel" autocomplete="tel" pattern="\\+?[0-9]{6,15}" required></label><div class="v4-code-row"><label>\u516d\u4f4d\u9a8c\u8bc1\u7801<input id="loginCode" inputmode="numeric" pattern="[0-9]{6}" autocomplete="one-time-code" required></label><button type="button" id="sendCode" class="btn ghost">\u83b7\u53d6\u6d4b\u8bd5\u7801</button></div><p id="loginStatus" role="status"></p><button id="loginSubmit" class="btn primary full" type="submit">\u767b\u5f55</button></form><p class="muted">\u5fae\u4fe1 OAuth \u672a\u63a5\u5165\uff0c\u4e0d\u4f1a\u6a21\u62df\u626b\u7801\u6210\u529f\u3002</p></div></section>`);
  let active=true,timer=null;routeDisposers.push(()=>{active=false;clearInterval(timer);});
  $('#sendCode').onclick=async()=>{const b=$('#sendCode');b.disabled=true;try{const r=await api.sendSms($('#loginPhone').value.trim());if(!active)return;$('#loginCode').value=r.dev_code||'';$('#loginStatus').textContent=`\u672c\u5730\u6d4b\u8bd5\u7801\uff1a${r.dev_code}\uff08\u6709\u6548\u671f 5 \u5206\u949f\uff0c\u4e00\u6b21\u6027\uff09`;let left=60;b.textContent=`${left}s`;timer=setInterval(()=>{left--;b.textContent=left>0?`${left}s`:'\u83b7\u53d6\u6d4b\u8bd5\u7801';if(left<=0){clearInterval(timer);b.disabled=false;}},1000);}catch(e){if(active){$('#loginStatus').textContent=e.message;b.disabled=false;}}};
  $('#loginForm').onsubmit=async e=>{e.preventDefault();const b=$('#loginSubmit');b.disabled=true;try{const r=await api.login($('#loginPhone').value.trim(),$('#loginCode').value.trim());store.setUser(r.user);await syncAccount();if(active)nav('/account');}catch(error){if(active){$('#loginStatus').textContent=error.message;b.disabled=false;}}};
}

async function accountPage() {
  if(!store.get().user){nav('/login');return;}
  let active=true;routeDisposers.push(()=>{active=false;});
  shell(`<section class="account page-width"><aside class="account-side"><div class="avatar">\u5305</div><h3 id="accountName">${esc(store.get().user.name)}</h3><span class="member-tag">\u6d4b\u8bd5\u8d26\u6237</span><nav>${[['designs','\u6211\u7684\u8bbe\u8ba1'],['favorites','\u6211\u7684\u6536\u85cf'],['exports','\u672c\u673a\u5bfc\u51fa\u8bb0\u5f55'],['orders','\u4f30\u4ef7\u8bb0\u5f55'],['settings','\u8d26\u6237\u8bbe\u7f6e']].map(([k,t])=>`<button data-account-tab="${k}">${t}</button>`).join('')}</nav><button id="logout" class="logout">\u9000\u51fa\u767b\u5f55</button></aside><div class="account-main" id="accountMain"><p>\u6b63\u5728\u8bfb\u53d6\u670d\u52a1\u5668\u6570\u636e\u2026</p></div></section>`);
  let serverOrders=[],loadingError='';
  try{const [,o]=await Promise.all([syncAccount(),api.orders()]);serverOrders=o.items;}catch(e){loadingError=e.message;if(e.status===401){store.logout();if(active)nav('/login');return;}}
  if(!active)return;
  const draw=tab=>{
    const s=store.get(),box=$('#accountMain');$$('[data-account-tab]').forEach(b=>b.classList.toggle('active',b.dataset.accountTab===tab));
    const warning=loadingError?`<p class="error-text">\u670d\u52a1\u5668\u8bfb\u53d6\u5931\u8d25\uff1a${esc(loadingError)}\u3002\u4ee5\u4e0b\u4ec5\u663e\u793a\u672c\u673a\u7f13\u5b58\u3002</p>`:'';
    if(tab==='designs')box.innerHTML=`${warning}<div class="account-title"><h1>\u6211\u7684\u8bbe\u8ba1</h1><a data-link href="/templates" class="btn primary">\u521b\u5efa\u8bbe\u8ba1</a></div>${s.designs.length?`<div class="design-list">${s.designs.map(d=>`<article><div class="design-cover">${visual((d.kind==='template'?templates:models).find(x=>x.id===d.sourceId)||templates[0])}</div><div><h3>${esc(d.name)}</h3><p>${d.cloudId?`\u670d\u52a1\u5668 v${d.version}`:'\u4ec5\u672c\u673a\u8349\u7a3f'}${d.dirty?' \u00b7 \u6709\u672a\u540c\u6b65\u4fee\u6539':''}</p></div><a data-link href="/design/${d.kind}/${d.sourceId}?draft=${d.id}" class="btn ghost">\u7ee7\u7eed\u7f16\u8f91</a><button data-delete-draft="${d.id}" class="btn ghost">\u5220\u9664</button></article>`).join('')}</div>`:empty('\u8fd8\u6ca1\u6709\u8bbe\u8ba1','\u4fdd\u5b58\u540e\u5c06\u663e\u793a\u5728\u8fd9\u91cc')}`;
    else if(tab==='favorites')box.innerHTML=`${warning}<h1>\u6211\u7684\u6536\u85cf</h1><div class="cards-grid four">${templates.filter(t=>s.favorites.templates.includes(t.id)).map(templateCard).join('')}${models.filter(m=>s.favorites.models.includes(m.id)).map(modelCard).join('')}</div>`;
    else if(tab==='exports')box.innerHTML=`<h1>\u672c\u673a\u5bfc\u51fa\u8bb0\u5f55</h1><p class="muted">\u4ec5\u8bb0\u5f55\u5f53\u524d\u6d4f\u89c8\u5668\u7684\u6210\u529f\u4e0b\u8f7d\uff0c\u6587\u4ef6\u4e0d\u4f1a\u4e0a\u4f20\u5230\u670d\u52a1\u5668\u3002</p>${simpleTable(['\u540d\u79f0','\u7c7b\u578b','\u65f6\u95f4'],s.exports.map(x=>[x.name,x.type,new Date(x.createdAt).toLocaleString()]))}`;
    else if(tab==='orders')box.innerHTML=`${warning}<h1>\u4f30\u4ef7\u8bb0\u5f55</h1><p class="muted">\u4ec5\u4e3a\u4f30\u4ef7\u5355\uff0c\u672a\u652f\u4ed8\u3001\u672a\u4e0b\u53d1\u751f\u4ea7\u3002</p>${simpleTable(['\u7f16\u53f7','\u91d1\u989d','\u72b6\u6001'],serverOrders.map(o=>[o.id,'CNY '+o.total,'\u4f30\u4ef7\u8bb0\u5f55']))}`;
    else box.innerHTML=`<h1>\u8d26\u6237\u8bbe\u7f6e</h1><form id="profileForm" class="settings-card"><label>\u6635\u79f0<input id="profileName" value="${esc(s.user.name)}" maxlength="60" required></label><label>\u624b\u673a\u53f7<input disabled value="${esc(s.user.phone)}"></label><button class="btn primary">\u4fdd\u5b58\u5230\u670d\u52a1\u5668</button></form>`;
    bindCards();
    $$('[data-delete-draft]').forEach(b=>b.onclick=async()=>{const d=s.designs.find(x=>x.id===+b.dataset.deleteDraft);if(!d||!confirm('\u786e\u8ba4\u5220\u9664\u8fd9\u4e2a\u8bbe\u8ba1\uff1f'))return;b.disabled=true;try{if(d.cloudId)await api.deleteDesign(d.cloudId);store.removeDesign(d.id);draw('designs');}catch(e){toast(e.message);b.disabled=false;}});
    if($('#profileForm'))$('#profileForm').onsubmit=async e=>{e.preventDefault();try{const r=await api.profile($('#profileName').value);store.setUser(r.user);$('#accountName').textContent=r.user.name;toast('\u6635\u79f0\u5df2\u4fdd\u5b58');}catch(error){toast(error.message);}};
  };
  $$('[data-account-tab]').forEach(b=>b.onclick=()=>{history.replaceState({},'',`/account?tab=${b.dataset.accountTab}`);draw(b.dataset.accountTab);});
  $('#logout').onclick=async()=>{try{await api.logout();store.logout();nav('/');}catch(e){toast('\u9000\u51fa\u5931\u8d25\uff1a'+e.message);}};
  draw(new URLSearchParams(location.search).get('tab')||'designs');
}

function empty(t,p){return `<div class="empty-state"><div class="empty-icon">◇</div><h3>${t}</h3><p>${p}</p></div>`}
function simpleTable(head,rows){return `<table class="simple-table"><thead><tr>${head.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table>`}

function teamPage(){shell(`<section class="page-width v4-capabilities"><h1>\u56e2\u961f\u4e0e\u79c1\u6709\u5305\u6750\u5e93</h1><p>\u672c\u7248\u5c1a\u672a\u5b9e\u73b0\u56e2\u961f\u6743\u9650\u3001GLB / DXF \u6587\u4ef6\u5b58\u50a8\u4e0e\u89e3\u6790\u3002</p><p>v3 \u7684\u4e0a\u4f20\u53ea\u4fdd\u5b58\u4e86\u6587\u4ef6\u540d\uff0c\u6ca1\u6709\u4fdd\u5b58\u6587\u4ef6\u5185\u5bb9\u3002\u8fd9\u91cc\u5df2\u505c\u7528\u8be5\u8bef\u5bfc\u6027\u5165\u53e3\uff0c\u4e0d\u4f1a\u62a5\u544a\u4e0a\u4f20\u6210\u529f\u3002</p><button class="btn ghost" disabled>GLB / DXF \u4e0a\u4f20\uff08\u672a\u5b9e\u73b0\uff09</button></section>`);}

function editorPage(kind,id) {
  const source=(kind==='template'?templates:models).find(x=>x.id===+id);if(!source){notFound();return;}
  const draftId=+new URLSearchParams(location.search).get('draft');
  let design=store.get().designs.find(x=>x.id===draftId)||{name:source.title,kind,sourceId:source.id,bg:hexColor(source.c?.[0]),accent:hexColor(source.c?.[1]),textColor:hexColor(source.c?.[3]),box:{length:120,width:80,height:180},...(source.document_payload||{})};
  let active=true,dirty=false,previewTimer=null,editor=null,layerPanel=null,saver=null;
  shell(`<div class="editor-shell pro-editor-shell" data-panel="canvas"><div class="editor-top"><a data-link href="/templates" class="editor-logo">\u5305\u5c0f\u76d2</a><input id="designName" value="${esc(design.name)}" maxlength="160"><span id="saveStatus" class="save-status" role="status">${design.cloudId?`\u670d\u52a1\u5668 v${design.version}`:'\u672c\u673a\u8349\u7a3f'}</span><div class="editor-top-actions"><button id="saveDesign" title="Ctrl/Cmd+S">\u4fdd\u5b58</button><button id="designHistory">\u5386\u53f2\u7248\u672c</button><button id="saveCopy" hidden>\u4fdd\u5b58\u526f\u672c</button><button id="openCAD">\u5bfc\u5165CAD\u6587\u4ef6</button><button id="openStructure">\u5200\u7248\u4e0e\u6298\u53e0</button><button id="preview3d">3D \u9884\u89c8</button><button id="exportDesign" class="primary">\u5bfc\u51fa</button></div></div>
    <div class="editor-document-note" role="note">${source.document_payload?'\u5df2\u52a0\u8f7d\u90e8\u7f72\u6570\u636e\u4e2d\u7684\u53ef\u7f16\u8f91\u56fe\u5c42\uff1b\u539f\u7ad9\u4e00\u81f4\u6027\u672a\u9a8c\u8bc1':'\u539f\u6a21\u677f\u56fe\u5c42\u548c\u771f\u5b9e\u76d2\u578b\u672a\u540c\u6b65\uff1b\u5f53\u524d\u662f\u516d\u9762\u76d2\u4f53\u6f14\u793a\uff0c\u4e0d\u662f\u539f\u6a21\u677f'}</div><div class="editor-mobile-tabs" role="group" aria-label="\u7f16\u8f91\u9762\u677f"><button data-editor-panel="canvas" aria-pressed="true">\u753b\u5e03</button><button data-editor-panel="properties" aria-pressed="false">\u5c5e\u6027</button><button data-editor-panel="layers" aria-pressed="false">\u56fe\u5c42</button><button data-editor-panel="preview" aria-pressed="false">3D</button></div><div class="editor-body pro-editor-body"><aside class="editor-tools pro-tools">${[['text','\u6587\u5b57'],['rect','\u5f62\u72b6'],['image','\u56fe\u7247'],['qrcode','\u4e8c\u7ef4\u7801'],['barcode','\u6761\u5f62\u7801']].map(([k,t])=>`<button data-ed-tool="${k}">${t}</button>`).join('')}<input id="edImage" type="file" accept="${IMAGE_ACCEPT}" hidden></aside>
    <aside class="property-panel pro-property"><div id="selectionInspector"></div><hr><h4>\u5305\u88c5\u5c3a\u5bf8\uff08mm\uff09</h4><div class="size-row"><label>\u957f<input id="boxL" type="number" min="30" max="500" value="${design.box?.length||120}"></label><label>\u5bbd<input id="boxW" type="number" min="20" max="400" value="${design.box?.width||80}"></label><label>\u9ad8<input id="boxH" type="number" min="30" max="600" value="${design.box?.height||180}"></label></div><label>\u5e95\u8272<input id="canvasBg" type="color" value="${hexColor(design.bg)}"></label><label>\u5f3a\u8c03\u8272<input id="canvasAccent" type="color" value="${hexColor(design.accent)}"></label><div class="prepress-tip"><b>\u8303\u56f4\u8bf4\u660e</b><span>\u5f53\u524d\u662f\u516d\u9762\u76d2\u4f53\u5c55\u793a\u6a21\u578b\uff0c\u4e0d\u542b\u7c98\u53e3\u3001\u63d2\u820c\u3001\u6750\u6599\u8865\u507f\uff1b\u4e0d\u80fd\u76f4\u63a5\u7528\u4e8e\u751f\u4ea7\u3002</span></div></aside>
    <section class="design-stage pro-design-stage"><div id="editorMount"></div></section><aside class="live-preview pro-live-preview"><h3>3D \u5b9e\u65f6\u9884\u89c8</h3><div id="livePkg" class="v4-live-canvas"></div><p id="previewStatus" class="muted">\u6587\u5b57\u3001\u56fe\u7247\u3001\u56fe\u5f62\u540c\u6b65\u5230\u516d\u4e2a\u9762\u3002</p><div id="layerPanel" class="v4-layers"></div></aside></div></div>`,{header:false,footer:false,float:false,mainClass:'editor-main'});
  const renderer=createBoxWebGLRenderer({mount:'#livePkg',box:design.box,colors:[hexColor(design.bg),hexColor(design.accent),'#ffffff','#333333']});
  if(renderer.engine==='canvas2d')$('#previewStatus').textContent='WebGL \u4e0d\u53ef\u7528\uff0c\u5df2\u5207\u6362\u771f\u5b9e Canvas 2D \u8d34\u56fe\u9884\u89c8\u3002';
  const setStatus=text=>{if(active)$('#saveStatus').textContent=text;};
  const updatePreview=p=>{clearTimeout(previewTimer);previewTimer=setTimeout(()=>{renderer.setDesign(p)?.catch(e=>{if(active)$('#previewStatus').textContent='3D \u66f4\u65b0\u5931\u8d25\uff1a'+e.message;});},70);};
  function layers() { if(active) layerPanel?.refresh(); }
  let inspectorIdentity = null;
  function syncInspector(o) {
    if (!o) return;
    const fields = {objText:o.text, objFamily:o.fontFamily||'Arial', objFont:o.fontSize,
      objLetter:o.letterSpacing||0, objLineHeight:o.lineHeight||1.2, objAlign:o.align||'center',
      objFill:hexColor(o.fill), objFit:o.fit||'contain', objOpacity:Math.round((o.opacity??1)*100),
      objX:o.x, objY:o.y, objW:o.w, objH:o.h, objRot:o.rotation||0};
    if($('#objWrap')){$('#objWrap').checked=!!o.wrap;$('#objWrap').disabled=!!o.locked;}
    for (const [id,value] of Object.entries(fields)) {
      const input=$('#'+id); if (!input) continue;
      // Keep the same DOM node and caret during an edit. Undo/selection changes hydrate it.
      if (document.activeElement!==input) input.value=typeof value==='number'?Math.round(value*100)/100:(value??'');
      input.disabled=!!o.locked;
    }
    for (const [id,on] of [['objBold',(o.fontWeight||500)>=600],['objItalic',o.fontStyle==='italic'],['objUnderline',!!o.underline],['objVertical',!!o.vertical]]) {
      const b=$('#'+id); if(b){b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));b.disabled=!!o.locked;}
    }
    for(const id of ['flipX','flipY','deleteObject']) {const b=$('#'+id);if(b)b.disabled=!!o.locked;}
    const stack=editor?.getObjects()||[],i=stack.findIndex(x=>x.id===o.id);
    if($('#layerUp'))$('#layerUp').disabled=!!o.locked||i===stack.length-1;
    if($('#layerDown'))$('#layerDown').disabled=!!o.locked||i===0;
  }
  function syncDesignControls(payload) {
    for(const [id,key] of [['boxL','length'],['boxW','width'],['boxH','height']]) {
      const input=$('#'+id);if(input)input.value=payload.box[key];
    }
    if($('#canvasBg'))$('#canvasBg').value=hexColor(payload.bg);
    if($('#canvasAccent'))$('#canvasAccent').value=hexColor(payload.accent);
  }
  function inspector(o) {
    const identity=o?`${o.id}:${o.type}:${!!o.locked}`:'none';
    if(identity===inspectorIdentity){syncInspector(o);layers();return;}
    inspectorIdentity=identity;
    const el=$('#selectionInspector');if(!o){el.innerHTML='<h3>\u5bf9\u8c61\u5c5e\u6027</h3><p class="muted">\u70b9\u51fb\u753b\u5e03\u6216\u56fe\u5c42\u9009\u62e9\u5143\u7d20\uff0c\u62d6\u52a8\u89d2\u70b9\u7f29\u653e\uff0c\u62d6\u52a8\u5706\u70b9\u65cb\u8f6c\u3002</p>';layers();return;}
    el.innerHTML=`<h3>\u5bf9\u8c61\u5c5e\u6027 ${o.locked?'\uff08\u5df2\u9501\u5b9a\uff09':''}</h3>${o.type==='text'?`<label>\u6587\u5b57<textarea id="objText" rows="3">${esc(o.text)}</textarea></label><label class="text-wrap-control"><input id="objWrap" type="checkbox" ${o.wrap?'checked':''}>\u6309\u6587\u672c\u6846\u5bbd\u5ea6\u81ea\u52a8\u6362\u884c</label><div class="two-col"><label>\u5b57\u4f53<select id="objFamily"><option>Arial</option><option>Microsoft YaHei</option><option>SimSun</option><option>sans-serif</option></select></label><label>\u5b57\u53f7<input id="objFont" type="number" min="1" max="500" value="${o.fontSize||28}"></label></div><div class="text-format-row"><button id="objBold">B</button><button id="objItalic"><i>I</i></button><button id="objUnderline"><u>U</u></button><button id="objVertical">\u7ad6\u6392</button></div><div class="two-col"><label>\u5b57\u8ddd<input id="objLetter" type="number" value="${o.letterSpacing||0}" step="0.5"></label><label>\u884c\u9ad8<input id="objLineHeight" type="number" value="${o.lineHeight||1.2}" min=".5" max="5" step=".1"></label></div><label>\u5bf9\u9f50<select id="objAlign"><option value="left">\u5de6</option><option value="center">\u4e2d</option><option value="right">\u53f3</option></select></label>`:''}
    ${o.type==='image'?`<label>\u56fe\u7247\u9002\u914d<select id="objFit"><option value="contain">\u5b8c\u6574\u663e\u793a</option><option value="cover">\u88c1\u526a\u586b\u5145</option><option value="stretch">\u62c9\u4f38</option></select></label><div class="two-col"><button id="flipX" class="btn ghost">\u6c34\u5e73\u7ffb\u8f6c</button><button id="flipY" class="btn ghost">\u5782\u76f4\u7ffb\u8f6c</button></div>`:`<label>\u989c\u8272<input id="objFill" type="color" value="${hexColor(o.fill)}"></label>`}
    <label>\u900f\u660e\u5ea6<input id="objOpacity" type="range" min="0" max="100" value="${Math.round((o.opacity??1)*100)}"></label><div class="two-col"><label>X<input id="objX" type="number" value="${Math.round(o.x)}"></label><label>Y<input id="objY" type="number" value="${Math.round(o.y)}"></label><label>\u5bbd<input id="objW" type="number" min="1" value="${Math.round(o.w)}"></label><label>\u9ad8<input id="objH" type="number" min="1" value="${Math.round(o.h)}"></label></div><label>\u65cb\u8f6c\uff08\u5ea6\uff09<input id="objRot" type="number" value="${Math.round(o.rotation||0)}"></label><div class="two-col"><button id="layerUp" class="btn ghost">\u4e0a\u79fb\u4e00\u5c42</button><button id="layerDown" class="btn ghost">\u4e0b\u79fb\u4e00\u5c42</button><button id="duplicateObject" class="btn ghost">\u590d\u5236</button><button id="deleteObject" class="btn ghost">\u5220\u9664</button></div>`;
    const bind=(id,key,transform=v=>v)=>{const node=$('#'+id);if(node)node.onchange=()=>editor.updateSelected({[key]:transform(node.value)});};
    for(const [id,key] of [['objX','x'],['objY','y'],['objW','w'],['objH','h'],['objRot','rotation'],['objFont','fontSize'],['objLetter','letterSpacing'],['objLineHeight','lineHeight']])bind(id,key,Number);
    if($('#objWrap'))$('#objWrap').onchange=e=>editor.updateSelected({wrap:e.target.checked});bind('objText','text');if($('#objText'))$('#objText').oninput=e=>editor.updateSelected({text:e.target.value});bind('objFill','fill');bind('objOpacity','opacity',v=>Number(v)/100);bind('objFamily','fontFamily');bind('objAlign','align');bind('objFit','fit');
    if(o.type==='text') {$('#objFamily').value=o.fontFamily||'Arial';$('#objAlign').value=o.align||'center';$('#objBold').classList.toggle('active',(o.fontWeight||500)>=600);$('#objItalic').classList.toggle('active',o.fontStyle==='italic');$('#objUnderline').classList.toggle('active',!!o.underline);$('#objVertical').classList.toggle('active',!!o.vertical);$('#objBold').onclick=()=>editor.updateSelected({fontWeight:(editor.getSelected()?.fontWeight||500)>=600?400:700});$('#objItalic').onclick=()=>editor.updateSelected({fontStyle:editor.getSelected()?.fontStyle==='italic'?'normal':'italic'});$('#objUnderline').onclick=()=>editor.updateSelected({underline:!editor.getSelected()?.underline});$('#objVertical').onclick=()=>editor.updateSelected({vertical:!editor.getSelected()?.vertical});}
    if(o.type==='image') {$('#objFit').value=o.fit||'contain';$('#flipX').onclick=()=>editor.updateSelected({flipX:!editor.getSelected()?.flipX});$('#flipY').onclick=()=>editor.updateSelected({flipY:!editor.getSelected()?.flipY});}
    $('#layerUp').onclick=()=>editor.moveLayer(o.id,1);$('#layerDown').onclick=()=>editor.moveLayer(o.id,-1);const stack=editor.getObjects(),stackIndex=stack.findIndex(x=>x.id===o.id);$('#layerUp').disabled=!!o.locked||stackIndex===stack.length-1;$('#layerDown').disabled=!!o.locked||stackIndex===0;$('#duplicateObject').onclick=()=>editor.duplicateSelected();$('#deleteObject').onclick=()=>editor.removeSelected();syncInspector(o);layers();
  }
  editor=createPackagingEditor({mount:'#editorMount',source,initial:design,onSelection:inspector,onChange:p=>{syncDesignControls(p);dirty=true;setStatus('\u6709\u672a\u4fdd\u5b58\u4fee\u6539');updatePreview(p);layers();saver?.changed();}});
  layerPanel=createLayerPanel({mount:'#layerPanel',editor});
  $$('[data-editor-panel]').forEach(button=>button.onclick=()=>{
    $('.pro-editor-shell').dataset.panel=button.dataset.editorPanel;
    $$('[data-editor-panel]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
    if(button.dataset.editorPanel==='canvas')requestAnimationFrame(()=>editor.fitToView());
  });
  $('#openCAD').onclick=()=>{cadTransfer=editor.serialize();nav('/cad');};
  $('#openStructure').onclick=()=>{structureTransfer=editor.serialize();nav('/structure');};
  renderer.setDesign(editor.serialize())?.catch(e=>{if(active)$('#previewStatus').textContent=e.message;});layers();
  const nameInput=$('#designName'),owner=store.get().user?.id||null;
  const editSession=globalThis.crypto?.randomUUID?.()||`edit-${Date.now()}-${Math.random()}`;
  if(design.id){try{design=store.saveDesign({...design,editSession});}catch(e){toast(e.message);}}
  const ownsDraft=()=> (store.get().user?.id||null)===owner;
  const snapshot=()=>({id:design.cloudId||null,version:design.version||null,
    name:nameInput.value.trim()||source.title,kind,source_id:source.id,payload:editor.serialize()});
  function writeDraft(request,meta) {
    if(!ownsDraft())throw new Error('Draft account changed');
    const current=design.id?store.get().designs.find(d=>d.id===design.id):null;
    if(!active&&current?.editSession&&current.editSession!==editSession)return current;
    design=store.saveDesign({...design,...request.payload,name:request.name,kind,sourceId:source.id,editSession,
      dirty:meta.dirty,pendingSave:meta.pending||null});
    if(active){const params=new URLSearchParams(location.search);params.set('draft',design.id);history.replaceState({},'',`${location.pathname}?${params}`);}
    return design;
  }
  function draft() {saver?.persist();return design;}
  const messages={dirty:'\u6709\u672a\u540c\u6b65\u4fee\u6539',saving:'\u81ea\u52a8\u4fdd\u5b58\u4e2d\u2026',saved:'\u5df2\u4fdd\u5b58',local:'\u5df2\u4fdd\u5b58\u672c\u673a\uff08\u767b\u5f55\u540e\u53ef\u540c\u6b65\uff09',
    retry:'\u8fde\u63a5\u5931\u8d25\uff0c\u6b63\u5728\u91cd\u8bd5',network:'\u7f51\u7edc\u4e0d\u53ef\u7528\uff0c\u672c\u673a\u8349\u7a3f\u4fdd\u7559',conflict:'\u7248\u672c\u51b2\u7a81\uff1a\u8349\u7a3f\u4fdd\u7559\uff0c\u8bf7\u4fdd\u5b58\u526f\u672c',auth:'\u767b\u5f55\u5df2\u8fc7\u671f\uff0c\u8349\u7a3f\u4fdd\u7559',
    rejected:'\u670d\u52a1\u5668\u62d2\u7edd\u4fdd\u5b58',storage_error:'\u672c\u673a\u7a7a\u95f4\u4e0d\u8db3\uff0c\u8bf7\u52ff\u5173\u95ed',saved_no_backup:'\u670d\u52a1\u5668\u5df2\u4fdd\u5b58\uff0c\u672c\u673a\u5907\u4efd\u5931\u8d25'};
  saver=createSaveCoordinator({read:snapshot,writeLocal:writeDraft,initialPending:design.pendingSave,
    canRemote:()=>!!owner&&ownsDraft(),send:(request,key)=>api.saveDesign(request,key),
    onAck:result=>{design={...design,cloudId:result.id,version:result.version};},
    onStatus:state=>{dirty=state.dirty;if(!active)return;const node=$('#saveStatus');
      node.dataset.state=state.state;node.title=state.error?.message||'';
      setStatus((messages[state.state]||state.state)+(state.version?` v${state.version}`:''));
      $('#saveCopy').hidden=state.state!=='conflict';}
  });
  if(design.dirty)saver.changed();
  nameInput.oninput=()=>saver.changed();
  // Commit only the field that changed; never read stale sibling inputs.
  for(const [id,key] of [['boxL','length'],['boxW','width'],['boxH','height']]) {
    $('#'+id).onchange=e=>{
      if(e.target.value===''||!e.target.validity.valid){syncDesignControls(editor.serialize());toast('\u5c3a\u5bf8\u8d85\u51fa\u8303\u56f4\uff0c\u5df2\u4fdd\u7559\u539f\u503c');return;}
      editor.setBox({[key]:Number(e.target.value)});syncDesignControls(editor.serialize());
    };
  }
  $('#canvasBg').onchange=e=>editor.setBackground(e.target.value);
  $('#canvasAccent').onchange=e=>editor.setAccent(e.target.value);
  $$('[data-ed-tool]').forEach(b=>b.onclick=()=>{if(b.dataset.edTool==='text')editor.addText();else if(b.dataset.edTool==='rect')editor.addRect();else if(b.dataset.edTool==='image')openFileInput($('#edImage'),e=>toast(e.message));else addToolImage(editor,b.dataset.edTool);});
  $('#edImage').onchange=async e=>{const file=takeSelectedFile(e.target);if(!file)return;try{const image=await fileToImage(file);if(active)editor.addImage(image.src);}catch(error){if(active)toast(error.message);}};
  const saveNow=async()=>{
    if(document.activeElement?.matches('input,textarea,select'))document.activeElement.blur();
    const button=$('#saveDesign');if(button)button.disabled=true;
    try {const result=await (saver.getState().blocked==='network'?saver.retry():saver.flush());if(!result.ok)toast('\u4fdd\u5b58\u672a\u5b8c\u6210\uff1a'+(result.error?.message||messages[result.reason]||result.reason));return result;}
    finally{if(active&&button)button.disabled=false;}
  };
  $('#saveDesign').onclick=saveNow;
  $('#saveCopy').onclick=async()=>{
    const button=$('#saveCopy');button.disabled=true;
    try {
      const req={...snapshot(),id:null,version:null,name:(snapshot().name+' - \u526f\u672c').slice(0,160)};
      const result=await api.saveDesign(req,globalThis.crypto?.randomUUID?.()||`copy-${Date.now()}`);
      if(!active||!ownsDraft())return;
      const local=store.saveDesign({...req.payload,name:req.name,kind,sourceId:source.id,cloudId:result.id,version:result.version,dirty:false});
      saver.discard();dirty=false;nav(`/design/${kind}/${source.id}?draft=${local.id}`);
    }catch(e){toast(e.message);}finally{if(active)button.disabled=false;}
  };
  $('#designHistory').onclick=async()=>{
    if(!owner){toast('\u5386\u53f2\u7248\u672c\u9700\u8981\u767b\u5f55\u5e76\u4fdd\u5b58\u5230\u670d\u52a1\u5668');return;}
    const saved=await saver.flush(!!(!design.cloudId));if(!saved.ok||!active)return;
    let dialog=null;
    try {
      const historyResult=await api.versions(design.cloudId);if(!active)return;
      dialog=document.createElement('dialog');dialog.className='v6-history-dialog';dialog.setAttribute('aria-labelledby','historyTitle');
      dialog.innerHTML=`<header><h2 id="historyTitle">\u5386\u53f2\u7248\u672c</h2><button data-history-close aria-label="\u5173\u95ed">\u5173\u95ed</button></header><p>\u4fdd\u7559\u6700\u8fd1 ${historyResult.retention_limit} \u4e2a\u7248\u672c\uff1b\u6062\u590d\u4f1a\u521b\u5efa\u65b0\u7248\u672c\uff0c\u4e0d\u4f1a\u5220\u9664\u5f53\u524d\u7248\u672c\u3002</p><div class="history-list">${historyResult.items.map(v=>`<article><div><b>v${v.version} ${v.version===historyResult.current_version?'\uff08\u5f53\u524d\uff09':''}</b><span>${esc(v.name)}</span><small>${esc(new Date(v.created_at*1000).toLocaleString())}</small></div><button data-version-restore="${v.version}" ${v.version===historyResult.current_version?'disabled':''}>\u6062\u590d\u6b64\u7248\u672c</button></article>`).join('')}</div><p class="history-error" role="status"></p>`;
      document.body.append(dialog);dialog.showModal();
      dialog.addEventListener('close',()=>dialog.remove(),{once:true});
      dialog.querySelector('[data-history-close]').onclick=()=>dialog.close();
      dialog.querySelectorAll('[data-version-restore]').forEach(button=>button.onclick=async()=>{
        const version=Number(button.dataset.versionRestore);
        if(!confirm(`\u786e\u8ba4\u6062\u590d v${version}\uff1f\u5f53\u524d\u7248\u672c\u4f1a\u4fdd\u7559\u5728\u5386\u53f2\u8bb0\u5f55\u4e2d\u3002`))return;
        button.disabled=true;
        try {
          await api.restore(design.cloudId,version,design.version);
          const {item}=await api.design(design.cloudId);if(!active)return;
          const local=store.saveDesign({...design,...item.payload,name:item.name,kind:item.kind,sourceId:item.source_id,version:item.version,dirty:false,pendingSave:null});
          saver.discard();dirty=false;dialog.close();nav(`/design/${item.kind}/${item.source_id}?draft=${local.id}`);
        }catch(error){dialog.querySelector('.history-error').textContent=error.message;button.disabled=false;}
      });
      routeDisposers.push(()=>dialog?.remove());
    }catch(error){dialog?.remove();toast(error.message);}
  };
  $('#preview3d').onclick=()=>{try{const d=draft();nav(`/render/${kind}/${source.id}?draft=${d.id}`);}catch(e){toast('\u65e0\u6cd5\u4fdd\u5b58\u8349\u7a3f\uff1a'+e.message);}};
  $('#exportDesign').onclick=()=>showExportDialog(editor,$('#designName').value||source.title);
  const beforeUnload=e=>{saver.persist();if(dirty){e.preventDefault();e.returnValue='';}};
  const saveKey=e=>{if(e.defaultPrevented||isComposingEvent(e)||e.altKey)return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();if(!e.repeat&&!hasBlockingDialog())void saveNow();}};
  const reconnect=()=>void saver.retry();
  const visibility=()=>{if(document.visibilityState==='hidden'){saver.persist();void saver.flush(false);}};
  window.addEventListener('beforeunload',beforeUnload);window.addEventListener('keydown',saveKey);
  window.addEventListener('online',reconnect);document.addEventListener('visibilitychange',visibility);
  routeDisposers.push(()=>{saver.dispose();active=false;clearTimeout(previewTimer);layerPanel?.destroy();editor.destroy();renderer.destroy();
    window.removeEventListener('beforeunload',beforeUnload);window.removeEventListener('keydown',saveKey);
    window.removeEventListener('online',reconnect);document.removeEventListener('visibilitychange',visibility);});

}

function renderPage(kind,id) {
  const source=(kind==='template'?templates:models).find(x=>x.id===+id);if(!source){notFound();return;}
  const draftId=+new URLSearchParams(location.search).get('draft'),d=store.get().designs.find(x=>x.id===draftId);
  const payload=d||defaultPayload(source),box=payload.box,colors=[hexColor(payload.bg),hexColor(payload.accent),'#ffffff','#333333'];
  let quality='4k',aspect='4:3',active=true;
  shell(`<div class="render-shell pro-render-shell"><div class="render-top"><a data-link href="/templates" class="editor-logo">\u5305\u5c0f\u76d2</a><b>3D \u9884\u89c8\u4e0e\u5bfc\u51fa</b><span class="render-engine-badge">WebGL</span><div><button data-link-back class="render-back">\u8fd4\u56de\u8bbe\u8ba1</button><button id="exportVideo">\u5bfc\u51fa 360\u00b0 \u89c6\u9891</button><button id="exportRender" class="btn primary">\u5bfc\u51fa PNG</button></div></div><div class="render-body"><aside class="render-side"><h3>\u80cc\u666f</h3><label>\u7eaf\u8272<input id="renderBg" type="color" value="#f2f3f5"></label><div class="scene-special"><button id="transparentBg">\u900f\u660e\u80cc\u666f</button><button id="uploadBg">\u4e0a\u4f20\u80cc\u666f</button><input id="bgFile" type="file" accept="${RASTER_ACCEPT}" hidden></div><h3>\u706f\u5149</h3><label>\u4eae\u5ea6<input id="lightRange" type="range" min="35" max="150" value="100"></label><label>\u65cb\u8f6c<input id="lightRot" type="range" min="-180" max="180" value="30"></label><label>\u9ad8\u5ea6<input id="lightHeight" type="range" min="0" max="100" value="55"></label><h3>\u81ea\u7531\u89c6\u89d2</h3><label>\u6c34\u5e73\u65cb\u8f6c<input id="rotY" type="range" min="-180" max="180" value="-30"></label><label>\u5782\u76f4\u65cb\u8f6c<input id="rotX" type="range" min="-90" max="90" value="16"></label></aside><section class="render-stage webgl-stage" id="renderStage"><div id="webglMount" class="webgl-mount"></div><p id="renderStatus" role="status" class="v4-render-status">\u6b63\u5728\u751f\u6210\u8bbe\u8ba1\u8d34\u56fe\u2026</p></section><aside class="render-info"><h2>${esc(d?.name||source.title)}</h2><p>${box.length} \u00d7 ${box.width} \u00d7 ${box.height} mm</p><div class="render-group"><span>\u6784\u56fe\u6bd4\u4f8b</span><div class="option-grid">${['16:9','9:16','4:3','3:4'].map(v=>`<button data-aspect="${v}" class="${v===aspect?'active':''}">${v}</button>`).join('')}</div></div><div class="render-group"><span>\u8f93\u51fa\u957f\u8fb9\u50cf\u7d20</span><div class="option-grid quality-grid">${['1k','2k','3k','4k'].map(v=>`<button data-quality="${v}" class="${v===quality?'active':''}">${v.toUpperCase()}</button>`).join('')}</div></div><div class="render-group"><span>\u9884\u8bbe\u89d2\u5ea6</span><div class="camera-presets">${[['rightFront','\u53f3\u524d'],['front','\u6b63\u524d'],['leftFront','\u5de6\u524d'],['topRight','\u9876\u53f3'],['top','\u6b63\u9876'],['topLeft','\u9876\u5de6']].map(([k,t])=>`<button data-camera="${k}">${t}</button>`).join('')}</div></div><div class="anim-list"><button data-animation="static" class="active">\u9759\u6001</button><button data-animation="rotate">360\u00b0 \u65cb\u8f6c</button><button data-animation="open" id="openingAnimation">\u5f00\u76d2\u52a8\u753b</button></div><div id="openingControls" class="opening-controls" hidden><label>\u5f00\u76d2\u8fdb\u5ea6 <output id="openingPercent">0%</output><input id="openingProgress" type="range" min="0" max="100" step="1" value="0" aria-label="\u5f00\u76d2\u8fdb\u5ea6"></label><div><button id="openingPlayPause">\u6682\u505c</button><button id="openingClose">\u5408\u4e0a\u76d2\u76d6</button></div><p>\u793a\u4f8b\u7ed3\u6784\uff1a\u53cc\u7aef\u63d2\u53e3\u76d2\u3002\u4fdd\u7559\u5f53\u524d\u516d\u9762\u753b\u7a3f\u4e0e\u5c3a\u5bf8\uff1b\u4e0d\u4ee3\u8868\u8be5\u6a21\u677f\u7684\u771f\u5b9e\u751f\u4ea7\u7ed3\u6784\u3002</p></div><button id="openLocalStructure" class="opening-workbench">\u5200\u7248 / \u9ad8\u7ea7\u672c\u5730\u6e32\u67d3</button><div class="render-note"><b>\u771f\u5b9e\u6d4f\u89c8\u5668\u5bfc\u51fa</b><p>1K/2K/3K/4K \u7684\u957f\u8fb9\u5206\u522b\u4e3a 1024/2048/3072/4096 \u50cf\u7d20\u3002\u8fd9\u662f\u5355\u4e2a\u516d\u9762\u76d2\u7684 WebGL \u9884\u89c8\uff0c\u4e0d\u662f\u4e91\u7aef\u5149\u8ffd\u6e32\u67d3\uff0c\u4e0d\u652f\u6301\u539f\u7ad9\u5168\u90e8\u76d2\u578b\u3002</p></div></aside></div></div>`,{header:false,footer:false,float:false});
  const renderer=createRenderPreview({mount:'#webglMount',box,colors,onRotation:(rx,ry)=>{if(active){$('#rotX').value=rx*180/Math.PI;$('#rotY').value=ry*180/Math.PI;}},onOpeningState:state=>{
    if(!active)return;
    $('#renderStage').dataset.animationMode=state.mode;
    $('#openingControls').hidden=state.mode!=='open';
    $('#openingProgress').value=Math.round(state.progress*100);$('#openingProgress').disabled=state.loading||state.recording;
    $('#openingPercent').textContent=Math.round(state.progress*100)+'%';
    $('#openingPlayPause').textContent=state.playing?'\u6682\u505c':state.progress>=1?'\u91cd\u65b0\u64ad\u653e':'\u64ad\u653e';
    $('#openingPlayPause').disabled=$('#openingClose').disabled=state.loading||state.recording;
    $('#openingAnimation').setAttribute('aria-busy',String(state.loading));
    $('#openingAnimation').textContent=state.loading?'\u8f7d\u5165\u5f00\u76d2\u2026':'\u5f00\u76d2\u52a8\u753b';
    $('#exportVideo').textContent=state.mode==='open'?'\u5bfc\u51fa\u5f00\u76d2\u89c6\u9891':'\u5bfc\u51fa 360\u00b0 \u89c6\u9891';
    $('.render-engine-badge').textContent=(state.engine==='canvas2d'?'Canvas 2D':'WebGL')+(state.mode==='open'?' \u6298\u53e0':'');
    $$('[data-animation]').forEach(x=>{x.classList.toggle('active',x.dataset.animation===state.mode);x.setAttribute('aria-pressed',String(x.dataset.animation===state.mode));});
    if(state.loading)$('#renderStatus').textContent='\u6b63\u5728\u751f\u6210\u672c\u5730\u5f00\u76d2\u7ed3\u6784\u5e76\u8f6c\u5165\u5f53\u524d\u753b\u7a3f\u2026';
  }});
  $('.render-engine-badge').textContent=renderer.engine==='canvas2d'?'Canvas 2D':'WebGL';
  routeDisposers.push(()=>{active=false;renderer.destroy();});
  const status=text=>{if(active)$('#renderStatus').textContent=text;};
  renderer.setDesign(payload)?.then(()=>status('\u8d34\u56fe\u5df2\u540c\u6b65\u3002\u53ef\u65cb\u8f6c\u9884\u89c8\u6216\u5bfc\u51fa\u3002')).catch(e=>status(e.message));
  const syncRotation=()=>renderer.setRotation(+$('#rotX').value,+$('#rotY').value);$('#rotX').oninput=syncRotation;$('#rotY').oninput=syncRotation;
  $('#lightRange').oninput=e=>renderer.setLight(+e.target.value/100);$('#lightRot').oninput=e=>renderer.setLightRotation(+e.target.value);$('#lightHeight').oninput=e=>renderer.setLightHeight(+e.target.value);
  $('#renderBg').oninput=e=>renderer.setBackground(e.target.value);$('#transparentBg').onclick=()=>renderer.setTransparent(true);$('#uploadBg').onclick=()=>openFileInput($('#bgFile'),e=>toast(e.message));
  $('#bgFile').onchange=async e=>{const chosen=takeSelectedFile(e.target);if(!chosen)return;try{const file=await fileToImage(chosen);if(active)await renderer.setBackgroundImage(file.src);}catch(error){if(active)toast(error.message);}};
  $$('[data-aspect]').forEach(b=>b.onclick=()=>{aspect=b.dataset.aspect;renderer.setAspect(aspect);$$('[data-aspect]').forEach(x=>x.classList.toggle('active',x===b));});
  $$('[data-quality]').forEach(b=>b.onclick=()=>{quality=b.dataset.quality;$$('[data-quality]').forEach(x=>x.classList.toggle('active',x===b));});
  $$('[data-camera]').forEach(b=>b.onclick=()=>renderer.setPreset(b.dataset.camera));
  $$('[data-animation]').forEach(b=>b.onclick=async()=>{try{if(await renderer.setAnimationMode(b.dataset.animation)){status(b.dataset.animation==='open'?'\u5f00\u76d2\u52a8\u753b\u5df2\u63a5\u5165\uff0c\u53ef\u6682\u505c\u6216\u62d6\u52a8\u8fdb\u5ea6\u3002\u5f53\u524d\u4e3a\u53cc\u7aef\u63d2\u53e3\u76d2\u793a\u4f8b\u3002':'\u8d34\u56fe\u5df2\u540c\u6b65\u3002\u53ef\u9884\u89c8\u6216\u5bfc\u51fa\u3002');}}catch(e){status(e.message);}});
  $('#openingProgress').oninput=e=>renderer.setOpening(+e.target.value/100);
  $('#openingPlayPause').onclick=()=>renderer.toggleOpening();
  $('#openingClose').onclick=()=>renderer.closeLid();
  $('[data-link-back]').onclick=()=>nav(`/design/${kind}/${source.id}${d?`?draft=${d.id}`:''}`);
  $('#openLocalStructure').onclick=()=>{structureTransfer=payload;nav('/structure');};
  $('#exportRender').onclick=async()=>{const button=$('#exportRender');button.disabled=true;status('\u6b63\u5728\u6309\u9009\u5b9a\u5206\u8fa8\u7387\u5bfc\u51fa\u2026');try{const image=await renderer.exportPNG({quality,aspect});if(!active)return;downloadDataUrl(`${safeName(d?.name||source.title)}-${quality}.png`,image);store.addExport({name:d?.name||source.title,type:`${quality.toUpperCase()} ${renderer.engine} PNG`});status(`\u5df2\u5bfc\u51fa ${quality.toUpperCase()} PNG\uff0c\u6bd4\u4f8b ${aspect}`);}catch(error){status('\u5bfc\u51fa\u5931\u8d25\uff1a'+error.message);}finally{if(active)button.disabled=false;}};
  $('#exportVideo').onclick=async()=>{const button=$('#exportVideo');const locks=$$('.render-side input,.render-side button,.render-info input,.render-info button,#exportRender').map(el=>[el,el.disabled]);locks.forEach(([el])=>el.disabled=true);button.disabled=true;try{const opening=renderer.mode==='open';status(opening?'\u6b63\u5728\u5f55\u5236\u5f00\u76d2\u89c6\u9891\u2026':'\u6b63\u5728\u5f55\u5236 360\u00b0 \u89c6\u9891\u2026');const blob=await renderer.recordVideo(4);const ext=videoExtension(blob),format=ext.toUpperCase();if(!active)return;downloadBlob(`${safeName(source.title)}-${opening?'opening':'360'}.${ext}`,blob);store.addExport({name:source.title,type:(opening?'\u5f00\u76d2 ':'360 ')+format+' \u9884\u89c8'});status(format+' \u89c6\u9891\u5df2\u5bfc\u51fa');}catch(error){status('\u5f55\u5236\u5931\u8d25\uff1a'+error.message);}finally{if(active){locks.forEach(([el,disabled])=>el.disabled=disabled);button.disabled=false;}}};
}

function printPage() {
  const printable=models.filter(x=>x.printable),initial=+new URLSearchParams(location.search).get('model');
  let active=true,lastQuote=null;routeDisposers.push(()=>{active=false;});
  shell(`<section class="quote-section"><div class="page-width quote-grid"><div><span>\u5370\u5237\u4f30\u4ef7</span><h1>\u5305\u88c5\u4f30\u4ef7\u8ba1\u7b97\u5668</h1><p>\u5f53\u524d\u4ef7\u683c\u7531\u672c\u5730\u6837\u4f8b\u7b97\u6cd5\u8ba1\u7b97\uff0c\u5e76\u975e\u539f\u7ad9\u6216\u5370\u5237\u5382\u62a5\u4ef7\u3002</p><p>\u4fdd\u5b58\u4f30\u4ef7\u5355\u4e0d\u4ee3\u8868\u5df2\u4e0b\u5355\u751f\u4ea7\uff0c\u4e0d\u6536\u6b3e\u3001\u4e0d\u751f\u6210\u7269\u6d41\u6216\u4ea4\u671f\u627f\u8bfa\u3002</p></div><form id="quoteForm" class="quote-form"><label>\u76d2\u578b<select id="qProduct">${printable.map(m=>`<option value="${m.id}">${esc(m.title)}</option>`).join('')}</select></label><div class="three"><label>\u957f(mm)<input id="qL" type="number" min="30" max="500" value="120" required></label><label>\u5bbd(mm)<input id="qW" type="number" min="20" max="400" value="80" required></label><label>\u9ad8(mm)<input id="qH" type="number" min="30" max="600" value="180" required></label></div><label>\u6750\u8d28<select id="qMat"><option>300g \u767d\u5361\u7eb8</option><option>350g \u767d\u5361\u7eb8</option></select></label><label>\u6570\u91cf<input id="qQty" type="number" min="1" max="100000" value="100" required></label><div class="check-row">${[['lamination','\u8986\u819c'],['foil','\u70eb\u91d1'],['uv','UV'],['emboss','\u51f9\u51f8']].map(([k,t])=>`<label><input type="checkbox" value="${k}">${t}</label>`).join('')}</div><button id="calcQuote" class="btn primary full" type="submit">\u83b7\u53d6\u4f30\u4ef7</button><div id="quoteResult" class="quote-result" role="status"></div></form></div></section>`);
  if(printable.some(x=>x.id===initial))$('#qProduct').value=String(initial);
  const invalidate=()=>{lastQuote=null;$('#quoteResult').innerHTML='';};$('#quoteForm').addEventListener('input',invalidate);$('#quoteForm').addEventListener('change',invalidate);
  $('#quoteForm').onsubmit=async e=>{e.preventDefault();const button=$('#calcQuote');button.disabled=true;const payload={model_id:+$('#qProduct').value,length_mm:+$('#qL').value,width_mm:+$('#qW').value,height_mm:+$('#qH').value,material:$('#qMat').value,quantity:+$('#qQty').value,crafts:$$('#quoteForm input[type=checkbox]:checked').map(x=>x.value)};
    try{const q=await api.quote(payload);if(!active)return;lastQuote={payload,q,key:globalThis.crypto.randomUUID?.()||Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('')};$('#quoteResult').innerHTML=`<div><span>\u793a\u4f8b\u4f30\u4ef7\u603b\u989d</span><b>CNY ${q.total.toFixed(2)}</b><small>\u5355\u4ef7 ${q.unit_price.toFixed(2)} \u00d7 ${payload.quantity} + \u8bbe\u7f6e\u8d39 ${q.setup.toFixed(2)}</small></div><button type="button" id="placeOrder" class="btn dark full">\u4fdd\u5b58\u4f30\u4ef7\u5355\uff08\u975e\u751f\u4ea7\u8ba2\u5355\uff09</button>`;
      $('#placeOrder').onclick=async()=>{if(!store.get().user){toast('\u8bf7\u5148\u767b\u5f55\u518d\u4fdd\u5b58\u4f30\u4ef7\u5355');return;}const orderButton=$('#placeOrder');orderButton.disabled=true;try{const r=await api.createOrder({quote:lastQuote.payload},lastQuote.key);if(active){toast(`\u4f30\u4ef7\u5355 ${r.id} \u5df2\u4fdd\u5b58`);nav('/account?tab=orders');}}catch(error){toast(error.message);orderButton.disabled=false;}};
    }catch(error){if(active)$('#quoteResult').textContent='\u4f30\u4ef7\u5931\u8d25\uff1a'+error.message;}finally{if(active)button.disabled=false;}
  };
}

function aiDesignPage(){shell(`<section class="ai-page"><div class="ai-copy"><span class="eyebrow">COLOR RULE DEMO</span><h1>配色规则演示（非 AI 生成）</h1><p>输入产品、品牌与风格需求，快速生成颜色、文案和包装视觉方案，再进入在线编辑器细化。</p><div class="prompt-box"><textarea id="aiPrompt" placeholder="例如：为一款面向年轻人的精品咖啡豆设计极简自立袋包装，主色深绿色，强调产地与烘焙香气"></textarea><div><select id="aiType"><option value="31002">软包装 / 自立袋</option><option value="74">纸盒</option><option value="1666">精品礼盒</option><option value="220010">手提袋</option></select><button id="aiGenerate" class="btn primary">✦ 生成方案</button></div></div></div><div class="ai-preview" id="aiPreview"><div class="ai-placeholder"><b>✦</b><h3>AI 方案将在这里生成</h3><p>颜色、文案、包装预览与编辑入口</p></div></div></section>`);
 $('#aiGenerate').onclick=()=>{const p=$('#aiPrompt').value.trim();if(!p){toast('先输入产品与设计需求');return}const words=p.replace(/[，。,.]/g,' ').split(/\s+/).filter(Boolean);const hue=[['#183f35','#c5a46b','#f5efe1','#f8f4ea'],['#db7f64','#f1c75d','#fff7e5','#4d392d'],['#504171','#d7b9e9','#f8f3fb','#2e243e']][p.length%3];const sourceId=+$('#aiType').value;const isModel=models.some(x=>x.id===sourceId);const source=isModel?models.find(x=>x.id===sourceId):templates.find(x=>x.id===sourceId);const title=(words.slice(0,4).join(' ')||'AI PACK')+' 包装方案';const draft={name:title,kind:isModel?'model':'template',sourceId:source.id,text:(words[0]||'BRAND').slice(0,10),bg:hue[0],accent:hue[1],textColor:hue[3]};const saved=store.saveDesign(draft);$('#aiPreview').innerHTML=`<div class="generated"><div class="generated-visual">${visual({...source,title:draft.text,c:hue},'detail-v')}</div><div class="generated-info"><span>规则演示方向</span><h2>${esc(title)}</h2><p>${esc(p)}</p><div class="palette">${hue.map(c=>`<i style="background:${c}"></i>`).join('')}</div><ul><li>主视觉：强化产品品类识别</li><li>版式：大留白 + 中心品牌信息</li><li>卖点：控制在 2–3 个信息层级</li></ul><a data-link href="/design/${draft.kind}/${draft.sourceId}?draft=${saved.id}" class="btn primary full">进入在线编辑器</a></div></div>`};}

function notFound(){shell(`<section class="notfound"><div class="big404">404</div><h1>啊哦！好像迷路了~</h1><p>网页无法打开，网址有错误或已失效。</p><a data-link href="/" class="btn primary">返回首页</a></section>`)}


async function blobToDataUrl(blob){return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob)})}
async function addToolImage(editor,type){
 const value=prompt(type==='qrcode'?'输入二维码内容（文本、网址或公众号信息）':'输入条形码内容');if(!value)return;
 let sym='CODE128';if(type==='barcode'){const choice=(prompt('码制：EAN13 / EAN8 / CODE128 / CODE39','CODE128')||'CODE128').toUpperCase();sym=['EAN13','EAN8','CODE128','CODE39'].includes(choice)?choice:'CODE128'}
 try{const url=type==='qrcode'?`/api/tools/qrcode.svg?value=${encodeURIComponent(value)}`:`/api/tools/barcode.svg?symbology=${encodeURIComponent(sym)}&value=${encodeURIComponent(value)}`;const res=await fetch(url);if(!res.ok)throw new Error(await res.text());const data=await blobToDataUrl(await res.blob());editor.addImage(data);toast(type==='qrcode'?'二维码已添加':`${sym} 条形码已添加`)}catch(e){toast('生成失败：'+e.message)}
}

let modalReturnFocus=null;
function closeModal(){document.querySelector('.app-modal-backdrop')?.remove();const back=modalReturnFocus;modalReturnFocus=null;if(back?.isConnected)back.focus({preventScroll:true});}
function showExportDialog(editor,name) {
  closeModal();modalReturnFocus=document.activeElement;const el=document.createElement('div');el.className='app-modal-backdrop';
  el.innerHTML=`<div class="app-modal" role="dialog" aria-modal="true" aria-label="Export"><div class="modal-head"><h3>\u5bfc\u51fa\u8bbe\u8ba1</h3><button data-close-modal>\u00d7</button></div><p>\u5f53\u524d\u5bfc\u51fa\u4e3a\u5c55\u793a\u9884\u89c8\uff0c<strong>\u4e0d\u662f\u53ef\u76f4\u63a5\u751f\u4ea7\u7684\u5370\u5237\u5200\u7248</strong>\u3002CMYK / ICC / PDF-X \u4ecd\u672a\u5b9e\u73b0\u3002</p><div class="export-options"><button data-export-kind="print"><b>\u8bbe\u8ba1 PDF \u9884\u89c8</b><span>RGB \u00b7 \u6587\u5b57 + \u56fe\u7247 + \u56fe\u5f62</span></button><button data-export-kind="structure"><b>\u5c55\u5f00\u7ed3\u6784 PDF \u9884\u89c8</b><span>\u516d\u9762\u5c55\u793a\u6a21\u578b\uff0c\u975e\u751f\u4ea7\u5200\u7248</span></button><button data-export-kind="svg"><b>SVG \u8bbe\u8ba1\u9884\u89c8</b><span>\u5b8c\u6574\u56fe\u5c42\u4e0e\u5c55\u5f00\u7ebf</span></button></div><div id="preflightReport" class="preflight-report" role="status"></div></div>`;
  document.body.appendChild(el);el.onclick=e=>{if(e.target===el)closeModal();};el.querySelector('[data-close-modal]').onclick=closeModal;el.addEventListener('keydown',e=>modalKeydown(e,el,closeModal));el.querySelector('[data-close-modal]').focus();
  let active=true;routeDisposers.push(()=>{active=false;el.remove();});
  el.querySelectorAll('[data-export-kind]').forEach(b=>b.onclick=async()=>{
    const mode=b.dataset.exportKind;
    if(mode==='svg'){downloadText(`${safeName(name)}-preview.svg`,editor.exportSVG(),'image/svg+xml');store.addExport({name,type:'SVG \u9884\u89c8'});toast('SVG \u9884\u89c8\u5df2\u5bfc\u51fa');return;}
    b.disabled=true;const report=el.querySelector('#preflightReport');report.textContent='\u6b63\u5728\u68c0\u67e5\u5e76\u5bfc\u51fa\u2026';
    try {
      const payload=editor.serialize(),pf=await api.preflight(payload);if(!active)return;
      report.textContent=[...pf.errors,...pf.warnings].join('\n');if(!pf.ok)throw new Error(pf.errors.join('; '));
      const response=await fetch('/api/exports/pdf',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name,mode,color_mode:'RGB',payload})});
      if(!response.ok){const error=await response.json();throw new Error(error?.error?.message||'PDF export failed');}
      const blob=await response.blob();if(!active)return;downloadBlob(`${safeName(name)}-${mode}-RGB-preview.pdf`,blob);store.addExport({name,type:'RGB PDF \u9884\u89c8'});toast('PDF \u9884\u89c8\u5df2\u5bfc\u51fa');
    }catch(e){report.textContent='\u5bfc\u51fa\u5931\u8d25\uff1a'+e.message;}finally{b.disabled=false;}
  });
}

function safeName(s){return String(s).replace(/[\\/:*?"<>|\s]+/g,'-').slice(0,80)}
function downloadText(name,text,type='text/plain'){const blob=new Blob([text],{type});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function downloadDataUrl(name,url){const a=document.createElement('a');a.href=url;a.download=name;a.click()}

async function render(){
  const sequence=++routeSequence;
  const dispose=routeDisposers;routeDisposers=[];dispose.forEach(fn=>{try{fn();}catch(e){console.error(e);}});closeModal();
  document.title=({templates:"\u6a21\u677f\u4e2d\u5fc3",models:"\u6a21\u578b\u5e93",account:"\u6211\u7684\u8bbe\u8ba1"}[location.pathname.split("/")[1]]||"\u5305\u88c5\u8bbe\u8ba1")+" - \u5305\u5c0f\u76d2\u91cd\u5efa\u7248";
  const p=location.pathname.replace(/\/+$/,'')||'/';
  const sourceRoute=p.match(/^\/(templates|models)\/(\d+)$/)||p.match(/^\/(?:design|render)\/(template|model)\/(\d+)$/);
  if(sourceRoute){
    shell('<section class="page-width v4-loading" role="status">\u6b63\u5728\u52a0\u8f7d\u8d44\u6e90\u8be6\u60c5\u2026</section>',{footer:false});
    try{const result=await loadSource(sourceRoute[1],sourceRoute[2]);if(sequence!==routeSequence)return;
      if(/^\/(?:design|render)\//.test(p)){
        const doc=await api.document(sourceRoute[1],sourceRoute[2]);if(sequence!==routeSequence)return;
        result.item.document_payload=doc.available?doc.payload:null;
      }
      catalogState.detail=result;document.title=result.item.title+' - \u5305\u5c0f\u76d2\u91cd\u5efa\u7248';}
    catch(error){if(sequence!==routeSequence)return;if(error.status===404){notFound();return;}shell(`<section class="page-width catalog-empty"><h1>\u8d44\u6e90\u52a0\u8f7d\u5931\u8d25</h1><p>${esc(error.message)}</p><button id="retryDetail" class="btn primary">\u91cd\u8bd5</button></section>`);$('#retryDetail').onclick=render;return;}
  }
  if(p==='/'||p==='/introduction')homePage();
  else if(p==='/templates')filterPage('templates');
  else if(/^\/templates\/\d+$/.test(p))templateDetail(p.split('/')[2]);
  else if(p==='/models')filterPage('models');
  else if(/^\/models\/\d+$/.test(p))modelDetail(p.split('/')[2]);
  else if(p==='/member')memberPage();
  else if(p==='/login')loginPage();
  else if(p==='/account')accountPage();
  else if(p==='/team')teamPage();
  else if(p==='/cad'){shell('<div id="cadStudio"></div>',{header:false,footer:false,float:false,mainClass:'local-main'});const controller=mountCadStudio({mount:'#cadStudio',payload:cadTransfer,onBack:()=>nav('/templates')});cadTransfer=null;routeDisposers.push(()=>controller.destroy());}
  else if(p==='/structure'){shell('<div id="structureStudio"></div>',{header:false,footer:false,float:false,mainClass:'local-main'});const controller=mountStructureStudio({mount:'#structureStudio',payload:structureTransfer,onBack:()=>nav('/templates')});structureTransfer=null;routeDisposers.push(()=>controller.destroy());}
  else if(/^\/design\/(template|model)\/\d+$/.test(p)){const [,kind,id]=p.match(/^\/design\/(template|model)\/(\d+)$/);editorPage(kind,id)}
  else if(/^\/render\/(template|model)\/\d+$/.test(p)){const [,kind,id]=p.match(/^\/render\/(template|model)\/(\d+)$/);renderPage(kind,id)}
  else if(p==='/print')printPage();
  else if(p==='/ai-design')aiDesignPage();
  else notFound();
  $$('[data-customer]').forEach(b=>b.onclick=()=>toast('客服入口（演示） 400 886 9050'));
  $$('[data-feedback]').forEach(b=>b.onclick=()=>toast('感谢反馈（演示）'));
}

function hexColor(value,fallback='#eeeeee'){if(/^#[0-9a-f]{6}$/i.test(value||''))return value;if(/^#[0-9a-f]{3}$/i.test(value||''))return '#'+value.slice(1).split('').map(c=>c+c).join('');return fallback;}
function defaultPayload(source){if(source.document_payload)return structuredClone(source.document_payload);const box={length:120,width:80,height:180},f=getBoxLayout(box).panels.front;return {schemaVersion:4,geometry:'six-face-box',box,bg:hexColor(source.c?.[0]),accent:hexColor(source.c?.[1]),objects:[{id:'title',type:'text',x:f.x+f.w*.1,y:f.y+f.h*.4,w:f.w*.8,h:60,text:source.title.slice(0,8),fontSize:Math.min(24,f.w/9),fill:hexColor(source.c?.[3]),align:'center',lineHeight:1.2}]};}
function downloadBlob(name,blob){const url=URL.createObjectURL(blob);downloadDataUrl(name,url);setTimeout(()=>URL.revokeObjectURL(url),1500);}
async function syncAccount(){if(!store.get().user)return;const [f,d]=await Promise.all([api.favorites(),api.designs()]);store.syncFavorites(f.items);store.hydrateDesigns(d.items);}
async function start(){
  app.innerHTML='<p class="v4-loading">\u6b63\u5728\u8fde\u63a5\u672c\u5730\u670d\u52a1\u2026</p>';
  try{await initializeCatalog();}catch(error){app.innerHTML=`<section class="catalog-empty"><h1>\u76ee\u5f55\u670d\u52a1\u4e0d\u53ef\u7528</h1><p>${esc(error.message)}</p><button id="retryStartup" class="btn primary">\u91cd\u8bd5</button></section>`;$('#retryStartup').onclick=start;return;}
  try{const r=await api.me();store.setUser(r.user);if(r.user)await syncAccount();}catch(e){store.logout();toast('\u8d26\u6237\u8fde\u63a5\u5931\u8d25: '+e.message);}render();
}
start();
