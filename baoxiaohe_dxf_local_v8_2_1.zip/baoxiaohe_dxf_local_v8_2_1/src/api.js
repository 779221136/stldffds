async function request(path,options={}) {
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
  try {
    const response=await fetch(path,{credentials:'same-origin',...options,signal:options.signal||controller.signal,headers:{...(options.body?{'content-type':'application/json'}:{}),...options.headers}});
    const isJSON=(response.headers.get('content-type')||'').includes('application/json');
    const body=isJSON?await response.json():await response.text();
    if(!response.ok) {
      const detail=body?.error?.message||body?.detail||body;
      const message=Array.isArray(detail)?detail.map(x=>`${(x.loc||[]).join('.')}: ${x.msg}`).join('; '):String(detail||`HTTP ${response.status}`);
      const err=new Error(message);err.status=response.status;throw err;
    }
    return body;
  } finally {clearTimeout(timer);}
}
const post=(path,data,headers={})=>request(path,{method:'POST',body:JSON.stringify(data),headers});
export const api={
  meta:()=>request('/api/catalog/meta'),readiness:()=>request('/api/readiness'),health:()=>request('/api/health'),me:()=>request('/api/me'),
  profile:name=>request('/api/me',{method:'PATCH',body:JSON.stringify({name})}),
  sendSms:phone=>post('/api/auth/sms/send',{phone}),login:(phone,code)=>post('/api/auth/sms/login',{phone,code}),logout:()=>post('/api/auth/logout',{}),
  templates:(p={})=>request('/api/templates?'+new URLSearchParams(p)),template:id=>request(`/api/templates/${id}`),
  models:(p={})=>request('/api/models?'+new URLSearchParams(p)),model:id=>request(`/api/models/${id}`),
  favorites:()=>request('/api/favorites'),favorite:(kind,item_id)=>post('/api/favorites',{kind,item_id}),
  unfavorite:(kind,id)=>request(`/api/favorites/${kind}/${id}`,{method:'DELETE',body:'{}'}),
  designs:()=>request('/api/designs'),design:id=>request(`/api/designs/${id}`),saveDesign:(data,key)=>post('/api/designs',data,key?{'idempotency-key':key}:{}),deleteDesign:id=>request(`/api/designs/${id}`,{method:'DELETE',body:'{}'}),
  document:(kind,id)=>request(`/api/${kind==='template'?'templates':'models'}/${id}/document`),
  versions:id=>request(`/api/designs/${id}/versions`),
  version:(id,version)=>request(`/api/designs/${id}/versions/${version}`),
  restore:(id,version,expected_version)=>post(`/api/designs/${id}/restore`,{version,expected_version}),
  preflight:payload=>post('/api/preflight',{payload,color_mode:'RGB'}),
  createRender:data=>post('/api/render/jobs',data),renderStatus:id=>request(`/api/render/jobs/${id}`),
  quote:data=>post('/api/print/quote',data),createOrder:(data,key)=>post('/api/print/orders',data,key?{'idempotency-key':key}:{}),orders:()=>request('/api/account/orders')
};
