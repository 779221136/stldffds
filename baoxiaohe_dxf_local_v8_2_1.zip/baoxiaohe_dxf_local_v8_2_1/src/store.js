/** Browser drafts are isolated by authenticated user. They never grant permissions. */
const PROFILE='bxh_v4_profile';
const seed=()=>({favorites:{templates:[],models:[]},designs:[],exports:[],orders:[],membership:'free'});
function currentUser(){try{return JSON.parse(localStorage.getItem(PROFILE)||'null');}catch{return null;}}
function key(){const u=currentUser();return u?.id?`bxh_v4_user_${u.id}`:'bxh_v4_guest';}
function read(){try{const s=JSON.parse(localStorage.getItem(key())||'null')||{};return {...seed(),...s,favorites:{...seed().favorites,...s.favorites},user:currentUser()};}catch{return {...seed(),user:currentUser()};}}
function write(state){const {user,...rest}=state;localStorage.setItem(key(),JSON.stringify(rest));return {...rest,user:currentUser()};}
export const store={
  get:read,
  setUser(user){localStorage.setItem(PROFILE,JSON.stringify(user||null));return read();},
  logout(){localStorage.removeItem(PROFILE);return read();},
  syncFavorites(items){const s=read();s.favorites={templates:[],models:[]};for(const item of items)if(s.favorites[item.kind])s.favorites[item.kind].push(Number(item.item_id));write(s);},
  setFavorite(kind,id,on){const s=read();s.favorites[kind]=s.favorites[kind].filter(x=>x!==id);if(on)s.favorites[kind].push(id);write(s);},
  toggleFavorite(kind,id){const on=!read().favorites[kind]?.includes(id);this.setFavorite(kind,id,on);return on;},
  isFavorite:(kind,id)=>read().favorites[kind]?.includes(id)||false,
  saveDesign(d){const s=read();const id=d.id||Math.max(Date.now(),0,...s.designs.map(x=>Number(x.id)+1));const item={...d,id,updatedAt:new Date().toISOString()};const i=s.designs.findIndex(x=>x.id===id);if(i>=0)s.designs[i]=item;else s.designs.unshift(item);write(s);return item;},
  removeDesign(id){const s=read();s.designs=s.designs.filter(x=>x.id!==id);write(s);},
  hydrateDesigns(items){const s=read();for(const d of items){const existing=s.designs.find(x=>x.cloudId===d.id);if(existing?.dirty)continue;const item={...d.payload,id:existing?.id||Date.now()+d.id,name:d.name,kind:d.kind,sourceId:d.source_id,cloudId:d.id,version:d.version,dirty:false,updatedAt:new Date(d.updated_at*1000).toISOString()};if(existing)s.designs[s.designs.indexOf(existing)]=item;else s.designs.push(item);}return write(s);},
  addExport(e){const s=read();s.exports.unshift({...e,id:Date.now(),createdAt:new Date().toISOString()});s.exports=s.exports.slice(0,200);write(s);},
  addOrder(o){const s=read();s.orders.unshift(o);write(s);return o;},
  setMembership(){throw new Error('Membership cannot be granted by browser storage');}
};
