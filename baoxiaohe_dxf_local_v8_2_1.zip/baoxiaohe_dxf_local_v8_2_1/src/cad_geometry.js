/** Pure CAD coordinate and vector helpers. Native DXF is millimetres, Y up.
 * Artwork uses the existing 1180x760 pixel canvas. The independent net layer
 * placement maps model (x,-y) into that canvas; it is NOT a manufacturing resize.
 */
export const copy=v=>structuredClone(v);
export const roleColor={cut:'#2677e2',crease:'#e14f54',perf:'#a047c0',guide:'#8995a5',ignore:'#c9cdd3',unassigned:'#e99916'};
export function placementMatrix(p){const t=p.rotation*Math.PI/180,c=Math.cos(t)*p.scale,s=Math.sin(t)*p.scale;return [c,s,-s,c,p.x,p.y];}
export function inverseMatrix(m){const [a,b,c,d,e,f]=m,det=a*d-b*c;if(Math.abs(det)<1e-12)throw Error('Invalid placement scale');return[d/det,-b/det,-c/det,a/det,(c*f-d*e)/det,(b*e-a*f)/det];}
export function applyMatrix(m,[x,y]){return[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]];}
export const rawToCanvas=(placement,pt)=>applyMatrix(placementMatrix(placement),[pt[0],-pt[1]]);
export function arcPoint(p,deg){const t=deg*Math.PI/180;return [p.center[0]+p.radius*Math.cos(t),p.center[1]+p.radius*Math.sin(t)];}
export function pathD(p){
  if(p.type==='LINE')return `M${p.a[0]},${-p.a[1]}L${p.b[0]},${-p.b[1]}`;
  if(p.type==='CIRCLE'){const[x,y]=p.center,r=p.radius;return`M${x+r},${-y}a${r},${r} 0 1 0 ${-2*r},0a${r},${r} 0 1 0 ${2*r},0Z`;}
  const a=arcPoint(p,p.start),b=arcPoint(p,p.start+p.sweep);
  return`M${a[0]},${-a[1]}A${p.radius},${p.radius} 0 ${p.sweep>180?1:0} 0 ${b[0]},${-b[1]}`;
}
export function polygonD(points,raw=true){return points.length?'M'+points.map(([x,y])=>`${x},${raw?-y:y}`).join('L')+'Z':'';}
export function pathBounds(paths){
  const pts=[];for(const p of paths){if(p.type==='LINE')pts.push(p.a,p.b);else{pts.push(arcPoint(p,p.start||0),arcPoint(p,(p.start||0)+(p.sweep||360)));for(const a of [0,90,180,270])if(p.type==='CIRCLE'||((a-p.start)%360+360)%360<=p.sweep)pts.push(arcPoint(p,a));}}
  if(!pts.length)return[0,0,100,100];return[Math.min(...pts.map(p=>p[0])),Math.min(...pts.map(p=>p[1])),Math.max(...pts.map(p=>p[0])),Math.max(...pts.map(p=>p[1]))];
}
export function fittedPlacement(paths){const[x0,y0,x1,y1]=pathBounds(paths),scale=Math.min(920/Math.max(.01,x1-x0),540/Math.max(.01,y1-y0));return{scale,x:590-(x0+x1)*scale/2,y:380+(y0+y1)*scale/2,rotation:0,visible:true,locked:true};}
export function canvasPanelLayout(doc,analysis){
  const m=placementMatrix(doc.placement),fs=analysis?.faces?.length?analysis.faces:[{id:'net',polygon:[[0,0],[100,0],[100,100],[0,100]]}];
  const panels={};for(const f of fs){const pts=f.polygon.map(pt=>applyMatrix(m,[pt[0],-pt[1]])),xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]);panels[f.id]={x:Math.min(...xs),y:Math.min(...ys),w:Math.max(20,Math.max(...xs)-Math.min(...xs)),h:Math.max(20,Math.max(...ys)-Math.min(...ys))};}
  panels.front=panels[analysis?.root]||Object.values(panels)[0];return {panels};
}
