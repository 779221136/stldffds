/**
 * Artwork is stored back-to-front (SVG painter order); the layer list is
 * displayed front-to-back. targetIndex is a FINAL visual index, 0 = top.
 * Return the same array on invalid/no-op requests, otherwise a new array.
 * Only the moved layer is subject to the lock; other locked layers can be
 * crossed, matching an object-edit lock rather than a fixed stack slot.
 */
export function reorderedLayers(objects, id, targetIndex) {
  if (!Array.isArray(objects) || !Number.isInteger(targetIndex) ||
      targetIndex < 0 || targetIndex >= objects.length) return objects;
  const from = objects.findIndex(object => object.id === id);
  if (from < 0 || objects[from].locked) return objects;
  const to = objects.length - 1 - targetIndex;
  if (from === to) return objects;
  const next = objects.slice();
  const [object] = next.splice(from, 1);
  next.splice(to, 0, object);
  return next;
}
