/** Row-major forward kinematics for local-carton/1, shared with Python fixtures. */
export const identity=()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
export function multiply(a,b){const r=Array(16).fill(0);for(let i=0;i<4;i++)for(let j=0;j<4;j++)for(let k=0;k<4;k++)r[i*4+j]+=a[i*4+k]*b[k*4+j];return r;}
export function transform(m,p){return [0,1,2].map(i=>m[i*4]*p[0]+m[i*4+1]*p[1]+m[i*4+2]*(p[2]||0)+m[i*4+3]);}
export const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export function progress(v,[a,b]){const t=clamp((v-a)/(b-a));return t*t*(3-2*t);}
export function hinge(axis,deg){
  const [a,b]=axis,dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),x=dx/len,y=dy/len,c=Math.cos(deg*Math.PI/180),s=Math.sin(deg*Math.PI/180),d=1-c;
  const m=[c+x*x*d,x*y*d,y*s,0,y*x*d,c+y*y*d,-x*s,0,-y*s,x*s,c,0,0,0,0,1];
  for(let i=0;i<3;i++)m[i*4+3]=(i===0?a[0]:i===1?a[1]:0)-m[i*4]*a[0]-m[i*4+1]*a[1];return m;
}
export function pose(model,fold=1,opening=0){
  fold=clamp(fold);opening=clamp(opening);const s=model.spec,matrices={},out=[];
  const D=model.displayMatrix?model.displayMatrix.flat():s.kind==='tuck'?[1,0,0,-s.length/2,0,-1,0,s.height/2,0,0,-1,s.width/2,0,0,0,1]:[1,0,0,-s.length/2,0,0,1,-s.height/2,0,1,0,-s.width/2,0,0,0,1];
  for(const p of model.panels){let M=identity(),angle=0;if(p.parent){angle=p.angle*progress(fold,p.stage)+p.openAngle*progress(opening,p.release)*progress(fold,[.98,1]);M=multiply(matrices[p.parent],hinge(p.axis,angle));}matrices[p.id]=M;const world=multiply(D,M);out.push({id:p.id,points:p.polygon.map(pt=>transform(world,pt)),matrix:world,angle});}
  return out;
}
export const sub=(a,b)=>a.map((x,i)=>x-b[i]);
export const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export const unit=a=>{const n=Math.hypot(...a);return a.map(x=>x/(n||1));};
export function mesh(model,view){
  const posed=pose(model,view.fold,view.opening),out=[],all=[];
  const layering=model.previewLayering,insetScale=layering?layering.spacing*progress(view.fold,layering.stage):model.spec.thickness;
  for(let k=0;k<model.panels.length;k++){
    const p=model.panels[k];
    if(p.triangles?.length){
      const world=coords=>coords.map(pt=>transform(posed[k].matrix,pt)),seed=world(p.triangles[0]);
      const n=unit(cross(sub(seed[1],seed[0]),sub(seed[2],seed[0]))).map(v=>-v),b=p.bounds;
      const offset=(v,sign)=>v.map(a=>a.map((x,i)=>x+n[i]*(model.spec.thickness*.5*sign+(p.visualInset||0)*insetScale)));
      for(const tri of p.triangles){
        const v=world(tri),front=offset(v,1),back=offset(v,-1),uv=tri.map(([x,y])=>[(x-b[0])/(b[2]-b[0]),(y-b[1])/(b[3]-b[1])]);
        all.push(...front,...back);
        out.push({points:[front[0],front[2],front[1]],uv:[uv[0],uv[2],uv[1]],panel:p.id,side:'front'});
        out.push({points:back,uv,panel:p.id,side:'back'});
      }
      for(const ring of [p.polygon,...(p.holes||[])]){
        const v=world(ring),front=offset(v,1),back=offset(v,-1);
        for(let i=0;i<v.length;i++){const j=(i+1)%v.length,q=[front[i],front[j],back[j],back[i]];
          for(const ids of [[0,1,2],[0,2,3]])out.push({points:ids.map(i=>q[i]),uv:[[0,0],[0,0],[0,0]],panel:p.id,side:'edge'});
        }
      }
      continue;
    }
    const pts=posed[k].points,n=unit(cross(sub(pts[1],pts[0]),sub(pts[2],pts[0]))).map(v=>-v);
    const front=pts.map(a=>a.map((x,i)=>x+n[i]*model.spec.thickness*(.5+(p.visualInset||0)))),back=pts.map(a=>a.map((x,i)=>x+n[i]*model.spec.thickness*(-.5+(p.visualInset||0))));all.push(...front,...back);
    const b=p.bounds,uv=p.polygon.map(([x,y])=>[(x-b[0])/(b[2]-b[0]),(y-b[1])/(b[3]-b[1])]);
    function tri(verts,coords,side,ids){out.push({points:ids.map(i=>verts[i]),uv:ids.map(i=>coords[i]),panel:p.id,side});}
    for(let i=1;i<pts.length-1;i++){tri(front,uv,'front',[0,i+1,i]);tri(back,uv,'back',[0,i,i+1]);}
    for(let i=0;i<pts.length;i++){const j=(i+1)%pts.length,q=[front[i],front[j],back[j],back[i]],v=[[0,0],[0,0],[0,0],[0,0]];tri(q,v,'edge',[0,1,2]);tri(q,v,'edge',[0,2,3]);}
  }
  const radius=view.framing==='motion'?model.motionRadius:Math.max(...all.map(a=>Math.hypot(...a)))*1.06;
  return {triangles:out,radius};
}
export function cameraPoint(a,view){const y=view.yaw*Math.PI/180,p=view.pitch*Math.PI/180,x=a[0]*Math.cos(y)+a[2]*Math.sin(y),z=-a[0]*Math.sin(y)+a[2]*Math.cos(y);return [x,a[1]*Math.cos(p)-z*Math.sin(p),a[1]*Math.sin(p)+z*Math.cos(p)];}
export function projected(model,view,width,height){
  const m=mesh(model,view),scale=Math.min(width,height)*.44/m.radius*view.zoom;
  const angle=(view.lightRotation??-23.6)*Math.PI/180;const light=unit([Math.sin(angle),(view.lightHeight??40.6)/62.5,Math.cos(angle)]);
  return {radius:m.radius,triangles:m.triangles.map(t=>{const q=t.points.map(a=>cameraPoint(a,view)),n=unit(cross(sub(q[1],q[0]),sub(q[2],q[0])));return {...t,q,n,screen:q.map(a=>[width/2+a[0]*scale,height/2-a[1]*scale]),shade:(.66+.34*Math.max(0,n.reduce((s,x,i)=>s+x*light[i],0)))*view.light};}).filter(t=>t.n[2]>1e-8)};
}
