import {createVideoRecorder,recordedVideo} from './browser_compat.js';
/** Render-page adapter: existing cube + local hinged-panel opening, no remote service. */
import {createBoxWebGLRenderer} from './webgl_renderer.js';
import {createStructureRenderer} from './structure_renderer.js';
import {pose,clamp} from './structure_math.js';
import {artworkSVG,svgToCanvas} from './artwork.js';
import {getBoxLayout} from './geometry.js';

const RATIOS={'1:1':1,'4:3':4/3,'3:4':3/4,'16:9':16/9,'9:16':9/16};
const PRESETS={rightFront:[16,-30],front:[0,0],leftFront:[16,30],topRight:[50,-30],top:[85,0],topLeft:[50,30]};
export function openingSpec(box){
  const limits={length:[40,500],width:[25,350],height:[20,500]};
  for(const [key,[a,b]] of Object.entries(limits)){
    if(typeof box?.[key]!=='number'||!Number.isFinite(box[key])||box[key]<a||box[key]>b)
      throw Error(`\u5f00\u76d2\u793a\u4f8b\u8981\u6c42 ${key} \u5728 ${a}-${b} mm\uff0c\u4e0d\u4f1a\u81ea\u52a8\u6539\u53d8\u4f60\u7684\u5c3a\u5bf8\u3002`);
  }
  return {kind:'tuck',length:box.length,width:box.width,height:box.height,glue:Math.min(12,Math.min(box.width,box.height)*.5),tuck:Math.min(12,box.width*.4),bleed:3,thickness:.4};
}
export function openingRadius(model){
  let max=0;
  // Fixed camera framing for this motion, rather than zooming as the lid opens.
  for(let i=0;i<=60;i++)for(const panel of pose(model,1,i/60))for(const p of panel.points)max=Math.max(max,Math.hypot(...p));
  return (max+model.spec.thickness*3)*1.08;
}
export function openingOutputSize(quality,aspect){
  const edge={'1k':1024,'2k':2048,'3k':3072,'4k':4096}[String(quality).toLowerCase()],ratio=RATIOS[aspect];
  if(!edge||!ratio)throw Error('Unsupported resolution/aspect');
  return ratio>=1?[edge,Math.round(edge/ratio)]:[Math.round(edge*ratio),edge];
}
export function createRenderPreview(options){
  const root=typeof options.mount==='string'?document.querySelector(options.mount):options.mount;
  root.innerHTML='<div class="render-cube-host"></div><div class="render-opening-host" hidden></div>';
  const cubeHost=root.firstElementChild,openHost=root.lastElementChild;
  let dead=false,mode='static',loading=false,playing=false,progress=0,frame=0,sequence=0,controller=null;
  let folded=null,model=null,documentData=null,backgroundImage=null,recordingCancel=null,initializing=null;
  let aspect='4:3',view={fold:1,opening:0,yaw:-30,pitch:16,zoom:1,light:1,lightRotation:30,lightHeight:55,background:options.background||'#f2f3f5',transparent:false,framing:'motion'};
  let appearance={exterior:options.colors?.[0]||'#eeeeee',interior:'#e8ddc9'};
  const cube=createBoxWebGLRenderer({...options,mount:cubeHost,onRotation:(rx,ry)=>{view.pitch=rx*180/Math.PI;view.yaw=ry*180/Math.PI;options.onRotation?.(rx,ry);}});
  const currentEngine=()=>mode==='open'?(folded?.engine==='WebGL'?'webgl':'canvas2d'):cube.engine;
  function emit(){if(!dead)options.onOpeningState?.({mode,loading,playing,progress,recording:!!recordingCancel,engine:currentEngine()});}
  function redraw(){if(folded&&!dead){folded.setView({...view,opening:progress,transparent:view.transparent||!!backgroundImage},appearance);openHost.style.backgroundImage=backgroundImage&&!view.transparent?`url("${backgroundImage.src}")`:'none';}}
  function stop(){if(frame)cancelAnimationFrame(frame);frame=0;playing=false;emit();}
  function setProgress(value){if(recordingCancel)return;stop();progress=clamp(Number(value)||0);redraw();emit();}
  function play(){
    if(dead||mode!=='open'||loading||!folded||recordingCancel)return;
    stop();if(progress>=.999)progress=0;
    const from=progress,start=performance.now(),duration=Math.max(250,(1-from)*3000);playing=true;
    const tick=now=>{if(dead||mode!=='open'||!playing)return;progress=from+(1-from)*clamp((now-start)/duration);redraw();emit();if(progress<1)frame=requestAnimationFrame(tick);else{frame=0;playing=false;emit();}};
    frame=requestAnimationFrame(tick);emit();
  }
  async function ensureModel(token){
    if(model&&folded)return;
    if(!documentData)throw Error('\u8bf7\u7b49\u5f85\u753b\u7a3f\u52a0\u8f7d\u5b8c\u6210');
    const spec=openingSpec(documentData.box),aborter=new AbortController();controller=aborter;
    const timeout=setTimeout(()=>aborter.abort(),15000);
    try{
      const response=await fetch('/api/local/structure',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify(spec),signal:aborter.signal});
      if(!response.ok){let detail='';try{const error=await response.json();detail=typeof error.detail==='string'?error.detail:JSON.stringify(error.detail||error.error||'');}catch{}
        if(response.status===404)throw Error('\u5f53\u524d\u540e\u7aef\u8fd8\u6ca1\u6709\u5f00\u76d2\u5f15\u64ce\uff1a\u8bf7\u5b89\u88c5\u5b8c\u6574\u8865\u4e01\u5e76\u91cd\u542f Python\uff0c\u4e0d\u80fd\u53ea\u66ff\u6362 HTML\u3002');
        throw Error(`\u7ed3\u6784\u751f\u6210\u5931\u8d25 (${response.status}) ${detail}`);
      }
      const next=await response.json();
      if(dead||token!==sequence)return;
      if(next.schema!=='local-carton/1'||!Array.isArray(next.panels))throw Error('\u7ed3\u6784\u63a5\u53e3\u7248\u672c\u4e0d\u5339\u914d\uff0c\u8bf7\u5b89\u88c5\u5b8c\u6574\u8865\u4e01');
      const atlas=await svgToCanvas(artworkSVG(documentData),2048,Math.round(2048*760/1180));
      if(dead||token!==sequence)return;
      const panels=getBoxLayout(documentData.box).panels,textures={};
      for(const p of next.panels){const r=panels[p.sourceFace];if(!r)continue;const c=document.createElement('canvas'),scale=1024/Math.max(r.w,r.h);c.width=Math.max(1,Math.round(r.w*scale));c.height=Math.max(1,Math.round(r.h*scale));c.getContext('2d').drawImage(atlas,r.x/1180*atlas.width,r.y/760*atlas.height,r.w/1180*atlas.width,r.h/760*atlas.height,0,0,c.width,c.height);textures[p.id]=c.toDataURL('image/png');}
      const candidate=createStructureRenderer(openHost,v=>{view={...view,...v};options.onRotation?.(v.pitch*Math.PI/180,v.yaw*Math.PI/180);});
      try{
        candidate.setModel({...next,motionRadius:openingRadius(next)});
        candidate.setView({...view,opening:progress},appearance);await candidate.setTextures(textures);
        if(dead||token!==sequence){candidate.destroy();return;}
        folded=candidate;model=next;openHost.dataset.textureFaces=String(Object.keys(textures).length);openHost.dataset.panels=String(next.panels.length);
      }catch(error){candidate.destroy();throw error;}
    }catch(error){if(aborter.signal.aborted&&token===sequence&&!dead)throw Error('\u5f00\u76d2\u5f15\u64ce\u54cd\u5e94\u8d85\u65f6\uff0c\u8bf7\u68c0\u67e5\u672c\u5730\u670d\u52a1\u540e\u91cd\u8bd5');throw error;}
    finally{clearTimeout(timeout);if(controller===aborter)controller=null;}
  }
  async function setAnimationMode(next){
    if(dead||recordingCancel)return false;
    if(!['static','rotate','open'].includes(next))throw Error('Unknown animation mode');
    const token=++sequence;controller?.abort();stop();cube.setAutoRotate(false);
    // Wait for a cancelled initialization to release its canvas before a new one.
    const previous=initializing;mode=next;loading=next==='open'&&!folded;emit();
    if(next!=='open'){loading=false;cubeHost.hidden=false;openHost.hidden=true;cube.setAutoRotate(next==='rotate');emit();return true;}
    try{
      if(previous)await previous.catch(()=>{});
      if(dead||token!==sequence)return false;
      initializing=ensureModel(token);await initializing;
      if(dead||token!==sequence)return false;
      loading=false;cubeHost.hidden=true;openHost.hidden=false;redraw();emit();play();return true;
    }catch(error){if(dead||token!==sequence)return false;mode='static';loading=false;cubeHost.hidden=false;openHost.hidden=true;emit();throw error;}
    finally{if(token===sequence)initializing=null;}
  }
  function setAspect(value){if(!RATIOS[value])return;aspect=value;root.style.aspectRatio=String(RATIOS[value]);root.style.setProperty('--render-aspect',String(RATIOS[value]));cube.setAspect(value);redraw();}
  function compose(width,height,opaque=false){
    const c=document.createElement('canvas');c.width=width;c.height=height;const ctx=c.getContext('2d');
    if(opaque||!view.transparent){ctx.fillStyle=view.background;ctx.fillRect(0,0,width,height);}
    if(backgroundImage&&!view.transparent){const f=Math.max(width/backgroundImage.width,height/backgroundImage.height);ctx.drawImage(backgroundImage,(width-backgroundImage.width*f)/2,(height-backgroundImage.height*f)/2,backgroundImage.width*f,backgroundImage.height*f);}
    const capture=folded.capture(width,height);ctx.drawImage(capture,0,0);return c;
  }
  async function exportPNG(opts={}){
    if(mode!=='open')return cube.exportPNG(opts);
    if(loading||!folded)throw Error('\u5f00\u76d2\u6a21\u578b\u6b63\u5728\u52a0\u8f7d\uff0c\u8bf7\u7a0d\u540e');
    const size=openingOutputSize(opts.quality||'1k',opts.aspect||aspect);stop();return compose(...size).toDataURL('image/png');
  }
  async function recordWebM(seconds=4){
    if(mode!=='open')return cube.recordWebM(seconds);
    if(!folded||loading)throw Error('\u5f00\u76d2\u6a21\u578b\u5c1a\u672a\u5c31\u7eea');
    if(recordingCancel)throw Error('\u5f55\u5236\u5df2\u5728\u8fdb\u884c');
    stop();const before=progress,duration=clamp(Number(seconds)||4,1,15)*1000,size=openingOutputSize('1k',aspect),canvas=document.createElement('canvas');[canvas.width,canvas.height]=size;
    if(!canvas.captureStream)throw Error('Canvas recording unavailable');
    const ctx=canvas.getContext('2d');
    // Prime a real frame before capture: some engines wait for it before onstart.
    try{progress=0;redraw();ctx.drawImage(compose(...size,true),0,0);}catch(error){progress=before;redraw();throw error;}
    const stream=canvas.captureStream(24),track=stream.getVideoTracks()[0],chunks=[];
    let rec;try{rec=createVideoRecorder(stream,{videoBitsPerSecond:4000000});}catch(e){stream.getTracks().forEach(t=>t.stop());progress=before;redraw();throw e;}
    return new Promise((resolve,reject)=>{
      let done=false,timer=0,watchdog=0,frames=0;
      function clean(){clearTimeout(timer);clearTimeout(watchdog);stream.getTracks().forEach(t=>t.stop());recordingCancel=null;if(!dead){progress=before;redraw();emit();}}
      function fail(e){if(done)return;done=true;if(rec.state!=='inactive')rec.stop();clean();reject(e);}
      recordingCancel=()=>fail(Error('Renderer disposed during recording'));
      rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};rec.onerror=e=>fail(e.error||Error('Video encoding failed'));
      rec.onstop=()=>{if(done)return;done=true;clean();try{const blob=recordedVideo(chunks,rec);if(frames<2||blob.size<500)throw Error('No usable opening video frames');resolve(blob);}catch(error){reject(error);}};
      rec.onstart=()=>{const began=performance.now();function tick(){if(done)return;if(dead){fail(Error('Renderer destroyed'));return;}try{progress=clamp((performance.now()-began)/duration);redraw();ctx.drawImage(compose(...size,true),0,0);track?.requestFrame?.();frames++;emit();if(progress>=1&&frames>=2)timer=setTimeout(()=>{if(rec.state==='recording')rec.stop();},180);else timer=setTimeout(tick,1000/24);}catch(e){fail(e);}}tick();};
      watchdog=setTimeout(()=>fail(Error('Video capture timed out')),duration+15000);
      try{rec.start(200);track?.requestFrame?.();}catch(e){fail(e);}
    });
  }
  setAspect(aspect);
  return {available:true,get engine(){return currentEngine();},get mode(){return mode;},get loading(){return loading;},get canvas(){return mode==='open'?folded?.canvas:cube.canvas;},
    get openingState(){return {mode,progress,playing,loading};},
    ready:()=>cube.ready(),
    setDesign(data){documentData=structuredClone(data);appearance.exterior=data.bg||appearance.exterior;return cube.setDesign(data);},
    setAnimationMode,setAutoRotate:v=>setAnimationMode(v?'rotate':'static'),setOpening:setProgress,
    toggleOpening(){if(playing)stop();else play();},closeLid:()=>setProgress(0),exportPNG,recordWebM,recordVideo:recordWebM,setAspect,
    setPreset(name){const p=PRESETS[name];if(p){view.pitch=p[0];view.yaw=p[1];cube.setPreset(name);options.onRotation?.(p[0]*Math.PI/180,p[1]*Math.PI/180);redraw();}},
    setRotation(rx,ry){view.pitch=clamp(Number(rx)||0,-85,85);view.yaw=Number(ry)||0;cube.setRotation(rx,ry);redraw();},
    setLight(v){view.light=clamp(Number(v)||1,.35,1.5);cube.setLight(v);redraw();},
    setLightRotation(v){view.lightRotation=Number(v)||0;cube.setLightRotation(v);redraw();},
    setLightHeight(v){view.lightHeight=Number(v)||0;cube.setLightHeight(v);redraw();},
    setBackground(v){view.background=v;view.transparent=false;backgroundImage=null;cube.setBackground(v);redraw();},
    setTransparent(v=true){view.transparent=!!v;if(v)backgroundImage=null;cube.setTransparent(v);redraw();},
    async setBackgroundImage(src){await cube.setBackgroundImage(src);if(dead)return;const im=new Image();im.src=src;await im.decode();if(dead)return;backgroundImage=im;view.transparent=false;redraw();},
    destroy(){dead=true;++sequence;controller?.abort();stop();recordingCancel?.();cube.destroy();folded?.destroy();root.innerHTML='';}
  };
}
