from PIL import Image
from tools.visual_regression import compare_images,capture_problem

def test_opaque_different_images_are_not_equal(tmp_path):
    a,b,d=[tmp_path/x for x in ['a.png','b.png','d.png']]
    Image.new('RGBA',(10,10),'white').save(a)
    Image.new('RGBA',(10,10),'black').save(b)
    assert compare_images(a,b,d)['different_percent']==100
    assert compare_images(a,a,d)['different_percent']==0

def test_loading_and_blocked_not_valid():
    assert capture_problem('https://example.com',200,'Loading...')
    assert capture_problem('chrome-error://chromewebdata',None,'blocked')
    assert capture_problem('https://example.com',403,'Forbidden')
    assert capture_problem('https://example.com',200,'Your organization doesn\u2019t allow you to view this site')
    assert capture_problem('https://example.com',200,'A complete page with content') is None
