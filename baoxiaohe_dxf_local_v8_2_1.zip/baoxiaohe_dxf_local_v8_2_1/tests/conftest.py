import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from fastapi.testclient import TestClient
import app.main as main

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('ENV','test')
    monkeypatch.setattr(main,'DB_PATH',tmp_path/'test.db')
    with TestClient(main.app) as c:
        yield c

def signin(c,phone='13800138000'):
    r=c.post('/api/auth/sms/send',json={'phone':phone})
    assert r.status_code==200,r.text
    code=r.json()['dev_code']
    r=c.post('/api/auth/sms/login',json={'phone':phone,'code':code})
    assert r.status_code==200,r.text
    return r.json()['user'],code
