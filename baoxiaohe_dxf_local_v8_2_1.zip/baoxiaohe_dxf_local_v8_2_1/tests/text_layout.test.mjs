import test from 'node:test';
import assert from 'node:assert/strict';
import {wrapMeasured,textHeight} from '../src/text_layout.js';
test('Wrap prefers word boundaries and preserves spaces',()=>assert.deepEqual(wrapMeasured('hello world',6,s=>s.length),['hello ','world']));
test('CJK without spaces wraps at grapheme boundaries',()=>assert.deepEqual(wrapMeasured('\u4e2d\u6587\u5305\u88c5\u8bbe\u8ba1',2,s=>s.length),['\u4e2d\u6587','\u5305\u88c5','\u8bbe\u8ba1']));
test('Explicit blank lines are preserved',()=>assert.deepEqual(wrapMeasured('A\n\nB',10,s=>s.length),['A','','B']));
test('Combining characters are never split',()=>assert.deepEqual(wrapMeasured('e\u0301e\u0301',2,s=>s.length),['e\u0301','e\u0301']));
test('Large strings preserve all content',()=>{const text='Packaging '.repeat(150);const lines=wrapMeasured(text,23,s=>s.length);assert.equal(lines.join(''),text);assert(lines.every(l=>l.length<=23));});
test('Single line height does not include a phantom line',()=>assert.equal(textHeight({text:'A',fontSize:24}),24));
