import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequestGate} from '../src/request_gate.js';
import {normalizeCadRenderOptions as normalize} from '../src/cad_render_options.js';
import {rasterizeProjected as raster} from '../src/structure_raster.js';

test('Changing file invalidates in-flight parse results',()=>{const g=createRequestGate(),old=g.begin();g.invalidate();assert.equal(g.isCurrent(old),false);const next=g.begin();assert.equal(g.isCurrent(next),true);assert.equal(g.isCurrent(old),false);});
test('Latest request wins including an earlier finally/error',()=>{const g=createRequestGate(),a=g.begin(),b=g.begin();assert.ok(!g.isCurrent(a)&&g.isCurrent(b));g.invalidate();assert.ok(!g.isCurrent(b));});
test('Independent jobs and import gates cannot invalidate each other',()=>{const a=createRequestGate(),b=createRequestGate(),ticket=a.begin();b.begin();b.invalidate();assert.ok(a.isCurrent(ticket));});
for(const format of ['mp4','webm','frames'])test(format+' clamps animation resolution and frame count',()=>{const p=normalize({format,long_edge:4096,fps:24,seconds:6,transparent:true});assert.equal(p.long_edge,1024);assert.equal(p.seconds,5);assert.ok(p.seconds*p.fps<=120);assert.equal(p.transparent,format==='frames');});
test('4K transparent PNG remains available',()=>{const p=normalize({format:'png',long_edge:4096,transparent:true});assert.equal(p.long_edge,4096);assert.equal(p.transparent,true);assert.equal(p.animation,false);});
test('Request options fail to safe defaults for malformed inputs',()=>{const p=normalize({format:'bad',long_edge:99999,fps:NaN,seconds:NaN});assert.equal(p.format,'png');assert.ok(Number.isFinite(p.seconds));assert.ok(Number.isFinite(p.fps));assert.equal(p.long_edge,1024);});
function tri(id,depth,side='front'){return {panel:id,side,screen:[[1,1],[14,1],[1,14]],q:[[0,0,depth[0]],[1,0,depth[1]],[0,1,depth[2]]],uv:[[0,0],[1,0],[0,1]],shade:1};}
const red={width:1,height:1,data:new Uint8ClampedArray([255,0,0,255])},blue={width:1,height:1,data:new Uint8ClampedArray([0,0,255,255])};
const textures=new Map([['red',red],['blue',blue]]),view={transparent:true};
const rgba=(p,x,y)=>Array.from(p.slice((y*16+x)*4,(y*16+x)*4+4));
test('Intersecting triangles use per-pixel depth, not painter order',()=>{const a=tri('red',[0,3,0]),b=tri('blue',[1,1,1]),p=raster({radius:1,triangles:[a,b]},16,16,view,{},textures),q=raster({radius:1,triangles:[b,a]},16,16,view,{},textures);assert.deepEqual(p,q);assert.deepEqual(rgba(p,2,2),[0,0,255,255]);assert.deepEqual(rgba(p,10,2),[255,0,0,255]);assert.deepEqual(rgba(p,15,15),[0,0,0,0]);});
test('Coincident surfaces do not alternate due to depth precision',()=>{const a=tri('red',[1.23456789,2.45678901,3.56789012]),b=tri('blue',[1.23456789,2.45678901,3.56789012]),p=raster({radius:2,triangles:[a,b]},16,16,view,{},textures);for(let y=2;y<8;y++)for(let x=2;x<8;x++)if(x+y<14)assert.deepEqual(rgba(p,x,y),[255,0,0,255]);});
test('Texture alpha composites against paper, not sky',()=>{const clear={width:1,height:1,data:new Uint8ClampedArray([255,0,0,0])},p=raster({radius:1,triangles:[tri('clear',[1,1,1])]},16,16,view,{exterior:'#abcdef'},new Map([['clear',clear]]));assert.deepEqual(rgba(p,3,3),[171,205,239,255]);});
test('Empty geometry remains background / transparent',()=>{const p=raster({radius:1,triangles:[]},16,16,{transparent:false,background:'#123456'});assert.deepEqual(rgba(p,3,3),[18,52,86,255]);});
for(const size of [0,4097,1.5])test('Invalid software canvas size '+size+' rejected',()=>assert.throws(()=>raster({radius:1,triangles:[]},size,16,view),/Invalid/));
