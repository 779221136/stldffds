import pytest
from app.domain import DesignObject,DesignPayload,preflight_payload
from app.preview_pdf import object_svg


def test_wrapped_preview_svg_uses_persisted_line_layout():
    obj=DesignObject.model_validate({'type':'text','id':'text','text':'Hello world','wrap':True,'textLines':['Hello ','world'],'fontSize':24})
    svg=object_svg(obj)
    assert svg.count('<tspan')==2
    assert '>Hello </tspan>' in svg and '>world</tspan>' in svg


@pytest.mark.parametrize('lines',[['Different'],['Hello\nworld'],['Hello','world']])
def test_lines_cannot_replace_original_text(lines):
    with pytest.raises(ValueError):
        DesignObject.model_validate({'type':'text','text':'Hello world','wrap':True,'textLines':lines})


def test_preflight_rejects_missing_wrapped_line_layout():
    payload=DesignPayload.model_validate({'objects':[{'id':'t','type':'text','text':'hello','wrap':True}]})
    report=preflight_payload(payload)
    assert not report['ok'] and any('line layout' in e for e in report['errors'])


def test_plain_v5_text_remains_compatible():
    obj=DesignObject.model_validate({'type':'text','text':'Legacy\ntext'})
    assert not obj.wrap and object_svg(obj).count('<tspan')==2
