#!/usr/bin/env python3
"""Local development smoke check. Never runs against a production environment."""
import argparse,json,secrets,urllib.request
from http.cookiejar import CookieJar

def main():
    p=argparse.ArgumentParser();p.add_argument('base',nargs='?',default='http://127.0.0.1:8088');a=p.parse_args()
    opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))
    def call(path,body=None,method=None):
        data=None if body is None else json.dumps(body).encode()
        req=urllib.request.Request(a.base.rstrip('/')+path,data=data,method=method or ('POST' if body is not None else 'GET'),headers={'Content-Type':'application/json'})
        with opener.open(req,timeout=30) as r:
            data=r.read();return json.loads(data) if 'json' in r.headers.get('content-type','') else data
    health=call('/api/health');assert health['ok']
    if health['environment']!='development':raise SystemExit('Smoke sign-in is for local development only; production SMS is intentionally disabled.')
    phone='139'+str(secrets.randbelow(10**8)).zfill(8)
    code=call('/api/auth/sms/send',{'phone':phone})['dev_code']
    call('/api/auth/sms/login',{'phone':phone,'code':code})
    payload={'box':{'length':120,'width':80,'height':180},'objects':[]}
    d=call('/api/designs',{'name':'smoke','kind':'template','source_id':25987,'payload':payload})
    updated=call('/api/designs',{'id':d['id'],'version':d['version'],'name':'smoke updated','kind':'template','source_id':25987,'payload':payload})
    assert updated['version']==2
    assert call('/api/exports/pdf',{'name':'smoke','mode':'structure','color_mode':'RGB','payload':payload}).startswith(b'%PDF')
    assert call('/api/templates?page_size=3')['page_size']==3
    quote=call('/api/print/quote',{'model_id':74,'length_mm':120,'width_mm':80,'height_mm':180,'material':'card','quantity':100,'crafts':['lamination']})
    assert quote['total']>0 and quote['estimate_only']
    call('/api/designs/'+str(d['id']),{},method='DELETE')
    call('/api/auth/logout',{})
    print('SMOKE_OK: local dev auth, versioned save, RGB preview, catalog, estimate and delete')
if __name__=='__main__':main()
