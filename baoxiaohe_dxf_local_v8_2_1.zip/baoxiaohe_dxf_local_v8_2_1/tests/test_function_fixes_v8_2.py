"""Regressions for the six v8.1 audit findings. Synthetic local fixtures only."""
import base64, copy, json, subprocess
from io import BytesIO
from pathlib import Path
import numpy as np
import pytest
from PIL import Image
from app.cad_engine import ImportRequest, CadDocument, parse_dxf, analyze, export_dxf, guess_role, scale_document
from app.cad_api import CadRenderRequest
from app.local_raster import render_image, triangles, RenderView
from app.structure import pose
ROOT=Path(__file__).resolve().parents[1]

def sample():
    data=base64.b64encode((ROOT/'examples/dxf/tuck.dxf').read_bytes()).decode()
    return CadDocument.model_validate(parse_dxf(ImportRequest(filename='tuck.dxf',data=data))['document'])

@pytest.mark.parametrize('name',['GUIDE','guide','REFERENCE','construction'])
def test_guide_names_take_precedence_over_cut_colour(name):
    assert guess_role(name,5,'CONTINUOUS')=='guide'

def test_customized_dxf_roundtrip_retains_roles_and_foldability():
    d=scale_document(sample(),1.25,1.25)
    source=d.model_dump_json(); exported=export_dxf(d)
    again=CadDocument.model_validate(parse_dxf(ImportRequest(filename='roundtrip.DXF',data=base64.b64encode(exported.encode()).decode()))['document'])
    assert d.model_dump_json()==source
    assert not any(p.role=='unassigned' for p in again.paths)
    assert any(p.layer=='GUIDE' and p.role=='guide' for p in again.paths)
    a,b=analyze(d),analyze(again)
    assert a['foldable'] and b['foldable']
    assert len(a['faces'])==len(b['faces'])==13
    assert sorted(round(f['area'],5) for f in a['faces'])==sorted(round(f['area'],5) for f in b['faces'])

def test_preview_layers_never_mutate_dxf_or_hinge_geometry():
    d=sample(); source=d.model_dump_json(); before=export_dxf(d)
    m=analyze(d)['model']
    assert d.model_dump_json()==source
    # ezdxf creates random document GUIDs/timestamps; compare exported geometry.
    def geometry(raw):
        data=base64.b64encode(raw.encode()).decode()
        return parse_dxf(ImportRequest(filename='same.dxf',data=data))['document']['paths']
    assert geometry(export_dxf(d))==geometry(before)
    assert len(m['previewLayering']['pairs'])==7
    assert m['previewLayering']['production_validated'] is False
    bare=copy.deepcopy(m);bare.pop('previewLayering')
    for p in bare['panels']: p['visualInset']=0
    assert pose(m,1,0)==pose(bare,1,0)
    assert any('preview-only' in w for w in m['warnings'])

@pytest.mark.parametrize('thickness',[0,.4,1.2])
def test_coplanar_overlaps_have_distinct_render_layers(thickness):
    d=sample();d.options.thickness=thickness;m=analyze(d)['model']
    byid={p['id']:p for p in m['panels']}
    for pair in m['previewLayering']['pairs']:
        a,b=(byid[id] for id in pair['panels'])
        assert a['visualInset']!=b['visualInset']
        assert byid[pair['outer']]['visualInset']==max(a['visualInset'],b['visualInset'])
    assert m['previewLayering']['spacing']>thickness

@pytest.mark.parametrize('fold',[0,.5,.95,1])
@pytest.mark.parametrize('opening',[0,1])
def test_python_browser_render_meshes_match(fold,opening):
    m=analyze(sample())['model']; v=RenderView(fold=fold,opening=opening)
    script="import {mesh} from './src/structure_math.js';let s='';for await(const c of process.stdin)s+=c;const r=JSON.parse(s);console.log(JSON.stringify(mesh(r.model,r.view)));"
    r=subprocess.run(['node','--input-type=module','-e',script],input=json.dumps({'model':m,'view':v.model_dump()}),text=True,capture_output=True,cwd=ROOT,check=True)
    js=json.loads(r.stdout);py,radius=triangles(m,v)
    assert js['radius']==pytest.approx(radius)
    assert len(py)==len(js['triangles'])
    for a,b in zip(py,js['triangles']):
        assert a[2:]==(b['panel'],b['side'])
        assert np.allclose(a[0],b['points'],atol=1e-8)
        assert np.allclose(a[1],b['uv'],atol=1e-8)

def solid_textures(m):
    values=['#1671ce','#c83244','#e8b021','#19a278','#772faa','#f0822e','#45bedd','#81766d','#ab4782','#305a9c','#6f9c26','#d06564','#518b8b']
    result={}
    for p,col in zip(m['panels'],values):
        b=BytesIO();Image.new('RGB',(16,16),col).save(b,format='PNG')
        result[p['id']]='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
    return result

def test_closed_solid_cover_has_no_alternating_stripes():
    d=sample();m=analyze(d)['model'];req=CadRenderRequest(cad_document=d,textures=solid_textures(m),long_edge=1024,view=RenderView(fold=1,yaw=-25,pitch=30))
    im=np.asarray(render_image(req,m))
    # Interior rectangle on the lid, >20 px from each projected edge.
    lid=im[135:175,460:620,:3]
    assert np.unique(lid.reshape(-1,3),axis=0).shape[0]==1
    assert not np.array_equal(im,np.asarray(render_image(req.model_copy(update={'view':RenderView(fold=.7,yaw=-25,pitch=30)}),m)))

def test_solid_render_is_repeatable_and_preserves_transparency():
    d=sample();m=analyze(d)['model'];req=CadRenderRequest(cad_document=d,long_edge=256,view=RenderView(transparent=True))
    a=np.asarray(render_image(req,m));b=np.asarray(render_image(req,m))
    assert np.array_equal(a,b)
    assert set(np.unique(a[:,:,3]))=={0,255}
