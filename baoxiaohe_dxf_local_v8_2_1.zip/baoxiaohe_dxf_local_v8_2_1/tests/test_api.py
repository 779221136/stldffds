import base64
import copy
import io
import json
from pathlib import Path
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from conftest import signin
import app.main as main

PAYLOAD={'box':{'length':120,'width':80,'height':180},'objects':[]}
DESIGN={'name':'audit','kind':'template','source_id':25987,'payload':PAYLOAD}
QUOTE={'model_id':74,'length_mm':120,'width_mm':80,'height_mm':180,'material':'white card','quantity':100,'crafts':['lamination']}

def png_src(w=100,h=100):
    b=io.BytesIO();Image.new('RGB',(w,h),'red').save(b,format='PNG')
    return 'data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()

def test_health_and_true_counts(client):
    h=client.get('/api/health').json();assert h['ok'] and not h['production_ready']
    m=client.get('/api/catalog/meta').json()
    assert m['template_count']==len(main.CATALOG['templates'])
    assert m['catalog_scope']=='sample'

def test_pagination(client):
    a=client.get('/api/templates?page_size=3&page=1').json()
    b=client.get('/api/templates?page_size=3&page=2').json()
    assert len(a['items'])==3
    assert {v['id'] for v in a['items']}.isdisjoint({v['id'] for v in b['items']})
    assert client.get('/api/templates?page=0').status_code==422
    assert client.get('/api/templates?sort=invalid').status_code==422

def test_search_and_sort(client):
    a=client.get('/api/templates?sort=new&page_size=100').json()['items']
    # Unknown publication dates retain source order; ID is not a timestamp.
    assert [x['id'] for x in a]==[x['id'] for x in main.CATALOG['templates']]
    name=a[0]['title'] if 'title' in a[0] else a[0]['name']
    assert client.get('/api/templates',params={'q':name}).json()['total']>0
    assert client.get('/api/templates?q=no-such-thing-xyz').json()['total']==0

@pytest.mark.parametrize('path',['/runtime/baoxiaohe.db','/runtime/catalog.json','/.env','/.env.example','/app/main.py','/requirements.txt','/server.py','/not-a-page','/api/no-such-route'])
def test_no_private_files(client,path):
    assert client.get(path).status_code==404

@pytest.mark.parametrize('path',['/','/templates','/models','/templates/25987','/models/74','/design/template/25987','/render/model/74','/team','/account'])
def test_spa_paths(client,path):
    assert client.get(path).status_code==200

def test_mutation_guards(client):
    assert client.post('/api/auth/sms/send',json={'phone':'13800138000'},headers={'Origin':'https://evil.example'}).status_code==403
    assert client.post('/api/auth/logout',content='{}',headers={'content-type':'text/plain'}).status_code==415
    assert client.post('/api/auth/logout',content=b'x'*(main.MAX_BODY+1),headers={'content-type':'application/json'}).status_code==413

def test_production_auth_fails_closed(client,monkeypatch):
    for value in ['production','prod','typo']:
        monkeypatch.setenv('ENV',value)
        assert client.post('/api/auth/sms/send',json={'phone':'13800138000'}).status_code==503
        assert client.post('/api/auth/sms/login',json={'phone':'13800138000','code':'123456'}).status_code==503

def test_otp_and_cookie_logout(client):
    user,code=signin(client)
    assert client.get('/api/me').json()['user']['id']==user['id']
    assert client.post('/api/auth/sms/login',json={'phone':user['phone'],'code':code}).status_code==400
    assert client.post('/api/auth/logout',json={}).status_code==200
    assert client.get('/api/me').json()['user'] is None

def test_otp_lock_and_resend(client):
    code=client.post('/api/auth/sms/send',json={'phone':'13800138000'}).json()['dev_code']
    assert client.post('/api/auth/sms/send',json={'phone':'13800138000'}).status_code==429
    wrong='000000' if code!='000000' else '111111'
    for i in range(5):
        assert client.post('/api/auth/sms/login',json={'phone':'13800138000','code':wrong}).status_code==400
    assert client.post('/api/auth/sms/login',json={'phone':'13800138000','code':code}).status_code==400

def test_expired_code(client):
    code=client.post('/api/auth/sms/send',json={'phone':'13800138000'}).json()['dev_code']
    with main.db() as c:c.execute('UPDATE sms_challenges SET expires_at=0')
    assert client.post('/api/auth/sms/login',json={'phone':'13800138000','code':code}).status_code==400

def test_design_crud_conflict_and_owner(client):
    assert client.post('/api/designs',json=DESIGN).status_code==401
    signin(client)
    a=client.post('/api/designs',json=DESIGN);assert a.status_code==200,a.text
    data={**DESIGN,**a.json(),'name':'updated'}
    b=client.post('/api/designs',json=data);assert b.status_code==200,b.text
    assert b.json()['version']==2
    assert client.post('/api/designs',json=data).status_code==409
    assert len(client.get('/api/designs').json()['items'])==1
    assert client.get('/api/designs/'+str(a.json()['id'])).json()['item']['name']=='updated'
    with TestClient(main.app) as other:
        signin(other,'13800138001')
        assert other.get('/api/designs/'+str(a.json()['id'])).status_code==404
        assert other.post('/api/designs',json={**data,'version':2}).status_code==404
        assert other.request('DELETE','/api/designs/'+str(a.json()['id']),json={}).status_code==404
        assert other.get('/api/designs').json()['items']==[]
    assert client.request('DELETE','/api/designs/'+str(a.json()['id']),json={}).status_code==200
    assert client.get('/api/designs').json()['items']==[]

def test_favorite_and_profile(client):
    assert client.get('/api/favorites').status_code==401
    signin(client)
    assert client.post('/api/favorites',json={'kind':'templates','item_id':25987}).status_code==200
    assert client.post('/api/favorites',json={'kind':'templates','item_id':99999999}).status_code==404
    assert len(client.get('/api/favorites').json()['items'])==1
    assert client.patch('/api/me',json={'name':'Updated'}).json()['user']['name']=='Updated'
    assert client.get('/api/me').json()['user']['name']=='Updated'

def test_quote_order_total_and_idempotency(client):
    q=client.post('/api/print/quote',json=QUOTE);assert q.status_code==200,q.text
    assert q.json()['estimate_only']
    request={'quote':QUOTE,'total':.01}
    assert client.post('/api/print/orders',json=request).status_code==401
    signin(client)
    a=client.post('/api/print/orders',json=request,headers={'Idempotency-Key':'audit-order-001'})
    assert a.status_code==200,a.text
    b=client.post('/api/print/orders',json=request,headers={'Idempotency-Key':'audit-order-001'})
    assert a.json()['id']==b.json()['id'] and a.json()['total']==q.json()['total']
    assert len(client.get('/api/account/orders').json()['items'])==1
    assert client.post('/api/print/quote',json={**QUOTE,'quantity':-1}).status_code==422

def test_no_fake_render_success(client):
    assert client.post('/api/render/jobs',json={}).status_code==501
    assert client.get('/api/render/jobs/fake').status_code==404
    assert client.get('/runtime/exports/fake.svg').status_code==404

@pytest.mark.parametrize('sym,value',[('CODE128','BOX-123'),('CODE39','BOX-123'),('EAN13','690123456789'),('EAN8','1234567')])
def test_barcode_svg_can_be_saved(client,sym,value):
    signin(client)
    r=client.get('/api/tools/barcode.svg',params={'symbology':sym,'value':value});assert r.status_code==200,r.text
    payload=copy.deepcopy(PAYLOAD)
    payload['objects']=[{'id':'b','type':'image','x':500,'y':300,'w':150,'h':80,'src':'data:image/svg+xml;base64,'+base64.b64encode(r.content).decode()}]
    r=client.post('/api/designs',json={**DESIGN,'payload':payload});assert r.status_code==200,r.text

def test_qr_and_invalid_barcode(client):
    r=client.get('/api/tools/qrcode.svg',params={'value':'https://example.com'});assert r.status_code==200
    from app.domain import image_data
    image_data('data:image/svg+xml;base64,'+base64.b64encode(r.content).decode())
    assert client.get('/api/tools/barcode.svg?value=6901234567899&symbology=EAN13').status_code==422
    assert client.get('/api/tools/barcode.svg?value=lowercase&symbology=CODE39').status_code==422

def test_image_dpi_and_pdf(client,tmp_path):
    payload=copy.deepcopy(PAYLOAD)
    payload['objects']=[{'id':'red','type':'image','x':510,'y':260,'w':100,'h':100,'src':png_src()},
      {'id':'t','type':'text','x':500,'y':400,'w':180,'h':60,'text':'AUDIT TEXT','fontSize':20,'fill':'#112233'},
      {'id':'s','type':'rect','x':540,'y':500,'w':80,'h':30,'fill':'#00bb66'}]
    r=client.post('/api/preflight',json={'payload':payload,'color_mode':'RGB'});assert r.status_code==200,r.text
    assert abs(r.json()['checks']['images'][0]['effective_dpi'] - (600/340)*25.4)<.1
    assert not r.json()['production_ready']
    for mode in ['print','structure']:
        pdf=client.post('/api/exports/pdf',json={'payload':payload,'name':'\u5305\u5c0f\u76d2','color_mode':'RGB','mode':mode})
        assert pdf.status_code==200,pdf.text
        assert pdf.content.startswith(b'%PDF')
        assert pdf.headers['X-Production-Ready']=='false'
        (tmp_path/(mode+'.pdf')).write_bytes(pdf.content)
    assert client.post('/api/exports/pdf',json={'payload':payload,'color_mode':'CMYK'}).status_code==501

@pytest.mark.parametrize('bad',["https://example.com/image.png",'data:image/svg+xml;base64,'+base64.b64encode(b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>').decode(),'data:image/svg+xml;base64,'+base64.b64encode(b'<svg xmlns="http://www.w3.org/2000/svg"><use href="https://example.com/a.svg"/></svg>').decode()])
def test_unsafe_image_rejected(client,bad):
    signin(client)
    payload=copy.deepcopy(PAYLOAD);payload['objects']=[{'id':'i','type':'image','src':bad}]
    assert client.post('/api/designs',json={**DESIGN,'payload':payload}).status_code==422

def test_invalid_dimensions_and_payload(client):
    assert client.post('/api/preflight',json={'payload':{'box':{'length':-1}}}).status_code==422
    assert client.post('/api/preflight',json={'payload':{'objects':[{'id':'x','type':'rect','w':-3}]}}).status_code==422

def test_cjk_preview_font_and_glyphs(client):
    import fitz
    payload=copy.deepcopy(PAYLOAD)
    payload['objects']=[{'id':'cjk','type':'text','x':600,'y':300,'w':150,'h':50,'text':'\u5305\u88c5\u9884\u89c8','fontSize':20}]
    response=client.post('/api/exports/pdf',json={'payload':payload,'color_mode':'RGB'})
    # No silent tofu: deployments with no CJK font must fail with a clear message.
    if response.status_code==422:
        assert 'CJK font' in response.text or 'CJK PDF' in response.text
        pytest.skip('CJK deployment font unavailable; explicit failure verified')
    assert response.status_code==200,response.text
    pdf=fitz.open(stream=response.content,filetype='pdf')
    assert '\u5305\u88c5\u9884\u89c8' in pdf[0].get_text()

def test_old_sessions_revoked_once_on_auth_migration(client):
    signin(client)
    assert client.get('/api/me').json()['user']
    with main.db() as c:
        c.execute("DELETE FROM schema_meta WHERE key='auth_version'")
    main.init_db()
    assert client.get('/api/me').json()['user'] is None
    user,_=signin(client,'13800138002')
    main.init_db()
    assert client.get('/api/me').json()['user']['id']==user['id']
