import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {wheelPixels,isComposingEvent,isEditableTarget,hasBlockingDialog,blockEditorShortcut,modalKeydown,createVideoRecorder,recordedVideo,videoExtension,rasterMime} from '../src/browser_compat.js';

const header = [137,80,78,71,13,10,26,10];
test('same physical wheel amount: 16 pixels equals one line',()=>assert.equal(wheelPixels({deltaMode:0,deltaY:16}),wheelPixels({deltaMode:1,deltaY:1})));
test('same physical wheel amount: page deltas use preview height',()=>assert.equal(wheelPixels({deltaMode:2,deltaY:.1},{pageHeight:200}),wheelPixels({deltaMode:0,deltaY:20})));
test('wheel reads deltaMode before deltaY',()=>{const order=[];wheelPixels({get deltaMode(){order.push('mode');return 0;},get deltaY(){order.push('delta');return 1;}});assert.deepEqual(order,['mode','delta']);});
test('wheel caps huge positive and negative device spikes',()=>{assert.equal(wheelPixels({deltaMode:2,deltaY:10000}),240);assert.equal(wheelPixels({deltaMode:2,deltaY:-10000}),-240);});
test('wheel preserves zero and fractional pixel deltas',()=>{assert.equal(wheelPixels({deltaMode:0,deltaY:.2}),.2);assert.equal(wheelPixels({deltaMode:0,deltaY:0}),0);});
test('wheel rejects nonfinite delta and uses safe invalid layout defaults',()=>{assert.equal(wheelPixels({deltaY:NaN}),0);assert.equal(wheelPixels({deltaY:Infinity}),0);assert.equal(wheelPixels({deltaMode:1,deltaY:1},{lineHeight:NaN}),16);});
test('IME composition and legacy 229 do not invoke editor shortcuts',()=>{assert.ok(isComposingEvent({isComposing:true}));assert.ok(isComposingEvent({keyCode:229}));assert.equal(isComposingEvent({keyCode:46}),false);});
test('text inputs, select, contenteditable and textbox roles are editable',()=>{for(const tagName of ['INPUT','TEXTAREA','SELECT'])assert.ok(isEditableTarget({tagName}));assert.ok(isEditableTarget({isContentEditable:true}));assert.ok(isEditableTarget({closest:()=>({})}));assert.equal(isEditableTarget({tagName:'BUTTON'}),false);});
function dialogDoc(shown=true){return {querySelectorAll:()=>[{hidden:!shown,closest:()=>null,getClientRects:()=>shown?[{}]:[]}],activeElement:{tagName:'BUTTON'}};}
test('visible modal blocks global shortcuts even when focus escapes',()=>assert.ok(blockEditorShortcut({target:{tagName:'BODY'}},dialogDoc())));
test('closed/hidden modal does not block normal artwork shortcuts',()=>{assert.equal(hasBlockingDialog(dialogDoc(false)),false);assert.equal(blockEditorShortcut({},dialogDoc(false)),false);});
test('prevented keys and editable event targets are respected',()=>{assert.ok(blockEditorShortcut({defaultPrevented:true},dialogDoc(false)));assert.ok(blockEditorShortcut({target:{tagName:'INPUT'}},dialogDoc(false)));});
function event(key,extra={}){return{key,stopped:false,prevented:false,stopPropagation(){this.stopped=true;},preventDefault(){this.prevented=true;},...extra};}
test('modal Delete stops bubbling without disabling native deletion in its input',()=>{const e=event('Delete');modalKeydown(e,{},()=>assert.fail('not Escape'));assert.ok(e.stopped);assert.equal(e.prevented,false);});
test('modal Escape closes once and cannot clear selection behind it',()=>{const e=event('Escape');let n=0;modalKeydown(e,{},()=>n++);assert.equal(n,1);assert.ok(e.stopped&&e.prevented);});
test('IME Escape in modal is left for the input method',()=>{const e=event('Escape',{isComposing:true});modalKeydown(e,{},()=>assert.fail('should not close'));assert.ok(e.stopped);assert.equal(e.prevented,false);});
test('modal blocks Ctrl+S and Command+S from saving/nesting',()=>{for(const modifier of ['ctrlKey','metaKey']){const e=event('s',{[modifier]:true});modalKeydown(e,{},()=>{});assert.ok(e.stopped&&e.prevented);}});
test('modal traps Tab and Shift+Tab on enabled visible controls',()=>{let focus='';const item=name=>({tabIndex:0,closest:()=>null,getClientRects:()=>[1],focus:()=>focus=name});const first=item('first'),last=item('last'),hidden={...item('hidden'),getClientRects:()=>[]};const wrap={querySelectorAll:()=>[first,last,hidden],ownerDocument:{activeElement:last}};let e=event('Tab');modalKeydown(e,wrap,()=>{});assert.equal(focus,'first');assert.ok(e.prevented);wrap.ownerDocument.activeElement=first;e=event('Tab',{shiftKey:true});modalKeydown(e,wrap,()=>{});assert.equal(focus,'last');});
function recorderClass(support,fail=()=>false){return class Recorder{static isTypeSupported(m){return support(m);}constructor(stream,opts){if(fail(opts.mimeType))throw Error('encoder unavailable');this.mimeType=opts.mimeType;this.stream=stream;this.opts=opts;}};}
test('WebM-capable recorder is selected without OS sniffing',()=>{const r=createVideoRecorder({}, {},recorderClass(t=>t.startsWith('video/webm')));assert.equal(r.mimeType,'video/webm;codecs=vp8');});
test('MP4-only capability chooses MP4 rather than rejecting recording',()=>{const r=createVideoRecorder({}, {},recorderClass(t=>t==='video/mp4'));assert.equal(r.mimeType,'video/mp4');});
test('advertised but unusable encoder falls through to next format',()=>{const r=createVideoRecorder({}, {},recorderClass(()=>true,t=>t.startsWith('video/webm')));assert.ok(r.mimeType.startsWith('video/mp4'));});
test('unavailable MediaRecorder or unsupported formats have actionable local fallback',()=>{assert.throws(()=>createVideoRecorder({}, {},null),/WebM\/MP4/);assert.throws(()=>createVideoRecorder({}, {},recorderClass(()=>false)),/WebM\/MP4/);});
test('recorder quality options are retained',()=>{const r=createVideoRecorder({}, {videoBitsPerSecond:4000000},recorderClass(()=>true));assert.equal(r.opts.videoBitsPerSecond,4000000);});
test('recorded MP4 blob MIME and extension remain MP4',()=>{const b=recordedVideo([new Blob(['test'],{type:'video/mp4'})],{mimeType:'video/mp4;codecs=avc1'});assert.equal(b.type,'video/mp4');assert.equal(videoExtension(b),'mp4');});
test('recorder-reported MIME is fallback for typeless chunks',()=>{const b=recordedVideo([new Blob(['test'])],{mimeType:'video/webm;codecs=vp8'});assert.equal(videoExtension(b),'webm');});
test('actual output MIME wins over requested recording MIME',()=>{const b=recordedVideo([new Blob(['test'],{type:'video/mp4'})],{mimeType:'video/webm'});assert.equal(videoExtension(b),'mp4');});
test('unknown video containers are rejected rather than mislabeled',()=>assert.throws(()=>recordedVideo([new Blob(['test'],{type:'text/plain'})],{mimeType:'video/mp4'})));
test('PNG detection uses magic bytes, not a MIME label',()=>assert.equal(rasterMime(new Uint8Array(header)),'image/png'));
test('JPEG detection uses magic bytes',()=>assert.equal(rasterMime(new Uint8Array([255,216,255,224])),'image/jpeg'));
test('truncated and nonimage signatures are rejected',()=>{for(const bytes of [[],[137,80],[255,216],[60,115,118,103],[137,80,78,71,0,10,26,10]])assert.equal(rasterMime(new Uint8Array(bytes)),null);});
const bootstrap=fs.readFileSync(new URL('../src/browser_bootstrap.js',import.meta.url),'utf8');
function gate({clone=true,arrayAt=true}={}){
 const elements=[];const element=tag=>({tag,noModule:false,style:{},children:[],setAttribute(){},appendChild(c){this.children.push(c);elements.push(c);}}),root=element('main');
 function BlobStub(){}BlobStub.prototype.arrayBuffer=function(){};BlobStub.prototype.text=function(){};
 function ImageStub(){}ImageStub.prototype.decode=function(){};
 const win={structuredClone:clone?()=>{}:undefined,ResizeObserver:function(){},PointerEvent:function(){},fetch:()=>{},Promise,AbortController,TextEncoder,TextDecoder,Blob:BlobStub,Image:ImageStub};
 const doc={createElement:element,getElementById:()=>root,body:element('body')};
 const prefix=arrayAt?'':'Array.prototype.at=undefined;';vm.runInNewContext(prefix+bootstrap,{window:win,document:doc});return {elements,root,doc};
}
test('modern capable engine loads app module once',()=>{const r=gate();assert.equal(r.elements.filter(e=>e.type==='module').length,1);assert.match(r.elements.find(e=>e.type==='module').src,/8\.1/);});
test('missing structuredClone shows message BEFORE any app module',()=>{const r=gate({clone:false});assert.equal(r.elements.filter(e=>e.type==='module').length,0);assert.ok(r.elements.some(e=>String(e.textContent).includes('structuredClone')));});
test('missing Array.at shows an explicit diagnostic',()=>{const r=gate({arrayAt:false});assert.equal(r.elements.filter(e=>e.type==='module').length,0);assert.ok(r.elements.some(e=>String(e.textContent).includes('Array.at')));});
test('failed module load displays recovery hint',()=>{const r=gate();r.elements.find(e=>e.type==='module').onerror();assert.equal(r.root.children.at(-1).id,'browser-compatibility-message');});
test('startup gate itself does not contain optional chaining or arrow syntax',()=>{assert.ok(!bootstrap.includes('?.'));assert.ok(!bootstrap.includes('=>'));});
test('all renderers use shared MIME negotiation and dynamic download extension',()=>{for(const name of ['webgl_renderer.js','canvas_renderer.js','render_opening.js']){const s=fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8');assert.ok(s.includes('createVideoRecorder('));assert.ok(s.includes('recordedVideo('));assert.ok(!s.includes("{type:'video/webm'}"));}const app=fs.readFileSync(new URL('../src/app.js',import.meta.url),'utf8');assert.ok(app.includes('videoExtension(blob)'));assert.ok(app.includes("${opening?'opening':'360'}.${ext}"));});
