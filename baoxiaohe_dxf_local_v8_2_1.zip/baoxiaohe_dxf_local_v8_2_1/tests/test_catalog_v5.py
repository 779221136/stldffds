import copy
import math
import pytest
from app.catalog import asset_path, has_price, query_items, present
import app.main as main

@pytest.fixture
def rich(client,monkeypatch):
    c=copy.deepcopy(main.CATALOG)
    c['templates']=[
        {'id':91001,'title':'A BOX','type':'paper','subtype':'tuck','style':['plain'],'use':['retail'],'material':'card','industry':'food','channels':['online'],'model':'M1','price':0,'member_price':0,'author':{'name':'Designer','official':False},'views':10,'created_at':'2025-01-01'},
        {'id':91002,'title':'B BOX','type':'paper','subtype':'tuck','style':['plain'],'use':['retail'],'material':'card','industry':'food','channels':['offline'],'model':'M1','price':80,'member_price':0,'views':30,'created_at':'2026-03-01'},
        {'id':91003,'title':'C BAG','type':'bag','subtype':'bag','style':['art'],'use':['gift'],'material':'film','industry':'other','channels':['online'],'model':'M2','price':20,'member_price':10,'views':20,'created_at':'2026-02-01'},
        {'id':91004,'title':'D UNKNOWN','type':'paper','material':'card','model':'M1','pro':False,'price':None,'member_price':None,'views':0},
    ]
    monkeypatch.setattr(main,'CATALOG',c);return client

@pytest.mark.parametrize('field,value,expected',[
 ('model','tuck',{91001,91002}),('model','M1',{91001,91002,91004}),
 ('material','card',{91001,91002,91004}),('channel','online',{91001,91003}),
 ('price','free',{91001}),('price','member_free',{91001,91002}),('price','paid',{91002,91003})])
def test_facets(rich,field,value,expected):
    r=rich.get('/api/templates',params={field:value,'page_size':100});assert r.status_code==200,r.text
    assert {x['id'] for x in r.json()['items']}==expected

def test_combined_facets_and_unknown_not_free(rich):
    r=rich.get('/api/templates',params={'type':'paper','model':'tuck','material':'card','channel':'offline','price':'member_free'}).json()
    assert [x['id'] for x in r['items']]==[91002]
    t=rich.get('/api/templates/91004').json()['item'];assert t['price'] is None and t['author'] is None

def test_price_sort_null_last(rich):
    assert [x['id'] for x in rich.get('/api/templates?sort=price_asc').json()['items']]==[91001,91003,91002,91004]
    assert [x['id'] for x in rich.get('/api/templates?sort=price_desc').json()['items']]==[91002,91003,91001,91004]

def test_new_uses_date_not_identifier(rich):
    assert rich.get('/api/templates?sort=new').json()['items'][0]['id']==91002

def test_metadata_and_filter_input_bounds(rich):
    m=rich.get('/api/catalog/meta').json();assert m['categories']['channels'][1:]==['offline','online']
    assert rich.get('/api/templates?price=invalid').status_code==422
    assert rich.get('/api/templates',params={'material':'x'*121}).status_code==422

def test_metadata_not_searchable_as_false_product_text(rich):
    assert rich.get('/api/templates?q=source_verified').json()['total']==0

def test_new_backend_only_details_are_served(rich):
    r=rich.get('/templates/91002');assert r.status_code==200
    assert '<title>B BOX' in r.text
    assert 'noindex' in r.headers['x-robots-tag']
    assert rich.get('/design/template/91002').status_code==200

@pytest.mark.parametrize('path',['/templates/99999999','/models/99999999','/design/template/99999999','/render/model/99999999'])
def test_nonexistent_item_really_404(client,path):
    assert client.get(path).status_code==404

def test_title_is_html_escaped(rich):
    main.CATALOG['templates'][0]['title']='</title><script>alert(1)</script>'
    r=rich.get('/templates/91001');assert '</title><script>alert(1)' not in r.text and '&lt;script&gt;' in r.text

@pytest.mark.parametrize('value',[None,-1,False,float('nan'),float('inf'),'0'])
def test_bad_prices_do_not_equal_free(value):assert not has_price(value)

@pytest.mark.parametrize('path',[None,'https://example.com/x.png','/assets/media/../x.png','/assets/media/x.png" onerror="alert(1)','/assets/media//x.svg','/assets/media/asset.woff2'])
def test_assets_are_local_allowlisted_paths(path):assert asset_path(path) is None

def test_palette_and_shape_injection_not_rendered():
    x=present({'id':1,'c':['" onmouseover="oops'], 'shape':'box" onclick="bad'},'templates')
    assert x['c'][0]=='#eee8df' and x['shape']=='box'

def test_acceptance_gate_remains_blocked(client):
    r=client.get('/api/readiness').json();assert not r['production_ready'] and not r['parity_verified'] and len(r['blockers'])>=6

def test_zoom_fits_narrow_editor():
    from app.domain import DesignPayload
    p=DesignPayload.model_validate({'box':{'length':120,'width':80,'height':180},'objects':[],'zoom':.15})
    assert p.zoom==.15
