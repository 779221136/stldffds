"""Encoding/container tests use authored fixtures, not the user's missing DXF."""
import base64
import codecs
import hashlib
import re
from io import StringIO

import ezdxf
import pytest
from pydantic import ValidationError

from app.cad_engine import ImportRequest, parse_dxf
from app.dxf_text_reader import read_ascii_dxf


def fixture(version='R2010', layer='CUT', encoding=None, remove_codepage=False):
    d = ezdxf.new(version)
    d.units = 4
    if encoding:
        d.encoding = encoding
    d.layers.new(layer, dxfattribs={'color': 5})
    m = d.modelspace()
    for a, b in [((0, 0), (60, 0)), ((60, 0), (60, 40)), ((60, 40), (0, 40)), ((0, 40), (0, 0))]:
        m.add_line(a, b, dxfattribs={'layer': layer})
    s = StringIO()
    d.write(s)
    text = s.getvalue()
    if remove_codepage:
        text = re.sub(r'(?m)^ *9\n\$DWGCODEPAGE\n *3\n[^\n]*\n', '', text)
    return text.encode(d.output_encoding)


def imported(data, **kw):
    return parse_dxf(ImportRequest(filename='test.DXF', data=base64.b64encode(data).decode('ascii'), **kw))


@pytest.mark.parametrize('version', ['R12', 'R2000', 'R2004', 'R2007', 'R2010', 'R2013', 'R2018'])
def test_supported_version_ascii_roundtrip(version):
    r = imported(fixture(version), unit='mm')
    assert len(r['document']['paths']) == 4
    assert r['encoding_info']['encoding'] == ('cp1252' if version in ('R12', 'R2000', 'R2004') else 'utf-8')


@pytest.mark.parametrize('ending', ['lf', 'crlf', 'cr'])
@pytest.mark.parametrize('bom', [False, True])
def test_utf8_bom_and_record_endings_preserve_coordinates(ending, bom):
    original = fixture(layer='\u5200\u7ebf')
    data = original.replace(b'\n', {'lf': b'\n', 'crlf': b'\r\n', 'cr': b'\r'}[ending])
    if bom:
        data = codecs.BOM_UTF8 + data
    r = imported(data)
    baseline = imported(original)
    assert r['document']['paths'] == baseline['document']['paths']
    assert r['document']['source_sha256'] == hashlib.sha256(data).hexdigest()
    assert r['encoding_info']['utf8_bom_removed'] == bom
    assert r['encoding_info']['line_endings_normalized'] == (ending != 'lf')


@pytest.mark.parametrize('encoding,layer', [('gbk', '\u5200\u7ebf'), ('cp950', '\u5200\u7dda'), ('cp932', '\u5207\u65ad'), ('cp949', 'CUT \ud55c\uae00'), ('cp1252', 'Caf\u00e9 CUT')])
def test_declared_legacy_encodings(encoding, layer):
    r = imported(fixture('R2000', layer, encoding))
    assert r['encoding_info']['encoding'] == encoding
    assert {p['layer'] for p in r['document']['paths']} == {layer}


def test_legacy_without_codepage_uses_documented_default():
    data = fixture('R2000', 'Caf\u00e9 CUT', 'cp1252', True)
    assert b'$DWGCODEPAGE' not in data
    r = imported(data)
    assert r['encoding_info']['encoding'] == 'cp1252'
    assert r['encoding_info']['encoding_source'] == 'legacy-default'
    assert r['document']['paths'][0]['layer'] == 'Caf\u00e9 CUT'
    assert any('no $DWGCODEPAGE' in w for w in r['warnings'])


def test_headerless_r12_default_and_explicit_units():
    data = b'0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nCaf\xe9 CUT\n62\n5\n10\n0\n20\n0\n11\n60\n21\n40\n0\nENDSEC\n0\nEOF\n'
    r = imported(data, unit='mm')
    assert r['document']['paths'][0]['layer'] == 'Caf\u00e9 CUT'
    with pytest.raises(ValueError, match='no declared units'):
        imported(data)


def test_metadata_beyond_old_64k_probe():
    data = b'999\n' + b'x'*70000 + b'\n' + fixture('R2000', '\u5200\u7ebf', 'gbk')
    r = imported(data)
    assert r['encoding_info']['encoding'] == 'gbk'
    assert r['document']['paths'][0]['layer'] == '\u5200\u7ebf'


def test_manual_gbk_for_known_misdeclared_export_not_automatic_guess():
    data = fixture('R2000', '\u5200\u7ebf', 'gbk').replace(b'ANSI_936', b'ANSI_1252')
    r = imported(data, encoding='gbk')
    assert r['encoding_info']['encoding_source'] == 'manual'
    assert r['document']['paths'][0]['layer'] == '\u5200\u7ebf'
    assert any('Manual' in w for w in r['warnings'])


def test_r2007_codepage_does_not_override_utf8():
    data = fixture(layer='\u5200\u7ebf').replace(b'ANSI_1252', b'ANSI_936')
    r = imported(data)
    assert r['encoding_info']['encoding'] == 'utf-8'
    assert r['document']['paths'][0]['layer'] == '\u5200\u7ebf'


def test_utf8_bom_disambiguates_legacy_nonstandard_utf8():
    # Build a valid R2000 text then encode it in UTF-8 with BOM, not the codepage.
    text = fixture('R2000', '\u5200\u7ebf', 'gbk').decode('gbk')
    r = imported(codecs.BOM_UTF8 + text.encode('utf-8'))
    assert r['encoding_info']['encoding_source'] == 'utf8-bom'
    assert r['document']['paths'][0]['layer'] == '\u5200\u7ebf'


def test_explicit_override_conflicting_with_bom_rejected():
    with pytest.raises(ValueError, match='DXF_ENCODING_CONFLICT'):
        imported(codecs.BOM_UTF8+fixture(), encoding='gbk')


def test_unknown_codepage_not_silently_accepted():
    data = fixture('R2000').replace(b'ANSI_1252', b'UNKNOWN_ENCODING')
    with pytest.raises(ValueError, match='DXF_CODEPAGE'):
        imported(data)
    assert len(imported(data, encoding='cp1252')['document']['paths']) == 4


def test_undecodable_utf8_is_not_silently_replaced_or_dropped():
    data = fixture(layer='Caf\u00e9 CUT').replace('Caf\u00e9'.encode('utf-8'), b'Caf\xff')
    with pytest.raises(ValueError, match='DXF_ENCODING') as exc:
        imported(data)
    assert isinstance(exc.value.__cause__, UnicodeDecodeError)


def test_corrupt_coordinates_report_structure_not_encoding():
    data = fixture()
    header, entity_data = data.split(b'ENTITIES\n', 1)
    entity_data, n = re.subn(rb'(?m)^ *10\n0\.0\n', b' 10\nnot-a-number\n', entity_data, count=1)
    data = header + b'ENTITIES\n' + entity_data
    assert n
    with pytest.raises(ValueError, match='DXF_STRUCTURE'):
        imported(data)


@pytest.mark.parametrize('raw,code', [(b'', 'DXF_EMPTY'), (b'AutoCAD Binary DXF\r\n\x1a\0', 'DXF_BINARY'), (b'AC1032\x00\x01', 'DXF_DWG'), (b'%PDF-1.7', 'DXF_FORMAT'), (b'PK\x03\x04data', 'DXF_FORMAT'), (b'hello world', 'DXF_FORMAT'), (codecs.BOM_UTF16_LE + '0\nSECTION'.encode('utf-16-le'), 'DXF_UNICODE_FORMAT'), (codecs.BOM_UTF16_BE + '0\nSECTION'.encode('utf-16-be'), 'DXF_UNICODE_FORMAT'), (codecs.BOM_UTF32_LE + '0\nSECTION'.encode('utf-32-le'), 'DXF_UNICODE_FORMAT'), (b'0\x00\nSECTION', 'DXF_FORMAT')])
def test_container_errors_are_distinct(raw, code):
    with pytest.raises(ValueError, match=code):
        read_ascii_dxf(raw)


def test_encoding_allowlist_and_size_limit():
    with pytest.raises(ValidationError):
        ImportRequest(filename='f.dxf', data='YQ==', encoding='unicode_escape')
    with pytest.raises(ValueError, match='5 MiB'):
        read_ascii_dxf(b' '* (5*1024*1024+1))


def test_api_legacy_request_unchanged_and_new_parameter(client):
    client.get('/api/local/capabilities')
    body = {'filename': '\u5200\u6a21.DXF', 'data': base64.b64encode(fixture()).decode()}
    r = client.post('/api/local/cad/import', json=body)
    assert r.status_code == 200, r.text
    assert r.json()['encoding_info']['encoding'] == 'utf-8'
    body['data'] = base64.b64encode(fixture('R2000', '\u5200\u7ebf', 'gbk')).decode()
    body['encoding'] = 'gbk'
    r = client.post('/api/local/cad/import', json=body)
    assert r.status_code == 200, r.text
    assert r.json()['document']['paths'][0]['layer'] == '\u5200\u7ebf'
    body['encoding'] = 'utf-8'
    r = client.post('/api/local/cad/import', json=body)
    assert r.status_code == 422
    assert '[DXF_ENCODING]' in r.text


def test_api_encoding_choice_rejected_if_not_allowlisted(client):
    client.get('/api/local/capabilities')
    r = client.post('/api/local/cad/import', json={'filename': 'x.dxf', 'data': 'YQ==', 'encoding': 'ascii-ignore'})
    assert r.status_code == 422
