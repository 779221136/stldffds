import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {placementMatrix,inverseMatrix,applyMatrix,rawToCanvas,pathD,pathBounds,canvasPanelLayout} from '../src/cad_geometry.js';
import {pose,mesh} from '../src/structure_math.js';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
const cases=JSON.parse(fs.readFileSync(new URL('./fixtures/cad_mesh.json',import.meta.url)));
for(const p of [{scale:2,rotation:0,x:10,y:20},{scale:.4,rotation:37,x:600,y:360},{scale:4,rotation:-120,x:-70,y:50}]){
 test('Placement inverse preserves artwork registration '+p.rotation,()=>{const m=placementMatrix(p),inv=inverseMatrix(m),point=[31.75,-27.4],result=applyMatrix(inv,applyMatrix(m,point));result.forEach((x,i)=>near(x,point[i]));});
}
test('DXF Y up maps to canvas Y down',()=>assert.deepEqual(rawToCanvas({scale:2,rotation:0,x:0,y:0},[5,10]),[10,-20]));
test('Arc uses analytic SVG arc, not a rectangle',()=>{const p={type:'ARC',center:[0,0],radius:10,start:0,sweep:270};assert.match(pathD(p),/A10,10 0 1 0/);assert.deepEqual(pathBounds([p]).map(v=>Math.round(v)),[-10,-10,10,10]);});
test('Circle bounds exact',()=>assert.deepEqual(pathBounds([{type:'CIRCLE',center:[30,40],radius:7,start:0,sweep:360}]),[23,33,37,47]));
for(const fixture of cases){
 test('Python and JavaScript imported hinges agree: '+fixture.name,()=>{for(const item of fixture.poses){const a=pose(fixture.model,item.fold,item.opening);assert.equal(a.length,item.expected.length);a.forEach((p,i)=>p.points.flat().forEach((x,j)=>near(x,item.expected[i].points.flat()[j])));}});
 test('Imported mesh is finite and respects triangulation: '+fixture.name,()=>{const view={fold:1,opening:.2,framing:'pose'},m=mesh(fixture.model,view);assert.ok(m.radius>0);assert.ok(m.triangles.length>0);assert.ok(m.triangles.flatMap(t=>t.points.flat()).every(Number.isFinite));const expected=fixture.model.panels.reduce((n,p)=>n+p.triangles.length,0);assert.equal(m.triangles.filter(t=>t.side==='front').length,expected);});
}
test('Hole is not filled by front triangles',()=>{const model=cases.find(x=>x.name==='hole').model,p=model.panels[0],area=t=>Math.abs((t[1][0]-t[0][0])*(t[2][1]-t[0][1])-(t[1][1]-t[0][1])*(t[2][0]-t[0][0]))/2;const total=p.triangles.reduce((n,t)=>n+area(t),0);assert.ok(total>8650&&total<8800);assert.equal(p.holes.length,1);});
