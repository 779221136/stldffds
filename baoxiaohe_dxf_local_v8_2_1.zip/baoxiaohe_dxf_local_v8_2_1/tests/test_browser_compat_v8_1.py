"""Scoped backend encoding check, not native Windows certification."""
import json
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
import app.local_worker as worker

def test_worker_explicit_utf8_preserves_unicode_on_non_utf8_defaults(tmp_path,monkeypatch):
    original_read=Path.read_text
    seen={}
    def read(path,*args,**kwargs):
        if path.name=='input.json':
            assert kwargs.get('encoding')=='utf-8'
            # Equivalent bytes would not survive a CP936/default-locale read.
        return original_read(path,*args,**kwargs)
    monkeypatch.setattr(Path,'read_text',read)
    original_write=Path.write_text
    def write(path,*args,**kwargs):
        if path.name=='progress.tmp':assert kwargs.get('encoding')=='utf-8'
        return original_write(path,*args,**kwargs)
    monkeypatch.setattr(Path,'write_text',write)
    data={'name':'\u5305\u88c5\u6e32\u67d3\u4efb\u52a1\U0001f4e6','format':'png'}
    (tmp_path/'input.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    def validate(payload):
        seen.update(payload);return SimpleNamespace(format='png',spec={})
    monkeypatch.setattr(worker,'LocalRenderRequest',SimpleNamespace(model_validate=validate))
    monkeypatch.setattr(worker,'build_structure',lambda _:None)
    monkeypatch.setattr(worker,'decode_textures',lambda _:None)
    monkeypatch.setattr(worker,'render_image',lambda *args:Image.new('RGBA',(4,4)))
    worker.run(tmp_path)
    assert seen==data
    assert (tmp_path/'result.png').read_bytes().startswith(b'\x89PNG')
    assert json.loads((tmp_path/'progress.json').read_text(encoding='utf-8'))['progress']==100

def test_index_has_classic_capability_gate_before_loading_application():
    source=(Path(__file__).resolve().parents[1]/'index.html').read_text(encoding='utf-8')
    assert '<script src="/src/browser_bootstrap.js?v=8.1-browser-compat"></script>' in source
    assert '<script type="module"' not in source
