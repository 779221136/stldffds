import sqlite3
from app import revisions

c = sqlite3.connect(':memory:')
c.executescript('''
CREATE TABLE designs(id INTEGER PRIMARY KEY,version INTEGER,user_id INTEGER,name TEXT,kind TEXT,source_id INTEGER,payload TEXT,updated_at INTEGER);
CREATE TABLE design_revisions(design_id INTEGER,version INTEGER,name TEXT,kind TEXT,source_id INTEGER,payload TEXT,created_at INTEGER,reason TEXT,restored_from INTEGER,PRIMARY KEY(design_id,version));
INSERT INTO designs VALUES(1,2,7,'current','template',25987,'{}',100);
INSERT INTO design_revisions VALUES(1,1,'old','template',25987,'{}',90,'save',NULL);
''')
revisions.migrate(c)
revisions.migrate(c)
revisions.checkpoint(c,1,7)
assert c.execute('SELECT version,user_id,name FROM design_revisions ORDER BY version').fetchall()==[(1,7,'old'),(2,7,'current')]
assert c.execute('PRAGMA integrity_check').fetchone()==('ok',)
print('v5.2 migration preserves history and is repeatable')
fresh = sqlite3.connect(':memory:')
fresh.execute('CREATE TABLE designs(id INTEGER PRIMARY KEY,version INTEGER,user_id INTEGER,name TEXT,kind TEXT,source_id INTEGER,payload TEXT,updated_at INTEGER)')
fresh.execute("INSERT INTO designs VALUES(1,1,7,'fresh','template',25987,'{}',100)")
revisions.migrate(fresh)
revisions.checkpoint(fresh,1,7)
assert fresh.execute('SELECT user_id,name FROM design_revisions').fetchall()==[(7,'fresh')]
print('Fresh database OK')
