import json
import math
import subprocess
from pathlib import Path
import numpy as np
import pytest
from shapely.geometry import Polygon,LineString
from shapely.ops import unary_union
from pydantic import ValidationError
from app.structure import StructureSpec,build_structure,pose,export_svg,export_dxf,hinge_matrix,display_matrix
from app.local_raster import LocalRenderRequest,RenderView,render_image,dimensions

@pytest.mark.parametrize('kind,height',[('tuck',160),('hinged',35)])
def test_no_flat_overlap_and_internal_hinges(kind,height):
    m=build_structure({'kind':kind,'height':height})
    union=unary_union([Polygon(p['polygon']) for p in m['panels']])
    assert union.area==pytest.approx(sum(Polygon(p['polygon']).area for p in m['panels']))
    assert union.geom_type=='Polygon'
    by={p['id']:p for p in m['panels']}
    for p in m['panels']:
        if p['parent']:
            edge=LineString(p['axis']);child=Polygon(p['polygon']);parent=Polygon(by[p['parent']]['polygon'])
            assert edge.difference(child.boundary.buffer(1e-7)).length < 1e-5
            assert edge.difference(parent.boundary.buffer(1e-7)).length < 1e-5
            assert edge.intersection(union.boundary).length<1e-5

@pytest.mark.parametrize('kind,height',[('tuck',160),('hinged',35)])
@pytest.mark.parametrize('fold,opening',[(0,0),(.2,0),(.64,.7),(1,0),(1,.5),(1,1)])
def test_hinge_integrity_and_panel_rigidity(kind,height,fold,opening):
    m=build_structure({'kind':kind,'height':height});p=pose(m,fold,opening);by={q['id']:q for q in p['panels']}
    for desc,trans in zip(m['panels'],p['panels']):
        points=np.array(trans['points']);original=np.array(desc['polygon'])
        for a in range(len(points)):
            for b in range(len(points)):
                assert np.linalg.norm(points[a]-points[b])==pytest.approx(np.linalg.norm(original[a]-original[b]),abs=1e-7)
        if desc['parent']:
            A=np.array(trans['matrix']);B=np.array(by[desc['parent']]['matrix'])
            for end in desc['axis']:
                v=np.array([*end,0,1]);assert np.max(np.abs(A@v-B@v))<1e-7

@pytest.mark.parametrize('kind,height,faces',[('tuck',160,['front','left','right','back','lid','bottom']),('hinged',35,['base','front','left','right','back','lid'])])
def test_closed_box_extent_and_opening(kind,height,faces):
    m=build_structure({'kind':kind,'height':height});closed=pose(m);op=pose(m,1,1)
    v=np.concatenate([p['points'] for p in closed['panels'] if p['id'] in faces]);assert np.ptp(v,axis=0)==pytest.approx([120,height,80])
    by={p['id']:p for p in closed['panels']};bo={p['id']:p for p in op['panels']}
    assert np.allclose(by['front']['points'],bo['front']['points'])
    assert not np.allclose(by['lid']['points'],bo['lid']['points'])

@pytest.mark.parametrize('kind,height',[('tuck',160),('hinged',35)])
def test_mm_exports(kind,height):
    m=build_structure({'kind':kind,'height':height});svg=export_svg(m);dxf=export_dxf(m)
    assert 'mm"' in svg and 'id="CUT"' in svg and 'id="CREASE"' in svg
    import ezdxf
    from io import StringIO
    doc=ezdxf.read(StringIO(dxf));assert doc.units==4;assert doc.dxfversion=='AC1024'
    audit=doc.audit();assert not audit.errors and not audit.fixes
    assert len(doc.modelspace().query('LINE[layer=="CREASE"]'))==12
    cuts=list(doc.modelspace().query('LWPOLYLINE[layer=="CUT"]'));assert len(cuts)==1 and cuts[0].closed
    xy=np.array(list(cuts[0].get_points('xy')));assert np.ptp(xy,axis=0)==pytest.approx([m['bounds'][2]-m['bounds'][0],m['bounds'][3]-m['bounds'][1]])

@pytest.mark.parametrize('bad',[{'length':float('nan')},{'width':20},{'tuck':31},{'kind':'arbitrary-dxf'},{'kind':'hinged','height':200},{'glue':30,'height':20}])
def test_bad_specs(bad):
    with pytest.raises(ValidationError):StructureSpec(**bad)

@pytest.mark.parametrize('kind,height',[('tuck',160),('hinged',35)])
def test_final_raster_changes_with_opening(kind,height):
    r=LocalRenderRequest(spec=StructureSpec(kind=kind,height=height),long_edge=256,view=RenderView(transparent=True))
    a=np.array(render_image(r));assert a.shape==(192,256,4);assert a[:,:,3].min()==0;assert a[:,:,3].max()==255
    r.view.opening=1;b=np.array(render_image(r));assert (a!=b).any(axis=2).sum()>800

@pytest.mark.parametrize('aspect,expected',[('16:9',(4096,2304)),('9:16',(2304,4096)),('4:3',(4096,3072)),('1:1',(4096,4096))])
def test_dimensions(aspect,expected):assert dimensions(LocalRenderRequest(long_edge=4096,aspect=aspect))==expected

@pytest.mark.parametrize('kw',[{'format':'mp4','long_edge':2048},{'format':'frames','seconds':6,'fps':24},{'textures':{'front':'https://example.com/secret'}},{'textures':{'alien':'data:image/png;base64,AA=='}}])
def test_resource_limits(kw):
    with pytest.raises(ValidationError):LocalRenderRequest(**kw)

def test_javascript_matches_python(tmp_path):
    cases=[]
    for kind,H in [('tuck',160),('hinged',35)]:
        m=build_structure({'kind':kind,'height':H})
        for f,o in [(0,0),(.37,0),(.86,0),(1,0),(1,.6),(1,1)]:cases.append({'model':m,'fold':f,'opening':o,'points':[p['points'] for p in pose(m,f,o)['panels']]})
    path=tmp_path/'kinematics.json';path.write_text(json.dumps(cases))
    module=(Path(__file__).parents[1]/'src/structure_math.js').resolve().as_uri()
    js=f"import {{pose}} from '{module}';import fs from 'node:fs';let max=0;for(const c of JSON.parse(fs.readFileSync(process.argv[1])) ){{const a=pose(c.model,c.fold,c.opening);a.forEach((p,i)=>p.points.forEach((v,j)=>v.forEach((x,k)=>max=Math.max(max,Math.abs(x-c.points[i][j][k])))));}}if(max>1e-7)throw Error(String(max));console.log(max);"
    out=subprocess.run(['node','--input-type=module','-e',js,str(path)],check=True,capture_output=True,text=True);assert float(out.stdout)<1e-7

def test_panel_texture_is_actually_rendered():
    import base64
    from io import BytesIO
    from PIL import Image
    out=BytesIO();Image.new('RGB',(64,64),(230,20,30)).save(out,format='PNG')
    src='data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()
    r=LocalRenderRequest(long_edge=256,textures={'front':src})
    im=np.array(render_image(r));red=(im[:,:,0]>150)&(im[:,:,1]<60)&(im[:,:,2]<60)
    assert red.sum()>1000
