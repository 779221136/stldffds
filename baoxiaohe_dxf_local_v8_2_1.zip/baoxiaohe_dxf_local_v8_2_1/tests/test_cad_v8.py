import base64,json,math,time,zipfile
from io import StringIO,BytesIO
from pathlib import Path
import ezdxf,numpy as np,pytest
from PIL import Image
from pydantic import ValidationError
from app.cad_engine import (HingeSetting,CadDocument,CadPath,CadOptions,ImportRequest,parse_dxf,analyze,cleaned_document,scale_document,export_dxf,export_svg,sampled)
from app.structure import build_structure,StructureSpec,export_dxf as parametric_export,pose
from app.cad_api import Library,SaveRequest,CadRenderRequest,render_model
from app.local_raster import render_image,triangles,RenderView

ROOT=Path(__file__).resolve().parents[1]
def raw(d):
 out=StringIO();d.write(out);return out.getvalue().encode()
def imported(data,**kw):return parse_dxf(ImportRequest(filename='test.dxf',data=base64.b64encode(data).decode(),**kw))['document']
def sample(kind='tuck'):
 spec=StructureSpec(kind=kind,height=35 if kind=='hinged' else 160)
 return CadDocument.model_validate(imported(parametric_export(build_structure(spec)).encode()))
def square(hole=False):
 paths=[CadPath(id=f'p{i}',type='LINE',role='cut',a=a,b=b) for i,(a,b) in enumerate([((0,0),(100,0)),((100,0),(100,100)),((100,100),(0,100)),((0,100),(0,0))])]
 if hole:paths.append(CadPath(id='hole',type='CIRCLE',role='cut',center=(50,50),radius=20))
 return CadDocument(paths=paths)
def boot(c):assert c.get('/api/local/capabilities').status_code==200

def test_real_entity_import_and_units():
 d=ezdxf.new('R2010');d.units=1;m=d.modelspace()
 m.add_line((0,0),(1,0),dxfattribs={'color':5});m.add_circle((1,1),.2,dxfattribs={'color':5});m.add_arc((1,1),.5,0,90,dxfattribs={'color':5})
 result=imported(raw(d));assert len(result['paths'])==3;assert result['paths'][0]['b'][0]==pytest.approx(25.4)
 assert result['paths'][1]['radius']==pytest.approx(5.08)
 assert result['source_sha256'];assert result['source_version']=='AC1024'

def test_polyline_bulge_preserved_as_arc():
 d=ezdxf.new();d.units=4;d.modelspace().add_lwpolyline([(0,0,0,0,1),(40,0,0,0,0),(40,40,0,0,0),(0,40,0,0,0)],close=True,dxfattribs={'color':5})
 data=imported(raw(d));assert any(p['type']=='ARC' for p in data['paths']);assert len(data['paths'])==4
 curve=next(p for p in data['paths'] if p['type']=='ARC');assert curve['radius']==20;assert curve['sweep']==180

def test_unitless_requires_choice():
 d=ezdxf.new();d.units=0;d.modelspace().add_circle((0,0),10,dxfattribs={'color':5})
 with pytest.raises(ValueError,match='no declared units'):imported(raw(d))
 assert imported(raw(d),unit='mm')['paths'][0]['radius']==10

@pytest.mark.parametrize('kind',['tuck','hinged'])
def test_real_dxf_to_hinges(kind):
 d=sample(kind);a=analyze(d)
 assert a['foldable'];assert len(a['faces'])==13;assert len(a['hinges'])==12;assert not a['angles_confirmed']
 assert np.isfinite(np.asarray(pose(a['model'])['panels'][0]['points'])).all()
 for h in a['hinges']:d.hinges[h['id']]=HingeSetting(angle=h['angle'],openAngle=15,stage=h['stage'],confirmed=True)
 d=CadDocument.model_validate(d.model_dump());a=analyze(d);assert a['angles_confirmed']
 q0=pose(a['model'],1,0);q1=pose(a['model'],1,1);assert q0!=q1

def test_hole_stays_empty_in_mesh_and_png():
 d=square(True);a=analyze(d);assert a['foldable'];f=a['faces'][0]
 assert len(f['holes'])==1;tri=a['model']['panels'][0]['triangles']
 area=sum(abs((t[1][0]-t[0][0])*(t[2][1]-t[0][1])-(t[1][1]-t[0][1])*(t[2][0]-t[0][0]))/2 for t in tri)
 assert area==pytest.approx(f['area'],abs=1e-7)
 req=CadRenderRequest(cad_document=d,long_edge=256,view=RenderView(fold=0,yaw=0,pitch=0,transparent=True))
 im=render_image(req,render_model(req));assert im.getpixel((im.width//2,im.height//2))[3]==0;assert im.getextrema()[3]==(0,255)

def test_concave_panel_not_fan_filled():
 pts=[(0,0),(60,0),(60,20),(20,20),(20,60),(0,60)]
 d=CadDocument(paths=[CadPath(id=str(i),type='LINE',role='cut',a=a,b=b) for i,(a,b) in enumerate(zip(pts,pts[1:]+pts[:1]))]);r=analyze(d)
 assert r['foldable'];assert r['faces'][0]['area']==2000
 assert sum(abs((t[1][0]-t[0][0])*(t[2][1]-t[0][1])-(t[1][1]-t[0][1])*(t[2][0]-t[0][0]))/2 for t in r['model']['panels'][0]['triangles'])==pytest.approx(2000)

def test_invalid_geometry_remains_editable_not_generic_box():
 d=square();d.paths.pop();r=analyze(d);assert not r['foldable'];assert r['model'] is None;assert r['errors'];assert len(d.paths)==3

def test_cyclic_fold_constraints_blocked():
 d=square();d.paths.extend([CadPath(id='v',type='LINE',role='crease',a=(50,0),b=(50,100)),CadPath(id='h',type='LINE',role='crease',a=(0,50),b=(100,50))]);a=analyze(d)
 assert len(a['faces'])==4;assert not a['foldable'];assert any('Closed-loop' in e for e in a['errors'])

def test_curved_crease_not_guessed():
 d=square();d.paths.append(CadPath(id='c',type='ARC',role='crease',center=(50,50),radius=50,start=0,sweep=180));a=analyze(d)
 assert not a['foldable'];assert any('Curved crease' in e for e in a['errors'])

def test_detached_material_blocked():
 d=square();other=square();d.paths.extend(p.model_copy(update={'id':'b'+p.id,'a':(p.a[0]+200,p.a[1]),'b':(p.b[0]+200,p.b[1])}) for p in other.paths)
 assert not analyze(d)['foldable']

def test_endpoint_snap_preview_does_not_change_native_export():
 d=square();d.paths[0].a=(.02,0);before=d.model_dump_json();a=analyze(d);assert a['foldable'];assert a['stats']['snapped_endpoints']>0;assert d.model_dump_json()==before
 clean=cleaned_document(d);assert clean.model_dump_json()!=before;assert analyze(clean)['foldable'];assert clean.import_warnings

def test_duplicate_and_partial_role_overlap():
 d=square();d.paths.append(d.paths[0].model_copy(update={'id':'copy'}));a=analyze(d);assert a['stats']['duplicate_segments']==1
 d.paths.append(CadPath(id='bad',type='LINE',role='crease',a=(20,0),b=(60,0)))
 a=analyze(d);assert not a['foldable'];assert any('overlap' in e for e in a['errors'])

def test_cleanup_nodes_intersections_and_is_opt_in():
 d=square();d.paths.append(CadPath(id='crease',type='LINE',role='crease',a=(50,0),b=(50,100)))
 cleaned=cleaned_document(d);assert len(cleaned.paths)>len(d.paths);assert len(analyze(cleaned)['faces'])==2;assert len(d.paths)==5

def test_scaling_arc_uniform_only():
 d=square(True)
 with pytest.raises(ValueError,match='Non-uniform'):scale_document(d,2,1)
 scaled=scale_document(d,2,2);assert scaled.paths[-1].radius==40;assert analyze(scaled)['foldable']

def test_dxf_export_native_curves_and_units_roundtrip():
 d=square(True);out=ezdxf.read(StringIO(export_dxf(d)));assert out.units==4;assert len(out.modelspace().query('CIRCLE'))==1;assert 'BLEED' in out.layers
 again=CadDocument.model_validate(imported(export_dxf(d).encode()));assert analyze(again)['foldable']
 assert 'BLEED' in export_svg(d);assert '100' in export_svg(d)

def test_import_hidden_unsupported_audited():
 d=ezdxf.new();d.units=4;m=d.modelspace();m.add_circle((0,0),10,dxfattribs={'color':5});m.add_text('annotation');d.layers.new('hidden',dxfattribs={'color':-5});m.add_line((0,0),(5,5),dxfattribs={'layer':'hidden'})
 result=imported(raw(d));assert len(result['paths'])==1;assert any('TEXT' in s for s in result['import_warnings']);assert any('hidden' in s for s in result['import_warnings'])

def test_block_transform_and_layer_inheritance():
 d=ezdxf.new();d.units=4;d.layers.new('CUT',dxfattribs={'color':5});b=d.blocks.new('B');b.add_lwpolyline([(0,0),(10,0),(10,10),(0,10)],close=True);d.modelspace().add_blockref('B',(50,20),dxfattribs={'layer':'CUT','xscale':2,'yscale':2})
 r=imported(raw(d));assert len(r['paths'])==4;assert all(p['role']=='cut' for p in r['paths']);assert analyze(r)['faces'][0]['area']==pytest.approx(400)

@pytest.mark.parametrize('data',[b'not a dxf',b'AutoCAD Binary DXF\r\n\x1a\x00'])
def test_bad_binary_input(data):
 with pytest.raises(ValueError):imported(data)

def test_z_not_silently_projected():
 d=ezdxf.new();d.units=4;d.modelspace().add_line((0,0,2),(10,10,2))
 with pytest.raises(ValueError,match='planar'):imported(raw(d))

@pytest.mark.parametrize('bad',[float('nan'),float('inf'),-float('inf')])
def test_nonfinite_rejected(bad):
 with pytest.raises(ValidationError):CadPath(id='a',type='LINE',a=(bad,0),b=(1,1))

def test_unknown_role_blocks_export_endpoint(client):
 boot(client);d=square().model_dump();d['paths'][0]['role']='unassigned'
 assert client.post('/api/local/cad/export/dxf',json=d).status_code==422

def test_library_roundtrip_and_isolation(client):
 boot(client);d=sample().model_dump();d['objects']=[{'id':'text','type':'text','x':20,'y':20,'w':100,'h':40,'text':'ABC'}]
 r=client.post('/api/local/cad/library',json={'document':d,'folder':'A/B/C','tags':['test']});assert r.status_code==201,r.text
 v=r.json();mid=v['id'];assert v['version']==1;assert v['document']['objects'][0]['text']=='ABC'
 assert client.get('/api/local/cad/library?folder=A&q=ABC').json()['total']==0
 assert client.get('/api/local/cad/library?folder=A&tag=test').json()['total']==1
 r=client.put('/api/local/cad/library/'+mid,json={'document':d,'expected_version':1});assert r.status_code==200 and r.json()['version']==2
 assert client.put('/api/local/cad/library/'+mid,json={'document':d,'expected_version':1}).status_code==409
 cookies=dict(client.cookies);client.cookies.clear();boot(client)
 assert client.get('/api/local/cad/library/'+mid).status_code==404
 assert client.put('/api/local/cad/library/'+mid,json={'document':d,'expected_version':2}).status_code==404
 assert client.get('/api/local/cad/library').json()['total']==0
 client.cookies.update(cookies)
 assert client.request('DELETE','/api/local/cad/library/'+mid+'?version=1',json={}).status_code==409
 assert client.request('DELETE','/api/local/cad/library/'+mid+'?version=2',json={}).status_code==200

def test_library_reopen_on_disk(tmp_path):
 p=tmp_path/'models.sqlite';saved=Library(p).save('owner',SaveRequest(document=sample(),folder='A/B'));again=Library(p).get('owner',saved['id']);assert again['document']['paths']==saved['document']['paths']

@pytest.mark.parametrize('folder',['../private','A/../B','A//B','A\\B','A/B/C/D/E/F'])
def test_library_folder_safety(folder):
 with pytest.raises(ValidationError):SaveRequest(document=square(),folder=folder)

def test_network_access_policy_preserved_and_cross_origin_blocked(client):
 assert client.get('http://192.168.3.1/api/local/cad/capabilities').status_code==200
 boot(client)
 assert client.post('/api/local/cad/analyze',json=square().model_dump(),headers={'origin':'https://evil.example'}).status_code==403
 assert client.get('/cad').status_code==200
 assert client.get('/runtime/cad-library.sqlite').status_code==404

def test_no_remote_images_in_project(client):
 boot(client);d=square().model_dump();d['objects']=[{'type':'image','id':'x','x':0,'y':0,'w':50,'h':50,'src':'https://example.org/secret'}]
 assert client.post('/api/local/cad/validate',json=d).status_code==422

@pytest.mark.parametrize('endpoint',['import','analyze','validate','cleanup'])
def test_owner_cookie_needed(client,endpoint):
 payload=sample().model_dump() if endpoint!='import' else {'filename':'box.dxf','data':base64.b64encode(parametric_export(build_structure(StructureSpec())).encode()).decode()}
 assert client.post('/api/local/cad/'+endpoint,json=payload).status_code==401

def wait(client,jid):
 for _ in range(180):
  job=client.get('/api/local/jobs/'+jid).json()
  if job['status'] not in {'running','queued'}:return job
  time.sleep(.1)
 raise AssertionError('Job timed out')

def test_local_cad_png_and_animation(client):
 boot(client);d=sample().model_dump()
 for fmt in ['png','frames']:
  r=client.post('/api/local/cad/jobs',json={'cad_document':d,'format':fmt,'long_edge':256,'seconds':1,'fps':6,'motion':'fold','view':{'transparent':True}});assert r.status_code==202,r.text
  job=wait(client,r.json()['id']);assert job['status']=='succeeded',job
  out=client.get(job['download']).content
  if fmt=='png':
   im=Image.open(BytesIO(out));assert im.size==(256,192);assert im.getextrema()[3]==(0,255)
  else:
   with zipfile.ZipFile(BytesIO(out)) as z:
    names=[n for n in z.namelist() if n.endswith('.png')];assert len(names)==6;assert z.read(names[0])!=z.read(names[-1])

def test_render_rejects_unfoldable_and_unknown_panel(client):
 boot(client);d=square();d.paths.pop()
 assert client.post('/api/local/cad/jobs',json={'cad_document':d.model_dump()}).status_code==422
 with pytest.raises(ValidationError):CadRenderRequest(cad_document=square(),textures={'front':'bad'})
 with pytest.raises(ValidationError):CadRenderRequest(cad_document=square(),format='webm',long_edge=4096)

def test_authenticated_library_survives_anonymous_cookie_rotation(client):
 from conftest import signin
 signin(client);boot(client)
 res=client.post('/api/local/cad/library',json={'document':square().model_dump()});assert res.status_code==201
 mid=res.json()['id'];client.cookies.delete('bxh_local_render',domain='testserver.local',path='/api/local')
 boot(client);assert client.get('/api/local/cad/library/'+mid).status_code==200
 assert client.get('/api/local/cad/capabilities').json()['library_scope']=='local-account'

def test_same_local_account_sees_library_after_new_login(client):
 from conftest import signin
 signin(client);boot(client);r=client.post('/api/local/cad/library',json={'document':square().model_dump()});mid=r.json()['id']
 client.cookies.clear();signin(client);boot(client)
 assert client.get('/api/local/cad/library/'+mid).status_code==200
 client.cookies.clear();signin(client,'13800138001');boot(client)
 assert client.get('/api/local/cad/library/'+mid).status_code==404
