import test from 'node:test';
import assert from 'node:assert/strict';
import {createSaveCoordinator,saveFingerprint} from '../src/save_coordinator.js';
const tick=()=>new Promise(r=>setTimeout(r,10));
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return{promise,resolve,reject};};
const request=()=>({id:null,version:null,name:'Test',kind:'template',source_id:25987,payload:{objects:[],bg:'#ffffff'}});
function setup(send,options={}){
  let value=request();const writes=[],statuses=[];
  const saver=createSaveCoordinator({read:()=>value,writeLocal:(v,m)=>writes.push(structuredClone({v,m})),send,
    onAck:r=>{value={...value,id:r.id,version:r.version};},onStatus:s=>statuses.push(s),delay:60000,localDelay:60000,maxWait:60000,...options});
  return{saver,writes,statuses,get:()=>value,edit:v=>{value={...value,...v};saver.changed();}};
}

test('content fingerprint ignores cloud id and version',()=>assert.equal(saveFingerprint(request()),saveFingerprint({...request(),id:12,version:2})));

test('single operation is persisted with exact request before send',async()=>{
  let h;h=setup(async(r,key)=>{assert.equal(h.writes.at(-1).m.pending.key,key);assert.deepEqual(h.writes.at(-1).m.pending.request,r);return{id:1,version:1};});
  h.edit({name:'A'});assert.equal((await h.saver.flush()).ok,true);assert.equal(h.saver.getState().state,'saved');h.saver.dispose();
});

test('older acknowledgment does not mark a newer edit clean',async()=>{
  const gate=deferred();let calls=0;const h=setup(()=>{calls++;return gate.promise;});
  h.edit({name:'First'});const flight=h.saver.flush();h.edit({name:'Latest'});
  gate.resolve({id:9,version:1});await flight;
  assert.equal(calls,1);assert.equal(h.saver.getState().dirty,true);assert.equal(h.writes.at(-1).v.name,'Latest');assert.equal(h.get().version,1);h.saver.dispose();
});

test('concurrent flushes do not duplicate a request',async()=>{
  const gate=deferred();let calls=0;const h=setup(()=>{calls++;return gate.promise;});
  h.edit({name:'A'});const a=h.saver.flush(),b=h.saver.flush();gate.resolve({id:1,version:1});await Promise.all([a,b]);assert.equal(calls,1);h.saver.dispose();
});

test('retry uses identical key/body even if user typed newer content',async()=>{
  const sent=[];let fail=true;
  const h=setup(async(r,k)=>{sent.push(structuredClone({r,k}));if(fail){fail=false;throw new Error('response lost');}return{id:1,version:1};});
  h.edit({name:'Old'});assert.equal((await h.saver.flush()).ok,false);h.edit({name:'New'});await h.saver.flush();
  assert.deepEqual(sent[0],sent[1]);assert.equal(h.saver.getState().dirty,true);h.saver.dispose();
});

test('restores persisted pending operation after reload',async()=>{
  const old={...request(),name:'Before reload'},pending={key:'stable-operation',request:old,fingerprint:saveFingerprint(old)};
  let sent;const h=setup(async(r,k)=>{sent={r,k};return{id:5,version:1};},{initialPending:pending});
  await h.saver.flush();assert.equal(sent.k,pending.key);assert.deepEqual(sent.r,old);assert.equal(h.get().id,5);h.saver.dispose();
});

test('conflict keeps pending draft and stops automatic retries',async()=>{
  let calls=0;const h=setup(async()=>{calls++;const e=new Error('conflict');e.status=409;throw e;});
  h.edit({name:'A'});await h.saver.flush();h.edit({name:'B'});await h.saver.flush();await h.saver.retry();
  assert.equal(calls,1);assert.equal(h.saver.getState().blocked,'conflict');assert.equal(h.writes.at(-1).v.name,'B');h.saver.dispose();
});

test('guest saves locally without a network call',async()=>{
  let calls=0;const h=setup(async()=>{calls++;},{canRemote:()=>false});
  h.edit({name:'Local'});const result=await h.saver.flush();assert.equal(result.local,true);assert.equal(calls,0);assert.equal(h.saver.getState().dirty,false);h.saver.dispose();
});

test('quota failure does not claim a guest draft was saved',async()=>{
  const h=setup(async()=>{}, {canRemote:()=>false,writeLocal:()=>{throw new Error('quota');}});
  h.edit({name:'Too big'});assert.equal((await h.saver.flush()).ok,false);assert.equal(h.saver.getState().state,'storage_error');assert.equal(h.saver.getState().dirty,true);h.saver.dispose();
});

test('local backup failure after remote success is not retried',async()=>{
  let calls=0;const h=setup(async()=>{calls++;return{id:1,version:1};},{writeLocal:()=>{throw new Error('quota');}});
  h.edit({name:'A'});assert.equal((await h.saver.flush()).ok,true);assert.equal(h.saver.getState().state,'saved_no_backup');assert.equal(calls,1);h.saver.dispose();
});

test('acknowledgment hook failure does not resubmit an accepted create',async()=>{
  let calls=0;const h=setup(async()=>{calls++;return{id:1,version:1};},{onAck:()=>{throw new Error('local metadata failure');}});
  h.edit({name:'A'});const result=await h.saver.flush();assert.equal(result.localAckFailed,true);await h.saver.flush();assert.equal(calls,1);h.saver.dispose();
});

test('dispose flushes local draft and cancels scheduled network writes',async()=>{
  let calls=0;const h=setup(async()=>{calls++;},{delay:1,localDelay:1});
  h.edit({name:'A'});h.saver.dispose();await tick();assert.equal(calls,0);assert.equal(h.writes.at(-1).v.name,'A');
});

test('unchanged content is not uploaded again after acknowledgment',async()=>{
  let calls=0;const h=setup(async()=>{calls++;return{id:1,version:1};});
  h.edit({name:'A'});await h.saver.flush();await h.saver.flush();assert.equal(calls,1);h.saver.dispose();
});

test('new edit after first save uses returned id and version',async()=>{
  const calls=[];const h=setup(async(r)=>{calls.push(r);return{id:4,version:calls.length};});
  h.edit({name:'A'});await h.saver.flush();h.edit({name:'B'});await h.saver.flush();assert.equal(calls[1].id,4);assert.equal(calls[1].version,1);h.saver.dispose();
});

test('discard prevents cleanup from persisting a stale restored document',async()=>{
  const h=setup(async()=>({id:1,version:1}));h.edit({name:'A'});h.saver.discard();h.saver.dispose();assert.equal(h.writes.length,0);
});
