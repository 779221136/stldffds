import copy
import pytest
import app.main as main
from app.revisions import HISTORY_LIMIT
from conftest import signin


def body(name='Draft'):
    return {'name':name,'kind':'template','source_id':25987,'payload':{'schemaVersion':4,'box':{'length':120,'width':80,'height':180},'objects':[]}}


def create(client,**kw):
    data={**body(),**kw};r=client.post('/api/designs',json=data);assert r.status_code==200,r.text
    return data,r.json()


def test_idempotent_create_and_payload_mismatch(client):
    signin(client);header={'idempotency-key':'create-stable-key'}
    a=client.post('/api/designs',json=body(),headers=header);b=client.post('/api/designs',json=body(),headers=header)
    assert a.json()==b.json() and len(client.get('/api/designs').json()['items'])==1
    assert client.post('/api/designs',json=body('Different'),headers=header).status_code==409


def test_idempotent_update_before_version_check(client):
    signin(client);data,created=create(client)
    update={**data,'id':created['id'],'version':1,'name':'Second'};h={'idempotency-key':'update-stable-key'}
    a=client.post('/api/designs',json=update,headers=h);b=client.post('/api/designs',json=update,headers=h)
    assert a.status_code==b.status_code==200 and a.json()==b.json()
    assert a.json()['version']==2
    assert len(client.get(f"/api/designs/{created['id']}/versions").json()['items'])==2


def test_history_restore_creates_new_version_and_preserves_previous(client):
    signin(client);data,c=create(client)
    changed=copy.deepcopy(data);changed.update(id=c['id'],version=1,name='Changed');changed['payload']['box']['length']=240
    assert client.post('/api/designs',json=changed).json()['version']==2
    r=client.post(f"/api/designs/{c['id']}/restore",json={'version':1,'expected_version':2})
    assert r.status_code==200 and r.json()['version']==3
    current=client.get(f"/api/designs/{c['id']}").json()['item']
    assert current['name']=='Draft' and current['payload']['box']['length']==120
    versions=client.get(f"/api/designs/{c['id']}/versions").json()['items']
    assert [v['version'] for v in versions]==[3,2,1]
    assert client.get(f"/api/designs/{c['id']}/versions/2").json()['item']['payload']['box']['length']==240


def test_restore_conflict_never_overwrites(client):
    signin(client);data,c=create(client)
    client.post('/api/designs',json={**data,'id':c['id'],'version':1,'name':'Second'})
    r=client.post(f"/api/designs/{c['id']}/restore",json={'version':1,'expected_version':1})
    assert r.status_code==409
    assert client.get(f"/api/designs/{c['id']}").json()['item']['name']=='Second'


@pytest.mark.parametrize('path',['/versions','/versions/1','/restore'])
def test_history_owner_isolation(client,path):
    signin(client);_,c=create(client)
    client.cookies.clear();signin(client,'13800138001')
    url=f"/api/designs/{c['id']}"+path
    response=client.post(url,json={'version':1,'expected_version':1}) if path=='/restore' else client.get(url)
    assert response.status_code==404


def test_history_delete_cascades(client):
    signin(client);_,c=create(client)
    assert client.delete(f"/api/designs/{c['id']}",headers={'content-type':'application/json'}).status_code==200
    assert client.get(f"/api/designs/{c['id']}/versions/1").status_code==404
    with main.db() as db:assert db.execute('SELECT COUNT(*) FROM design_revisions').fetchone()[0]==0


def test_noop_save_does_not_create_history_noise(client):
    signin(client);data,c=create(client)
    assert client.post('/api/designs',json={**data,'id':c['id'],'version':1}).json()['version']==1


def test_history_retention_and_legacy_backfill(client):
    signin(client);data,c=create(client)
    for version in range(1,HISTORY_LIMIT+3):
        r=client.post('/api/designs',json={**data,'id':c['id'],'version':version,'name':f'Revision {version+1}'})
        assert r.status_code==200
    listing=client.get(f"/api/designs/{c['id']}/versions").json()
    assert len(listing['items'])==HISTORY_LIMIT
    assert client.get(f"/api/designs/{c['id']}/versions/1").status_code==404
    main.init_db() # Idempotent migration must not duplicate or fabricate old snapshots.
    assert len(client.get(f"/api/designs/{c['id']}/versions").json()['items'])==HISTORY_LIMIT


@pytest.mark.parametrize('key',['bad','x'*129,'bad key'])
def test_bad_save_keys_rejected(client,key):
    signin(client);assert client.post('/api/designs',json=body(),headers={'idempotency-key':key}).status_code==422


def test_save_key_owner_scoped(client):
    signin(client);h={'idempotency-key':'same-key-across-users'}
    a=client.post('/api/designs',json=body(),headers=h).json()
    client.cookies.clear();signin(client,'13800138002')
    b=client.post('/api/designs',json=body(),headers=h).json()
    assert a['id']!=b['id']


def test_snapshot_copies_full_layer_order(client):
    signin(client);data=body()
    data['payload']['objects']=[{'id':'a','type':'rect','x':20,'y':30,'w':60,'h':70},{'id':'b','type':'text','text':'Test','w':80,'h':40}]
    _,c=create(client,**data)
    second=copy.deepcopy(data);second.update(id=c['id'],version=1);second['payload']['objects'].reverse()
    assert client.post('/api/designs',json=second).status_code==200
    assert [o['id'] for o in client.get(f"/api/designs/{c['id']}/versions/1").json()['item']['payload']['objects']]==['a','b']
