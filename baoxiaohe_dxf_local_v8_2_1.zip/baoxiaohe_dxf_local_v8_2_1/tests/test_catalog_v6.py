import copy
import pytest
import app.main as main
from app.catalog import query_items,metadata


def test_category_resolves_model_code(client):
    result=client.get('/api/templates',params={'model':'\u5929\u5730\u76d6'}).json()
    assert 25987 in {i['id'] for i in result['items']}
    assert result['total']==2


def test_all_advertised_model_facets_match_something(client):
    meta=client.get('/api/catalog/meta').json()
    for kind in ['templates','models']:
        for opt in meta['model_options'][kind]:
            r=client.get('/api/'+kind,params={'model':opt['value']}).json()
            assert r['total']>0,(kind,opt)


def test_model_reference_can_be_code_or_id():
    catalog={'templates':[{'id':1,'model':7},{'id':2,'model':'B7'}], 'models':[{'id':7,'code':'B7','sub':'drawer'}]}
    assert len(query_items(catalog,'templates','','all',{'model':'drawer'}))==2


def test_usage_is_not_page_views():
    catalog={'models':[],'templates':[{'id':1,'views':1000,'uses':1},{'id':2,'views':1,'uses':20},{'id':3,'views':9000}]}
    assert [i['id'] for i in query_items(catalog,'templates','','uses',{})]==[2,1,3]
    assert [i['id'] for i in query_items(catalog,'templates','','popular',{})]==[3,1,2]


def test_unknown_dates_keep_stable_order():
    c={'models':[],'templates':[{'id':1},{'id':99},{'id':4}]}
    assert [i['id'] for i in query_items(c,'templates','','new',{})]==[1,99,4]


def test_unavailable_metrics_are_not_advertised(client):
    m=client.get('/api/catalog/meta').json()
    assert 'new' not in m['available_sorts']['templates']
    assert 'uses' not in m['available_sorts']['templates']
    assert 'uses' in m['available_sorts']['models']


def test_missing_document_is_explicit(client):
    r=client.get('/api/templates/25987/document');assert r.status_code==200 and not r.json()['available']
    assert 'payload' not in r.json()


def test_deployment_document_loads_original_objects_not_defaults(client,monkeypatch):
    c=copy.deepcopy(main.CATALOG)
    c['templates'][0]['document_access']='public'
    c['templates'][0]['design_payload']={'schemaVersion':4,'box':{'length':100,'width':60,'height':140},'bg':'#abcdef','objects':[{'id':'brand','type':'text','text':'OWNED DOCUMENT','x':50,'y':60,'w':100,'h':40}]}
    monkeypatch.setattr(main,'CATALOG',c)
    result=client.get('/api/templates/25987/document').json()
    assert result['available'] and result['payload']['objects'][0]['text']=='OWNED DOCUMENT'
    assert result['payload']['box']['length']==100
    assert 'design_payload' not in client.get('/api/templates').json()['items'][0]


@pytest.mark.parametrize('access,status',[('authenticated',401),('paid',401)])
def test_private_documents_not_exposed_by_catalog(client,monkeypatch,access,status):
    c=copy.deepcopy(main.CATALOG);c['templates'][0].update(document_access=access,design_payload={'objects':[]})
    monkeypatch.setattr(main,'CATALOG',c)
    assert client.get('/api/templates/25987/document').status_code==status
    assert 'design_payload' not in client.get('/api/templates/25987').json()['item']


def test_unsupported_document_schema_rejected(client,monkeypatch):
    c=copy.deepcopy(main.CATALOG);c['templates'][0].update(document_access='public',design_payload={'geometry':'bottle'})
    monkeypatch.setattr(main,'CATALOG',c)
    assert client.get('/api/templates/25987/document').status_code==422
