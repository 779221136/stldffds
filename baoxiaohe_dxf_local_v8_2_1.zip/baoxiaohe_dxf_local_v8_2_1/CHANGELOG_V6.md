# v5.1 -> v6 changes

This is source maintenance on an existing uploaded project, not a verified source-site clone.

| Module | Change | Evidence |
|---|---|---|
| Editor state | Per-field dimension commits; undo input/color sync; preserved zoom | component assertions and screenshots |
| Inspector | Stable DOM/caret; first-click format; glyph scaling and wrapped line persistence | browser components + typography tests |
| Layers | Preserve existing pointer and keyboard reorder; autosave/history object order | API and component tests |
| Autosave | Local debounce, serial sends, bounded retries, pending-operation persistence, stale-ACK guard | 15 JS coordinator tests |
| History | Owner-only snapshots, latest 50, restore-as-new, expected-version protection | revision tests + history dialog |
| Catalog | Identifier/category binding, no invented sort metrics, compact secondary filters | catalog tests + measured local views |
| Documents | Validated deployment-supplied six-face objects; missing/private/paid state handling | document tests + exact fixture load |
| Mobile | Canvas/properties/layers/3D tabs; visible save/export/state | 390x844 component screenshots |
| Export | Persist wrap line layout into RGB preview; independent CJK specimen rendered | API/typography tests + PDF render |

The intentional overlap in `editor-desktop.png` and `wrapped-preview.pdf` comes from a stress-test that adds layers in the same position. It is not an original design, nor a claim of print-ready layout. `typography-preview.pdf/png` is a separate authored clean specimen.

Original assets, real carton geometry, GPU/cloud rendering, payments, member authorization, team operations and production print/color workflows remain blocked. See PRODUCTION_STATUS.md.
