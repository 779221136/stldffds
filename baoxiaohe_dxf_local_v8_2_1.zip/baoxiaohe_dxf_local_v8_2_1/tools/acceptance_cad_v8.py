"""Scoped authored-code browser checks + real in-process local API. Not native E2E."""
import sys,os,asyncio,json,tempfile,base64,time
from pathlib import Path
from io import BytesIO
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from fastapi.testclient import TestClient
from playwright.async_api import async_playwright
from tools.component_harness_v6 import boot
import app.main as main
OUT=ROOT/'evidence/dxf_v8/browser';OUT.mkdir(parents=True,exist_ok=True)
async def probe():
 checks=[];errors=[]
 def ok(name,val=True):
  assert val,name;checks.append(name);print(name,flush=True)
 with tempfile.TemporaryDirectory() as td:
  os.environ['ENV']='test';main.DB_PATH=Path(td)/'test.db'
  with TestClient(main.app) as client:
   async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page,errors=await boot(browser,'/cad',client=client)
    page.set_default_timeout(10000)
    async def handle_dialog(d):
     print('DIALOG',d.type,flush=True);await d.accept('123456789012' if d.type=='prompt' else None)
    page.on('dialog',handle_dialog)
    try:
     await page.locator('[data-example]').click();await page.locator('[data-parse]').click()
     await page.locator('[data-import-confirm]').wait_for(timeout=20000)
     await page.screenshot(path=str(OUT/'import-mapping.png'))
     ok('DXF import produces actual editable layer mapping',await page.locator('[data-import-map]').count()==3)
     await page.locator('[data-import-confirm]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden",timeout=20000)
     ok('13 actual DXF panels identified','13' in await page.locator('[data-summary]').inner_text())
     await page.screenshot(path=str(OUT/'editor-flat.png'))
     ok('CAD adapter replaced six-face geometry note','DXF' in await page.locator('.editor-scope-note').inner_text())
     await page.locator('[data-add="text"]').click();await page.locator('[data-obj="text"]').fill('LOCAL CAD TEST');await page.locator('[data-obj="text"]').press('Tab')
     await page.locator('[data-bold]').click()
     await page.wait_for_timeout(900)
     ok('Text editing updates SVG',await page.locator('svg.packaging-svg text').filter(has_text='LOCAL CAD TEST').count()==1)
     await page.locator('[data-right-tab="params"]').click()
     ok('Opening disabled until a hinge action is configured',await page.locator('[data-opening]').is_disabled())
     await page.locator('[data-hopen]').fill('75');await page.locator('[data-happly]').click();await page.wait_for_function("!document.querySelector('[data-opening]').disabled")
     ok('Configured opening action enables animation')
     await page.locator('[data-hconfirm]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden")
     await page.locator('[data-fold]').fill('1');await page.locator('[data-fold]').dispatch_event('input')
     await page.wait_for_timeout(700);await page.screenshot(path=str(OUT/'editor-folded-artwork.png'))
     ok('Folding controls enabled',await page.locator('[data-fold]').is_enabled())
     closed=await page.locator('[data-render] canvas').evaluate("c=>c.toDataURL()")
     await page.locator('[data-opening]').fill('1');await page.locator('[data-opening]').dispatch_event('input');await page.wait_for_timeout(150)
     opened=await page.locator('[data-render] canvas').evaluate("c=>c.toDataURL()")
     ok('Opening changes actual rendered pixels',opened!=closed);await page.screenshot(path=str(OUT/'editor-opening.png'))
     await page.locator('[data-opening]').fill('0');await page.locator('[data-opening]').dispatch_event('input')
     await page.locator('[data-save]').click();await page.locator('[data-save-name]').fill('CAD roundtrip');await page.locator('[data-save-folder]').fill('Project/Packaging');await page.locator('[data-save-tags]').fill('box, test');await page.locator('[data-confirm-save]').click()
     await page.wait_for_function("!document.querySelector('.cad-modal-backdrop')")
     r=client.get('/api/local/cad/library').json();ok('Model saved on local disk',r['total']==1);mid=r['items'][0]['id']
     saved=client.get('/api/local/cad/library/'+mid).json();ok('All DXF paths persisted',len(saved['document']['paths'])==64);ok('Artwork persisted',saved['document']['objects'][0]['text']=='LOCAL CAD TEST');ok('Fold parameters persisted',len(saved['document']['hinges'])==12)
     await page.locator('[data-library]').click();await page.locator('[data-lib-load]').wait_for();await page.screenshot(path=str(OUT/'local-library.png'));await page.locator('[data-lib-load]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden")
     ok('Model reload retains objects',await page.locator('[data-layer-row]').count()==1)
     await page.locator('[data-mode="net"]').click();await page.locator('[data-net-lock]').uncheck();await page.locator('[data-placement]').click();await page.wait_for_timeout(300)
     old_x=float(await page.locator('[data-param="x"]').input_value());box=await page.locator('svg.packaging-svg').bounding_box()
     await page.mouse.move(box['x']+45,box['y']+70);await page.mouse.down();await page.mouse.move(box['x']+95,box['y']+95,steps=5);await page.mouse.up()
     new_x=float(await page.locator('[data-param="x"]').input_value());ok('Independent dieline layer can be dragged',new_x>old_x+20)
     await page.locator('[data-geom-undo]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden")
     ok('Dieline drag undo restores placement',abs(float(await page.locator('[data-param="x"]').input_value())-old_x)<.001)
     await page.locator('[data-mode="lines"]').click();await page.locator('[data-path]').select_option('p1');await page.locator('[data-line-role]').select_option('guide');await page.locator('[data-path-apply]').click();await page.wait_for_timeout(650)
     ok('Invalid topology blocks stale 3D',not await page.locator('[data-preview-block]').is_hidden())
     await page.locator('[data-geom-undo]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden")
     ok('Geometry undo restores foldable topology')
     await page.locator('[data-mode="draw"]').click();await page.locator('[data-add="shape"]').click();await page.wait_for_timeout(800)
     await page.locator('[data-add="barcode"]').click();await page.wait_for_timeout(500)
     ok('Barcode generated locally and added as an editable object',await page.locator('[data-layer-row]').count()==3)
     from PIL import Image
     img=BytesIO();Image.new('RGB',(24,24),(225,80,50)).save(img,format='PNG')
     await page.locator('[data-image]').set_input_files({'name':'test.png','mimeType':'image/png','buffer':img.getvalue()});await page.wait_for_timeout(600)
     ok('Raster upload stays in local design',await page.locator('[data-layer-row]').count()==4)

     await page.locator('[data-edge]').select_option('256');await page.locator('[data-submit]').click()
     await page.locator('[data-jobs] a[download]').wait_for(timeout=40000)
     href=await page.locator('[data-jobs] a[download]').get_attribute('href');png=client.get(href);(OUT/'render.png').write_bytes(png.content);ok('Local background PNG job completed',png.content.startswith(b'\x89PNG'))
     await page.locator('[data-export]').click()
     async with page.expect_download() as event:await page.locator('[data-out="json"]').click()
     dl=await event.value;await dl.save_as(OUT/'project.json');exported=json.loads((OUT/'project.json').read_text());ok('Portable project contains geometry and artwork',len(exported['paths'])==64 and len(exported['objects'])==4)
     await page.locator('[data-modal-close]').click()
     await page.set_viewport_size({'width':390,'height':844});await page.locator('[data-tab="canvas"]').click();await page.wait_for_timeout(250);await page.screenshot(path=str(OUT/'mobile-canvas.png'))
     ok('Mobile canvas has no document overflow',await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
     await page.locator('[data-tab="props"]').click();await page.locator('[data-right-tab="params"]').click();await page.wait_for_timeout(250);await page.screenshot(path=str(OUT/'mobile-properties.png'));ok('Mobile parameters accessible',await page.locator('[data-params]').is_visible())
     await page.locator('[data-tab="preview"]').click();await page.wait_for_timeout(250);await page.screenshot(path=str(OUT/'mobile-preview.png'));ok('Mobile 3D visible',await page.locator('[data-render]').is_visible())
     ok('No JavaScript uncaught errors',not errors)
    except Exception:
     await page.screenshot(path=str(OUT/'failure.png'),full_page=True,timeout=10000)
     print((await page.locator('body').inner_text())[-7000:]);print('BROWSER ERRORS',errors);raise
    finally:
     (OUT/'checks.json').write_text(json.dumps({'scope':'Offline authored-code Chromium + in-process local API; not native URL E2E or GPU validation','checks':checks,'errors':errors},indent=2))
     await page.close();await browser.close()
 print(json.dumps({'passed':len(checks),'checks':checks},indent=2))
if __name__=='__main__':asyncio.run(probe())
