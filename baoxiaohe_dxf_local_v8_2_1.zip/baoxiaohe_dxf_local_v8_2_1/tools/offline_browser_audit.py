import asyncio,base64,json,sys,time,io,os
from pathlib import Path
from PIL import Image,ImageChops
from playwright.async_api import async_playwright
from offline_harness import boot,OUT

async def main():
    checks=[]
    def ok(name,**details):checks.append({'name':name,'passed':True,**details});(OUT/'browser_partial.json').write_text(json.dumps(checks,indent=2));print('PASS',name,details,flush=True)
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
        page,api,errors=await boot(browser)
        page.set_default_timeout(10000)
        page.on('dialog',lambda d: asyncio.create_task(d.accept()))
        await page.wait_for_function("document.querySelectorAll('#catalogGrid .item-card').length===10")
        first=await page.locator('#catalogGrid .card-title').all_text_contents()
        await page.locator('#catalogPager [data-page="2"]').first.click()
        await page.wait_for_function("document.querySelector('#count').textContent.includes('2/2')")
        second=await page.locator('#catalogGrid .card-title').all_text_contents()
        assert set(first).isdisjoint(second);ok('Catalog pagination changes all ten records')
        assert await page.evaluate("__route.search.includes('page=2')");ok('Catalog page state in route query')
        await page.locator('#catalogQuery').fill('no-such-thing-xyz');await page.locator('#catalogSearch').click()
        await page.wait_for_function("document.querySelector('#count').textContent.startsWith('0')");assert await page.locator('#catalogGrid .item-card').count()==0;ok('Search empty state')
        await page.evaluate("__navigate('/login')");await page.wait_for_selector('#loginPhone')
        phone='139'+str(time.time_ns())[-8:]
        await page.locator('#loginPhone').fill(phone);await page.locator('#sendCode').click()
        await page.wait_for_function("document.querySelector('#loginCode').value.length===6")
        await page.locator('#loginSubmit').click();await page.wait_for_selector('#accountName')
        assert (await api.get('/api/me')).json()['user'];ok('Development login UI backed by actual session API')
        await page.evaluate("__navigate('/templates')");await page.wait_for_selector('[data-fav="templates:25987"]')
        b=page.locator('[data-fav="templates:25987"]');await b.click();await page.wait_for_function("document.querySelector('[data-fav=\"templates:25987\"]').classList.contains('on')")
        assert len((await api.get('/api/favorites')).json()['items'])==1
        await b.click();await page.wait_for_function("!document.querySelector('[data-fav=\"templates:25987\"]').classList.contains('on')")
        assert (await api.get('/api/favorites')).json()['items']==[];ok('Favorite and unfavorite round-trip')
        await page.evaluate("__navigate('/design/template/25987')");await page.wait_for_selector('[data-ed-tool="text"]')
        await page.locator('[data-ed-tool="text"]').click();await page.locator('#objText').fill('AUDIT FRONT\nSECOND LINE');await page.locator('#objText').dispatch_event('change')
        await page.locator('#objFill').fill('#122c44');await page.locator('#objFill').dispatch_event('change')
        await page.locator('#objX').fill('545');await page.locator('#objX').dispatch_event('change')
        await page.locator('#objY').fill('330');await page.locator('#objY').dispatch_event('change')
        await page.locator('#objFont').fill('20');await page.locator('#objFont').dispatch_event('change')
        count=await page.locator('#layerPanel .v4-layer').count()
        await page.locator('#duplicateObject').click();assert await page.locator('#layerPanel .v4-layer').count()==count+1
        await page.locator('[data-ed-undo]').click();assert await page.locator('#layerPanel .v4-layer').count()==count
        await page.locator('[data-ed-redo]').click();assert await page.locator('#layerPanel .v4-layer').count()==count+1;ok('Text, duplicate, undo and redo')
        await page.locator('#deleteObject').click();assert await page.locator('#layerPanel .v4-layer').count()==count
        await page.locator('[data-ed-tool="rect"]').click();await page.locator('#objFill').fill('#24a077');await page.locator('#objFill').dispatch_event('change')
        await page.locator('#objY').fill('460');await page.locator('#objY').dispatch_event('change')
        await page.locator('#objH').fill('35');await page.locator('#objH').dispatch_event('change')
        shape=page.locator('.selection-layer [data-handle="se"]');box=await shape.bounding_box()
        await page.mouse.move(box['x']+5,box['y']+5);await page.mouse.down();await page.mouse.move(box['x']+30,box['y']+15,steps=5);await page.mouse.up()
        assert float(await page.locator('#objH').input_value())>35;ok('Resize handle changes dimensions')
        lock=page.locator('#layerPanel .v4-layer.selected [data-layer-lock]');await lock.click();assert await page.locator('.selection-layer [data-handle]').count()==0
        await page.locator('#layerPanel .v4-layer.selected [data-layer-lock]').click();assert await page.locator('.selection-layer [data-handle]').count()==5;ok('Layer lock disables transform handles')
        await page.locator('#designName').fill('Browser audit design');await page.locator('#saveDesign').click()
        await page.wait_for_function("document.querySelector('#saveStatus').textContent.includes('v1')")
        one=(await api.get('/api/designs')).json()['items'];assert len(one)==1
        await page.locator('#saveDesign').click();await page.wait_for_function("document.querySelector('#saveStatus').textContent.includes('v2')")
        two=(await api.get('/api/designs')).json()['items'];assert len(two)==1 and two[0]['version']==2;ok('Repeated save updates one cloud design')
        assert any(o.get('text')=='AUDIT FRONT\nSECOND LINE' for o in two[0]['payload']['objects']);ok('Saved multiline artwork preserved')
        await page.wait_for_timeout(600);await page.screenshot(path=str(OUT/'editor-tested.png'),full_page=True)
        await page.locator('#preview3d').click();await page.wait_for_selector('#exportRender')
        await page.wait_for_function("document.querySelector('#renderStatus').textContent.includes('\u540c\u6b65')")
        await page.screenshot(path=str(OUT/'render-tested.png'),full_page=True)
        await page.evaluate("window.__downloads=[];HTMLAnchorElement.prototype.click=function(){if(this.download)window.__downloads.push({name:this.download,href:this.href});};")
        for quality,aspect,size in [('1k','4:3',(1024,768)),('2k','3:4',(1536,2048)),('3k','16:9',(3072,1728)),('4k','16:9',(4096,2304)),('4k','9:16',(2304,4096))]:
            await page.locator('[data-quality="'+quality+'"]').click();await page.locator('[data-aspect="'+aspect+'"]').click()
            before=await page.evaluate('__downloads.length');await page.locator('#exportRender').click()
            await page.wait_for_function('(n)=>__downloads.length>n',arg=before,timeout=30000)
            item=await page.evaluate('__downloads.at(-1)');raw=base64.b64decode(item['href'].split(',')[1]);im=Image.open(io.BytesIO(raw));assert im.size==size,im.size
            filename='export-'+quality+'-'+aspect.replace(':','x')+'.png';(OUT/filename).write_bytes(raw)
            assert len(im.convert('RGB').resize((128,128)).getcolors(16384))>10;ok('PNG dimensions '+quality+' '+aspect,width=im.width,height=im.height)
        await page.locator('[data-quality="1k"]').click();await page.locator('[data-aspect="4:3"]').click();await page.locator('#transparentBg').click()
        before=await page.evaluate('__downloads.length');await page.locator('#exportRender').click();await page.wait_for_function('(n)=>__downloads.length>n',arg=before)
        raw=base64.b64decode((await page.evaluate('__downloads.at(-1).href')).split(',')[1]);im=Image.open(io.BytesIO(raw)).convert('RGBA')
        assert im.getpixel((0,0))[3]==0 and im.getpixel((512,384))[3]>0;(OUT/'export-transparent.png').write_bytes(raw);ok('Transparent PNG alpha with non-empty box')
        # Projected UV verification using the exact shipped module in an isolated mount.
        await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(200)
        await page.evaluate('''async()=>{const mount=document.createElement('div');mount.id='test-renderer';mount.style.cssText='width:800px;height:600px;position:fixed;inset:0;background:white;z-index:9999';document.body.append(mount);const box={length:120,width:80,height:180},panels=__modules['geometry.js'].getBoxLayout(box).panels;const colors={front:'#ee2233',back:'#3344ee',left:'#22bb44',right:'#efbb22',top:'#aa22cc',bottom:'#11bbcc'};window.__renderPayload={schemaVersion:4,box,bg:'#ffffff',accent:'#ffffff',objects:Object.entries(panels).map(([name,r])=>({id:name,type:'rect',...r,fill:colors[name]}))};window.__renderer=__modules['webgl_renderer.js'].createBoxWebGLRenderer({mount});await __renderer.setDesign(__renderPayload);}''')
        async def face_png(rx,ry,name):
            uri=await page.evaluate('''async([rx,ry])=>{__renderer.setRotation(rx,ry);return await __renderer.exportPNG({quality:'1k',aspect:'4:3'});}''',[rx,ry])
            raw=base64.b64decode(uri.split(',')[1]);(OUT/('face-'+name+'.png')).write_bytes(raw)
            im=Image.open(io.BytesIO(raw)).convert('RGB');return im.getpixel((512,384))
        expected=[('front',0,0,0),('back',0,180,2),('left',0,90,1),('right',0,-90,0),('top',90,0,0),('bottom',-90,0,1)]
        colors={}
        for name,rx,ry,dominant in expected:
            color=await face_png(rx,ry,name);colors[name]=color
        assert colors['front'][0]>colors['front'][1]*2
        assert colors['back'][2]>colors['back'][0]*2
        assert colors['left'][1]>colors['left'][0]*2
        assert colors['right'][0]>colors['right'][2]*2 and colors['right'][1]>colors['right'][2]*2
        assert colors['top'][2]>colors['top'][1]*2 and colors['top'][0]>colors['top'][1]*2
        assert colors['bottom'][1]>colors['bottom'][0]*2 and colors['bottom'][2]>colors['bottom'][0]*2
        ok('Six distinct artwork faces mapped to projected box',center_colors=colors)
        before=await face_png(0,0,'before-edit')
        await page.evaluate("async()=>{__renderPayload.objects.find(o=>o.id==='front').fill='#113355';await __renderer.setDesign(__renderPayload);}")
        after=await face_png(0,0,'after-edit');assert before!=after;ok('Artwork edit changes rendered texture')
        video=await page.evaluate("async()=>{const blob=await __renderer.recordWebM(1);return {size:blob.size,type:blob.type};}")
        assert video['size']>500;ok('Software preview WebM encoding',**video)
        await page.evaluate("__renderer.destroy();document.querySelector('#test-renderer').remove();__navigate('/models/74')")
        await page.wait_for_selector('[data-detail-view="2d"]');await page.locator('[data-detail-view="2d"]').click();assert await page.locator('#detailMain svg').count()==1
        await page.locator('[data-detail-view="3d"]').click();assert await page.locator('#detailMain canvas').count()==1;ok('Model detail labeled generic 2D/3D switch (not original geometry)')
        await page.evaluate("__navigate('/account')");await page.wait_for_selector('[data-delete-draft]');await page.locator('[data-delete-draft]').click();await page.wait_for_function("document.querySelectorAll('[data-delete-draft]').length===0")
        assert (await api.get('/api/designs')).json()['items']==[];ok('UI design delete persists on server')
        await page.evaluate("__navigate('/print')");await page.wait_for_selector('#calcQuote');await page.locator('#calcQuote').click();await page.wait_for_selector('#placeOrder')
        await page.locator('#placeOrder').click();await page.wait_for_timeout(400)
        assert len((await api.get('/api/account/orders')).json()['items'])==1;ok('Estimate order submission')
        await page.evaluate("__navigate('/print')");await page.wait_for_selector('#calcQuote');await page.locator('#calcQuote').click();await page.wait_for_selector('#placeOrder');await page.locator('#qQty').fill('200');assert await page.locator('#placeOrder').count()==0;ok('Changing specification invalidates old quote')
        await page.set_viewport_size({'width':390,'height':844});await page.evaluate("__navigate('/templates')");await page.wait_for_selector('#catalogGrid .item-card')
        assert await page.evaluate('document.documentElement.scrollWidth<=395');await page.screenshot(path=str(OUT/'mobile-catalog.png'),full_page=True);ok('Mobile catalog no horizontal overflow')
        await page.evaluate("__navigate('/render/template/25987')");await page.wait_for_selector('#exportRender');await page.wait_for_timeout(500)
        assert await page.locator('.render-info').is_visible();assert await page.locator('.render-side').is_visible();await page.screenshot(path=str(OUT/'mobile-render.png'),full_page=True);ok('Mobile render controls accessible')
        assert not errors,errors;ok('No uncaught page errors during audited interactions')
        await api.aclose();await browser.close()
    report={'scope':'Offline Chromium harness; authored UI injected into about:blank. History/localStorage/network fetch adapted; actual localhost HTTP API and software renderer used. Native route navigation and GPU WebGL were blocked/unavailable, not verified.','checks':checks,'passed':len(checks),'errors':errors}
    (OUT/'browser_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':asyncio.run(main())
