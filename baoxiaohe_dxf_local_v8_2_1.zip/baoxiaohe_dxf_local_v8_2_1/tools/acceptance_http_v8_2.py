from pathlib import Path
import os,sys,json,time,hashlib,base64,subprocess,socket,copy,zipfile,asyncio
from io import BytesIO,StringIO
import httpx,ezdxf,numpy as np
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/fixes_v8_2/http';OUT.mkdir(parents=True,exist_ok=True);MEDIA=OUT/'outputs';MEDIA.mkdir(exist_ok=True);(OUT/'logs').mkdir(exist_ok=True)
checks=[];summary={}
def check(name,condition,detail=None,soft=False):
    checks.append({'name':name,'passed':bool(condition),'detail':detail}); print(name, bool(condition),flush=True)
    if not condition and not soft: raise AssertionError(name+': '+str(detail))
def read_dxf(data):return ezdxf.read(StringIO(data.decode('utf-8')))
def raw(d):
    s=StringIO();d.write(s);return s.getvalue().encode(d.encoding if d.dxfversion<'AC1021' else 'utf-8')
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
base=f'http://127.0.0.1:{port}'
import tempfile
_tmp=tempfile.TemporaryDirectory(prefix='bxh-v82-http-');state=Path(_tmp.name)
env={**os.environ,'ENV':'test','HOST':'127.0.0.1','PORT':str(port),'BAOXIAOHE_DB':str(state/'audit.sqlite'),'BAOXIAOHE_LOCAL_RENDER_DIR':str(state/'renders')}
log=(OUT/'logs/http-server.log').open('wb');process=None

def start():
    global process
    process=subprocess.Popen([sys.executable,'server.py'],cwd=ROOT,env=env,stdout=log,stderr=log)
    for _ in range(100):
        try:
            if httpx.get(base+'/api/health',timeout=1).status_code==200:return
        except httpx.HTTPError:pass
        time.sleep(.1)
    raise RuntimeError('Server did not start')
def stop():
    if process and process.poll() is None:
        process.terminate()
        try:process.wait(12)
        except subprocess.TimeoutExpired:process.kill();process.wait(3)
def import_file(c,data,name='sample.dxf',**kw):
    return c.post('/api/local/cad/import',json={'filename':name,'data':base64.b64encode(data).decode(),**kw})
def analyze(c,d):
    r=c.post('/api/local/cad/analyze',json=d);r.raise_for_status();return r.json()
def wait(c,jid):
    t=time.monotonic();states=[]
    while time.monotonic()-t<90:
        r=c.get('/api/local/jobs/'+jid);r.raise_for_status();j=r.json()
        if not states or states[-1]!=j['status']:states.append(j['status'])
        if j['status'] not in ('running','queued'):return j,round(time.monotonic()-t,3),states
        time.sleep(.15)
    raise TimeoutError(jid)
def render(c,payload,label):
    r=c.post('/api/local/cad/jobs',json=payload);r.raise_for_status();jid=r.json()['id'];j,duration,states=wait(c,jid)
    check(label+' completes',j['status']=='succeeded',{'seconds':duration,'states':states,'error':j.get('error')})
    r=c.get('/api/local/jobs/'+jid+'/result');r.raise_for_status()
    return r.content,jid
async def native_probe():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await b.new_page();record={}
        try:
            r=await page.goto(base+'/cad',wait_until='domcontentloaded',timeout=15000)
            record={'result':'opened','http':r.status,'body':(await page.locator('body').inner_text())[:250]}
            await page.screenshot(path=str(MEDIA/'native-cad.png'))
        except Exception as e:record={'result':'blocked_or_failed','error':str(e)}
        await b.close();return record
try:
    start()
    with httpx.Client(base_url=base,timeout=90) as c:
        for route in ['/cad','/structure','/templates','/render/template/16835']:
            r=c.get(route);check('HTTP route '+route,r.status_code==200,r.status_code)
        c.get('/api/local/capabilities').raise_for_status();caps=c.get('/api/local/cad/capabilities').json();summary['capabilities']=caps
        summary['native_browser']=asyncio.run(native_probe());print('NATIVE',summary['native_browser'],flush=True)
        data=(ROOT/'examples/dxf/tuck.dxf').read_bytes();r=import_file(c,data,'\u81ea\u5b9a\u4e49\u5200\u6a21.DXF');r.raise_for_status();doc=r.json()['document'];a=analyze(c,doc)
        check('Uppercase DXF and Chinese filename import',doc['source_name'].endswith('.DXF') and a['foldable'],{'paths':a['stats']['paths'],'faces':len(a['faces']),'hinges':len(a['hinges'])})
        r2=import_file(c,data,'\u81ea\u5b9a\u4e49\u5200\u6a21.DXF');check('Repeated identical import retains geometry',r2.json()['document']['paths']==doc['paths'])
        hinged=import_file(c,(ROOT/'examples/dxf/hinged.dxf').read_bytes()).json()['document'];ha=analyze(c,hinged)
        check('Hinged DXF forms real topology',ha['foldable'] and len(ha['faces'])==13)
        hole=import_file(c,(ROOT/'examples/dxf/circle-cutout.dxf').read_bytes()).json()['document'];ah=analyze(c,hole)
        check('Round cutout retains hole',ah['foldable'] and any(f['holes'] for f in ah['faces']))
        units=ezdxf.new('R2010');units.units=1;units.modelspace().add_lwpolyline([(0,0),(2,0),(2,1),(0,1)],close=True,dxfattribs={'color':5})
        u=import_file(c,raw(units)).json()['document'];check('Declared inches converted to millimetres',abs(max(p['b'][0] for p in u['paths'])-50.8)<1e-8,{'measured_mm':max(p['b'][0] for p in u['paths']),'tolerance_mm':1e-8})
        units.units=0;ur=import_file(c,raw(units));check('Unitless file requires explicit unit',ur.status_code==422)
        check('Unitless file accepts explicit mm',import_file(c,raw(units),unit='mm').status_code==200)
        for version in ['R12','R2000','R2018']:
            d=ezdxf.new(version);d.units=4;d.layers.new('CUT',dxfattribs={'color':5});d.modelspace().add_circle((50,50),20,dxfattribs={'layer':'CUT'});r=import_file(c,raw(d),unit='mm' if version=='R12' else 'auto');check(version+' ASCII import (R12 explicit mm)',r.status_code==200,r.status_code)
        for label,bad in [('corrupt',b'not a dxf'),('binary',b'AutoCAD Binary DXF\r\n\x1a\x00'),('oversize',b' '* (5*1024*1024+1))]:
            r=import_file(c,bad);check(label+' import rejected',r.status_code==422,r.status_code)
        # Genuine scaling and edit/save/reopen; only in audit runtime.
        doc['name']='AUDIT custom dieline';doc['objects']=[{'id':'audit-text','type':'text','text':'CUSTOM AUDIT','x':250,'y':220,'w':280,'h':50,'fontSize':24,'fill':'#194881'}]
        scaled=c.post('/api/local/cad/scale',json={'document':doc,'x':1.2,'y':1.2});scaled.raise_for_status();sc=scaled.json()['document'];sa=analyze(c,sc)
        check('Custom net scaling remains foldable',sa['foldable'] and sc['paths'][0]['b'][0]==doc['paths'][0]['b'][0]*1.2)
        r=c.post('/api/local/cad/library',json={'document':doc,'folder':'Audit/Packaging/Custom','tags':['audit','dxf']});r.raise_for_status();mid=r.json()['id']
        saved=c.get('/api/local/cad/library/'+mid).json();check('Model save/reload preserves paths and artwork',saved['document']['paths']==doc['paths'] and saved['document']['objects'][0]['text']=='CUSTOM AUDIT')
        check('Model search by name/tag/folder',c.get('/api/local/cad/library?q=AUDIT&folder=Audit&tag=audit').json()['total']==1)
        r=c.put('/api/local/cad/library/'+mid,json={'document':doc,'expected_version':1});check('Versioned update succeeds',r.status_code==200 and r.json()['version']==2)
        check('Stale save rejected',c.put('/api/local/cad/library/'+mid,json={'document':doc,'expected_version':1}).status_code==409)
        for fmt in ['dxf','svg']:
            r=c.post('/api/local/cad/export/'+fmt,json=doc);r.raise_for_status();(MEDIA/('custom-review.'+fmt)).write_bytes(r.content)
        dx=read_dxf((MEDIA/'custom-review.dxf').read_bytes());check('DXF export units and format audit',dx.units==4 and len(dx.audit().errors)==0)
        rt=import_file(c,(MEDIA/'custom-review.dxf').read_bytes()).json()['document'];ra=analyze(c,rt);check('DXF reimport preserves foldable face count',ra['foldable'] and len(ra['faces'])==len(a['faces']),{'errors':ra['errors'][:5],'unassigned':sum(p['role']=='unassigned' for p in rt['paths'])})
        check('GUIDE maps automatically without manual repair',all(p['role']=='guide' for p in rt['paths'] if p['layer']=='GUIDE'))
        # Use independent bitmap textures to validate worker, not editor's baker.
        doc['hinges']={h['id']:{'angle':h['angle'],'openAngle':75 if i==0 else 0,'stage':h['stage'],'confirmed':True} for i,h in enumerate(a['hinges'])}
        tex=Image.new('RGB',(96,96),'white');draw=ImageDraw.Draw(tex);draw.rectangle((2,2,40,94),fill='#1464c8');draw.rectangle((47,3,94,28),fill='#d94632');draw.text((47,50),'AUDIT',fill='black');buf=BytesIO();tex.save(buf,'PNG');src='data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()
        textures={p['id']:src for p in a['model']['panels']}
        req={'cad_document':doc,'textures':textures,'long_edge':1024,'aspect':'4:3','view':{'fold':1,'opening':0,'transparent':True,'yaw':-25,'pitch':18},'format':'png'}
        png,done_job=render(c,req,'CAD textured 1024 PNG');(MEDIA/'cad-closed.png').write_bytes(png);im=Image.open(BytesIO(png));check('CAD PNG has real pixels and alpha',im.size==(1024,768) and im.getextrema()[3]==(0,255),{'size':im.size,'alpha':im.getextrema()[3]})
        no_tex,_=render(c,{**req,'textures':{}},'CAD blank PNG');check('Worker applies artwork textures',no_tex!=png)
        opened,_=render(c,{**req,'view':{**req['view'],'opening':1}},'CAD opened PNG');(MEDIA/'cad-opened.png').write_bytes(opened);check('Opening changes output pixels',opened!=png)
        for aspect,size in [('16:9',(4096,2304)),('9:16',(2304,4096))]:
            hi,_=render(c,{**req,'long_edge':4096,'aspect':aspect},'CAD 4K '+aspect);him=Image.open(BytesIO(hi));check('4K dimensions '+aspect,him.size==size and him.getextrema()[3]==(0,255));(MEDIA/('cad-4k-'+aspect.replace(':','x')+'.png')).write_bytes(hi)
        for fmt in ['frames','mp4','webm']:
            vreq={**req,'format':fmt,'long_edge':256,'seconds':1,'fps':12,'motion':'open','view':{**req['view'],'transparent':fmt=='frames'}}
            vid,_=render(c,vreq,'CAD open '+fmt);ext='zip' if fmt=='frames' else fmt;p=MEDIA/('cad-opening.'+ext);p.write_bytes(vid)
            if fmt=='frames':
                with zipfile.ZipFile(BytesIO(vid)) as z:
                    names=sorted(n for n in z.namelist() if n.endswith('.png'));check('Frames ZIP decodes and moves',len(names)==12 and z.read(names[0])!=z.read(names[-1]),{'frames':len(names)})
            else:
                pr=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=codec_name,width,height,nb_read_frames','-of','json',str(p)],capture_output=True,text=True,check=True)
                info=json.loads(pr.stdout)['streams'][0];decoded=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True).stdout;stride=info['width']*info['height']*3
                check(fmt+' decodes into distinct moving frames',int(info['nb_read_frames'])==12 and decoded[:stride]!=decoded[-stride:],info)
        r=c.post('/api/local/cad/jobs',json={**req,'format':'mp4','long_edge':4096});check('Invalid video output rejected',r.status_code==422)
        r=c.post('/api/local/cad/jobs',json={**req,'format':'mp4','long_edge':256});check('Transparent MP4 explicitly rejected',r.status_code==422)
        r=c.post('/api/local/cad/jobs',json={**req,'format':'frames','long_edge':1024,'seconds':6,'fps':20});r.raise_for_status();jid=r.json()['id'];c.post('/api/local/jobs/'+jid+'/cancel',json={}).raise_for_status();j,_,_=wait(c,jid);check('Render cancellation stops export',j['status']=='cancelled' and c.get('/api/local/jobs/'+jid+'/result').status_code==409)
        with httpx.Client(base_url=base,timeout=30) as other:
            other.get('/api/local/capabilities');check('Other session cannot read model',other.get('/api/local/cad/library/'+mid).status_code==404);check('Other session cannot download render',other.get('/api/local/jobs/'+done_job+'/result').status_code==404)
        stop();start();check('Model survives actual service restart',c.get('/api/local/cad/library/'+mid).json()['document']['paths']==doc['paths']);check('Rendered PNG survives actual restart',c.get('/api/local/jobs/'+done_job+'/result').content==png)
except Exception as e:
    summary['exception']=repr(e);raise
finally:
    stop();log.close();_tmp.cleanup();summary.update({'scope':'Fresh runtime; actual localhost HTTP, subprocess worker and ffmpeg decoding. Native browser status separate. Not user deployment.','checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)});(OUT/'http_results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
