"""Authored local UI + in-process API + actual local worker, NOT native browser E2E."""
import asyncio,json,os,sys,tempfile,base64
from io import BytesIO
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tools.component_harness_v6 import boot
from playwright.async_api import async_playwright
from fastapi.testclient import TestClient
from PIL import Image
import app.main as main
OUT=ROOT/'evidence/v7';OUT.mkdir(exist_ok=True)

async def run():
    results=[]
    def check(name,value,details=None):
        assert value,(name,details);results.append({'name':name,'passed':True,'details':details})
    os.environ['ENV']='test'
    with tempfile.TemporaryDirectory() as d:
        main.DB_PATH=Path(d)/'browser.sqlite'
        with TestClient(main.app) as client:
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                page,errors=await boot(browser,'/structure',client=client)
                try:
                    await page.wait_for_function("document.querySelectorAll('#texturePanel option').length===13",timeout=20000)
                    check('Parametric workbench loads 13 panels',True)
                    await page.wait_for_function("!document.querySelector('#submitLocalRender').disabled")
                    check('Local renderer session initialised',True)
                    engine=await page.locator('#localEngine').inner_text()
                    check('Actual browser preview engine reported',bool(engine),engine)
                    await page.locator('#textureTitle').click();await page.wait_for_timeout(350)
                    check('Authored panel texture generated',await page.locator('#netViewport image').count()==1)
                    await page.screenshot(path=str(OUT/'studio-desktop.png'),full_page=True)
                    await page.locator('#foldProgress').evaluate("el=>{el.value=44;el.dispatchEvent(new Event('input',{bubbles:true}));}")
                    check('Fold slider and opening gate',await page.locator('#openProgress').is_disabled() and await page.locator('#foldValue').inner_text()=='44%')
                    await page.screenshot(path=str(OUT/'tuck-part-folded.png'),full_page=True)
                    await page.locator('#playFold').click();await page.wait_for_timeout(3300)
                    check('Fold animation completes',await page.locator('#foldProgress').input_value()=='100')
                    await page.locator('#playOpen').click();await page.wait_for_timeout(3300)
                    check('Lid animation completes',await page.locator('#openProgress').input_value()=='100')
                    await page.locator('#fitStructure').click()
                    await page.screenshot(path=str(OUT/'tuck-open.png'),full_page=True)
                    await page.locator('#structureKind').select_option('hinged')
                    await page.wait_for_function("document.querySelector('#sp-height').value==='35' && document.querySelector('#texturePanel option[value=base]')")
                    check('Hinged net has base/lid hierarchy',await page.locator('#texturePanel option[value=lid]').count()==1)
                    await page.locator('#sp-height').fill('200');await page.locator('#applyStructure').click();await page.wait_for_timeout(250)
                    check('Invalid dimensions blocked',await page.locator('#localStatus.error').count()==1)
                    await page.locator('#sp-height').fill('35');await page.locator('#applyStructure').click();await page.wait_for_timeout(300)
                    await page.locator('#texturePanel').select_option('lid');await page.locator('#textureTitle').click();await page.wait_for_timeout(250)
                    await page.locator('#openProgress').evaluate("el=>{el.value=80;el.dispatchEvent(new Event('input',{bubbles:true}));}")
                    await page.screenshot(path=str(OUT/'hinged-open.png'),full_page=True)
                    await page.locator('#localFormat').select_option('mp4')
                    check('Video size cap visible',await page.locator('#localQuality option[value="4096"]').evaluate('e=>e.disabled'),await page.evaluate("({format:document.querySelector('#localFormat').value,options:[...document.querySelector('#localQuality').options].map(o=>[o.value,o.disabled]),caps:[...document.querySelector('#localFormat').options].map(o=>[o.value,o.disabled])})"))
                    await page.locator('#localFormat').select_option('png');await page.locator('#localQuality').select_option('512');await page.locator('#localTransparent').check()
                    await page.locator('#submitLocalRender').click()
                    await page.wait_for_selector('.local-job[data-status=succeeded]',timeout=30000)
                    check('UI submitted real local PNG job',True)
                    href=await page.locator('.local-job[data-status=succeeded] a').first.get_attribute('href');r=client.get(href)
                    check('Result link returns real PNG',r.status_code==200 and r.content.startswith(b'\x89PNG'))
                    with Image.open(BytesIO(r.content)) as im:check('PNG dimensions and alpha',im.size==(512,384) and im.getextrema()[3]==(0,255))
                    (OUT/'ui-render.png').write_bytes(r.content)
                    await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(300)
                    for tab in ('params','stage','output'):
                        await page.locator(f'[data-local-tab={tab}]').click();await page.wait_for_timeout(180)
                        width=await page.evaluate('({viewport:innerWidth,content:document.documentElement.scrollWidth})')
                        check('Mobile panel visible without overflow: '+tab,width['content']<=width['viewport'],width)
                        await page.screenshot(path=str(OUT/('mobile-'+tab+'.png')),full_page=True)
                    await page.set_viewport_size({'width':1440,'height':1000})
                    await page.evaluate("__navigate('/design/template/25987')")
                    await page.wait_for_selector('#openStructure',timeout=10000)
                    check('Existing editor has structure entry',True)
                    await page.locator('#openStructure').click()
                    await page.wait_for_function("document.querySelectorAll('#netViewport image').length===6",timeout=10000)
                    check('Six existing artwork faces transfer to real panels',True)
                    await page.wait_for_timeout(300)
                    await page.screenshot(path=str(OUT/'from-editor.png'),full_page=True)
                    await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(300)
                    check('Workbench unmounts cleanly',await page.locator('#foldViewport').count()==0)
                    await page.evaluate("__navigate('/structure')")
                    await page.wait_for_function("document.querySelectorAll('#netViewport image').length===6")
                    check('Browser project restored including embedded textures',True)
                    check('No uncaught JavaScript errors',not errors,errors)
                except Exception:
                    await page.screenshot(path=str(OUT/'browser-failure.png'),full_page=True)
                    print('BODY',(await page.locator('body').inner_text())[-7000:]);print('JS ERRORS',errors);raise
                finally:
                    (OUT/'browser-report.json').write_text(json.dumps({'scope':'Local authored-code components + in-process API + actual worker. NOT native browser E2E or original-site pixel QA.','engine':engine,'checks':results,'page_errors':errors},ensure_ascii=False,indent=2))
                    await browser.close()
    print('BROWSER_CHECKS_PASSED',len(results))
if __name__=='__main__':asyncio.run(run())
