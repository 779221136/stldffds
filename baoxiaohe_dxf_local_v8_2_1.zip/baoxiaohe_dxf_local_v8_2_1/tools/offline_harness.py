"""Offline browser harness; no browser URL-blocking policies are changed.
Only authored source is injected into about:blank. Relative API requests are
forwarded by a Python binding to the local development server. History and
localStorage are test doubles due to the opaque about:blank origin.
"""
import asyncio,base64,json,re,os
from pathlib import Path
from urllib.parse import urlsplit
import httpx
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ.get('AUDIT_OUTPUT','offline-audit')).resolve();OUT.mkdir(parents=True,exist_ok=True)

def bundle(route='/templates'):
    modules={};order=[]
    def visit(name):
        if name in modules:return
        text=(ROOT/'src'/name).read_text();modules[name]=text
        for dep in re.findall(r"import .*? from ['\"]\./([^'\"]+)['\"];",text):visit(dep)
        order.append(name)
    visit('app.js')
    prefix='''window.__modules={};window.__testStorage=new Map();
    window.__route=new URL(%s,'http://local.test');
    window.__navigate=(path)=>{window.__route=new URL(path,window.__route);dispatchEvent(new PopStateEvent('popstate'));};
    (()=>{
    const location=new Proxy({},{get:(_,key)=>window.__route[key]});
    const history={pushState:(_,__,p)=>window.__route=new URL(p,window.__route),replaceState:(_,__,p)=>window.__route=new URL(p,window.__route)};
    const localStorage={getItem:k=>window.__testStorage.get(k)||null,setItem:(k,v)=>window.__testStorage.set(k,String(v)),removeItem:k=>window.__testStorage.delete(k)};
    const fetch=async(path,opts={})=>{const r=await window.__localAPI({path:String(path),method:opts.method||'GET',headers:opts.headers||{},body:opts.body||null});const bytes=Uint8Array.from(atob(r.data),c=>c.charCodeAt(0));return new Response(bytes,{status:r.status,headers:r.headers});};
    '''%json.dumps(route)
    parts=[prefix]
    for name in order:
        s=modules[name];exports=re.findall(r'export (?:async )?(?:function|const|let|class)\s+(\w+)',s)
        s=re.sub(r"import (.*?) from ['\"]\./([^'\"]+)['\"];",lambda m:f'const {m[1]}=window.__modules[{json.dumps(m[2])}];',s)
        s=re.sub(r'\bexport (?=(?:async )?(?:function|const|let|class)\b)','',s)
        parts.append('window.__modules['+json.dumps(name)+']=(()=>{'+s+';return {'+','.join(exports)+'};})();')
    parts.append('})();')
    return '\n'.join(parts)

async def boot(browser,route='/templates',viewport=None):
    page=await browser.new_page(viewport=viewport or {'width':1440,'height':1000},device_scale_factor=1)
    api=httpx.AsyncClient(base_url=os.environ.get('AUDIT_BASE','http://127.0.0.1:8088'),timeout=30)
    async def local_api(data):
        path=data['path']
        if not path.startswith('/api/') or urlsplit(path).netloc:raise ValueError('Only local /api/ paths may be requested')
        response=await api.request(data['method'],path,headers=data['headers'],content=data['body'])
        return {'status':response.status_code,'headers':dict(response.headers),'data':base64.b64encode(response.content).decode()}
    await page.expose_function('__localAPI',local_api)
    html=(ROOT/'index.html').read_text()
    html=re.sub(r'<script.*?</script>','',html,flags=re.S)
    html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
    await page.set_content(html)
    await page.add_style_tag(content=(ROOT/'assets/styles.css').read_text())
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    await page.add_script_tag(content=bundle(route))
    await page.wait_for_timeout(1000)
    return page,api,errors

async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
        page,api,errors=await boot(browser)
        result=[]
        for name,route in [('catalog','/templates'),('editor','/design/template/25987'),('render','/render/template/25987'),('login','/login'),('print','/print')]:
            await page.evaluate('(route)=>__navigate(route)',route);await page.wait_for_timeout(1200)
            await page.screenshot(path=str(OUT/(name+'.png')),full_page=True)
            result.append({'route':route,'errors':errors[:],'text':(await page.locator('body').inner_text())[:3000],'canvas':await page.locator('canvas').count()})
        (OUT/'browser_probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
        print(json.dumps(result,ensure_ascii=False,indent=2));await api.aclose();await browser.close()
if __name__=='__main__':asyncio.run(main())
