"""UI checks using the explicit offline harness, not native browser E2E parity."""
import asyncio,json,time,os
from pathlib import Path
from playwright.async_api import async_playwright
from offline_harness import boot,OUT

async def main():
    checks=[]
    def ok(name,**details):
        checks.append({'name':name,'passed':True,**details})
        print('PASS',name,details,flush=True)
        (OUT/'v5_browser_partial.json').write_text(json.dumps(checks,indent=2))
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page,api,errors=await boot(browser)
        page.set_default_timeout(12000)
        async def shot(name):
            await page.evaluate('window.scrollTo(0,0)');await page.wait_for_timeout(120)
            await page.screenshot(path=str(OUT/name),full_page=True)
        async def go(route,selector):
            await page.evaluate('(route)=>__navigate(route)',route)
            await page.wait_for_selector(selector)
        await page.wait_for_function("document.querySelectorAll('#catalogGrid .item-card').length===10")
        assert await page.locator('#filters .filter-row').count()==8;ok('Eight template filter dimensions')
        assert await page.locator('#catalogGrid .badge.free').count()==0
        assert await page.locator('#catalogGrid .price-unknown').count()==10;ok('Unknown price is not free')
        assert await page.locator('#catalogGrid .unknown-author').count()==10;ok('Unknown authors are not marked official')
        first=await page.locator('#catalogGrid .card-title').all_text_contents()
        await page.locator('[data-page="2"]').first.click()
        await page.wait_for_function("document.querySelector('#count').textContent.includes('2/2')")
        second=await page.locator('#catalogGrid .card-title').all_text_contents()
        assert set(first).isdisjoint(second);ok('Pagination changes actual records')
        await page.locator('[data-filter="price|free"]').click()
        await page.wait_for_function("document.querySelector('#catalogGrid').getAttribute('aria-busy')==='false'")
        assert await page.locator('#catalogGrid .item-card').count()==0
        assert await page.evaluate("__route.search.includes('price=free')");ok('Free facet and URL state')
        await page.locator('#clearFilters').click()
        await page.wait_for_function("document.querySelectorAll('#catalogGrid .item-card').length===10")
        await page.locator('#pageSize').select_option('20')
        await page.wait_for_function("document.querySelectorAll('#catalogGrid .item-card').length===20");ok('Page-size selector requests actual data')
        await shot('templates-desktop.png')
        await go('/templates?material='+__import__('urllib.parse',fromlist=['quote']).quote('\u94dc\u7248\u7eb8'),'#catalogGrid .item-card')
        r=(await api.get('/api/templates',params={'material':'\u94dc\u7248\u7eb8'})).json()
        assert await page.locator('#catalogGrid .item-card').count()==len(r['items']);ok('Material facet renders server-filtered records')
        await go('/models','#catalogGrid .item-card')
        await page.locator('[data-view="2d"]').click()
        assert await page.locator('#catalogGrid .asset-missing').count()>0
        assert await page.evaluate("__route.search.includes('view=2d')");ok('2D mode reports missing real dielines rather than showing a fake one')
        await page.locator('[data-view="3d"]').click()
        await shot('models-desktop.png')
        await page.evaluate("__modules['data.js'].templates.splice(0)")
        await go('/templates/25987','.v5-detail')
        assert await page.locator('.v5-detail h1').inner_text()
        assert await page.evaluate("__modules['data.js'].templates.some(x=>x.id===25987)");ok('Deep link rehydrates source from API after cache is emptied')
        await shot('detail-desktop.png')
        await go('/templates/99999999','.notfound');ok('Unknown detail shows not-found UI')
        await go('/design/template/25987','.packaging-svg')
        await page.wait_for_timeout(700)
        bounds=await page.evaluate("""()=>{const s=document.querySelector('.packaging-svg').getBoundingClientRect(),w=document.querySelector('.svg-scroll').getBoundingClientRect();return {s:{left:s.left,right:s.right,top:s.top,bottom:s.bottom},w:{left:w.left,right:w.right,top:w.top,bottom:w.bottom},zoom:document.querySelector('[data-ed-zoom]').textContent};}""")
        assert bounds['s']['right']<=bounds['w']['right']+1 and bounds['s']['left']>=bounds['w']['left']-1,bounds
        assert bounds['s']['bottom']<=bounds['w']['bottom']+1,bounds;ok('Desktop artboard fits within workspace',bounds=bounds)
        original=await page.locator('[data-ed-zoom]').inner_text()
        await page.locator('[data-ed-zoomin]').click();assert await page.locator('[data-ed-zoom]').inner_text()!=original
        await page.keyboard.press('Control+0');assert await page.locator('[data-ed-zoom]').inner_text()==original;ok('Zoom and Ctrl+0 fit-to-view')
        await shot('editor-desktop.png')
        await go('/login','#loginPhone');phone='139'+str(time.time_ns())[-8:]
        await page.locator('#loginPhone').fill(phone);await page.locator('#sendCode').click()
        await page.wait_for_function("document.querySelector('#loginCode').value.length===6")
        await page.locator('#loginSubmit').click();await page.wait_for_selector('#accountName');ok('Development OTP session round-trip')
        await go('/design/template/25987','.packaging-svg');await page.wait_for_timeout(400)
        await page.locator('#saveDesign').click()
        await page.wait_for_function("document.querySelector('#saveStatus').textContent.includes('v1')")
        saved=(await api.get('/api/designs')).json()['items'];assert len(saved)==1;ok('Fitted viewport design saves to actual backend')
        await page.set_viewport_size({'width':390,'height':844})
        await go('/templates','#catalogGrid .item-card')
        dimensions=await page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})')
        assert dimensions['scroll']<=dimensions['width']+1,dimensions;ok('390px catalog without document horizontal overflow')
        assert await page.locator('#navToggle').is_visible();await page.locator('#navToggle').click()
        assert await page.locator('#mobileNav').is_visible();await page.locator('#navToggle').click();ok('Mobile navigation opens and closes')
        await shot('templates-mobile.png')
        await go('/templates/25987','.v5-detail')
        assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');ok('Mobile detail page without horizontal overflow')
        await shot('detail-mobile.png')
        r=(await api.get('/api/readiness')).json();assert r['production_ready'] is False;ok('Readiness remains blocked despite passing functional checks')
        assert not errors,errors;ok('No uncaught browser JavaScript errors',errors=errors)
        report={'scope':'offline Chromium with history/storage/fetch adapters and real local APIs; NOT native E2E or original-site pixel comparison','checks':checks,'count':len(checks),'errors':errors}
        (OUT/'v5_browser_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
        print('V5_BROWSER_OK',len(checks));await api.aclose();await browser.close()
if __name__=='__main__':asyncio.run(main())
