"""Regression interactions on authored code with in-process backend.
Run: python tools/acceptance_v6.py. No network navigation or original-site capture.
"""
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from fastapi.testclient import TestClient
from playwright.async_api import async_playwright
from tools.component_harness_v6 import boot
import app.main as main
OUT=Path(os.environ.get('AUDIT_OUTPUT',str(ROOT/'evidence/v6')));OUT.mkdir(parents=True,exist_ok=True)
checks=[];errors=[];metrics={}

def check(name,ok,details=None):
    item={'name':name,'passed':bool(ok)}
    if details is not None:item['details']=details
    checks.append(item)
    if not ok:raise AssertionError(name+': '+str(details))

def signin(c):
    phone='13800138106'
    r=c.post('/api/auth/sms/send',json={'phone':phone});assert r.status_code==200
    r=c.post('/api/auth/sms/login',json={'phone':phone,'code':r.json()['dev_code']});assert r.status_code==200

async def pause(page,ms=500):await page.wait_for_timeout(ms)
async def shot(page,name):await page.screenshot(path=str(OUT/(name+'.png')),full_page=True)
async def draft(page):return await page.evaluate("window.__modules['store.js'].store.get().designs[0]")
async def field(page,selector,value):
    await page.locator(selector).fill(str(value));await page.locator(selector).dispatch_event('change');await pause(page,100)

async def run():
    os.environ['ENV']='test'
    with tempfile.TemporaryDirectory() as d:
        main.DB_PATH=Path(d)/'test.db'
        with TestClient(main.app) as client:
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                page,err=await boot(browser,client=client);errors.append(err)
                await page.wait_for_selector('.v5-item')
                box=await page.locator('.v5-item').first.bounding_box();metrics['desktop_first_card_y']=round(box['y'],1)
                check('Catalog initial filters do not consume entire desktop viewport',box['y']<800,box)
                check('Secondary filters collapsed by default',await page.locator('.advanced-filter:visible').count()==0)
                await page.locator('#toggleAdvanced').click()
                check('Secondary filters can be expanded',await page.locator('.advanced-filter:visible').count()==5)
                await page.locator('#toggleAdvanced').click()
                check('Missing publication/usage metrics cannot masquerade as real sort',await page.locator('[data-sort="new"]').is_disabled() and await page.locator('[data-sort="uses"]').is_disabled())
                await page.locator('[data-filter="model|\u5929\u5730\u76d6"]').click();await pause(page)
                check('Model category finds existing perfume/nuts templates',await page.locator('.v5-item').count()==2)
                await page.locator('[data-clear="model"]').click();await pause(page);await shot(page,'catalog-desktop')
                await page.set_viewport_size({'width':390,'height':844});await pause(page)
                box=await page.locator('.v5-item').first.bounding_box();metrics['mobile_first_card_y']=round(box['y'],1)
                check('Mobile catalog displays first card in first viewport',box['y']<844,box)
                check('Mobile catalog has no document overflow',await page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                await shot(page,'catalog-mobile');await page.close()

                signin(client)
                page,err=await boot(browser,'/design/template/25987',client=client);errors.append(err)
                await page.wait_for_selector('#boxL');await pause(page)
                await shot(page,'editor-desktop-before-actions')
                zoom_before=await page.locator('[data-ed-zoom]').inner_text()
                await field(page,'#boxL',240);await page.locator('[data-ed-undo]').click()
                check('Undo preserves viewport zoom instead of restoring 100 percent',await page.locator('[data-ed-zoom]').inner_text()==zoom_before)
                check('Undo restores visible length input',float(await page.locator('#boxL').input_value())==120)
                await field(page,'#boxW',90);await pause(page,1600)
                saved=await draft(page)
                check('Width edit cannot resurrect stale undone length',saved['box']['length']==120 and saved['box']['width']==90,saved['box'])
                previous=await page.locator('#canvasBg').input_value()
                await page.locator('#canvasBg').fill('#ff0000');await page.locator('#canvasBg').dispatch_event('change')
                await page.locator('[data-ed-undo]').click()
                check('Undo restores color input',await page.locator('#canvasBg').input_value()==previous)
                await page.locator('[data-ed-tool="text"]').click();await pause(page,100)
                await page.locator('#objText').evaluate("e=>e.dataset.identity='persistent'")
                await page.locator('#objText').fill('FIRST CLICK WORKS')
                check('Typing preserves inspector DOM node/caret',await page.locator('#objText').get_attribute('data-identity')=='persistent')
                was=await page.locator('#objBold').get_attribute('aria-pressed');await page.locator('#objBold').click()
                check('First click after typing toggles bold',await page.locator('#objBold').get_attribute('aria-pressed')!=was)
                await page.locator('#objItalic').click();check('Formatting state updates on one click',await page.locator('#objItalic').get_attribute('aria-pressed')=='true')
                await pause(page,1700)
                saved=await draft(page);cloud=client.get(f"/api/designs/{saved['cloudId']}").json()['item']
                check('Autosave reaches backend without clicking Save',any(o.get('text')=='FIRST CLICK WORKS' and o.get('fontStyle')=='italic' for o in cloud['payload']['objects']))
                check('Server acknowledgment clears dirty state',not saved['dirty'] and await page.locator('#saveStatus').get_attribute('data-state')=='saved')
                base_version=cloud['version']
                # Text corners scale glyphs, while text-frame width supports wrapping.
                await page.locator('[data-ed-tool="text"]').click()
                text='Packaging design wraps long text without dropping characters.'
                await page.locator('#objText').fill(text);await pause(page,300)
                selection=await page.locator('.selection-layer rect').first.bounding_box()
                handle=await page.locator('[data-handle="se"]').bounding_box()
                fs=float(await page.locator('#objFont').input_value())
                await page.mouse.move(handle['x']+5,handle['y']+5);await page.mouse.down()
                await page.mouse.move(handle['x']+28,handle['y']+20,steps=8);await page.mouse.up();await pause(page,400)
                check('Dragging text corner scales actual font size',float(await page.locator('#objFont').input_value())>fs)
                wrapped=next(o for o in (await draft(page))['objects'] if o.get('text')==text)
                check('Wrapped text preserves every character',len(wrapped['textLines'])>1 and ''.join(wrapped['textLines'])==text)
                await pause(page,1400)
                cloud_wrapped=client.get(f"/api/designs/{(await draft(page))['cloudId']}").json()['item']
                check('Line layout persists in server document',any(o.get('textLines')==wrapped['textLines'] for o in cloud_wrapped['payload']['objects']))
                pdf=client.post('/api/exports/pdf',json={'payload':cloud_wrapped['payload'],'color_mode':'RGB','mode':'print','name':'v6-wrapped-preview'})
                check('Wrapped design exports an actual RGB preview PDF',pdf.status_code==200 and pdf.content.startswith(b'%PDF'),{'status':pdf.status_code})
                (OUT/'wrapped-preview.pdf').write_bytes(pdf.content)
                # Source text persists; current shape positions do not get altered by layer reorder.
                await page.locator('[data-ed-tool="rect"]').click();await pause(page,200)
                before=await page.evaluate("window.__modules['store.js'].store.get().designs[0]")
                rows=page.locator('[data-layer-row]')
                count=await rows.count()
                check('Layers panel lists current objects',count>=4,count)
                order_before=await page.locator('[data-layer-row]').evaluate_all('es=>es.map(e=>e.dataset.layerRow)')
                drag_id=order_before[-1]
                await pause(page,400);prior=await draft(page)
                source_box=await page.locator('[data-layer-handle]').last.bounding_box()
                target_box=await page.locator('[data-layer-row]').first.bounding_box()
                await page.mouse.move(source_box['x']+8,source_box['y']+8);await page.mouse.down()
                await page.mouse.move(target_box['x']+12,target_box['y']+3,steps=15);await pause(page,100)
                await shot(page,'layers-dragging');await page.mouse.up();await pause(page,1700)
                ordered=await page.locator('[data-layer-row]').evaluate_all('es=>es.map(e=>e.dataset.layerRow)')
                check('Pointer drag moves visual bottom layer to top',ordered[0]==drag_id)
                current=await draft(page)
                old_obj=next(o for o in prior['objects'] if o['id']==drag_id);new_obj=next(o for o in current['objects'] if o['id']==drag_id)
                check('Pointer layer reorder preserves geometry',all(old_obj.get(k)==new_obj.get(k) for k in ['x','y','w','h','rotation']))
                await page.locator('[data-ed-undo]').click();await pause(page,100)
                check('One undo reverses exactly one layer drag',await page.locator('[data-layer-row]').evaluate_all('es=>es.map(e=>e.dataset.layerRow)')==order_before)
                # Keyboard fallback also uses exactly the same reorder transaction as drag.
                handles=page.locator('[data-layer-handle]')
                if await handles.count()==0:handles=page.locator('.layer-drag-handle')
                handle=handles.last;await handle.focus();await page.keyboard.press('Home');await pause(page,1700)
                after=await draft(page)
                check('Layer reorder persists complete object set',len(after['objects'])==count)
                ids=[o['id'] for o in after['objects']]
                check('Layer objects have unique persistent IDs',len(ids)==len(set(ids)))
                await shot(page,'editor-desktop')

                # History UI and actual restore, with an explicit confirmation dialog.
                await page.locator('#designName').fill('BEFORE RESTORE');await pause(page,1700)
                before_restore=await draft(page)
                await page.locator('#designHistory').click();await page.wait_for_selector('.v6-history-dialog[open]')
                check('History dialog displays server checkpoints',await page.locator('.history-list article').count()>=3)
                await shot(page,'history-dialog')
                page.on('dialog',lambda d: asyncio.create_task(d.accept()))
                await page.locator('[data-version-restore="1"]').click()
                await page.wait_for_selector('.v6-history-dialog',state='detached');await pause(page,1000)
                restored=await draft(page)
                check('Restore advances version, rather than overwriting history',restored['version']>before_restore['version'])
                check('Restore updates design title and rendered controls',await page.locator('#designName').input_value()!='BEFORE RESTORE')

                # The route uses a persistent local draft to reopen the exact saved document.
                rid=restored['id'];expected=restored['objects']
                await page.evaluate("__navigate('/templates')");await pause(page)
                await page.evaluate('(id)=>__navigate(`/design/template/25987?draft=${id}`)',rid);await pause(page,800)
                reopened=await draft(page)
                check('Saved draft reopens with same layers',reopened['objects']==expected)
                await page.set_viewport_size({'width':390,'height':844});await pause(page)
                check('Mobile save state remains visible',await page.locator('#saveStatus').is_visible())
                check('Mobile editor no longer forces 780px document width',await page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                for selector in ['#saveDesign','#exportDesign','[data-editor-panel="layers"]']:
                    rect=await page.locator(selector).bounding_box()
                    check('Mobile control fits viewport: '+selector,rect is not None and rect['x']>=0 and rect['x']+rect['width']<=391,rect)
                await shot(page,'editor-mobile-canvas')
                await page.locator('[data-editor-panel="properties"]').click()
                check('Mobile properties can be opened',await page.locator('#boxL').is_visible())
                await field(page,'#boxW',95);await pause(page,1600)
                check('Mobile dimension change reaches stored model',(await draft(page))['box']['width']==95)
                await shot(page,'editor-mobile-properties')
                await page.locator('[data-editor-panel="layers"]').click()
                check('Mobile layer ordering panel is accessible',await page.locator('#layerPanel').is_visible() and await page.locator('[data-layer-row]').count()>=2)
                await shot(page,'editor-mobile-layers')
                await page.locator('[data-editor-panel="preview"]').click()
                check('Mobile live preview is accessible',await page.locator('#livePkg').is_visible())
                await page.set_viewport_size({'width':1440,'height':1000});await pause(page,200)
                current=await draft(page);other=client.get(f"/api/designs/{current['cloudId']}").json()['item']
                external=client.post('/api/designs',json={'id':other['id'],'version':other['version'],'name':'OTHER TAB','kind':other['kind'],'source_id':other['source_id'],'payload':other['payload']})
                assert external.status_code==200
                await page.locator('#designName').fill('MY LOCAL CHANGE');await pause(page,1800)
                check('Conflicting remote save is not silently overwritten',await page.locator('#saveStatus').get_attribute('data-state')=='conflict')
                check('Conflict retains local changes and offers a copy',await page.locator('#saveCopy').is_visible() and (await draft(page))['name']=='MY LOCAL CHANGE')
                await shot(page,'save-conflict')
                await page.locator('#saveCopy').click();await pause(page,1000)
                copied=await draft(page)
                check('Save copy creates independent design',copied['cloudId']!=other['id'] and copied['name'].startswith('MY LOCAL CHANGE'))
                check('Copy operation leaves competing server document untouched',client.get(f"/api/designs/{other['id']}").json()['item']['name']=='OTHER TAB')
                await page.close()
                # Actual supplied document schema is loaded, not renamed generic objects.
                item=main.CATALOG['templates'][0]
                original=item.copy()
                item.update(document_access='public',design_payload={'schemaVersion':4,'box':{'length':160,'width':65,'height':200},'objects':[{'id':'imported-layer','type':'text','text':'DEPLOYMENT DOCUMENT','x':400,'y':300,'w':200,'h':80}]})
                try:
                    imported,err=await boot(browser,'/design/template/25987',client=client);errors.append(err)
                    await imported.wait_for_selector('#boxL');await pause(imported)
                    check('Supplied document dimensions load correctly',float(await imported.locator('#boxL').input_value())==160)
                    check('Supplied document objects replace placeholder layers',await imported.locator('[data-layer-row]').count()==1 and 'DEPLOYMENT DOCUMENT' in await imported.locator('#layerPanel').inner_text())
                    await imported.close()
                finally:item.clear();item.update(original)
                check('No uncaught JavaScript errors in component runs',not any(errors),errors)
                await browser.close()

if __name__=='__main__':
    failure=None
    try:asyncio.run(run())
    except Exception as e:failure=repr(e)
    result={'scope':'Authored code in about:blank; in-process FastAPI TestClient; no browser URL navigation, no original website capture, no GPU verification',
            'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'metrics':metrics,'failure':failure}
    (OUT/'component-report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=True,indent=2))
    if failure:sys.exit(1)
