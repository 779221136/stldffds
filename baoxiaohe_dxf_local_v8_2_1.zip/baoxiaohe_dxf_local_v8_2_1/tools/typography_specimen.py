"""Render an authored RGB typography specimen. Not original-site artwork or print output."""
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.domain import DesignPayload, box_layout
from app.preview_pdf import make_preview_pdf


def main():
    output = ROOT / 'evidence' / 'v6'
    output.mkdir(parents=True, exist_ok=True)
    box = {'length':120, 'width':80, 'height':180}
    payload = DesignPayload.model_validate({'box':box, 'objects':[]})
    front = box_layout(payload.box)['panels']['front']
    x,y,w,h = (front[k] for k in ['x','y','w','h'])
    data = {'schemaVersion':4, 'geometry':'six-face-box', 'box':box, 'bg':'#f4efe8','accent':'#bba38a',
            'objects':[
              {'id':'heading','type':'text','text':'LAYOUT CHECK','x':x+16,'y':y+24,'w':w-32,'h':24,'fontSize':22,'fontWeight':700,'align':'left','fill':'#202832'},
              {'id':'body','type':'text','text':'Packaging design\nkeeps every word\non the saved lines.','textLines':['Packaging design','keeps every word','on the saved lines.'],'wrap':True,'x':x+16,'y':y+80,'w':w-32,'h':100,'fontSize':18,'lineHeight':1.6,'align':'left','fill':'#344251'},
              {'id':'zh','type':'text','text':'\u5305\u88c5\u8bbe\u8ba1\u9884\u89c8','x':x+16,'y':y+198,'w':w-32,'h':30,'fontSize':22,'fontWeight':500,'align':'left','fill':'#344251'},
              {'id':'note','type':'text','text':'RGB PREVIEW ONLY','x':x+16,'y':y+264,'w':w-32,'h':22,'fontSize':12,'align':'left','fill':'#786750'}]}
    model = DesignPayload.model_validate(data)
    pdf = make_preview_pdf(model, 'print')
    (output/'typography-preview.pdf').write_bytes(pdf)
    (output/'typography-fixture.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(output/'typography-preview.pdf')
if __name__ == '__main__':main()
