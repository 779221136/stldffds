"""Authored-code Chromium components and in-process FastAPI, not native OS E2E."""
import asyncio
import json
import os
from io import StringIO
from pathlib import Path
import sys
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ezdxf
from fastapi.testclient import TestClient
from playwright.async_api import async_playwright
from tools.component_harness_v6 import boot
import app.main as main

OUT = ROOT/'evidence/dxf_encoding_fix/browser'
OUT.mkdir(parents=True, exist_ok=True)


def fixture(version='R2010', layer='CUT', encoding=None):
    d = ezdxf.new(version);d.units=4
    if encoding:d.encoding=encoding
    d.layers.new(layer,dxfattribs={'color':5})
    m=d.modelspace();m.add_lwpolyline([(0,0),(60,0),(60,40),(0,40)],close=True,dxfattribs={'layer':layer})
    s=StringIO();d.write(s)
    return s.getvalue().encode(d.output_encoding)


async def run():
    checks=[]
    def ok(name, value):
        checks.append({'name':name,'passed':bool(value)})
        print(name, bool(value), flush=True)
        assert value, name
    os.environ['ENV']='test'
    with tempfile.TemporaryDirectory() as td:
        main.DB_PATH=Path(td)/'test.db'
        with TestClient(main.app) as client:
            original=client.request;captured=[];responses=[];delay=False;started=threading.Event()
            def request(method, url, **kw):
                body=json.loads(kw['content']) if kw.get('content') else kw.get('json')
                if str(url)=='/api/local/cad/import':
                    captured.append(body)
                    if delay and body['encoding']=='utf-8':started.set();time.sleep(.8)
                    r=original(method,url,**kw)
                    responses.append(r)
                    return r
                return original(method,url,**kw)
            client.request=request
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                page,errors=await boot(browser,'/cad',client=client)
                page.set_default_timeout(15000)
                page.on('dialog',lambda d:d.accept())
                try:
                    await page.locator('[data-import]').click()
                    ok('Encoding defaults to Auto',await page.locator('[data-encoding]').input_value()=='auto')
                    async def select(data,name):
                        async with page.expect_file_chooser() as chooser:
                            await page.locator('[data-drop]').click()
                        await (await chooser.value).set_files({'name':name,'mimeType':'','buffer':data})
                    async def parse():
                        await page.locator('[data-parse]').click()
                        await page.locator('[data-import-confirm]').wait_for()
                    await select(b'\xef\xbb\xbf'+fixture(layer='\u5200\u7ebf'),'BOM-\u5200\u6a21.DXF')
                    await parse()
                    ok('BOM file accepted',responses[-1].status_code==200)
                    ok('Detected UTF-8 visible', 'utf-8' in await page.locator('[data-import-state]').inner_text())
                    ok('Decoded Chinese layer preserved', '\u5200\u7ebf' in await page.locator('[data-import-preview]').inner_text())
                    ok('BOM normalization warning visible','BOM' in await page.locator('[data-import-warnings]').inner_text())
                    await page.locator('[data-encoding]').select_option('utf-8')
                    ok('Changing encoding removes stale confirm',await page.locator('[data-import-confirm]').count()==0)
                    await parse()
                    ok('Chosen encoding sent to backend',captured[-1]['encoding']=='utf-8')
                    await select(fixture('R2000','\u5200\u7ebf','gbk'),'Legacy-GBK.dxf')
                    await page.locator('[data-parse]').click()
                    await page.locator('.cad-modal-error').wait_for(state='visible')
                    ok('Wrong codec gives specific decoding error','DXF_ENCODING' in await page.locator('.cad-modal-error').inner_text())
                    ok('Wrong codec cannot be confirmed',await page.locator('[data-import-confirm]').count()==0)
                    await page.locator('[data-encoding]').select_option('gbk')
                    await parse()
                    ok('Known GBK selection parses same file',responses[-1].status_code==200 and responses[-1].json()['encoding_info']['encoding']=='gbk')
                    ok('GBK retains real layer name',responses[-1].json()['document']['paths'][0]['layer']=='\u5200\u7ebf')
                    await page.screenshot(path=str(OUT/'gbk-preview.png'))
                    delay=True;await page.locator('[data-encoding]').select_option('utf-8')
                    await page.locator('[data-parse]').click()
                    for _ in range(100):
                        if started.is_set():break
                        await page.wait_for_timeout(10)
                    ok('Delayed parse actually started',started.is_set())
                    await page.locator('[data-encoding]').select_option('gbk')
                    await parse()
                    await page.wait_for_timeout(950)
                    ok('Late old-codec error cannot replace latest preview',await page.locator('[data-import-confirm]').count()==1 and not await page.locator('.cad-modal-error').is_visible())
                    delay=False
                    await page.locator('[data-import-confirm]').click()
                    await page.wait_for_function('!document.querySelector(".cad-modal-backdrop")')
                    ok('Imported geometry visible',await page.locator('[data-editor] svg').count()>=1)
                    await page.locator('[data-import]').click()
                    await select(b'AC1032\x00\x01','renamed-DWG.dxf')
                    await page.locator('[data-parse]').click()
                    await page.locator('.cad-modal-error').wait_for(state='visible')
                    ok('DWG is diagnosed rather than treated as bad encoding','DXF_DWG' in await page.locator('.cad-modal-error').inner_text())
                    ok('No uncaught JavaScript errors',not errors)
                except Exception:
                    await page.screenshot(path=str(OUT/'failure.png'))
                    raise
                finally:
                    (OUT/'checks.json').write_text(json.dumps({'scope':__doc__,'browser':browser.version,'checks':checks,'errors':errors},indent=2),encoding='utf-8')
                    await browser.close()
    print('PASSED',len(checks))
if __name__=='__main__':asyncio.run(run())
