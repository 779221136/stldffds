"""Synthetic, reproducible acceptance geometry (not an official-site asset)."""
import sys,json,base64
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.cad_engine import ImportRequest,CadDocument,CadPath,parse_dxf,analyze,export_dxf,HingeSetting
from app.structure import build_structure,StructureSpec,export_dxf as standard,pose

def main():
 out=ROOT/'tests/fixtures';out.mkdir(exist_ok=True)
 cases=[]
 for kind in ('tuck','hinged'):
  raw=standard(build_structure(StructureSpec(kind=kind,length=100,width=65,height=30 if kind=='hinged' else 140)))
  (ROOT/'examples/dxf'/f'{kind}.dxf').write_text(raw)
  d=CadDocument.model_validate(parse_dxf(ImportRequest(filename=kind+'.dxf',data=base64.b64encode(raw.encode()).decode()))['document'])
  a=analyze(d)
  for h in a['hinges']:d.hinges[h['id']]=HingeSetting(angle=h['angle'],openAngle=-h['angle']*.6,stage=h['stage'],confirmed=True)
  model=analyze(d)['model'];cases.append({'name':kind,'model':model,'poses':[{'fold':f,'opening':o,'expected':pose(model,f,o)['panels']} for f,o in [(0,0),(.4,0),(1,0),(1,.6)]]})
  (ROOT/'examples/dxf'/f'{kind}-project.json').write_text(d.model_dump_json(indent=2))
 points=[(0,0),(100,0),(100,100),(0,100)];paths=[CadPath(id=f'p{i}',type='LINE',role='cut',a=a,b=b) for i,(a,b) in enumerate(zip(points,points[1:]+points[:1]))]
 d=CadDocument(name='Circle cutout',paths=paths+[CadPath(id='hole',type='CIRCLE',role='cut',center=(50,50),radius=20)])
 (ROOT/'examples/dxf/circle-cutout.dxf').write_text(export_dxf(d));model=analyze(d)['model'];cases.append({'name':'hole','model':model,'poses':[{'fold':0,'opening':0,'expected':pose(model,0,0)['panels']}]})
 (out/'cad_mesh.json').write_text(json.dumps(cases))
if __name__=='__main__':main()
