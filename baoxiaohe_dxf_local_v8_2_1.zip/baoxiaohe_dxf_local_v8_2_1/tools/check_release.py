"""Local readiness check. Test success never implies original-site parity."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import httpx

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',default='http://127.0.0.1:8088')
    parser.add_argument('--output')
    args=parser.parse_args()
    try:
        response=httpx.get(args.base.rstrip('/')+'/api/readiness',timeout=10)
        response.raise_for_status();report=response.json()
    except Exception as exc:
        report={'production_ready':False,'parity_verified':False,'blockers':['Readiness endpoint unavailable: '+str(exc)]}
    report['release_decision']='PASS' if report.get('production_ready') is True and report.get('parity_verified') is True and not report.get('blockers') else 'BLOCKED'
    text=json.dumps(report,ensure_ascii=False,indent=2)
    print(text)
    if args.output:Path(args.output).write_text(text+'\n',encoding='utf-8')
    return 0 if report['release_decision']=='PASS' else 2
if __name__=='__main__':sys.exit(main())
