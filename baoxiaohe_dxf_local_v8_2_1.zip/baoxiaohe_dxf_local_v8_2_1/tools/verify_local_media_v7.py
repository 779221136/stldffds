"""Actual localhost HTTP worker and media verification. No external services."""
import base64,json,time,subprocess,sys,argparse
from io import BytesIO
from pathlib import Path
import httpx
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/v7';OUT.mkdir(exist_ok=True)
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--base',default='http://127.0.0.1:8088');args=parser.parse_args();client=httpx.Client(base_url=args.base,timeout=30)
client.get('/api/local/capabilities').raise_for_status()
canvas=Image.new('RGB',(512,340),'#f4f1e9');draw=ImageDraw.Draw(canvas)
draw.rectangle((0,0,512,44),fill='#16394e');draw.text((145,130),'LOCAL PACKAGING',fill='#16394e',font_size=25)
draw.text((166,175),'STRUCTURE / V7',fill='#16394e',font_size=20)
out=BytesIO();canvas.save(out,format='PNG');src='data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()
results=[]
for fmt,name,opts in [('png','render-4k-landscape.png',{'long_edge':4096,'aspect':'16:9','view':{'opening':.7,'transparent':True}}),('png','render-4k-portrait.png',{'long_edge':4096,'aspect':'9:16','view':{'opening':.7,'transparent':True}}),('mp4','opening-local.mp4',{'long_edge':512,'seconds':3,'fps':12}),('webm','folding-local.webm',{'long_edge':512,'seconds':3,'fps':12,'motion':'fold'})]:
    payload={'spec':{'kind':'hinged','height':35},'textures':{'lid':src,'front':src},'format':fmt,**opts}
    t=time.monotonic();r=client.post('/api/local/jobs',json=payload);r.raise_for_status();jid=r.json()['id'];states=[]
    while time.monotonic()-t<180:
        job=client.get('/api/local/jobs/'+jid).json();states.append((job['status'],job['progress']))
        if job['status'] not in {'queued','running'}:break
        time.sleep(.25)
    assert job['status']=='succeeded',job
    content=client.get(job['download']);content.raise_for_status();path=OUT/name;path.write_bytes(content.content)
    result={'file':name,'format':fmt,'bytes':len(content.content),'elapsed_seconds':round(time.monotonic()-t,2),'progress_states':states}
    if fmt=='png':
        with Image.open(path) as im:
            result['size']=list(im.size);result['alpha_extrema']=im.getextrema()[3]
            assert im.size==((4096,2304) if 'landscape' in name else (2304,4096));assert im.getextrema()[3]==(0,255)
    else:
        p=subprocess.run(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=codec_name,width,height,nb_read_frames','-of','json',str(path)],check=True,capture_output=True,text=True)
        result['probe']=json.loads(p.stdout)['streams'][0];assert int(result['probe']['nb_read_frames'])==36
        # Decode the first and last frames and verify that this is actual animation.
        frames=[]
        for at in (0,2.9):
            p=subprocess.run(['ffmpeg','-v','error','-ss',str(at),'-i',str(path),'-frames:v','1','-f','image2pipe','-vcodec','png','-'],check=True,capture_output=True)
            frames.append(p.stdout)
        assert frames[0]!=frames[1] and len(frames[0])>1000
        result['first_last_frames_differ']=True
    results.append(result);print(name,result['bytes'],result['elapsed_seconds'])
(OUT/'media-report.json').write_text(json.dumps(results,indent=2))
