#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
from html import escape
import math
import os
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageChops, ImageStat
from playwright.async_api import async_playwright

DEFAULT_ROUTES = [
    "/introduction",
    "/templates",
    "/models",
    "/templates/25987",
    "/models/74",
    "/member",
    "/login",
    "/print",
]
DEFAULT_VIEWPORTS = [(1440, 1100), (1920, 1200), (390, 844)]


def slug(route: str) -> str:
    s = route.strip("/").replace("/", "__") or "home"
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in s)


def compare_images(a_path: Path, b_path: Path, out_path: Path) -> dict:
    a = Image.open(a_path).convert("RGB")
    b = Image.open(b_path).convert("RGB")
    width = max(a.width, b.width)
    height = max(a.height, b.height)
    canvas_a = Image.new("RGB", (width, height), "white")
    canvas_b = Image.new("RGB", (width, height), "white")
    canvas_a.paste(a, (0, 0))
    canvas_b.paste(b, (0, 0))
    diff = ImageChops.difference(canvas_a, canvas_b)
    diff.save(out_path)

    stat = ImageStat.Stat(diff)
    rms = math.sqrt(sum(v * v for v in stat.rms[:3]) / 3.0)
    bbox = diff.getbbox()  # RGB only: RGBA zero-alpha deltas can hide all differences.
    nonzero = 0
    if bbox:
        # Count pixels with meaningful RGB difference; alpha is ignored.
        rgb = diff.convert("RGB")
        pixels = rgb.get_flattened_data() if hasattr(rgb, "get_flattened_data") else rgb.getdata()
        nonzero = sum(1 for px in pixels if max(px) > 8)
    total = width * height
    return {
        "width": width,
        "height": height,
        "rms": round(rms, 4),
        "different_pixels": nonzero,
        "different_percent": round((nonzero / total) * 100.0, 4) if total else 0,
    }


async def capture(base: str, routes: Iterable[str], viewports: Iterable[tuple[int, int]], out_dir: Path, label: str, wait_ms: int) -> list[dict]:
    results = []
    async with async_playwright() as p:
        launch_args = {'headless': True}
        chromium_path = os.environ.get('CHROMIUM_PATH')
        if chromium_path:
            launch_args['executable_path'] = chromium_path
        elif Path('/usr/bin/chromium').exists():
            launch_args['executable_path'] = '/usr/bin/chromium'
        browser = await p.chromium.launch(**launch_args)
        context = await browser.new_context(locale="zh-CN", color_scheme="light", device_scale_factor=1)
        page = await context.new_page()
        for route in routes:
            for width, height in viewports:
                await page.set_viewport_size({"width": width, "height": height})
                url = base.rstrip("/") + route
                item = {"route": route, "viewport": [width, height], "url": url, "label": label}
                try:
                    response = await page.goto(url, wait_until="domcontentloaded", timeout=45000)
                    try:
                        await page.wait_for_load_state("networkidle", timeout=15000)
                    except Exception:
                        pass
                    await page.wait_for_timeout(wait_ms)
                    # Hide carets / transient focus effects to stabilize diffs.
                    await page.evaluate("document.activeElement && document.activeElement.blur && document.activeElement.blur()")
                    path = out_dir / f"{label}__{slug(route)}__{width}x{height}.png"
                    await page.screenshot(path=str(path), full_page=True, animations="disabled")
                    body = (await page.locator("body").inner_text()).strip()
                    invalid = capture_problem(page.url, response.status if response else None, body)
                    item.update({"ok": not invalid, "status": response.status if response else None, "screenshot": str(path)})
                    if invalid:
                        item["error"] = invalid
                except Exception as exc:
                    item.update({"ok": False, "error": str(exc)})
                results.append(item)
        await browser.close()
    return results


def capture_problem(url: str, status: int | None, body: str) -> str | None:
    if not url.startswith(("http://", "https://")):
        return "Invalid browser page; visual match is unverified"
    if status is None or status >= 400:
        return f"HTTP {status}; visual match is unverified"
    normalized = body.strip().lower()
    if len(normalized) < 100 and (not normalized or normalized in {"loading...", "loading", "loading\u2026"}):
        return "SPA content did not load; visual match is unverified"
    if any(s in normalized for s in ["err_blocked_by_administrator", "your organization doesn", "access denied", "verify you are human"]):
        return "Blocked or challenge page; visual match is unverified"
    return None


def render_html(report: dict, out_file: Path) -> None:
    rows = []
    for item in report["comparisons"]:
        if not item.get("ok"):
            rows.append(f"<tr><td>{escape(item['route'])}</td><td>{item['viewport']}</td><td colspan=4>UNVERIFIED: {escape(str(item.get('error')))}</td></tr>")
            continue
        rows.append(
            "<tr>"
            f"<td>{escape(item['route'])}</td>"
            f"<td>{item['viewport'][0]}x{item['viewport'][1]}</td>"
            f"<td>{item['different_percent']:.4f}%</td>"
            f"<td>{item['rms']:.4f}</td>"
            f"<td><a href='{Path(item['reference']).name}'>reference</a></td>"
            f"<td><a href='{Path(item['candidate']).name}'>candidate</a> · <a href='{Path(item['diff']).name}'>diff</a></td>"
            "</tr>"
        )
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>Visual regression</title>
<style>body{{font-family:Arial,sans-serif;padding:30px;color:#222}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #ddd;padding:8px;text-align:left}}th{{background:#f5f5f5}}code{{background:#f5f5f5;padding:2px 5px}}</style></head><body>
<h1>包小盒 1:1 视觉回归报告</h1>
<p>Reference: <code>{escape(report['reference_base'])}</code><br>Candidate: <code>{escape(report['candidate_base'])}</code></p>
<table><thead><tr><th>Route</th><th>Viewport</th><th>Different pixels</th><th>RMS</th><th>Reference</th><th>Candidate / Diff</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
</body></html>"""
    out_file.write_text(html, "utf-8")


async def main_async(args):
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    routes = args.routes or DEFAULT_ROUTES
    viewports = []
    for value in args.viewport:
        w, h = value.lower().split("x", 1)
        viewports.append((int(w), int(h)))
    if not viewports:
        viewports = DEFAULT_VIEWPORTS

    refs = await capture(args.reference, routes, viewports, out, "reference", args.wait_ms)
    cands = await capture(args.candidate, routes, viewports, out, "candidate", args.wait_ms)
    lookup = {(x["route"], tuple(x["viewport"])): x for x in cands}
    comparisons = []
    for ref in refs:
        key = (ref["route"], tuple(ref["viewport"]))
        cand = lookup.get(key)
        if not ref.get("ok") or not cand or not cand.get("ok"):
            comparisons.append({"route": ref["route"], "viewport": ref["viewport"], "ok": False, "error": (ref.get("error") or (cand or {}).get("error") or "capture failed")})
            continue
        diff_path = out / f"diff__{slug(ref['route'])}__{ref['viewport'][0]}x{ref['viewport'][1]}.png"
        metrics = compare_images(Path(ref["screenshot"]), Path(cand["screenshot"]), diff_path)
        comparisons.append({
            "route": ref["route"],
            "viewport": ref["viewport"],
            "ok": True,
            "reference": ref["screenshot"],
            "candidate": cand["screenshot"],
            "diff": str(diff_path),
            **metrics,
        })

    report = {
        "reference_base": args.reference,
        "candidate_base": args.candidate,
        "routes": routes,
        "viewports": viewports,
        "comparisons": comparisons,
    }
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), "utf-8")
    render_html(report, out / "report.html")
    print(out / "report.html")


def main():
    parser = argparse.ArgumentParser(description="Capture and pixel-compare the public BaoXiaoHe site with the local clone.")
    parser.add_argument("--reference", default="https://www.baoxiaohe.com")
    parser.add_argument("--candidate", default="http://127.0.0.1:8088")
    parser.add_argument("--output", default="visual-report")
    parser.add_argument("--routes", nargs="*")
    parser.add_argument("--viewport", action="append", default=[], help="Example: 1440x1100 (repeatable)")
    parser.add_argument("--wait-ms", type=int, default=1800, help="Extra wait after network idle for SPA rendering")
    args = parser.parse_args()
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
