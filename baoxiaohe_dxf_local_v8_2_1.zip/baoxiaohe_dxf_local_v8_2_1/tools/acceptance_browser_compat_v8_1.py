"""Scoped compatibility checks using authored UI + in-process API, not native OS E2E.
No policy bypass, no external website, no live credentials, no persistent user data.
"""
from pathlib import Path
import asyncio,base64,json,os,sys,tempfile,traceback
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
os.environ['ENV']='test'
OUT=ROOT/'evidence/browser_compat_v8_1';OUT.mkdir(parents=True,exist_ok=True)
os.environ['AUDIT_OUTPUT']=str(OUT/'harness')
from fastapi.testclient import TestClient
from playwright.async_api import async_playwright
from tools.component_harness_v6 import boot
import app.main as main

async def run():
 checks=[];metadata={};errors=[]
 def ok(name,value=True,detail=None):
  item={'name':name,'passed':bool(value),'detail':detail};checks.append(item);print(json.dumps(item,ensure_ascii=True),flush=True);assert value,name
 async def sample(page):
  await page.locator('[data-example]').click();await page.locator('[data-parse]').click();await page.locator('[data-import-confirm]').wait_for(timeout=30000)
  await page.locator('[data-import-confirm]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden",timeout=30000)
 def count_models(client):return client.get('/api/local/cad/library').json()['total']
 with tempfile.TemporaryDirectory(prefix='bxh-compat-test-') as td:
  main.DB_PATH=Path(td)/'test.db'
  with TestClient(main.app) as client:
   async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=None
    try:
     page,errors=await boot(browser,'/cad',viewport={'width':1440,'height':900},client=client);page.set_default_timeout(12000)
     metadata['engine']=browser.version;metadata['os']=sys.platform
     metadata['capabilities']=await page.evaluate("()=>({webgl:!!document.createElement('canvas').getContext('webgl'),mediaTypes:['video/webm;codecs=vp8','video/mp4;codecs=avc1.42E01E','video/mp4'].map(t=>[t,typeof MediaRecorder==='function'&&MediaRecorder.isTypeSupported(t)])})")
     await sample(page);ok('Existing DXF parsing and folding still loads 13 panels','13' in await page.locator('[data-summary]').inner_text())
     for kind in ['text','shape','shape']:await page.locator('[data-add="'+kind+'"]').click()
     n=await page.locator('[data-layer-row]').count();ok('Three editable layers created',n==3)
     before=await page.locator('svg.packaging-svg .art-object').evaluate_all('(es)=>es.map(e=>e.outerHTML)')
     await page.locator('[data-export]').click()
     for key in ['Delete','Backspace','Control+z','Control+y','Control+d','ArrowLeft','Meta+z']:
      await page.keyboard.press(key)
      now=await page.locator('svg.packaging-svg .art-object').evaluate_all('(es)=>es.map(e=>e.outerHTML)')
      ok('CAD modal isolates '+key,now==before and await page.locator('.cad-modal-backdrop').count()==1)
     await page.keyboard.press('Shift+Tab');ok('Modal Shift+Tab stays within dialog',await page.evaluate("()=>!!document.activeElement.closest('.cad-modal-backdrop')"))
     await page.keyboard.press('Tab');ok('Modal Tab cycles back to close control',await page.locator('[data-modal-close]').evaluate('(e)=>document.activeElement===e'))
     await page.locator('[data-modal-close]').dispatch_event('keydown',{'key':'Escape','isComposing':True,'keyCode':229})
     ok('IME Escape does not close modal',await page.locator('.cad-modal-backdrop').count()==1)
     await page.screenshot(path=str(OUT/'cad-modal-protected.png'))
     await page.keyboard.press('Escape');ok('Escape closes modal without changing layers',await page.locator('.cad-modal-backdrop').count()==0 and await page.locator('[data-layer-row]').count()==n)
     ok('Modal restores focus to export button',await page.locator('[data-export]').evaluate('(e)=>document.activeElement===e'))
     # Normal canvas deletion still works after closing a modal.
     await page.locator('svg.packaging-svg').focus();await page.keyboard.press('Delete');ok('Canvas Delete works outside modal',await page.locator('[data-layer-row]').count()==n-1)
     await page.keyboard.press('Control+z');ok('Canvas undo restores deleted layer',await page.locator('[data-layer-row]').count()==n)
     for modifier in ['ctrlKey','metaKey']:
      result=await page.evaluate('''(key)=>{const e=new KeyboardEvent('keydown',{key:'s',bubbles:true,cancelable:true,[key]:true});window.dispatchEvent(e);return{prevented:e.defaultPrevented,open:!!document.querySelector('[data-confirm-save]')};}''',modifier)
      ok('CAD '+modifier+'+S opens existing save dialog',result['prevented'] and result['open'])
      await page.keyboard.press('Control+s');ok('Repeated save while modal is open does not nest',await page.locator('.cad-modal-backdrop').count()==1)
      await page.locator('[data-save-name]').fill('\u517c\u5bb9\u6027-\u6d4b\u8bd5');await page.locator('[data-confirm-save]').click();await page.wait_for_function("!document.querySelector('.cad-modal-backdrop')")
     ok('Save keys update one local record rather than creating duplicates',count_models(client)==1)
     record=client.get('/api/local/cad/library').json()['items'][0];ok('Saved model name retains Unicode',record['name']=='\u517c\u5bb9\u6027-\u6d4b\u8bd5')
     # Ctrl+S must commit the current text input before opening the save dialog.
     await page.locator('[data-layer-select]').last.click();await page.locator('[data-right-tab="object"]').click()
     await page.locator('[data-obj="text"]').fill('IME-safe pending edit')
     await page.keyboard.press('Control+s');await page.locator('[data-confirm-save]').click();await page.wait_for_function("!document.querySelector('.cad-modal-backdrop')")
     saved=client.get('/api/local/cad/library/'+record['id']).json();ok('Focused text edit is included when saving by shortcut',saved['document']['objects'][0]['text']=='IME-safe pending edit')
     compose=await page.evaluate('''()=>{const result=[];for(const key of ['Delete','Backspace','z','s']){const e=new KeyboardEvent('keydown',{key,ctrlKey:['z','s'].includes(key),bubbles:true,cancelable:true,isComposing:true,keyCode:229});window.dispatchEvent(e);result.push(e.defaultPrevented);}return result;}''')
     ok('Composing keys do not trigger global editing or save',not any(compose) and await page.locator('.cad-modal-backdrop').count()==0)
     # Image validation: same bytes, varied metadata, and hostile/invalid inputs.
     image_results=await page.evaluate('''async()=>{
       const c=document.createElement('canvas');c.width=c.height=4;c.getContext('2d').fillRect(0,0,4,4);
       const png=await new Promise(r=>c.toBlob(r,'image/png')),jpg=await new Promise(r=>c.toBlob(r,'image/jpeg'));
       const tests=[['PNG normal',png,'image/png','a.png',true],['PNG empty MIME',png,'','\u56fe\u7247.PNG',true],['PNG generic MIME',png,'application/octet-stream','a.png',true],['PNG misleading MIME',png,'image/jpeg','a.jpg',true],['JPEG empty MIME',jpg,'','\u56fe\u7247.JPG',true],['Fake PNG',new Blob(['<html>not image</html>']),'image/png','a.png',false],['Truncated PNG',new Blob([new Uint8Array([137,80,78,71,13,10,26,10])]),'image/png','a.png',false],['Safe SVG missing MIME',new Blob(['<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4"/></svg>']),'','a.SVG',true],['Script SVG',new Blob(['<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>']),'','a.svg',false],['External SVG',new Blob(['<svg xmlns="http://www.w3.org/2000/svg"><use href="https://example.com/x"/></svg>']),'image/svg+xml','a.svg',false],['Oversized image',new Blob([new Uint8Array(6*1024*1024)]),'image/png','a.png',false]];
       const results=[];for(const [name,blob,type,fileName,expected] of tests){try{const x=await __modules['artwork.js'].fileToImage(new File([blob],fileName,{type}));results.push({name,ok:expected,srcType:x.src.slice(0,30),width:x.width});}catch(e){results.push({name,ok:!expected,error:e.message});}}return results;
     }''')
     for r in image_results:ok(r['name'],r['ok'],r)
     from PIL import Image
     from io import BytesIO
     data=BytesIO();Image.new('RGB',(4,4),(10,70,200)).save(data,format='PNG')
     await page.locator('[data-image]').set_input_files({'name':'\u6807\u7b7e.PNG','mimeType':'','buffer':data.getvalue()});await page.wait_for_timeout(500)
     ok('Real CAD file-input path accepts empty-MIME PNG',await page.locator('[data-layer-row]').count()==n+1)
     wheel=await page.evaluate('''()=>{const host=document.createElement('div');host.style.cssText='width:320px;height:240px;line-height:16px';document.body.append(host);let last;const r=__modules['structure_renderer.js'].createStructureRenderer(host,v=>last=v);const vals=[];try{for(const [mode,delta] of [[0,16],[1,1],[2,16/(r.canvas.clientHeight||800)]]){r.setView({zoom:1});r.canvas.dispatchEvent(new WheelEvent('wheel',{deltaMode:mode,deltaY:delta,cancelable:true}));vals.push(last.zoom);}return vals;}finally{r.destroy();host.remove();}}''')
     ok('Actual structure preview wheel handler normalizes pixel/line/page input',max(wheel)-min(wheel)<1e-10,wheel)
     await page.screenshot(path=str(OUT/'cad-editor-compat.png'))
     # Startup gate executes without modern clone and blocks module loading.
     gp=await browser.new_page();await gp.set_content('<div id="app"></div>');await gp.evaluate('window.structuredClone=undefined')
     await gp.add_script_tag(content=(ROOT/'src/browser_bootstrap.js').read_text(encoding='utf-8'))
     ok('Browser with missing clone gets clear startup diagnostic',await gp.locator('#browser-compatibility-message').count()==1 and await gp.locator('script[type="module"]').count()==0)
     await gp.screenshot(path=str(OUT/'unsupported-browser-message.png'));await gp.close()
     # Remove CAD mount and confirm save listener is released.
     await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(350)
     cleared=await page.evaluate("()=>{const e=new KeyboardEvent('keydown',{key:'s',ctrlKey:true,cancelable:true,bubbles:true});window.dispatchEvent(e);return !e.defaultPrevented&&!document.querySelector('.cad-modal-backdrop');}")
     ok('CAD save listener removed when leaving the route',cleared)
     await page.evaluate("__navigate('/design/template/25987')");await page.locator('#exportDesign').wait_for();await page.wait_for_timeout(300)
     nb=await page.locator('[data-layer-row]').count();await page.locator('[data-layer-select]').first.click();await page.locator('#exportDesign').click();await page.keyboard.press('Delete')
     ok('Original template editor export dialog also protects layers',await page.locator('[data-layer-row]').count()==nb)
     await page.keyboard.press('Escape');ok('Original template editor modal closes with Escape',await page.locator('.app-modal-backdrop').count()==0)
     # Actual native encoder output for Canvas preview.
     media=await page.evaluate('''async()=>{const host=document.createElement('div');host.style.cssText='width:320px;height:240px';document.body.append(host);const r=__modules['canvas_renderer.js'].createBoxCanvasRenderer({mount:host});try{await r.ready();const blob=await r.recordVideo(1);const bytes=new Uint8Array(await blob.arrayBuffer());let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return{type:blob.type,size:blob.size,extension:__modules['browser_compat.js'].videoExtension(blob),bytes:btoa(s)};}finally{r.destroy();host.remove();}}''')
     (OUT/('actual-rotation.'+media['extension'])).write_bytes(base64.b64decode(media.pop('bytes')))
     ok('Real browser encoder produces a video with matching MIME and extension',media['size']>500,media)
     # Force MP4-only advertised capabilities. Real bytes if native MP4 is supported;
     # otherwise use an explicitly labelled encoder stub to test fallback/control flow only.
     mp4=await page.evaluate('''async()=>{const Native=window.MediaRecorder;const actual=Native.isTypeSupported('video/mp4')||Native.isTypeSupported('video/mp4;codecs=avc1.42E01E');let used=[];
      class Stub {static isTypeSupported(t){return t==='video/mp4';}constructor(s,o){this.mimeType=o.mimeType;this.state='inactive';used.push(o.mimeType);}start(){this.state='recording';setTimeout(()=>this.onstart?.(),10);}stop(){if(this.state==='inactive')return;this.state='inactive';this.ondataavailable?.({data:new Blob([new Uint8Array(2048)],{type:this.mimeType})});this.onstop?.();}}
      class OnlyMP4 extends Native{static isTypeSupported(t){return t.startsWith('video/mp4')&&Native.isTypeSupported(t);}constructor(s,o){super(s,o);used.push(o.mimeType);}}
      window.MediaRecorder=actual?OnlyMP4:Stub;
      const host=document.createElement('div');host.style.cssText='width:320px;height:240px';document.body.append(host);const r=__modules['canvas_renderer.js'].createBoxCanvasRenderer({mount:host});
      try{await r.ready();const blob=await r.recordVideo(1);let bytes=null;if(actual){const b=new Uint8Array(await blob.arrayBuffer());let s='';for(let i=0;i<b.length;i+=32768)s+=String.fromCharCode(...b.subarray(i,i+32768));bytes=btoa(s);}return{actualEncoded:actual,used,type:blob.type,extension:__modules['browser_compat.js'].videoExtension(blob),bytes};}finally{window.MediaRecorder=Native;r.destroy();host.remove();}}''')
     b=mp4.pop('bytes');
     if b:(OUT/'actual-mp4-only.mp4').write_bytes(base64.b64decode(b))
     ok('MP4-only capability path chooses MP4 and preserves its extension',mp4['extension']=='mp4',mp4)
     # Opening path and main UI filename, using real native encoder where available.
     await page.evaluate("__navigate('/render/template/25987')");await page.locator('#openingAnimation').wait_for();await page.wait_for_timeout(450)
     await page.locator('#openingAnimation').click();await page.wait_for_timeout(3500)
     actual_mp4=mp4['actualEncoded']
     await page.evaluate('''()=>{window.__nativeRecorder=window.MediaRecorder;const Native=window.MediaRecorder;class Stub {static isTypeSupported(t){return t==='video/mp4';}constructor(s,o){this.mimeType=o.mimeType;this.state='inactive';}start(){this.state='recording';setTimeout(()=>this.onstart?.(),10);}stop(){if(this.state==='inactive')return;this.state='inactive';this.ondataavailable?.({data:new Blob([new Uint8Array(2048)],{type:this.mimeType})});this.onstop?.();}}class MP4Only extends Native{static isTypeSupported(t){return t.startsWith('video/mp4')&&Native.isTypeSupported(t);}}window.MediaRecorder=Native.isTypeSupported('video/mp4')||Native.isTypeSupported('video/mp4;codecs=avc1.42E01E')?MP4Only:Stub;}''')
     async with page.expect_download(timeout=30000) as ev:await page.locator('#exportVideo').click()
     dl=await ev.value
     ok('Opening export UI downloads .mp4 in MP4-only mode',dl.suggested_filename.endswith('.mp4'),{'name':dl.suggested_filename,'real_encoder':actual_mp4})
     if actual_mp4:await dl.save_as(OUT/'actual-opening.mp4')
     await page.evaluate('window.MediaRecorder=window.__nativeRecorder;delete window.__nativeRecorder')
     await page.screenshot(path=str(OUT/'opening-video-export.png'))
     ok('No uncaught JavaScript errors',not errors,errors)
    except Exception as exc:
     metadata['failure']=repr(exc);metadata['traceback']=traceback.format_exc();print(metadata['traceback'],flush=True)
     if page:
      try:await page.screenshot(path=str(OUT/'failure.png'),timeout=5000)
      except Exception:pass
     raise
    finally:
     if page:await page.close()
     await browser.close()
     (OUT/'browser_checks.json').write_text(json.dumps({'scope':'Linux Chromium authored-code components + in-process FastAPI, not Mac/Windows/Safari/GPU or native URL E2E. Capability simulations labelled per check.','metadata':metadata,'passed':sum(c['passed'] for c in checks),'checks':checks,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':asyncio.run(run())
