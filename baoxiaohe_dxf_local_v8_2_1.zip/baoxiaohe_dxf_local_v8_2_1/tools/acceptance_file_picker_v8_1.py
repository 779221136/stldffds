"""Filechooser boundary checks on authored components, not native Windows dialogs.
Uses genuine Chromium filechooser events and local filesystem fixtures.
Does not connect to the user's computer or the original website.
"""
import sys,os,asyncio,json,tempfile,traceback
from pathlib import Path
from io import BytesIO
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));os.environ['ENV']='test'
from playwright.async_api import async_playwright
from fastapi.testclient import TestClient
from tools.component_harness_v6 import boot
from PIL import Image
import app.main as main
OUT=ROOT/'evidence/browser_compat_v8_1/pickers';OUT.mkdir(parents=True,exist_ok=True)
async def run():
 checks=[];errors=[];metadata={}
 def ok(name,yes,detail=None):
  checks.append({'name':name,'passed':bool(yes),'detail':detail});print(json.dumps(checks[-1],ensure_ascii=True),flush=True);assert yes,name
 with tempfile.TemporaryDirectory(prefix='bxh-picker-test-') as d:
  td=Path(d);main.DB_PATH=td/'app.db'
  fixture=td/'\u5200\u6a21 \u4e2d\u6587.DXF';fixture.write_bytes((ROOT/'examples/dxf/tuck.dxf').read_bytes())
  png=td/'\u56fe\u7247 \u4e2d\u6587.PNG';Image.new('RGB',(8,8),(180,80,30)).save(png,format='PNG')
  bad=td/'bad.png';bad.write_bytes(b'not an image')
  with TestClient(main.app) as client:
   async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page,errors=await boot(browser,'/cad',client=client);page.set_default_timeout(10000)
    metadata={'engine':browser.version,'os':sys.platform,'boundary':'Chromium filechooser interception (no OS-native dialog UI)'}
    chooser_count=[];page.on('filechooser',lambda f:chooser_count.append(f))
    page.on('dialog',lambda d:d.accept())
    async def choose(selector,key=None):
     before=len(chooser_count)
     async with page.expect_file_chooser() as ev:
      if key:await page.locator(selector).press(key)
      else:await page.locator(selector).click()
     f=await ev.value
     ok('Exactly one connected picker: '+selector+(' '+key if key else ''),len(chooser_count)==before+1 and await f.element.evaluate('e=>e.isConnected'))
     return f
    async def cancel(f):
     # Test empty selection/cancel event paths. This does not operate an OS Cancel button.
     await f.set_files([])
     await f.element.dispatch_event('cancel')
     await page.wait_for_timeout(80)
    try:
     await page.locator('[data-empty-import]').click()
     f=await choose('[data-drop]');ok('DXF filter is extension-based',await f.element.get_attribute('accept')=='.dxf')
     await page.evaluate("window.__changes=0;document.querySelector('[data-file]').addEventListener('change',()=>window.__changes++);")
     await f.set_files(fixture);await page.wait_for_timeout(100)
     ok('Uppercase Chinese DXF filename accepted',await page.locator('[data-filename]').inner_text()==fixture.name)
     f=await choose('[data-drop]');await f.set_files(fixture);await page.wait_for_timeout(100)
     ok('Same file chosen twice triggers two changes',await page.evaluate('window.__changes')==2)
     f=await choose('[data-drop]',key='Enter');await cancel(f)
     f=await choose('[data-drop]',key='Space');await cancel(f)
     ok('Cancel leaves prior DXF selection and wizard intact',await page.locator('[data-filename]').inner_text()==fixture.name and await page.locator('.cad-modal-backdrop').count()==1)
     await page.locator('[data-parse]').click();await page.locator('[data-import-confirm]').wait_for(timeout=25000)
     await page.screenshot(path=str(OUT/'dxf-selected-and-parsed.png'))
     await page.locator('[data-import-confirm]').click();await page.wait_for_function("document.querySelector('[data-preview-block]').hidden",timeout=25000)
     ok('Actual selected DXF parsed into foldable model','13' in await page.locator('[data-summary]').inner_text())
     f=await choose('[data-add="image"]');accepted=await f.element.get_attribute('accept');ok('Image filter contains explicit extensions',all(e in accepted for e in ['.png','.jpg','.jpeg','.svg']))
     await f.set_files(png);await page.wait_for_function("document.querySelectorAll('[data-layer-row]').length===1")
     f=await choose('[data-add="image"]');await f.set_files(png);await page.wait_for_function("document.querySelectorAll('[data-layer-row]').length===2")
     ok('Repeat image selection inserts two independent layers',await page.locator('[data-layer-row]').count()==2)
     for _ in range(2):
      f=await choose('[data-add="image"]');await f.set_files(bad);await page.wait_for_timeout(150)
      ok('Failed image read leaves picker reset for retry',await page.locator('[data-image]').input_value()=='' and await page.locator('[data-layer-row]').count()==2)
     f=await choose('[data-add="image"]');await cancel(f)
     ok('Cancel image chooser never deletes existing layers',await page.locator('[data-layer-row]').count()==2)
     await page.locator('[data-export]').click()
     async with page.expect_download() as ev:await page.locator('[data-out="json"]').click()
     dl=await ev.value;project=td/'project.json';await dl.save_as(project);await page.locator('[data-modal-close]').click()
     await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(150);await page.evaluate("__navigate('/cad')");await page.locator('[data-json-open]').wait_for()
     f=await choose('[data-json-open]');await f.set_files(project)
     await page.wait_for_function("document.querySelector('[data-preview-block]').hidden",timeout=25000)
     ok('Mounted JSON selector reloads geometry and artwork',await page.locator('[data-layer-row]').count()==2)
     # Exercise click fallback without showPicker; no policy restrictions are disabled.
     await page.locator('[data-image]').evaluate('e=>e.showPicker=undefined')
     f=await choose('[data-add="image"]');await cancel(f)
     ok('Older-browser click fallback opens and returns safely',await page.locator('[data-layer-row]').count()==2)
     # Explicit rejection must show an error, with no synthetic retry.
     await page.locator('[data-image]').evaluate("e=>e.showPicker=()=>{throw new DOMException('test denial','NotAllowedError')}")
     before=len(chooser_count);await page.locator('[data-add="image"]').click();await page.wait_for_timeout(100)
     ok('Denied picker gives message without bypass/retry',len(chooser_count)==before and await page.locator('[data-message]').is_visible())
     await page.locator('[data-image]').evaluate('e=>delete e.showPicker')
     await page.screenshot(path=str(OUT/'picker-error-message.png'))
     await page.evaluate("__navigate('/design/template/25987')");await page.locator('[data-ed-tool="image"]').wait_for();n=await page.locator('[data-layer-row]').count()
     f=await choose('[data-ed-tool="image"]',key='Enter');await f.set_files(png);await page.wait_for_timeout(250)
     ok('Original editor keyboard upload adds image',await page.locator('[data-layer-row]').count()==n+1)
     f=await choose('[data-ed-tool="image"]');await cancel(f);ok('Original editor cancel is a no-op',await page.locator('[data-layer-row]').count()==n+1)
     await page.evaluate("__navigate('/render/template/25987')");await page.locator('#uploadBg').wait_for();await page.wait_for_timeout(200)
     f=await choose('#uploadBg');await f.set_files(png);await page.wait_for_timeout(200)
     f=await choose('#uploadBg');await cancel(f);ok('Background picker can reopen after a selection',await page.locator('#bgFile').input_value()=='')
     await page.evaluate("__navigate('/structure')");await page.locator('#textureUpload').wait_for();await page.wait_for_timeout(500)
     f=await choose('#textureUpload');await f.set_files(png);await page.wait_for_timeout(250)
     f=await choose('#textureUpload');await cancel(f)
     ok('Structure texture selector handles cancel/retry',await page.locator('#textureFile').input_value()=='')
     f=await choose('#projectOpen');await cancel(f)
     ok('Structure JSON selector handles empty selection',await page.locator('#projectFile').input_value()=='')
     await page.screenshot(path=str(OUT/'structure-upload-controls.png'))
     ok('No uncaught page exceptions',not errors,errors)
    except Exception as e:
     metadata['failure']=str(e);metadata['traceback']=traceback.format_exc();print(metadata['traceback'],flush=True)
     await page.screenshot(path=str(OUT/'failure.png'));raise
    finally:
     (OUT/'checks.json').write_text(json.dumps({'scope':'Local authored UI + in-process API; no Windows/macOS native shell tested. No fake User-Agent used.','metadata':metadata,'passed':sum(c['passed'] for c in checks),'checks':checks,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
     await page.close();await browser.close()
if __name__=='__main__':asyncio.run(run())
