"""Scoped authored components + in-process API; NOT native OS/GPU/URL E2E."""
import sys,os,json,time,asyncio,tempfile,copy,threading
from io import StringIO
from pathlib import Path
import ezdxf
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
OUT=ROOT/'evidence/fixes_v8_2/browser';OUT.mkdir(parents=True,exist_ok=True)
from fastapi.testclient import TestClient
from playwright.async_api import async_playwright
from tools.component_harness_v6 import boot
import app.main as main

def fixture(w=60):
 d=ezdxf.new('R2010');d.units=4;m=d.modelspace();m.add_lwpolyline([(0,0),(w,0),(w,40),(0,40)],close=True,dxfattribs={'layer':'CUT','color':5});m.add_line((w/2,0),(w/2,40),dxfattribs={'layer':'CREASE','color':1});s=StringIO();d.write(s);return s.getvalue().encode()

async def run():
 checks=[];allerrors=[];measurements=[]
 def ok(name,value=True,detail=None):
  checks.append({'name':name,'passed':bool(value),'detail':detail});print(name,bool(value),flush=True);assert value,(name,detail)
 os.environ['ENV']='test'
 with tempfile.TemporaryDirectory() as td:
  main.DB_PATH=Path(td)/'test.db'
  with TestClient(main.app) as client:
   orig=client.request;captured=[];delay=False;delay_confirm=False;started=threading.Event();confirm_started=threading.Event()
   def request(method,url,**kw):
    body=json.loads(kw['content']) if kw.get('content') else kw.get('json')
    if method.upper() in ('POST','PUT'):captured.append((str(url),copy.deepcopy(body)))
    if str(url)=='/api/local/cad/import' and delay and body['filename'].startswith('A-'):started.set();time.sleep(1.2)
    if str(url)=='/api/local/cad/validate' and delay_confirm:confirm_started.set();time.sleep(.9)
    return orig(method,url,**kw)
   client.request=request
   async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=None
    async def new_page(route='/cad'):
     nonlocal page
     if page and not page.is_closed():await page.close()
     page,err=await boot(browser,route,client=client);allerrors.append(err);page.set_default_timeout(15000);page.on('dialog',lambda d:d.accept())
    async def select(data,name):
     async with page.expect_file_chooser() as event:await page.locator('[data-drop]').click()
     await (await event.value).set_files({'name':name,'mimeType':'','buffer':data})
    async def parse():
     await page.locator('[data-parse]').click();await page.locator('[data-import-confirm]').wait_for()
    async def confirm():
     await page.locator('[data-import-confirm]').click();await page.wait_for_function('document.querySelector("[data-preview-block]").hidden')
    async def save(name):
     await page.locator('[data-save]').click();await page.locator('[data-save-name]').fill(name);await page.locator('[data-confirm-save]').click();await page.wait_for_function('!document.querySelector(".cad-modal-backdrop")');return next(body['document'] for url,body in reversed(captured) if url.startswith('/api/local/cad/library'))
    async def wait_event(event):
     for _ in range(150):
      if event.is_set():return
      await page.wait_for_timeout(10)
     raise AssertionError('Controlled request did not start')
    async def size(selector):return await page.locator(selector).evaluate('(e)=>{let r=e.getBoundingClientRect();return {width:r.width,height:r.height,x:r.x,y:r.y}}')
    try:
     await new_page();await page.locator('[data-import]').click();await select(fixture(),'unit.DXF');await page.locator('[data-unit]').select_option('mm');await parse();await page.locator('[data-unit]').select_option('cm')
     ok('Changing units removes the stale confirm button',await page.locator('[data-import-confirm]').count()==0)
     await parse();await confirm();d=await save('unit-cm');ok('Reparse in cm saves 600 mm, not stale 60 mm',max(x['b'][0] for x in d['paths'])==600)
     await page.locator('[data-import]').click();await select(fixture(),'precision.dxf');await parse();await page.locator('[data-tolerance]').fill('.1');ok('Changing tolerance invalidates old result',await page.locator('[data-import-confirm]').count()==0)
     await parse();await confirm();d=await save('tolerance');ok('New tolerance actually saved',d['options']['curve_tolerance']==.1)
     await new_page();delay=True;started.clear();await page.locator('[data-import]').click();await select(fixture(),'A-60mm.dxf');await page.locator('[data-parse]').click();await wait_event(started)
     await select(fixture(90),'B-90mm.dxf');await parse();await page.wait_for_timeout(1450);ok('Slower A response does not overwrite B preview','B-90mm.dxf' in await page.locator('[data-import-state]').inner_text())
     await confirm();d=await save('latest-file');ok('Saved document uses latest file and dimensions',d['source_name']=='B-90mm.dxf' and max(x['b'][0] for x in d['paths'])==90);delay=False
     await page.locator('[data-import]').click();await select(fixture(),'confirm-race.dxf');await parse();delay_confirm=True;confirm_started.clear();await page.locator('[data-import-confirm]').click();await wait_event(confirm_started)
     await page.locator('[data-unit]').select_option('cm');await page.wait_for_timeout(1100);ok('Unit change during confirm cannot replace current document',await page.locator('.cad-modal-backdrop').count()==1 and await page.locator('[data-import-confirm]').count()==0)
     delay_confirm=False;await page.locator('[data-modal-close]').click()
     delay=True;started.clear();await page.locator('[data-import]').click();await select(fixture(),'A-close.dxf');await page.locator('[data-parse]').click();await wait_event(started);await page.locator('[data-modal-close]').click();await page.wait_for_timeout(1450)
     ok('Closed dialog ignores late parse completion',await page.locator('.cad-modal-backdrop').count()==0);delay=False
     await page.locator('[data-import]').click();await select((ROOT/'examples/dxf/tuck.dxf').read_bytes(),'tuck.dxf');await parse();await confirm()
     await page.locator('[data-add="text"]').click();await page.locator('[data-obj="text"]').fill('V8.2 LOCAL');await page.locator('[data-obj="text"]').press('Tab');await page.locator('[data-right-tab="params"]').click();await page.locator('[data-hopen]').fill('75');await page.locator('[data-happly]').click();await page.wait_for_function('!document.querySelector("[data-opening]").disabled')
     await page.locator('[data-fold]').fill('1');await page.locator('[data-fold]').dispatch_event('input');await page.wait_for_timeout(700)
     a=await page.locator('[data-render] canvas').evaluate('c=>c.toDataURL()');await page.locator('[data-opening]').fill('1');await page.locator('[data-opening]').dispatch_event('input');await page.wait_for_timeout(300);b=await page.locator('[data-render] canvas').evaluate('c=>c.toDataURL()')
     ok('Folded and opened frames really differ',a!=b);await page.screenshot(path=str(OUT/'cad-opened.png'));await page.locator('[data-opening]').fill('0');await page.locator('[data-opening]').dispatch_event('input')
     await page.locator('[data-format]').select_option('png');await page.locator('[data-edge]').select_option('4096');await page.locator('[data-transparent]').check();await page.locator('[data-format]').select_option('mp4')
     ok('4K PNG to MP4 clamps edge to 1024',await page.locator('[data-edge]').input_value()=='1024');ok('4K option disabled for animation',await page.locator('[data-edge] option[value="4096"]').evaluate('e=>e.disabled'));ok('MP4 transparent option disabled and unchecked',await page.locator('[data-transparent]').is_disabled() and not await page.locator('[data-transparent]').is_checked())
     await page.locator('[data-format]').select_option('webm');ok('WebM has identical quota guard',await page.locator('[data-transparent]').is_disabled());await page.locator('[data-format]').select_option('frames');await page.locator('[data-transparent]').check();ok('Transparent frame sequences still allowed',await page.locator('[data-transparent]').is_checked())
     await page.locator('[data-format]').select_option('png');ok('4K transparent PNG still selectable',await page.locator('[data-edge] option[value="4096"]').evaluate('e=>!e.disabled') and await page.locator('[data-transparent]').is_checked());await page.locator('[data-edge]').select_option('256');await page.locator('[data-submit]').click();await page.locator('[data-jobs] a[download]').first.wait_for(timeout=45000)
     href=await page.locator('[data-jobs] a[download]').first.get_attribute('href');data=client.get(href).content;ok('Actual PNG job downloads',data.startswith(b'\x89PNG'));(OUT/'cad-background.png').write_bytes(data)
     await save('reopen-history');mid=client.get('/api/local/cad/library?q=reopen-history').json()['items'][0]['id'];await new_page();await page.wait_for_function('document.querySelector("[data-jobs] a[download]")');ok('Jobs retrieved even before a document is loaded',await page.locator('[data-jobs] .cad-job').count()>0)
     await page.locator('[data-library]').click();await page.locator('[data-lib-load="'+mid+'"]').click();await page.wait_for_function('document.querySelector("[data-preview-block]").hidden');await page.locator('[data-jobs] a[download]').first.wait_for();ok('Saved model reopening displays completed render history')
     await page.locator('[data-refresh-jobs]').click();await page.locator('[data-jobs] a[download]').first.wait_for();ok('Manual task refresh retains downloadable results')
     await page.locator('[data-fold]').fill('1');await page.locator('[data-fold]').dispatch_event('input')
     await page.locator('.cad-right').evaluate('e=>e.scrollTop=0')
     baseline=os.environ.get('BASELINE_CSS')
     for w,h in [(1440,1000),(1366,768),(1920,1080),(390,844)]:
      await page.set_viewport_size({'width':w,'height':h})
      if w<780:await page.locator('[data-tab="preview"]').click()
      await page.locator('.cad-right').evaluate('e=>e.scrollTop=0');await page.wait_for_timeout(250);after=await size('[data-render]');before=None
      if baseline:
       tag=await page.add_style_tag(content=Path(baseline).read_text(encoding='utf-8'));await page.wait_for_timeout(150);before=await size('[data-render]');await tag.evaluate('e=>e.remove()');await page.wait_for_timeout(150)
       ok('CAD preview enlarged at '+str(w),after['height']>before['height'] and after['width']>=before['width'],{'before':before,'after':after})
      ok('No page overflow at '+str(w),await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'));ok('Top export accessible at '+str(w),await page.locator('[data-export]').is_visible() and (await size('[data-export]'))['x']<w)
      measurements.append({'route':'cad','viewport':[w,h],'before':before,'after':after})
      if w in (1440,390):await page.screenshot(path=str(OUT/('cad-'+str(w)+'.png')))
     for route,selector in [('/structure','.local-viewport'),('/design/template/25987','.v4-live-canvas'),('/render/template/25987','.webgl-mount')]:
      await new_page(route);await page.locator(selector).wait_for();await page.wait_for_timeout(500);after=await size(selector);before=None
      if baseline:
       tag=await page.add_style_tag(content=Path(baseline).read_text(encoding='utf-8'));await page.wait_for_timeout(150);before=await size(selector);await tag.evaluate('e=>e.remove()');await page.wait_for_timeout(150)
       ok('Preview enlarged: '+route,after['height']>=before['height'] and after['width']>=before['width'],{'before':before,'after':after})
      ok('Route has no page overflow: '+route,await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'));measurements.append({'route':route,'viewport':[1440,1000],'before':before,'after':after});await page.screenshot(path=str(OUT/(route.split('/')[1]+'-desktop.png')))
     ok('No uncaught JavaScript errors',not any(allerrors),allerrors)
    except Exception:
     if page and not page.is_closed():await page.screenshot(path=str(OUT/'failure.png'),full_page=True);print((await page.locator('body').inner_text())[-3500:],flush=True)
     raise
    finally:
     (OUT/'checks.json').write_text(json.dumps({'scope':__doc__,'checks':checks,'measurements':measurements,'errors':allerrors},indent=2),encoding='utf-8')
     if page and not page.is_closed():await page.close()
     await browser.close()
 print('PASSED',len(checks))
if __name__=='__main__':asyncio.run(run())
