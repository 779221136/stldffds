import asyncio,json,base64,os
from playwright.async_api import async_playwright
from offline_harness import boot,OUT

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page,api,errors=await boot(browser,'/render/template/25987')
  result=await page.evaluate('''async()=>{
    const mount=document.createElement('div');mount.style.cssText='height:400px;width:600px';document.body.append(mount);
    const r=__modules['canvas_renderer.js'].createBoxCanvasRenderer({mount});await r.ready();
    const outputs=[];
    for(let i=0;i<2;i++){const blob=await r.recordWebM(1);const b64=await new Promise(ok=>{const f=new FileReader();f.onload=()=>ok(f.result.split(',')[1]);f.readAsDataURL(blob);});outputs.push({size:blob.size,type:blob.type,data:b64});}
    r.destroy();mount.remove();return outputs;
  }''')
  report=[]
  for i,value in enumerate(result):
   data=base64.b64decode(value.pop('data'));(OUT/f'video-v5-{i}.webm').write_bytes(data)
   assert value['size']>500,value
   report.append(value)
  assert not errors,errors
  (OUT/'video-v5.json').write_text(json.dumps({'scope':'Two standalone Canvas 2D recording runs; not GPU or photorealistic rendering','results':report,'errors':errors},indent=2))
  print(report);await api.aclose();await browser.close()
if __name__=='__main__':asyncio.run(main())
