"""Offline authored-page + real in-process API regression; not native URL E2E."""
import asyncio,base64,json,os,sys,tempfile,subprocess,httpx
from pathlib import Path
from io import BytesIO
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from playwright.async_api import async_playwright
from fastapi.testclient import TestClient
from PIL import Image,ImageChops
from tools.component_harness_v6 import boot
import app.main as main
OUT=ROOT/'evidence/opening_fix';OUT.mkdir(parents=True,exist_ok=True)

async def run():
    checks=[];errors=[]
    def check(name,value,details=None):
        assert value,(name,details)
        checks.append({'name':name,'passed':True,'details':details});print('PASS',name,flush=True)
    os.environ['ENV']='test'
    with tempfile.TemporaryDirectory() as tmp:
        main.DB_PATH=Path(tmp)/'test.sqlite'
        with TestClient(main.app) as client:
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                page,errors=await boot(browser,'/render/template/16835',client=client)
                try:
                    await page.wait_for_selector('#openingAnimation')
                    check('Opening button is enabled',not await page.locator('#openingAnimation').is_disabled())
                    check('No disabled placeholder remains','\u672a\u5b9e\u73b0' not in await page.locator('#openingAnimation').inner_text())
                    await page.locator('#openingAnimation').click()
                    await page.wait_for_function("document.querySelector('#openingAnimation').getAttribute('aria-busy')==='false' && !document.querySelector('.render-opening-host').hidden",timeout=20000)
                    check('Same render route, no workbench redirect',await page.evaluate('__route.pathname')=='/render/template/16835')
                    check('Cube hidden and hinged canvas visible',await page.locator('.render-cube-host').is_hidden() and await page.locator('.render-opening-host canvas').is_visible())
                    await page.wait_for_function("+document.querySelector('#openingProgress').value>10",timeout=6000)
                    check('Opening timeline advances',True)
                    await page.locator('#openingPlayPause').click();await page.wait_for_timeout(70)
                    paused=await page.locator('#openingProgress').input_value();await page.wait_for_timeout(250)
                    check('Pause keeps current progress',await page.locator('#openingProgress').input_value()==paused)
                    async def seek(n):
                        await page.locator('#openingProgress').evaluate('(e,n)=>{e.value=n;e.dispatchEvent(new Event("input",{bubbles:true}));}',n)
                        await page.wait_for_timeout(120)
                    await seek(0);await page.screenshot(path=str(OUT/'closed.png'),full_page=True)
                    before=await page.locator('.render-opening-host canvas').evaluate('c=>c.toDataURL()')
                    await seek(100);await page.screenshot(path=str(OUT/'opened.png'),full_page=True)
                    after=await page.locator('.render-opening-host canvas').evaluate('c=>c.toDataURL()')
                    check('Lid motion changes actual canvas pixels',before!=after)
                    check('Opening output controls shown',await page.locator('#openingControls').is_visible() and 'WebGL' in (await page.locator('.render-engine-badge').inner_text()) or 'Canvas' in (await page.locator('.render-engine-badge').inner_text()))
                    check('Video button correctly labels opening',await page.locator('#exportVideo').inner_text()=='\u5bfc\u51fa\u5f00\u76d2\u89c6\u9891')
                    await page.locator('#openingClose').click()
                    check('Close lid returns to zero',await page.locator('#openingProgress').input_value()=='0')
                    await page.locator('#openingPlayPause').click()
                    await page.wait_for_function("document.querySelector('#openingProgress').value==='100'",timeout=6000)
                    check('Opening can replay to completion',True)
                    await page.locator('[data-camera=topRight]').click()
                    check('Camera inputs synchronize with presets',await page.locator('#rotX').input_value()=='50')
                    await page.locator('#transparentBg').click();await seek(70)
                    async with page.expect_download(timeout=30000) as info:await page.locator('#exportRender').click()
                    d=await info.value;await d.save_as(str(OUT/'opening-4k.png'))
                    with Image.open(OUT/'opening-4k.png') as im:
                        check('PNG is current opening at 4096 x 3072 with alpha',im.size==(4096,3072) and im.mode=='RGBA' and im.getextrema()[3]==(0,255),(im.size,im.mode))
                    await page.locator('[data-aspect="9:16"]').click()
                    async with page.expect_download(timeout=30000) as info:await page.locator('#exportRender').click()
                    d=await info.value;await d.save_as(str(OUT/'opening-portrait.png'))
                    with Image.open(OUT/'opening-portrait.png') as im:check('Portrait export obeys 4K long edge',im.size==(2304,4096),im.size)
                    await page.locator('[data-aspect="4:3"]').click();await seek(40)
                    async with page.expect_download(timeout=30000) as info:await page.locator('#exportVideo').click()
                    d=await info.value;await d.save_as(str(OUT/'opening.webm'))
                    check('Opening WebM exported', (OUT/'opening.webm').stat().st_size>1000,(OUT/'opening.webm').stat().st_size)
                    check('Video completion restores progress',await page.locator('#openingProgress').input_value()=='40')
                    check('Controls unlocked after recording',not await page.locator('#openingProgress').is_disabled() and not await page.locator('#exportRender').is_disabled())
                    await page.locator('[data-animation=static]').click()
                    check('Static switches back to original cube',await page.locator('#openingControls').is_hidden() and not await page.locator('.render-cube-host').is_hidden())
                    await page.locator('[data-animation=rotate]').click()
                    check('360 rotation remains selectable',await page.locator('[data-animation=rotate]').get_attribute('aria-pressed')=='true')
                    await page.locator('#openingAnimation').click();await page.wait_for_timeout(300);await seek(60)
                    check('Can reenter opening after 360 rotation',await page.locator('.render-opening-host canvas').is_visible())
                    await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(200)
                    await page.locator('#openingControls').scroll_into_view_if_needed();await page.screenshot(path=str(OUT/'mobile-controls.png'),full_page=True)
                    widths=await page.evaluate('({viewport:innerWidth,width:document.documentElement.scrollWidth})')
                    check('Mobile controls accessible without page overflow',widths['width']<=widths['viewport'],widths)
                    await page.evaluate("__navigate('/templates')");await page.wait_for_selector('.page-width')
                    check('Navigation removes opening viewport',await page.locator('.render-opening-host').count()==0)
                    # Cancellation/race regression: superseded fetch must not switch mode later.
                    await page.set_viewport_size({'width':1440,'height':1000})
                    await page.evaluate("__navigate('/render/template/16835')");await page.wait_for_selector('#openingAnimation')
                    await page.locator('#openingAnimation').click();await page.locator('[data-animation=static]').click();await page.wait_for_timeout(500)
                    check('Static selection cancels pending opening initialization',await page.locator('#openingControls').is_hidden() and not await page.locator('.render-cube-host').is_hidden())
                    await page.locator('#openingAnimation').click();await page.wait_for_function("!document.querySelector('.render-opening-host').hidden")
                    check('Opening retries successfully after cancellation',True)
                    await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(150)
                    # Load a real browser draft (with an image) rather than recreate a template.
                    draft=await page.evaluate("""()=>{const store=__modules['store.js'].store,box={length:140,width:90,height:160},f=__modules['geometry.js'].getBoxLayout(box).panels.front,c=document.createElement('canvas');c.width=c.height=60;const ctx=c.getContext('2d');ctx.fillStyle='#f03080';ctx.fillRect(0,0,60,60);return store.saveDesign({id:717171,kind:'template',sourceId:16835,name:'Opening regression draft',schemaVersion:4,geometry:'six-face-box',box,bg:'#6197b6',accent:'#ecd644',objects:[{id:'image',type:'image',x:f.x+15,y:f.y+25,w:60,h:60,src:c.toDataURL('image/png')}]});}""")
                    await page.evaluate("__navigate('/render/template/16835?draft=717171')")
                    await page.wait_for_selector('#openingAnimation');await page.locator('#openingAnimation').click()
                    await page.wait_for_function("!document.querySelector('.render-opening-host').hidden")
                    check('All six draft faces are transferred to hinged geometry',await page.locator('.render-opening-host').get_attribute('data-texture-faces')=='6')
                    after_draft=await page.evaluate("__modules['store.js'].store.get().designs.find(d=>d.id===717171)")
                    check('Preview does not change or overwrite the saved draft',after_draft==draft)
                    check('Current draft title and dimensions retained','Opening regression draft' in await page.locator('.render-info').inner_text() and '140' in await page.locator('.render-info').inner_text())
                    await seek(65);await page.screenshot(path=str(OUT/'draft-artwork.png'),full_page=True)
                    # Genuine old-server response: keep button retryable, do not fake success.
                    await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(150)
                    old_request=client.request
                    def missing(method,url,*args,**kw):
                        if str(url)=='/api/local/structure':return httpx.Response(404,json={'detail':'Not Found'})
                        return old_request(method,url,*args,**kw)
                    client.request=missing
                    await page.evaluate("__navigate('/render/template/16835')");await page.wait_for_selector('#openingAnimation')
                    await page.locator('#openingAnimation').click();await page.wait_for_timeout(400)
                    await page.wait_for_function("document.querySelector('#renderStatus').textContent.includes('Python')")
                    check('Missing backend produces actionable update message',await page.locator('#openingControls').is_hidden() and not await page.locator('#openingAnimation').is_disabled())
                    client.request=old_request
                    await page.locator('#openingAnimation').click();await page.wait_for_function("!document.querySelector('.render-opening-host').hidden")
                    check('Can retry after backend error',True)
                    await page.evaluate("__navigate('/templates')");await page.wait_for_timeout(100)
                    check('No uncaught JavaScript errors',not errors,errors)
                except Exception:
                    await page.screenshot(path=str(OUT/'failure.png'),full_page=True)
                    print('BODY',(await page.locator('body').inner_text())[-5000:]);print('ERRORS',errors);raise
                finally:
                    (OUT/'browser-tests.json').write_text(json.dumps({'scope':'Offline authored modules + FastAPI TestClient. Native URL navigation blocked by browser policy; GPU not claimed.','checks':checks,'errors':errors},ensure_ascii=False,indent=2))
                    await browser.close()
    print('OPENING_BROWSER_CHECKS',len(checks))
if __name__=='__main__':asyncio.run(run())
