import {readdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
for(const file of readdirSync('src').filter(x=>x.endsWith('.js'))){const p=spawnSync(process.execPath,['--check','src/'+file],{stdio:'inherit'});if(p.status)process.exit(p.status);}console.log('JS_SYNTAX_OK');
