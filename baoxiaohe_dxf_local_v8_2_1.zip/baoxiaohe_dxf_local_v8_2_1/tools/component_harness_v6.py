"""Authored-code component harness. No browser navigation or HTTP network proxy.

The document is assembled from local authored source in about:blank.
API actions execute in-process using FastAPI TestClient, not a network URL.
Location/history/localStorage are test doubles. This is NOT native browser E2E.
"""
import asyncio
import base64
import os
import re
import sys
import tempfile
from pathlib import Path
from playwright.async_api import async_playwright
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.offline_harness import bundle
import app.main as main

async def boot(browser,route='/templates',viewport=None,client=None):
    page=await browser.new_page(viewport=viewport or {'width':1440,'height':1000},device_scale_factor=1)
    async def local_api(data):
        path=data['path']
        if not path.startswith('/api/') or '://' in path:
            raise ValueError('In-process API path required')
        response=await asyncio.to_thread(client.request,data['method'],path,headers=data['headers'],content=data['body'])
        return {'status':response.status_code,'headers':dict(response.headers),
                'data':base64.b64encode(response.content).decode()}
    await page.expose_function('__localAPI',local_api)
    html=re.sub(r'<script.*?</script>','',(ROOT/'index.html').read_text(),flags=re.S)
    html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
    await page.set_content(html)
    await page.add_style_tag(content=(ROOT/'assets/styles.css').read_text())
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    await page.add_script_tag(content=bundle(route))
    await page.wait_for_timeout(500)
    return page,errors

async def main_probe():
    os.environ['ENV']='test'
    with tempfile.TemporaryDirectory() as d:
        main.DB_PATH=Path(d)/'test.db'
        with TestClient(main.app) as client:
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                page,errors=await boot(browser,'/design/template/25987',client=client)
                print('INITIAL',await page.locator('body').inner_text(),errors)
                await page.close();await browser.close()
if __name__=='__main__':asyncio.run(main_probe())
