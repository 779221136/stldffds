"""Focused v5.1 interaction audit: authored offline page + real local API.
Run the dev server with a throwaway database, then npm run test:layers:browser.
Browser URL-policy restrictions are not modified; this is not native E2E.
"""
import asyncio, base64, io, json, os, time
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright
from offline_harness import boot

OUT=Path(os.environ.get('AUDIT_OUTPUT','evidence/layers-v5.1')).resolve()
OUT.mkdir(parents=True,exist_ok=True)

async def main():
    checks=[]
    def ok(name,**details):
        checks.append({'name':name,'passed':True,**details})
        (OUT/'browser-partial.json').write_text(json.dumps(checks,indent=2))
        print('PASS',name,flush=True)
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page,api,errors=await boot(browser,'/login')
        page.set_default_timeout(10000)
        page.on('dialog',lambda d:asyncio.create_task(d.accept()))
        async def go(route,selector='.packaging-svg'):
            await page.evaluate('(r)=>__navigate(r)',route)
            await page.wait_for_selector(selector)
            await page.wait_for_timeout(160)
        async def order():
            return await page.locator('[data-layer-row]').evaluate_all('(rs)=>rs.map(r=>r.dataset.layerRow)')
        async def painted():
            return await page.locator('.packaging-svg [data-object]').evaluate_all('(rs)=>rs.map(r=>r.dataset.object)')
        async def handle(id):
            return await page.locator(f'[data-layer-handle="{id}"]').bounding_box()
        async def drag_to(id,target,before=True,screenshot=None):
            a=await handle(id)
            b=await page.locator(f'[data-layer-row="{target}"]').bounding_box()
            assert a and b
            await page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2)
            await page.mouse.down()
            await page.mouse.move(b['x']+18,b['y']+(3 if before else b['height']-3),steps=12)
            if screenshot:
                assert await page.locator('.layer-drop-indicator').is_visible()
                await page.screenshot(path=str(OUT/screenshot))
            await page.mouse.up()
            await page.wait_for_timeout(150)
        async def save():
            old=await page.locator('#saveStatus').inner_text()
            await page.locator('#saveDesign').click()
            await page.wait_for_function("document.querySelector('#saveDesign').disabled===false")
            designs=(await api.get('/api/designs')).json()['items']
            assert designs,old
            return designs[0]
        async def artwork_png(payload, name):
            data=await page.evaluate("async p=>{const a=__modules['artwork.js'];return (await a.svgToCanvas(a.artworkSVG(p),1180,760)).toDataURL('image/png');}",payload)
            raw=base64.b64decode(data.split(',')[1]);(OUT/name).write_bytes(raw)
            with Image.open(io.BytesIO(raw)) as im: assert im.size==(1180,760)
        async def pixel(payload):
            return await page.evaluate('''async p=>{const a=__modules['artwork.js'],g=__modules['geometry.js'].getBoxLayout(p.box).panels.front;
            const c=await a.svgToCanvas(a.artworkSVG(p),1180,760);const d=c.getContext('2d').getImageData(g.x+g.w*.5,g.y+g.h*.54,1,1).data;return [...d];}''',payload)
        phone='139'+str(time.time_ns())[-8:]
        await page.locator('#loginPhone').fill(phone)
        await page.locator('#sendCode').click()
        await page.wait_for_function("document.querySelector('#loginCode').value.length===6")
        await page.locator('#loginSubmit').click()
        await page.wait_for_selector('#accountName')
        await go('/design/template/25987')
        for color in ['#dd3344','#28a366','#3268df']:
            await page.locator('[data-ed-tool="rect"]').click()
            await page.locator('#objFill').fill(color)
            await page.locator('#objFill').dispatch_event('change')
        baseline=await order();assert len(baseline)==5
        blue,green,red=baseline[:3]
        stored=await save();base_payload=stored['payload']
        assert await pixel(base_payload)==[50,104,223,255]
        await artwork_png(base_payload,'artwork-before.png')
        await page.locator('#livePkg').screenshot(path=str(OUT/'preview-before.png'))
        await page.screenshot(path=str(OUT/'editor-before.png'))
        ok('Layer list top-to-bottom equals reverse SVG painter order',count=5)
        assert await painted()==baseline[::-1]
        await drag_to(red,blue,screenshot='editor-dragging.png')
        after=await order();assert after==[red,blue,green,*baseline[3:]],after
        assert await painted()==after[::-1]
        assert await page.locator(f'[data-layer-row="{red}"]').get_attribute('class')=='v4-layer sortable-layer selected'
        ok('Mouse handle drop updates model, canvas painter order and selection')
        changed=(await save())['payload']
        assert await pixel(changed)==[221,51,68,255]
        await artwork_png(changed,'artwork-after.png')
        await page.wait_for_timeout(200)
        await page.locator('#livePkg').screenshot(path=str(OUT/'preview-after.png'))
        assert {o['id']:o for o in base_payload['objects']}=={o['id']:o for o in changed['objects']}
        ok('Overlap pixel changes from blue to red; object geometry and content unchanged')
        from PIL import ImageChops
        a=Image.open(OUT/'preview-before.png').convert('RGB');b=Image.open(OUT/'preview-after.png').convert('RGB')
        assert ImageChops.difference(a,b).getbbox() is not None
        ok('PNG artwork export and live software-rendered 3D preview reflect reorder')
        await page.locator('[data-ed-undo]').click();assert await order()==baseline
        assert await page.locator(f'[data-layer-row="{red}"]').get_attribute('class')=='v4-layer sortable-layer selected'
        await page.locator('[data-ed-redo]').click();assert await order()==after
        ok('One drop is one undo step; redo restores order and selected layer')
        await drag_to(red,green,before=False)
        assert await order()==[blue,green,red,*baseline[3:]]
        ok('Downward drag calculates final insertion index correctly')
        # Mouse dragging the label also works; visibility and lock are not drag zones.
        a=await page.locator(f'[data-layer-select="{red}"]').bounding_box()
        b=await page.locator(f'[data-layer-row="{blue}"]').bounding_box()
        await page.mouse.move(a['x']+30,a['y']+12);await page.mouse.down()
        await page.mouse.move(b['x']+40,b['y']+2,steps=10);await page.mouse.up()
        assert (await order())[0]==red
        ok('Mouse drag from the layer name works')
        # Same-position drop must not dirty a saved design.
        await save();status_before=await page.locator('#saveStatus').inner_text()
        before=await order();a=await handle(red)
        await page.mouse.move(a['x']+9,a['y']+12);await page.mouse.down()
        await page.mouse.move(a['x']+18,a['y']+12,steps=4);await page.mouse.up()
        assert await order()==before
        assert await page.locator('#saveStatus').inner_text()==status_before
        ok('Same-position drop is a no-op: no dirty flag')
        # Cancellation does not serialize transient order.
        for mode in ['escape','outside','pointercancel']:
            a=await handle(red)
            b=await page.locator(f'[data-layer-row="{green}"]').bounding_box()
            await page.mouse.move(a['x']+9,a['y']+12);await page.mouse.down()
            await page.mouse.move(b['x']+20,b['y']+b['height']-3,steps=8)
            if mode=='escape':await page.keyboard.press('Escape')
            elif mode=='outside':await page.mouse.move(500,400,steps=6)
            else:await page.evaluate("dispatchEvent(new PointerEvent('pointercancel',{pointerId:1}))")
            await page.mouse.up()
            assert await order()==before,mode
            assert await page.locator('.layer-drag-ghost').count()==0
            assert await page.locator('#saveStatus').inner_text()==status_before
            ok('Cancel '+mode+' preserves order and removes drag artifacts')
        # Keyboard moves and locks are enforced in both UI paths.
        await page.locator(f'[data-layer-handle="{red}"]').focus()
        await page.keyboard.press('End');assert (await order())[-1]==red
        await page.keyboard.press('Home');assert (await order())[0]==red
        await page.keyboard.press('ArrowDown');assert (await order())[1]==red
        await page.keyboard.press('ArrowUp');assert (await order())[0]==red
        ok('Handle keyboard ArrowUp/Down/Home/End reorders without moving artwork')
        await page.locator('[data-layer-action="bottom"]').click();assert (await order())[-1]==red
        await page.locator('[data-layer-action="top"]').click();assert (await order())[0]==red
        await page.locator('[data-layer-action="down"]').click();assert (await order())[1]==red
        await page.locator('[data-layer-action="up"]').click();assert (await order())[0]==red
        ok('Top/bottom/up/down toolbar shares the same stack model')
        await page.locator(f'[data-layer-lock="{red}"]').click()
        assert await page.locator(f'[data-layer-handle="{red}"]').is_disabled()
        assert await page.locator('#layerUp').is_disabled() and await page.locator('#layerDown').is_disabled()
        assert await page.locator('[data-layer-action="bottom"]').is_disabled()
        await page.locator(f'[data-layer-lock="{red}"]').click()
        await page.locator(f'[data-layer-visibility="{red}"]').click()
        assert red not in await painted()
        await drag_to(red,green,before=False)
        assert (await order())[2]==red and red not in await painted()
        await page.locator(f'[data-layer-visibility="{red}"]').click()
        assert red in await painted()
        ok('Locked layer cannot reorder; hidden layer can reorder without becoming visible')
        # Save both current order and top-left content; reopen from the server.
        final_order=await order();record=await save()
        assert [o['id'] for o in record['payload']['objects']]==final_order[::-1]
        await go('/account','#accountName')
        local_id=await page.evaluate("__modules['store.js'].store.get().designs.find(d=>d.cloudId==="+str(record['id'])+").id")
        await go('/design/template/25987?draft='+str(local_id))
        assert await order()==final_order
        await page.screenshot(path=str(OUT/'editor-after.png'))
        await page.locator('#layerPanel').screenshot(path=str(OUT/'layer-panel.png'))
        ok('API persistence and account-page reopen preserve layer order',version=record['version'])
        # App route lifecycle: create a new editor instance with saved data.
        await go('/templates','#catalogGrid')
        await go('/account','#accountName')
        await page.locator(f'a[href="/design/template/25987?draft={local_id}"]').click()
        await page.wait_for_selector('.packaging-svg')
        assert await order()==final_order
        ok('Navigation destroys/recreates panel listeners without duplicate drops')
        # A new app page has no local drafts. Rehydrate only authenticated API data.
        fresh,api2,errors2=await boot(browser,'/login')
        api2.cookies.update(api.cookies)
        me=(await api2.get('/api/me')).json()['user']
        await fresh.evaluate("u=>__modules['store.js'].store.setUser(u)",me)
        await fresh.evaluate("__navigate('/account')")
        await fresh.wait_for_selector('.design-list a[data-link]')
        await fresh.locator('.design-list a[data-link]').first.click()
        await fresh.wait_for_selector('.packaging-svg')
        assert await fresh.locator('[data-layer-row]').evaluate_all('(rs)=>rs.map(r=>r.dataset.layerRow)')==final_order
        assert not errors2,errors2
        await api2.aclose();await fresh.close()
        ok('Fresh app instance with empty draft cache restores API layer order')

        # Many rows: hold near the bottom and verify the internal list scrolls.
        for _ in range(16):await page.locator('[data-ed-tool="rect"]').click()
        await page.locator('.layer-sort-list').evaluate('(el)=>el.scrollTop=0')
        many=await order();a=await handle(many[0]);box=await page.locator('.layer-sort-list').bounding_box()
        await page.mouse.move(a['x']+10,a['y']+12);await page.mouse.down()
        await page.mouse.move(box['x']+20,box['y']+box['height']-8,steps=10)
        await page.wait_for_timeout(650)
        scroll=await page.locator('.layer-sort-list').evaluate('(el)=>el.scrollTop')
        assert scroll>50,scroll
        await page.mouse.up()
        assert await order()!=many
        ok('Long layer list auto-scrolls while dragging',scrollTop=scroll)
        # Touch pointer input is delivered through Chromium CDP, not synthetic DOM moves.
        await page.locator('.layer-sort-list').evaluate('(el)=>el.scrollTop=0')
        current=await order();a=await handle(current[0]);b=await page.locator(f'[data-layer-row="{current[2]}"]').bounding_box()
        cdp=await page.context.new_cdp_session(page)
        await cdp.send('Emulation.setTouchEmulationEnabled',{'enabled':True,'maxTouchPoints':1})
        x=a['x']+10;y=a['y']+12;end=b['y']+b['height']-3
        await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
        for i in range(1,8):await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':y+(end-y)*i/7}]})
        await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
        assert (await order())[2]==current[0],await order()
        ok('Chromium touch input on handle changes the order')
        await cdp.send('Emulation.setTouchEmulationEnabled',{'enabled':False})
        # Navigate away during drag: no zombie listeners, no floating DOM remains.
        await page.locator('.layer-sort-list').evaluate('(el)=>el.scrollTop=0')
        current=await order();a=await handle(current[0])
        await page.mouse.move(a['x']+10,a['y']+12);await page.mouse.down();await page.mouse.move(a['x']+10,a['y']+75,steps=5)
        await go('/templates','#catalogGrid');await page.mouse.up()
        assert await page.locator('.layer-drag-ghost').count()==0
        assert not errors,errors
        ok('Route cleanup removes pointer handlers and drag overlays; no JS errors')
        report={'scope':'offline Chromium authored-code harness + real local API; pointer mouse/touch input; native URL navigation blocked; not original-site pixel comparison','checks':checks,'count':len(checks),'errors':errors}
        (OUT/'browser-results.json').write_text(json.dumps(report,indent=2))
        print('LAYER_BROWSER_OK',len(checks),flush=True)
        await api.aclose();await browser.close()

if __name__=='__main__':asyncio.run(main())
