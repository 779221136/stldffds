from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
from contextlib import asynccontextmanager, contextmanager
from decimal import Decimal, ROUND_HALF_UP
from io import BytesIO
from pathlib import Path
from typing import Any, Literal

from fastapi import Cookie, FastAPI, HTTPException, Request, Response, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field
from reportlab.graphics.barcode import createBarcodeDrawing
import qrcode
import qrcode.image.svg

from .catalog import query_items, metadata, present
from . import revisions
from .local_jobs import router as local_router, LocalJobManager
from .domain import DesignPayload, preflight_payload, image_data
from .preview_pdf import make_preview_pdf

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime'
DB_PATH = Path(os.environ.get('BAOXIAOHE_DB', str(RUNTIME / 'baoxiaohe.db')))
CATALOG_PATH = Path(os.environ.get('BAOXIAOHE_CATALOG', str(RUNTIME / 'catalog.json')))
CATALOG = json.loads(CATALOG_PATH.read_text('utf-8'))
SESSION_COOKIE = 'bxh_session'
MAX_BODY = 12 * 1024 * 1024
ORIGINS = [s.strip() for s in os.environ.get('CORS_ORIGINS', 'http://127.0.0.1:8088,http://localhost:8088').split(',') if s.strip()]


def development() -> bool:
    # Unknown environment values must NOT enable development authentication.
    return os.environ.get('ENV', 'development').lower() in {'development', 'dev', 'test'}


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with db() as c:
        c.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS schema_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE, name TEXT NOT NULL, created_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
            CREATE TABLE IF NOT EXISTS sms_challenges(phone TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires_at INTEGER NOT NULL, attempts INTEGER NOT NULL, sent_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL,kind TEXT NOT NULL,item_id INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(user_id,kind,item_id));
            CREATE TABLE IF NOT EXISTS designs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,name TEXT NOT NULL,kind TEXT NOT NULL,source_id INTEGER NOT NULL,payload TEXT NOT NULL,updated_at INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL,total REAL NOT NULL,created_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS order_keys(user_id INTEGER NOT NULL,key TEXT NOT NULL,order_id TEXT NOT NULL,UNIQUE(user_id,key));
            CREATE INDEX IF NOT EXISTS idx_design_owner ON designs(user_id,updated_at);
            CREATE INDEX IF NOT EXISTS idx_orders_owner ON orders(user_id,created_at);
        ''')
        columns = {r['name'] for r in c.execute('PRAGMA table_info(designs)')}
        if 'version' not in columns:
            c.execute('ALTER TABLE designs ADD COLUMN version INTEGER NOT NULL DEFAULT 1')
        revisions.migrate(c)
        marker=c.execute("SELECT value FROM schema_meta WHERE key='auth_version'").fetchone()
        if not marker or marker['value'] != '4':
            # v3 production login accepted unverified codes: revoke inherited sessions.
            c.execute('DELETE FROM sessions')
            c.execute('DELETE FROM sms_challenges')
            c.execute("INSERT OR REPLACE INTO schema_meta VALUES('auth_version','4')")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    render_root=Path(os.environ.get("BAOXIAOHE_LOCAL_RENDER_DIR",str(DB_PATH.parent/(DB_PATH.stem+"-renders"))))
    _app.state.local_renderer=LocalJobManager(render_root)
    _app.state.local_renderer.start()
    try:
        yield
    finally:
        _app.state.local_renderer.close()


app = FastAPI(title='Packaging rebuild - audited development system', version='7.0.0', lifespan=lifespan)
app.include_router(local_router)
from .cad_api import create_router as create_cad_router
app.include_router(create_cad_router(lambda: DB_PATH.parent,lambda r: get_user(r.cookies.get(SESSION_COOKIE))))
app.add_middleware(CORSMiddleware, allow_origins=ORIGINS, allow_credentials=True,
                   allow_methods=['GET','POST','PATCH','DELETE','OPTIONS'], allow_headers=['content-type','idempotency-key'])


@app.middleware('http')
async def security_headers(request: Request, call_next):
    if request.method in {'POST','PUT','PATCH','DELETE'} and request.url.path.startswith('/api/'):
        origin = request.headers.get('origin')
        # Docker-published IPs/domains may submit to their own origin.
        same_origin = f'{request.url.scheme}://{request.url.netloc}'
        if origin and origin not in ORIGINS and origin != same_origin:
            return JSONResponse({'error': {'message': 'Origin is not allowed'}}, status_code=403)
        if not request.headers.get('content-type', '').lower().startswith('application/json'):
            return JSONResponse({'error': {'message': 'application/json is required'}}, status_code=415)
        try:
            if int(request.headers.get('content-length', '0')) > MAX_BODY:
                return JSONResponse({'error': {'message': 'Request body exceeds 12 MiB'}}, status_code=413)
        except ValueError:
            return JSONResponse({'error': {'message': 'Invalid Content-Length'}}, status_code=400)
        # Bound even streamed bodies; Starlette reuses the cached body downstream.
        parts = []; size = 0
        async for part in request.stream():
            size += len(part)
            if size > MAX_BODY:
                return JSONResponse({'error': {'message': 'Request body exceeds 12 MiB'}}, status_code=413)
            parts.append(part)
        request._body = b''.join(parts)
    response = await call_next(request)
    response.headers['x-request-id'] = secrets.token_hex(8)
    response.headers['x-content-type-options'] = 'nosniff'
    response.headers['referrer-policy'] = 'strict-origin-when-cross-origin'
    response.headers['x-frame-options'] = 'SAMEORIGIN'
    response.headers['permissions-policy'] = 'camera=(), microphone=(), geolocation=()'
    if request.url.path.startswith('/api/'):
        response.headers['cache-control'] = 'no-store'
    return response


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def get_user(session: str | None) -> dict | None:
    if not session:
        return None
    with db() as c:
        row = c.execute('SELECT u.id,u.phone,u.name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?',
                        (hash_token(session), int(time.time()))).fetchone()
    return dict(row) if row else None


def require_user(session: str | None) -> dict:
    user = get_user(session)
    if not user:
        raise HTTPException(401, 'Please sign in; browser drafts are not a server session')
    return user


def source_item(kind: str, item_id: int) -> dict:
    collection = 'templates' if kind in {'template','templates'} else 'models'
    item = next((x for x in CATALOG[collection] if x['id'] == item_id), None)
    if not item:
        raise HTTPException(404, 'Catalog item not found')
    return item


@app.get('/api/health')
def health():
    with db() as c:
        c.execute('SELECT 1').fetchone()
    return {'ok': True, 'version': '7.0.0', 'environment': 'development' if development() else 'production',
            'production_ready': False, 'capabilities': {'sms': 'development-code' if development() else 'not-configured',
            'payments': False, 'cloud_render': False, 'local_render': True, 'parametric_structures': ['tuck','hinged'], 'icc_export': False, 'catalog': 'sample'}}


@app.get('/api/catalog/meta')
def catalog_meta():
    return metadata(CATALOG)


@app.get('/api/readiness')
def readiness():
    return {'version':'7.0.0','production_ready':False,'parity_verified':False,
            'catalog':metadata(CATALOG), 'blockers':[
                'Original-site screenshots and UI-state comparison not verified',
                'Original templates, textures and geometry library not imported',
                'Only two idealised parametric structures; allowances/collisions/manufacturing validation not implemented',
                'Local CPU rendering available; no photorealistic cloud renderer or print-ready ICC/PDF-X',
                'SMS/OAuth/payment/membership/team/factory integration not implemented',
                'GPU, native browser E2E, load, restore and production security acceptance not verified']}


def filtered(kind: str, q: str, sort: str, filters: dict) -> list[dict]:
    return query_items(CATALOG,kind,q,sort,filters)


def paginated(items: list, page: int, page_size: int) -> dict:
    pages = max(1,(len(items)+page_size-1)//page_size)
    page = min(page,pages)
    return {'items': items[(page-1)*page_size:page*page_size], 'page': page, 'page_size': page_size,
            'total': len(items), 'pages': pages, 'catalog_scope': CATALOG.get('scope','unverified')}


@app.get('/api/templates')
def list_templates(q: str = Query('',max_length=200), page: int = Query(1,ge=1), page_size: int = Query(10,ge=1,le=100),
                   sort: Literal['all','new','popular','uses','price_asc','price_desc'] = 'all',
                   type: str | None = Query(None,max_length=120), model: str | None = Query(None,max_length=120),
                   industry: str | None = Query(None,max_length=120), style: str | None = Query(None,max_length=120),
                   use: str | None = Query(None,max_length=120), material: str | None = Query(None,max_length=120),
                   channel: str | None = Query(None,max_length=120), price: Literal['all','free','member_free','paid'] = 'all'):
    return paginated(filtered('templates',q,sort,{'type':type,'model':model,'industry':industry,'style':style,
                     'use':use,'material':material,'channel':channel,'price':price}),page,page_size)


@app.get('/api/models')
def list_models(q: str = Query('',max_length=200), page: int = Query(1,ge=1), page_size: int = Query(10,ge=1,le=100),
                sort: Literal['all','new','popular','uses'] = 'all', type: str | None = Query(None,max_length=120),
                model: str | None = Query(None,max_length=120), material: str | None = Query(None,max_length=120),
                printable: bool | None = None):
    return paginated(filtered('models',q,sort,{'type':type,'model':model,'material':material,'printable':printable}),page,page_size)


@app.get('/api/templates/{item_id}')
def template(item_id: int):
    item=present(source_item('template',item_id),'templates')
    return {'item': item, 'related': [present(x,'templates') for x in CATALOG['templates'] if x['id'] != item_id and x.get('type')==item.get('type')][:8]}


@app.get('/api/models/{item_id}')
def model(item_id: int):
    item=present(source_item('model',item_id),'models')
    return {'item': item, 'related': [present(x,'models') for x in CATALOG['models'] if x['id'] != item_id and x.get('type')==item.get('type')][:8]}


def document_for(kind:str,item_id:int,session:str|None):
    item=source_item(kind,item_id)
    payload=item.get('design_payload')
    if payload is None:
        return {'available':False,'item_id':item_id,'reason':'Editable document is not supplied; generic preview is not the original design.'}
    access=item.get('document_access','authenticated')
    if access!='public':
        require_user(session)
    if access not in {'public','authenticated'}:
        raise HTTPException(501,'Membership/paid document authorization is not configured')
    try:
        validated=DesignPayload.model_validate(payload)
    except ValueError:
        raise HTTPException(422,'Deployment document does not conform to the supported six-face schema')
    return {'available':True,'item_id':item_id,'payload':validated.model_dump(),
            'scope':'deployment-supplied document; original-source parity is not verified'}


@app.get('/api/templates/{item_id}/document')
def template_document(item_id:int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    return document_for('template',item_id,bxh_session)


@app.get('/api/models/{item_id}/document')
def model_document(item_id:int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    return document_for('model',item_id,bxh_session)


class SmsRequest(BaseModel):
    phone: str = Field(pattern=r'^\+?[0-9]{6,15}$')


class LoginRequest(SmsRequest):
    code: str = Field(pattern=r'^[0-9]{6}$')


@app.post('/api/auth/sms/send')
def send_sms(body: SmsRequest):
    if not development():
        raise HTTPException(503,'SMS provider is not configured; production sign-in is disabled')
    now=int(time.time()); code=f'{secrets.randbelow(1_000_000):06d}'
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute('SELECT sent_at FROM sms_challenges WHERE phone=?',(body.phone,)).fetchone()
        if row and now-row['sent_at'] < 60:
            raise HTTPException(429,'Wait 60 seconds before requesting another code')
        c.execute('INSERT OR REPLACE INTO sms_challenges VALUES(?,?,?,?,?)',
                  (body.phone,hash_token(body.phone+':'+code),now+300,0,now))
    return {'ok':True,'dev_code':code,'expires_in':300,'development_only':True,'sms_sent':False}


@app.post('/api/auth/sms/login')
def login(body: LoginRequest,response: Response):
    if not development():
        raise HTTPException(503,'SMS provider is not configured; production sign-in is disabled')
    now=int(time.time()); invalid=False
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        ch=c.execute('SELECT * FROM sms_challenges WHERE phone=?',(body.phone,)).fetchone()
        if not ch or ch['expires_at'] <= now or ch['attempts'] >= 5:
            raise HTTPException(400,'Code is absent, expired or locked; request a new code')
        if not secrets.compare_digest(ch['code_hash'], hash_token(body.phone+':'+body.code)):
            c.execute('UPDATE sms_challenges SET attempts=attempts+1 WHERE phone=?',(body.phone,))
            invalid=True
        else:
            c.execute('DELETE FROM sms_challenges WHERE phone=?',(body.phone,))
            c.execute('INSERT OR IGNORE INTO users(phone,name,created_at) VALUES(?,?,?)',(body.phone,'\u5305\u5c0f\u76d2\u7528\u6237',now))
            user=dict(c.execute('SELECT id,phone,name FROM users WHERE phone=?',(body.phone,)).fetchone())
            token=secrets.token_urlsafe(32)
            c.execute('DELETE FROM sessions WHERE expires_at<=?',(now,))
            c.execute('INSERT INTO sessions VALUES(?,?,?)',(hash_token(token),user['id'],now+7*86400))
    if invalid:
        raise HTTPException(400,'Invalid verification code')
    response.set_cookie(SESSION_COOKIE,token,httponly=True,secure=not development(),samesite='lax',max_age=7*86400,path='/')
    return {'user':user,'development_only':True}


@app.post('/api/auth/logout')
def logout(response: Response,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    if bxh_session:
        with db() as c:
            c.execute('DELETE FROM sessions WHERE token_hash=?',(hash_token(bxh_session),))
    response.delete_cookie(SESSION_COOKIE,path='/')
    return {'ok':True}


@app.get('/api/me')
def me(bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    return {'user':get_user(bxh_session)}


class ProfileRequest(BaseModel):
    name: str = Field(min_length=1,max_length=60)


@app.patch('/api/me')
def profile(body: ProfileRequest,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    name=body.name.strip()
    if not name:
        raise HTTPException(422,'Name must not be empty')
    with db() as c:
        c.execute('UPDATE users SET name=? WHERE id=?',(name,user['id']))
    return {'user':{**user,'name':name}}


class FavoriteRequest(BaseModel):
    kind: Literal['templates','models']
    item_id: int = Field(gt=0)


@app.get('/api/favorites')
def favorites(bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        rows=c.execute('SELECT kind,item_id,created_at FROM favorites WHERE user_id=? ORDER BY created_at DESC',(user['id'],)).fetchall()
    return {'items':[dict(r) for r in rows]}


@app.post('/api/favorites')
def favorite(body: FavoriteRequest,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session);source_item(body.kind,body.item_id)
    with db() as c:
        c.execute('INSERT OR IGNORE INTO favorites VALUES(?,?,?,?)',(user['id'],body.kind,body.item_id,int(time.time())))
    return {'ok':True}


@app.delete('/api/favorites/{kind}/{item_id}')
def unfavorite(kind: Literal['templates','models'],item_id: int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        c.execute('DELETE FROM favorites WHERE user_id=? AND kind=? AND item_id=?',(user['id'],kind,item_id))
    return {'ok':True}


class DesignRequest(BaseModel):
    id: int | None = Field(None,gt=0)
    version: int | None = Field(None,ge=1)
    name: str = Field(min_length=1,max_length=160)
    kind: Literal['template','model']
    source_id: int = Field(gt=0)
    payload: DesignPayload


def unpack_design(row) -> dict:
    return {**dict(row),'payload':json.loads(row['payload'])}


@app.get('/api/designs')
def designs(bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        rows=c.execute('SELECT id,name,kind,source_id,payload,updated_at,version FROM designs WHERE user_id=? ORDER BY updated_at DESC,id DESC',(user['id'],)).fetchall()
    return {'items':[unpack_design(r) for r in rows]}


@app.get('/api/designs/{design_id}')
def design(design_id: int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        row=c.execute('SELECT id,name,kind,source_id,payload,updated_at,version FROM designs WHERE id=? AND user_id=?',(design_id,user['id'])).fetchone()
    if not row:
        raise HTTPException(404,'Design not found')
    return {'item':unpack_design(row)}


@app.post('/api/designs')
def save_design(body: DesignRequest,request: Request,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session);source_item(body.kind,body.source_id)
    key=revisions.validate_key(request.headers.get('idempotency-key'))
    fingerprint=revisions.request_hash(body)
    now=int(time.time());payload=body.payload.model_dump_json()
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        replay=revisions.receipt(c,user['id'],key,fingerprint)
        if replay is not None:
            return replay
        if body.id is not None:
            row=c.execute('SELECT * FROM designs WHERE id=? AND user_id=?',(body.id,user['id'])).fetchone()
            if not row:
                raise HTTPException(404,'Design not found')
            if body.version != row['version']:
                raise HTTPException(409,'Design changed in another session. Your local draft is retained; reload or save a copy.')
            unchanged=(row['name']==body.name and row['kind']==body.kind and
                       row['source_id']==body.source_id and row['payload']==payload)
            if unchanged:
                result={'id':body.id,'updated_at':row['updated_at'],'version':row['version']}
                revisions.remember_receipt(c,user['id'],key,fingerprint,result)
                return result
            version=row['version']+1
            c.execute('UPDATE designs SET name=?,kind=?,source_id=?,payload=?,updated_at=?,version=? WHERE id=? AND user_id=?',
                      (body.name,body.kind,body.source_id,payload,now,version,body.id,user['id']))
            design_id=body.id
        else:
            version=1
            cur=c.execute('INSERT INTO designs(user_id,name,kind,source_id,payload,updated_at,version) VALUES(?,?,?,?,?,?,?)',
                          (user['id'],body.name,body.kind,body.source_id,payload,now,version))
            design_id=cur.lastrowid
        result={'id':design_id,'updated_at':now,'version':version}
        revisions.checkpoint(c,design_id,user['id'])
        revisions.remember_receipt(c,user['id'],key,fingerprint,result)
    return result


@app.get('/api/designs/{design_id}/versions')
def design_versions(design_id:int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        doc=c.execute('SELECT version FROM designs WHERE id=? AND user_id=?',(design_id,user['id'])).fetchone()
        if not doc:
            raise HTTPException(404,'Design not found')
        rows=c.execute('''SELECT version,name,kind,source_id,created_at,reason FROM design_revisions
          WHERE design_id=? AND user_id=? ORDER BY version DESC''',(design_id,user['id'])).fetchall()
    return {'items':[dict(r) for r in rows],'current_version':doc['version'],'retention_limit':revisions.HISTORY_LIMIT}


@app.get('/api/designs/{design_id}/versions/{version}')
def design_version(design_id:int,version:int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        row=c.execute('''SELECT design_id,version,name,kind,source_id,payload,created_at,reason
          FROM design_revisions WHERE design_id=? AND version=? AND user_id=?''',
          (design_id,version,user['id'])).fetchone()
    if not row:
        raise HTTPException(404,'Version not found')
    return {'item':unpack_design(row)}


class RestoreRequest(BaseModel):
    version: int = Field(ge=1)
    expected_version: int = Field(ge=1)


@app.post('/api/designs/{design_id}/restore')
def restore_design(design_id:int,body:RestoreRequest,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    now=int(time.time())
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        current=c.execute('SELECT version FROM designs WHERE id=? AND user_id=?',(design_id,user['id'])).fetchone()
        if not current:
            raise HTTPException(404,'Design not found')
        if current['version']!=body.expected_version:
            raise HTTPException(409,'Design changed. Refresh version history before restoring.')
        old=c.execute('SELECT * FROM design_revisions WHERE design_id=? AND version=? AND user_id=?',
                      (design_id,body.version,user['id'])).fetchone()
        if not old:
            raise HTTPException(404,'Version not found or expired')
        # Validate legacy stored content against the current safe image/schema policy.
        payload=DesignPayload.model_validate_json(old['payload']).model_dump_json()
        version=current['version']+1
        c.execute('''UPDATE designs SET name=?,kind=?,source_id=?,payload=?,updated_at=?,version=?
          WHERE id=? AND user_id=?''',(old['name'],old['kind'],old['source_id'],payload,now,version,design_id,user['id']))
        revisions.checkpoint(c,design_id,user['id'],'restore:'+str(body.version))
    return {'id':design_id,'version':version,'updated_at':now,'restored_from':body.version}


@app.delete('/api/designs/{design_id}')
def delete_design(design_id: int,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        changed=c.execute('DELETE FROM designs WHERE id=? AND user_id=?',(design_id,user['id'])).rowcount
    if not changed:
        raise HTTPException(404,'Design not found')
    return {'ok':True}


@app.post('/api/render/jobs')
def render_job():
    raise HTTPException(501,'Cloud rendering is not configured. Use the real browser WebGL PNG export; no placeholder job is created.')


@app.get('/api/render/jobs/{job_id}')
def render_job_status(job_id: str):
    raise HTTPException(404,'No cloud render job exists in this installation')


class PreflightRequest(BaseModel):
    payload: DesignPayload
    color_mode: str = Field(default='RGB',max_length=16)


@app.post('/api/preflight')
def preflight(body: PreflightRequest):
    return preflight_payload(body.payload,body.color_mode)


class ExportRequest(PreflightRequest):
    name: str = Field(default='packaging-preview',max_length=160)
    mode: Literal['print','structure'] = 'print'


@app.post('/api/exports/pdf')
def export_pdf(body: ExportRequest):
    result=preflight_payload(body.payload,body.color_mode)
    if body.color_mode.upper() != 'RGB':
        raise HTTPException(501,'ICC-managed CMYK export is not implemented. RGB preview export is available.')
    if not result['ok']:
        raise HTTPException(422,'; '.join(result['errors']))
    try:
        pdf=make_preview_pdf(body.payload,body.mode)
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from exc
    except Exception as exc:
        raise HTTPException(422,'Preview export failed; check SVG and image content') from exc
    # ASCII fallback avoids a Unicode filename crash in HTTP headers.
    filename=re.sub(r'[^A-Za-z0-9_.-]','-',body.name)[:70].strip('-') or 'packaging'
    return Response(pdf,media_type='application/pdf',headers={
        'Content-Disposition':f'attachment; filename="{filename}-{body.mode}-RGB-preview.pdf"',
        'X-Production-Ready':'false','X-Color-Mode':'RGB','X-Geometry':'six-face-preview'})


@app.get('/api/tools/qrcode.svg')
def qr(value: str = Query(min_length=1,max_length=2048)):
    img=qrcode.make(value,image_factory=qrcode.image.svg.SvgPathImage,box_size=8,border=4)
    data=BytesIO();img.save(data)
    return Response(data.getvalue(),media_type='image/svg+xml')


def check_digit(digits: str) -> str:
    return str((-sum(int(v)*(3 if i%2==0 else 1) for i,v in enumerate(reversed(digits))))%10)


@app.get('/api/tools/barcode.svg')
def barcode(value: str = Query(min_length=1,max_length=128),symbology: str = 'CODE128'):
    sym=symbology.upper(); aliases={'CODE128':'Code128','CODE39':'Standard39','EAN13':'EAN13','EAN8':'EAN8'}
    if sym not in aliases:
        raise HTTPException(422,'Unsupported barcode symbology')
    if sym in {'EAN13','EAN8'}:
        n=13 if sym=='EAN13' else 8
        if not value.isascii() or not value.isdigit() or len(value) not in {n-1,n}:
            raise HTTPException(422,f'{sym} requires {n-1} data digits or {n} digits including checksum')
        if len(value)==n and value[-1] != check_digit(value[:-1]):
            raise HTTPException(422,'Invalid EAN checksum')
        value=value[:n-1]
    elif sym=='CODE39' and not re.fullmatch(r'[0-9A-Z .$/+%\-]+',value):
        raise HTTPException(422,'CODE39 accepts uppercase letters, numbers and standard CODE39 punctuation')
    elif sym=='CODE128' and not re.fullmatch(r'[ -~]+',value):
        raise HTTPException(422,'CODE128 accepts printable ASCII in this implementation')
    try:
        out=createBarcodeDrawing(aliases[sym],value=value,barHeight=72,humanReadable=True).asString('svg')
        import xml.etree.ElementTree as ET
        import base64
        root=ET.fromstring(out)
        for node in root.iter():
            style=node.attrib.pop('style','')
            for declaration in style.split(';'):
                if ':' not in declaration:
                    continue
                key,val=declaration.split(':',1)
                key=key.strip();val=val.strip()
                if key in {'fill','stroke','stroke-width','stroke-linecap','stroke-linejoin','fill-opacity','stroke-opacity','font-family','font-size','font-weight','text-anchor'}:
                    node.set(key,val)
        out=ET.tostring(root,encoding='utf-8',xml_declaration=True)
        image_data('data:image/svg+xml;base64,'+base64.b64encode(out).decode())
    except Exception as exc:
        raise HTTPException(422,'Invalid barcode data') from exc
    return Response(out,media_type='image/svg+xml')


class QuoteRequest(BaseModel):
    model_config=ConfigDict(allow_inf_nan=False)
    model_id: int = Field(gt=0)
    length_mm: float = Field(ge=30,le=500)
    width_mm: float = Field(ge=20,le=400)
    height_mm: float = Field(ge=30,le=600)
    material: str = Field(min_length=1,max_length=100)
    quantity: int = Field(ge=1,le=100000)
    crafts: list[Literal['lamination','foil','uv','emboss']] = Field(default_factory=list,max_length=4)


def quote_value(body: QuoteRequest) -> dict:
    item=source_item('model',body.model_id)
    if not item.get('printable'):
        raise HTTPException(422,'This sample model does not support an estimated print quote')
    volume=Decimal(str(body.length_mm))*Decimal(str(body.width_mm))*Decimal(str(body.height_mm))/Decimal(1_000_000)
    unit=Decimal('1.65')+volume*Decimal('.042')+Decimal(len(set(body.crafts)))*Decimal('.42')
    discount=min(Decimal('.9'),max(Decimal(0),Decimal(len(str(body.quantity))-2)*Decimal('.12')))
    unit=max(Decimal('.72'),unit-discount).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
    setup=Decimal('28')+(Decimal('35') if 'foil' in body.crafts else Decimal(0))
    total=unit*body.quantity+setup
    return {'currency':'CNY','unit_price':float(unit),'setup':float(setup),'total':float(total),
            'estimate_only':True,'payment_available':False,'lead_time_days':None,'pricing_version':'sample-v1'}


@app.post('/api/print/quote')
def quote(body: QuoteRequest):
    return quote_value(body)


class OrderRequest(BaseModel):
    quote: QuoteRequest
    total: float | None = Field(None,allow_inf_nan=False)  # Legacy client field: intentionally ignored.
    contact: dict[str,str] = Field(default_factory=dict,max_length=10)


@app.post('/api/print/orders')
def create_order(body: OrderRequest,request: Request,bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session);calculated=quote_value(body.quote)
    key=request.headers.get('idempotency-key','')
    if key and not re.fullmatch(r'[A-Za-z0-9_-]{8,100}',key):
        raise HTTPException(422,'Invalid idempotency key')
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        if key:
            row=c.execute('SELECT o.id,o.total,o.status FROM order_keys k JOIN orders o ON k.order_id=o.id WHERE k.user_id=? AND k.key=?',(user['id'],key)).fetchone()
            if row:
                return {**dict(row),'estimate_only':True,'replayed':True}
        oid='EST-'+secrets.token_hex(8).upper()
        content={'quote':body.quote.model_dump(),'calculated':calculated,'contact':body.contact}
        c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?)',(oid,user['id'],json.dumps(content,ensure_ascii=False),'estimate_only',calculated['total'],int(time.time())))
        if key:
            c.execute('INSERT INTO order_keys VALUES(?,?,?)',(user['id'],key,oid))
    return {'id':oid,'status':'estimate_only','total':calculated['total'],'estimate_only':True}


@app.get('/api/account/orders')
def orders(bxh_session: str | None = Cookie(None,alias=SESSION_COOKIE)):
    user=require_user(bxh_session)
    with db() as c:
        rows=c.execute('SELECT id,status,total,created_at,payload FROM orders WHERE user_id=? ORDER BY created_at DESC',(user['id'],)).fetchall()
    return {'items':[{**dict(r),'payload':json.loads(r['payload'])} for r in rows]}


@app.exception_handler(HTTPException)
async def http_error(_request: Request,exc: HTTPException):
    return JSONResponse(status_code=exc.status_code,content={'error':{'status':exc.status_code,'message':exc.detail}})


# Only explicit public directories are served. Never serve project-root files.
app.mount('/assets',StaticFiles(directory=ROOT/'assets',follow_symlink=False),name='assets')
app.mount('/src',StaticFiles(directory=ROOT/'src',follow_symlink=False),name='src')
SPA_EXACT={'','index.html','introduction','templates','models','member','login','account','team','print','ai-design','structure','cad'}
SPA_PATTERN=re.compile(r'(?:(?:templates|models)/\d+|(?:design|render)/(?:template|model)/\d+)')


@app.get('/{path:path}',include_in_schema=False)
def spa(path: str):
    import html
    value=path.strip('/')
    if value not in SPA_EXACT and not SPA_PATTERN.fullmatch(value):
        raise HTTPException(404,'Resource not found')
    title='\u5305\u5c0f\u76d2 - \u672c\u5730\u91cd\u5efa\u9a8c\u6536\u7248'
    description='Local acceptance build. Original-site parity is not verified.'
    match=re.fullmatch(r'(templates|models)/(\d+)',value)
    edit=re.fullmatch(r'(design|render)/(template|model)/(\d+)',value)
    if match or edit:
        kind,item_id=(match[1],int(match[2])) if match else (edit[2]+'s',int(edit[3]))
        item=source_item(kind,item_id)
        title=str(item['title'])+' - \u5305\u5c0f\u76d2\u91cd\u5efa\u7248'
        description=str(item['title'])+' | Local metadata preview, not a verified copy of the original asset.'
    elif value in ('templates','models'):
        title= ('\u6a21\u677f\u4e2d\u5fc3' if value=='templates' else '\u76d2\u578b/\u6a21\u578b\u5e93')+' - \u5305\u5c0f\u76d2\u91cd\u5efa\u7248'
    text=(ROOT/'index.html').read_text('utf-8')
    text=re.sub(r'<title>.*?</title>',lambda _: '<title>'+html.escape(title)+'</title>',text,flags=re.S)
    meta='<meta name="description" content="'+html.escape(description,quote=True)+'">'
    meta+='<meta name="robots" content="noindex,nofollow">'
    text=text.replace('</head>',meta+'\n</head>')
    return HTMLResponse(text,headers={'Cache-Control':'no-cache','X-Robots-Tag':'noindex, nofollow'})
