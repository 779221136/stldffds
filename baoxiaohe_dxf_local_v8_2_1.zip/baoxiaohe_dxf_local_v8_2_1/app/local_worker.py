"""One job per child process. JSON is data, never executable code."""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from .local_raster import LocalRenderRequest, build_structure, decode_textures, render_image, animation_request

def ffmpeg_binary():
    local=shutil.which('ffmpeg')
    if local:return local
    try:
        import imageio_ffmpeg
        candidate=imageio_ffmpeg.get_ffmpeg_exe()
        return candidate if Path(candidate).is_file() else None
    except (ImportError,RuntimeError):return None

def run(job_dir):
    root=Path(job_dir).resolve();payload=json.loads((root/'input.json').read_text(encoding='utf-8'))
    if 'cad_document' in payload:
        from .cad_api import CadRenderRequest,render_model
        req=CadRenderRequest.model_validate(payload);model=render_model(req)
    else:
        req=LocalRenderRequest.model_validate(payload);model=build_structure(req.spec)
    textures=decode_textures(req)
    def report(value):
        tmp=root/'progress.tmp';tmp.write_text(json.dumps({'progress':value}),encoding='utf-8');os.replace(tmp,root/'progress.json')
    if req.format=='png':
        report(10);render_image(req,model,textures).save(root/'result.png');report(100);return
    frames=root/'frames';frames.mkdir(exist_ok=True);count=req.seconds*req.fps
    for i in range(count):
        render_image(animation_request(req,i,count),model,textures).save(frames/f'{i:04d}.png')
        report(5+int((i+1)/count*83))
    if req.format=='frames':
        with zipfile.ZipFile(root/'result.zip','w',zipfile.ZIP_DEFLATED) as z:
            for p in sorted(frames.glob('*.png')):z.write(p,'frames/'+p.name)
            z.writestr('manifest.json',json.dumps({'fps':req.fps,'frames':count,'seconds':req.seconds,'motion':req.motion,'units':'mm'}))
    else:
        exe=ffmpeg_binary()
        if not exe:raise RuntimeError('FFmpeg is not installed. Use PNG sequence ZIP instead.')
        out=root/('result.'+req.format)
        args=[exe,'-hide_banner','-loglevel','error','-nostdin','-y','-framerate',str(req.fps),'-i',str(frames/'%04d.png'),'-an']
        if req.format=='mp4':args+=['-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart']
        else:args+=['-c:v','libvpx-vp9','-pix_fmt','yuv420p','-crf','26','-b:v','0']
        args+=[str(out)]
        subprocess.run(args,check=True,timeout=120,stdout=subprocess.DEVNULL)
    shutil.rmtree(frames);report(100)

if __name__=='__main__':
    try:run(sys.argv[1])
    except Exception as exc:
        print(type(exc).__name__+': '+str(exc),file=sys.stderr);sys.exit(1)
