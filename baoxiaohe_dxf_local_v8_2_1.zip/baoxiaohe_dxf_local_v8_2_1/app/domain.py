"""Validated design data shared by persistence, preview export and preflight.

The canonical six-face net is a visualization primitive, NOT a die-cut box.
No glue tabs, material allowances or manufacturing tolerances are implied.
"""
from __future__ import annotations
import base64
import re
from io import BytesIO
from typing import Literal
from xml.etree import ElementTree as ET
from defusedxml.ElementTree import fromstring
from PIL import Image
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

MAX_RASTER_BYTES = 5 * 1024 * 1024
MAX_SVG_BYTES = 1024 * 1024
MAX_PIXELS = 25_000_000
COLOR = r'^#[0-9a-fA-F]{6}$'
SVG_ALLOWED = {'svg','g','path','rect','circle','ellipse','line','polyline','polygon','text','tspan','defs','clipPath','linearGradient','radialGradient','stop','title','desc','use'}


def image_data(src: str) -> tuple[str, bytes, tuple[int, int] | None]:
    """Allow self-contained data images only; never fetch a URL from a design."""
    match = re.fullmatch(r'data:(image/(?:png|jpeg|svg\+xml));base64,([A-Za-z0-9+/=\r\n]+)', src)
    if not match:
        raise ValueError('Only base64 PNG, JPEG or self-contained SVG images are allowed')
    mime, data = match.groups()
    if len(data) > (MAX_RASTER_BYTES * 4 // 3 + 1024):
        raise ValueError('Image exceeds 5 MiB')
    try:
        raw = base64.b64decode(data, validate=True)
    except Exception as exc:
        raise ValueError('Invalid base64 image') from exc
    if mime == 'image/svg+xml':
        if len(raw) > MAX_SVG_BYTES:
            raise ValueError('SVG exceeds 1 MiB')
        try:
            root = fromstring(raw, forbid_dtd=True)
        except Exception as exc:
            raise ValueError('Invalid or unsafe SVG') from exc
        if root.tag.split('}')[-1] != 'svg':
            raise ValueError('Expected an SVG root')
        for node in root.iter():
            if node.tag.split('}')[-1] not in SVG_ALLOWED:
                raise ValueError('Unsupported SVG element')
            for key, val in node.attrib.items():
                name = key.split('}')[-1].lower()
                if name.startswith('on') or name == 'style':
                    raise ValueError('SVG event handlers and inline styles are not accepted')
                if name in {'href','src'} and not val.startswith('#'):
                    raise ValueError('External or embedded SVG references are not accepted')
                if 'url(' in val.lower() and not re.fullmatch(r'url\(#[A-Za-z0-9_-]+\)', val.strip()):
                    raise ValueError('External SVG paint references are not accepted')
        return mime, raw, None
    if len(raw) > MAX_RASTER_BYTES:
        raise ValueError('Image exceeds 5 MiB')
    try:
        with Image.open(BytesIO(raw)) as im:
            expected = 'PNG' if mime == 'image/png' else 'JPEG'
            if im.format != expected or im.width * im.height > MAX_PIXELS:
                raise ValueError('Image format mismatch or image exceeds 25 megapixels')
            size = im.size
            im.verify()
    except Exception as exc:
        raise ValueError('Invalid raster image') from exc
    return mime, raw, size


class Box(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False, extra='forbid')
    length: float = Field(default=120, ge=30, le=500)
    width: float = Field(default=80, ge=20, le=400)
    height: float = Field(default=180, ge=30, le=600)


class DesignObject(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False, extra='ignore')
    id: str = Field(default='object', max_length=100)
    type: Literal['text','rect','image']
    x: float = Field(default=0, ge=-10000, le=10000)
    y: float = Field(default=0, ge=-10000, le=10000)
    w: float = Field(default=100, gt=0, le=10000)
    h: float = Field(default=50, gt=0, le=10000)
    rotation: float = Field(default=0, ge=-36000, le=36000)
    opacity: float = Field(default=1, ge=0, le=1)
    fill: str = Field(default='#222222', pattern=COLOR)
    text: str = Field(default='', max_length=5000)
    fontSize: float = Field(default=28, gt=0, le=500)
    fontWeight: int = Field(default=500, ge=100, le=900)
    fontStyle: Literal['normal','italic'] = 'normal'
    fontFamily: str = Field(default='Arial', max_length=100)
    letterSpacing: float = Field(default=0, ge=-20, le=100)
    lineHeight: float = Field(default=1.2, ge=.5, le=5)
    align: Literal['left','center','right'] = 'center'
    underline: bool = False
    vertical: bool = False
    wrap: bool = False
    textLines: list[str] | None = Field(default=None, max_length=5000)
    flipX: bool = False
    flipY: bool = False
    hidden: bool = False
    locked: bool = False
    radius: float = Field(default=0, ge=0, le=500)
    fit: Literal['contain','cover','stretch'] = 'contain'
    craft: str = Field(default='none', max_length=32)
    src: str = Field(default='', max_length=7_100_000)

    @model_validator(mode='after')
    def valid_text_lines(self):
        if self.textLines is not None:
            # Line positions are layout data, not permission to substitute hidden text.
            normalized=self.text.replace('\r\n','\n').replace('\r','\n').replace('\n','')
            if any('\n' in line or '\r' in line for line in self.textLines) or ''.join(self.textLines)!=normalized:
                raise ValueError('textLines must preserve the original text exactly')
        return self

    @field_validator('src')
    @classmethod
    def safe_image(cls, value: str) -> str:
        if value:
            image_data(value)
        return value


class DesignPayload(BaseModel):
    model_config = ConfigDict(extra='ignore')
    schemaVersion: int = Field(default=4, ge=1, le=4)
    geometry: Literal['six-face-box'] = 'six-face-box'
    box: Box = Field(default_factory=Box)
    bg: str = Field(default='#f4efe8', pattern=COLOR)
    accent: str = Field(default='#c7a679', pattern=COLOR)
    objects: list[DesignObject] = Field(default_factory=list, max_length=300)
    zoom: float = Field(default=1, ge=.08, le=4, allow_inf_nan=False)
    showDieline: bool = True
    showBleed: bool = True
    showSafe: bool = True
    snap: bool = True


def box_layout(box: Box) -> dict:
    """Same formulas as src/geometry.js; coordinates are SVG viewBox units."""
    L, W, H = box.length, box.width, box.height
    s = min(920 / (2 * (L + W)), 600 / (H + 2 * W), 2)
    x, y = (1180 - 2 * (L + W) * s) / 2, (760 - (H + 2 * W) * s) / 2
    def panel(a, b, w, h):
        return {'x': x + a*s, 'y': y + b*s, 'w': w*s, 'h': h*s}
    return {'scale': s, 'x': x, 'y': y, 'w': 2*(L+W)*s, 'h': (H+2*W)*s,
            'panels': {'back': panel(0,W,L,H), 'left': panel(L,W,W,H),
                       'front': panel(L+W,W,L,H), 'right': panel(2*L+W,W,W,H),
                       'top': panel(L+W,0,L,W), 'bottom': panel(L+W,W+H,L,W)}}


def preflight_payload(payload: DesignPayload, color_mode: str = 'RGB') -> dict:
    warnings = ['Six-face preview net only: no glue tabs, folding allowances or manufacturing validation.',
                'No ICC, spot-color, trapping, overprint or PDF/X verification is implemented.']
    errors = []
    images = []
    s = box_layout(payload.box)['scale']
    if color_mode.upper() != 'RGB':
        errors.append('ICC-managed CMYK export is not configured. Use the explicitly labeled RGB preview.')
    for obj in payload.objects:
        if obj.hidden:
            continue
        if obj.type == 'text':
            if obj.wrap and not obj.vertical and obj.textLines is None:
                errors.append(f'{obj.id}: wrapped text requires saved line layout. Open and save the document in the editor.')
            pt = obj.fontSize / s * 72 / 25.4
            if pt < 6:
                warnings.append(f'{obj.id}: effective font size {pt:.1f} pt is below 6 pt.')
        if obj.craft != 'none':
            warnings.append(f'{obj.id}: craft is metadata only; no separate production plate is generated.')
        if obj.type == 'image':
            if not obj.src:
                errors.append(f'{obj.id}: image source is missing.')
                continue
            _, _, size = image_data(obj.src)
            if size:
                dpi = min(size[0] / (obj.w/s) * 25.4, size[1] / (obj.h/s) * 25.4)
                images.append({'id': obj.id, 'pixels': list(size), 'effective_dpi': round(dpi, 1)})
                if dpi < 300:
                    warnings.append(f'{obj.id}: effective resolution {dpi:.0f} DPI is below 300 DPI at this placed size.')
    return {'ok': not errors, 'production_ready': False, 'errors': errors, 'warnings': warnings,
            'checks': {'color_mode': color_mode.upper(), 'object_count': len(payload.objects), 'images': images,
                       'geometry': 'six-face-box-preview', 'icc_managed': False}}
