from __future__ import annotations
import re
import math
from datetime import datetime, timezone
from typing import Any

ALL = {None, '', 'all', '\u5168\u90e8'}
SORTS = {'all', 'new', 'popular', 'uses', 'price_asc', 'price_desc'}

def has_price(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0

def asset_path(value: Any) -> str | None:
    if not isinstance(value, str) or not re.fullmatch(r'/assets/media/[A-Za-z0-9_./-]+\.(?:png|jpg|jpeg|webp|svg)', value, re.I):
        return None
    return None if '..' in value.split('/') or '//' in value else value

def present(item: dict, kind: str) -> dict:
    out = dict(item)
    out.pop('design_payload',None)
    out['has_design_document'] = isinstance(item.get('design_payload'),dict)
    out['thumbnail'] = asset_path(item.get('thumbnail'))
    out['dieline_thumbnail'] = asset_path(item.get('dieline_thumbnail'))
    out['gallery'] = [p for x in item.get('gallery', []) if (p := asset_path(x))]
    defaults=['#eee8df', '#b7a388', '#faf9f6', '#3c3c3c']
    colors=item.get('c') if isinstance(item.get('c'),list) else []
    out['c']=[v if isinstance(v,str) and re.fullmatch(r'#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?',v) else defaults[i] for i,v in enumerate((colors+defaults)[:4])]
    out['shape'] = item.get('shape') if item.get('shape') in {'box','gift','bottle','can','pouch','bag','cup','drawer','tube','jar','carton','mailer'} else 'box'
    if kind == 'templates':
        out['price'] = item.get('price') if has_price(item.get('price')) else None
        out['member_price'] = item.get('member_price') if has_price(item.get('member_price')) else None
        for k in ('style','use','tags','channels'): out[k] = item.get(k) or []
        out['author'] = item.get('author') if isinstance(item.get('author'), dict) else None
    else:
        out['materials'] = item.get('materials') or []
        out['sizes'] = item.get('sizes') or '\u5c3a\u5bf8\u672a\u540c\u6b65'
    return out

def model_index(catalog: dict) -> dict:
    index={}
    for row in catalog.get('models',[]):
        for key in ('id','code'):
            if row.get(key) is not None:index[str(row[key])]=row
    return index


def model_category(catalog:dict,row:dict,kind:str,index:dict) -> str | None:
    explicit=row.get('model_category') or row.get('sub') or row.get('subtype')
    if explicit:return str(explicit)
    reference=index.get(str(row.get('model')),{}) if kind=='templates' else row
    category=reference.get('sub') or reference.get('subtype')
    binding=catalog.get('model_bindings',{}).get(str(row.get('model')),{})
    return category or binding.get('category')


def model_terms(catalog:dict,row:dict,kind:str,index:dict) -> set[str]:
    values=[row.get(k) for k in ('model','model_category','sub','subtype','code')]
    values.append(model_category(catalog,row,kind,index))
    return {str(x) for x in values if x is not None and str(x)}


def number(value):
    return value if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>=0 else None


def date_number(value):
    if isinstance(value,(int,float)):return number(value)
    if not isinstance(value,str) or not value.strip():return None
    try:
        dt=datetime.fromisoformat(value.replace('Z','+00:00'))
        return dt.replace(tzinfo=timezone.utc).timestamp() if dt.tzinfo is None else dt.timestamp()
    except (ValueError,OverflowError):return None


def sort_available(rows,sort):
    if sort=='new':return any(date_number(x.get('created_at')) is not None for x in rows)
    if sort=='uses':return any(number(x.get('use_count',x.get('uses'))) is not None for x in rows)
    if sort=='popular':return any(number(x.get('views')) is not None for x in rows)
    return True


def query_items(catalog: dict, kind: str, query: str, sort: str, filters: dict) -> list[dict]:
    rows = [present(x,kind) for x in catalog[kind]]
    index=model_index(catalog)
    if query.strip():
        text = query.casefold().strip()
        def searchable(x):
            parts = [x.get(k,'') for k in ('title','code','model','type','sub','subtype','material','industry')]
            parts += x.get('tags',[]) + x.get('style',[]) + x.get('materials',[])
            return ' '.join(str(v) for v in parts if v is not None).casefold()
        rows = [x for x in rows if text in searchable(x)]
    for key, value in filters.items():
        if value in ALL: continue
        if key in ('style','use'): rows = [x for x in rows if value in x.get(key,[])]
        elif key == 'channel': rows = [x for x in rows if value in x.get('channels',[])]
        elif key == 'material': rows = [x for x in rows if value == x.get('material') or value in x.get('materials',[])]
        elif key == 'model': rows = [x for x in rows if str(value) in model_terms(catalog,x,kind,index)]
        elif key == 'price':
            if value == 'free': rows = [x for x in rows if x.get('price') == 0]
            elif value == 'member_free': rows = [x for x in rows if x.get('member_price') == 0]
            elif value == 'paid': rows = [x for x in rows if has_price(x.get('price')) and x['price'] > 0]
        elif key == 'printable': rows = [x for x in rows if bool(x.get('printable')) == value]
        elif key == 'type' and kind == 'models': rows = [x for x in rows if value in {x.get('type'),x.get('sub')}]
        else: rows = [x for x in rows if str(x.get(key,'')) == value]
    if sort in ('popular','uses'):
        metric=(lambda x:number(x.get('views'))) if sort=='popular' else (lambda x:number(x.get('use_count',x.get('uses'))))
        rows.sort(key=lambda x:(metric(x) is None,-(metric(x) or 0)))
    elif sort == 'new':
        rows.sort(key=lambda x:(date_number(x.get('created_at')) is None,-(date_number(x.get('created_at')) or 0)))
    elif sort.startswith('price_'):
        sign = -1 if sort == 'price_desc' else 1
        rows.sort(key=lambda x:(not has_price(x.get('price')),sign*x['price'] if has_price(x.get('price')) else 0,x['id']))
    return rows

def metadata(catalog: dict) -> dict:
    categories = dict(catalog['categories'])
    channels = sorted({v for row in catalog['templates'] for v in row.get('channels',[])})
    categories['channels'] = ['\u5168\u90e8'] + channels
    index=model_index(catalog);options={};sorts={}
    for kind in ('templates','models'):
        counts={}
        for row in catalog[kind]:
            category=model_category(catalog,row,kind,index)
            value=category or str(row.get('model') or row.get('code') or '')
            if not value:continue
            key=value
            entry=counts.setdefault(key,{'value':value,'label':category or value,'count':0,'types':[], 'unclassified':not bool(category)})
            entry['count']+=1
            if row.get('type') not in entry['types']:entry['types'].append(row.get('type'))
        options[kind]=list(counts.values())
        sorts[kind]=[sort for sort in ('all','new','uses','popular') if sort_available(catalog[kind],sort)]
        type_key='templateTypes' if kind=='templates' else 'modelTypes'
        categories[type_key]=list(dict.fromkeys(categories.get(type_key,['\u5168\u90e8'])+[x['type'] for x in catalog[kind] if x.get('type')]))
    return {'template_count':len(catalog['templates']), 'model_count':len(catalog['models']),
        'catalog_scope':catalog.get('scope','unverified'), 'categories':categories,
        'model_options':options, 'available_sorts':sorts,
        'thumbnail_count':sum(bool(asset_path(x.get('thumbnail'))) for k in ('templates','models') for x in catalog[k]),
        'verified_records':sum(x.get('source_verified') is True for k in ('templates','models') for x in catalog[k]),
        'prices_verified':False,'payments_configured':False, 'pricing':[],
        'scope_note':'Classification can be sample/admin supplied. It does not prove original geometry, assets or usage metrics.'}
