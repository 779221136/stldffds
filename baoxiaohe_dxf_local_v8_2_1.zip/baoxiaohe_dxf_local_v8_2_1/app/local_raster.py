"""Deterministic LOCAL CPU triangle rasterisation, with depth buffer and panel textures.
Not a path tracer. No remote services, arbitrary asset paths or network requests.
"""
from __future__ import annotations
import base64
import math
from io import BytesIO
from typing import Literal
import numpy as np
from PIL import Image
from pydantic import BaseModel, Field, ConfigDict, model_validator
from .domain import image_data
from .structure import StructureSpec, build_structure, pose, progress

class RenderView(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    fold: float = Field(1,ge=0,le=1)
    opening: float = Field(0,ge=0,le=1)
    yaw: float = Field(-28,ge=-360,le=360)
    pitch: float = Field(20,ge=-85,le=85)
    zoom: float = Field(1,ge=.3,le=2)
    light: float = Field(1,ge=.2,le=1.8)
    background: str = Field('#edf0f4',pattern=r'^#[0-9A-Fa-f]{6}$')
    transparent: bool = False
    framing: Literal['pose','motion'] = 'pose'

class LocalRenderRequest(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    spec: StructureSpec = Field(default_factory=StructureSpec)
    view: RenderView = Field(default_factory=RenderView)
    textures: dict[str,str] = Field(default_factory=dict,max_length=13)
    exterior: str = Field('#f9f5ef',pattern=r'^#[0-9A-Fa-f]{6}$')
    interior: str = Field('#e8ddc9',pattern=r'^#[0-9A-Fa-f]{6}$')
    format: Literal['png','frames','mp4','webm'] = 'png'
    long_edge: Literal[256,512,1024,2048,3072,4096] = 1024
    aspect: Literal['1:1','4:3','3:4','16:9','9:16'] = '4:3'
    motion: Literal['fold','open','rotate'] = 'open'
    seconds: int = Field(3,ge=1,le=6)
    fps: int = Field(12,ge=6,le=24)

    @model_validator(mode='after')
    def resources(self):
        if self.format!='png' and (self.long_edge>1024 or self.seconds*self.fps>120):
            raise ValueError('Local video/sequence: long edge <=1024, <=120 frames')
        if sum(len(s) for s in self.textures.values()) > 9_000_000:
            raise ValueError('Combined panel textures exceed 9 MB base64')
        known={p['id'] for p in build_structure(self.spec)['panels']}
        pixels=0
        for key,src in self.textures.items():
            if key not in known: raise ValueError('Unknown texture panel: '+key)
            mime,raw,size=image_data(src)
            if mime not in {'image/png','image/jpeg'} or not size:
                raise ValueError('Panel texture must be embedded PNG/JPEG, not SVG or URL')
            if size[0]*size[1]>4_194_304:raise ValueError('Panel texture exceeds 4 megapixels')
            pixels+=size[0]*size[1]
        if pixels>16_777_216:raise ValueError('Combined textures exceed 16 megapixels')
        return self

def rgb(color): return np.array([int(color[i:i+2],16) for i in (1,3,5)],float)

def dimensions(req):
    a,b=map(int,req.aspect.split(':'));edge=req.long_edge
    w,h=(edge,round(edge*b/a)) if a>=b else (round(edge*a/b),edge)
    if req.format in {'mp4','webm'}: w-=w%2;h-=h%2
    return w,h

def rotation(view):
    y=math.radians(view.yaw);p=math.radians(view.pitch)
    Y=np.array([[math.cos(y),0,math.sin(y)],[0,1,0],[-math.sin(y),0,math.cos(y)]])
    X=np.array([[1,0,0],[0,math.cos(p),-math.sin(p)],[0,math.sin(p),math.cos(p)]])
    return X@Y

def triangles(model,view):
    posed=pose(model,view.fold,view.opening)['panels'];allpts=[];out=[]
    thickness=model['spec']['thickness']
    layering=model.get('previewLayering',{})
    inset_scale=layering.get('spacing',thickness)*progress(view.fold,layering['stage']) if layering else thickness
    for desc,pp in zip(model['panels'],posed):
        if desc.get('triangles'):
            M=np.asarray(pp['matrix'],float)
            def world(coords):
                q=np.asarray([[x,y,0,1] for x,y in coords],float)
                return (M@q.T).T[:,:3]
            b=desc['bounds'];seed=world(desc['triangles'][0])
            n=-np.cross(seed[1]-seed[0],seed[2]-seed[0]);n/=np.linalg.norm(n)
            offset=n*thickness/2
            inset=n*inset_scale*desc.get('visualInset',0)
            for tri in desc['triangles']:
                v=world(tri)+inset;uv=np.array([[(x-b[0])/(b[2]-b[0]),(y-b[1])/(b[3]-b[1])] for x,y in tri])
                front=v+offset;back=v-offset;allpts.extend(front);allpts.extend(back)
                out.append((front[[0,2,1]],uv[[0,2,1]],desc['id'],'front'))
                out.append((back,uv,desc['id'],'back'))
            for ring in [desc['polygon']]+desc.get('holes',[]):
                v=world(ring)+inset;front=v+offset;back=v-offset
                for i in range(len(v)):
                    j=(i+1)%len(v);q=np.array([front[i],front[j],back[j],back[i]])
                    for inds in ([0,1,2],[0,2,3]):out.append((q[inds],np.zeros((3,2)),desc['id'],'edge'))
            continue
        v=np.array(pp['points'],float);n=-np.cross(v[1]-v[0],v[2]-v[0]);n/=np.linalg.norm(n)
        v=v+n*thickness*desc.get('visualInset',0)
        front=v+n*thickness/2;back=v-n*thickness/2
        allpts.extend(front);allpts.extend(back)
        b=desc['bounds'];uv=np.array([[(x-b[0])/(b[2]-b[0]),(y-b[1])/(b[3]-b[1])] for x,y in desc['polygon']])
        for i in range(1,len(v)-1):
            out.append((front[[0,i+1,i]],uv[[0,i+1,i]],desc['id'],'front'))
            out.append((back[[0,i,i+1]],uv[[0,i,i+1]],desc['id'],'back'))
        for i in range(len(v)):
            j=(i+1)%len(v)
            q=np.array([front[i],front[j],back[j],back[i]])
            for inds in ([0,1,2],[0,2,3]):out.append((q[inds],np.zeros((3,2)),desc['id'],'edge'))
    radius=model['motionRadius'] if view.framing=='motion' else max(float(np.linalg.norm(x)) for x in allpts)*1.06
    return out,radius

def decode_textures(req):
    result={}
    for key,src in req.textures.items():
        _,raw,_=image_data(src)
        with Image.open(BytesIO(raw)) as image:
            result[key]=np.asarray(image.convert('RGBA')).copy()
    return result

def render_image(req: LocalRenderRequest,model=None,textures=None):
    model=model or build_structure(req.spec);textures=textures if textures is not None else decode_textures(req)
    w,h=dimensions(req);view=req.view;R=rotation(view);mesh,radius=triangles(model,view)
    scale=min(w,h)*.44/radius*view.zoom
    canvas=np.zeros((h,w,4),dtype=np.uint8)
    if not view.transparent:canvas[:,:,:3]=rgb(view.background);canvas[:,:,3]=255
    # Compare depths at the same precision. Float32 storage versus float64
    # barycentrics caused alternating winners on coincident surfaces.
    depth=np.full((h,w),-np.inf,dtype=np.float64)
    depth_epsilon=max(1e-9,radius*1e-9)
    light=np.array([-.35,.65,.8]);light/=np.linalg.norm(light)
    for vertices,uv,panel,side in mesh:
        q=vertices@R.T;n=np.cross(q[1]-q[0],q[2]-q[0]);mag=np.linalg.norm(n)
        if mag<1e-9 or n[2]<=1e-9:continue
        n/=mag;shade=(.66+.34*max(0,float(n@light)))*view.light
        p=np.column_stack((w/2+q[:,0]*scale,h/2-q[:,1]*scale))
        x0=max(0,int(np.floor(p[:,0].min())));x1=min(w,int(np.ceil(p[:,0].max()))+1)
        y0=max(0,int(np.floor(p[:,1].min())));y1=min(h,int(np.ceil(p[:,1].max()))+1)
        if x1<=x0 or y1<=y0:continue
        ax,ay=p[0];bx,by=p[1];cx,cy=p[2]
        den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
        if abs(den)<1e-9:continue
        tex=textures.get(panel) if side=='front' else None
        base=rgb(req.exterior if side=='front' else req.interior)
        if side=='edge':base=base*.88
        # Bounded row blocks: high-resolution exports do NOT allocate per-triangle full images.
        for ya in range(y0,y1,64):
            yb=min(y1,ya+64);yy,xx=np.mgrid[ya:yb,x0:x1];xx=xx+.5;yy=yy+.5
            A=((by-cy)*(xx-cx)+(cx-bx)*(yy-cy))/den
            B=((cy-ay)*(xx-cx)+(ax-cx)*(yy-cy))/den;C=1-A-B
            z=A*q[0,2]+B*q[1,2]+C*q[2,2]
            mask=(A>=-1e-7)&(B>=-1e-7)&(C>=-1e-7)&(z>depth[ya:yb,x0:x1]+depth_epsilon)
            if not mask.any():continue
            if tex is not None:
                u=A[mask]*uv[0,0]+B[mask]*uv[1,0]+C[mask]*uv[2,0]
                v=A[mask]*uv[0,1]+B[mask]*uv[1,1]+C[mask]*uv[2,1]
                tx=np.clip(np.rint(u*(tex.shape[1]-1)).astype(int),0,tex.shape[1]-1)
                ty=np.clip(np.rint(v*(tex.shape[0]-1)).astype(int),0,tex.shape[0]-1)
                sample=tex[ty,tx].astype(float);alpha=sample[:,3:4]/255
                cols=(sample[:,:3]*alpha+base*(1-alpha))*shade
            else:cols=np.broadcast_to(base*shade,(int(mask.sum()),3))
            region=canvas[ya:yb,x0:x1];region[mask,:3]=np.clip(cols,0,255).astype(np.uint8);region[mask,3]=255
            depth[ya:yb,x0:x1][mask]=z[mask]
    return Image.fromarray(canvas)

def animation_request(req,index,count):
    t=index/max(1,count-1);view=req.view.model_copy(update={'framing':'motion'})
    if req.motion=='fold':view=view.model_copy(update={'fold':t,'opening':0})
    elif req.motion=='open':view=view.model_copy(update={'fold':1,'opening':t})
    else:view=view.model_copy(update={'yaw':req.view.yaw+360*index/count})
    return req.model_copy(update={'view':view})
