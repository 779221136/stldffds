"""Owner-scoped design history and retry-safe save receipts (SQLite edition)."""
from __future__ import annotations
import hashlib
import json
import re
import time
from fastapi import HTTPException

HISTORY_LIMIT = 50
RECEIPT_TTL = 24 * 60 * 60


def migrate(connection):
    columns = {row[1] for row in connection.execute('PRAGMA table_info(design_revisions)')}
    if columns and 'user_id' not in columns:
        with connection:
            connection.execute('ALTER TABLE design_revisions ADD COLUMN user_id INTEGER')
            connection.execute('''UPDATE design_revisions SET user_id=(
                SELECT user_id FROM designs WHERE designs.id=design_revisions.design_id)''')
    connection.executescript('''
        CREATE TABLE IF NOT EXISTS design_revisions(
          design_id INTEGER NOT NULL, version INTEGER NOT NULL, user_id INTEGER NOT NULL,
          name TEXT NOT NULL, kind TEXT NOT NULL, source_id INTEGER NOT NULL,
          payload TEXT NOT NULL, created_at INTEGER NOT NULL, reason TEXT NOT NULL,
          PRIMARY KEY(design_id,version),
          FOREIGN KEY(design_id) REFERENCES designs(id) ON DELETE CASCADE);
        CREATE INDEX IF NOT EXISTS idx_revision_owner ON design_revisions(user_id,design_id,version);
        CREATE TABLE IF NOT EXISTS design_save_receipts(
          user_id INTEGER NOT NULL, key TEXT NOT NULL, request_hash TEXT NOT NULL,
          design_id INTEGER NOT NULL, result TEXT NOT NULL, created_at INTEGER NOT NULL,
          PRIMARY KEY(user_id,key),
          FOREIGN KEY(design_id) REFERENCES designs(id) ON DELETE CASCADE);
        CREATE INDEX IF NOT EXISTS idx_save_receipt_age ON design_save_receipts(created_at);
    ''')
    # Only the existing current version can be backfilled; never invent older history.
    connection.execute('''INSERT OR IGNORE INTO design_revisions
      (design_id,version,user_id,name,kind,source_id,payload,created_at,reason)
      SELECT id,version,user_id,name,kind,source_id,payload,updated_at,'migration'
      FROM designs''')


def request_hash(body) -> str:
    canonical = json.dumps(body.model_dump(mode='json'), sort_keys=True,
                           separators=(',', ':'), ensure_ascii=False)
    return hashlib.sha256(canonical.encode()).hexdigest()


def validate_key(key: str | None) -> str | None:
    if key is not None and not re.fullmatch(r'[A-Za-z0-9_.:-]{8,128}', key):
        raise HTTPException(422, 'Invalid Idempotency-Key')
    return key


def receipt(connection, user_id: int, key: str | None, fingerprint: str):
    if not key:
        return None
    row = connection.execute('''SELECT request_hash,result FROM design_save_receipts
      WHERE user_id=? AND key=? AND created_at>?''',
      (user_id,key,int(time.time())-RECEIPT_TTL)).fetchone()
    if row:
        if row['request_hash'] != fingerprint:
            raise HTTPException(409, 'Idempotency-Key was already used for a different save')
        return json.loads(row['result'])
    return None


def remember_receipt(connection,user_id,key,fingerprint,result):
    if not key:
        return
    now=int(time.time())
    connection.execute('DELETE FROM design_save_receipts WHERE created_at<=?', (now-RECEIPT_TTL,))
    connection.execute('''INSERT INTO design_save_receipts
      (user_id,key,request_hash,design_id,result,created_at) VALUES(?,?,?,?,?,?)''',
      (user_id,key,fingerprint,result['id'],json.dumps(result),now))


def checkpoint(connection,design_id:int,user_id:int,reason='save'):
    connection.execute('''INSERT OR IGNORE INTO design_revisions
      (design_id,version,user_id,name,kind,source_id,payload,created_at,reason)
      SELECT id,version,user_id,name,kind,source_id,payload,updated_at,?
      FROM designs WHERE id=? AND user_id=?''',(reason,design_id,user_id))
    # Keep the latest 50 real checkpoints. A restore creates a NEW checkpoint.
    connection.execute('''DELETE FROM design_revisions WHERE design_id=? AND user_id=?
      AND version NOT IN (SELECT version FROM design_revisions WHERE design_id=?
      AND user_id=? ORDER BY version DESC LIMIT ?)''',
      (design_id,user_id,design_id,user_id,HISTORY_LIMIT))
