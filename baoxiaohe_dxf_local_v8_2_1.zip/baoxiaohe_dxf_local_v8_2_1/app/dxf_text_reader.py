"""Bounded local ASCII-DXF decoding. No geometry repair or lossy decoding.

R2004 and older use $DWGCODEPAGE (default cp1252); R2007+ uses UTF-8.
A BOM is handled as transport metadata and CR/CRLF line endings are normalized.
An explicit, allowlisted encoding override is for known nonstandard exports,
never a heuristic that tries codecs until one happens to accept the bytes.
"""
from __future__ import annotations

from io import StringIO
from typing import Literal
import codecs

import ezdxf
from ezdxf.filemanagement import dxf_stream_info
from ezdxf.lldxf.const import DXFError
from ezdxf.lldxf.tagger import ascii_tags_loader
from ezdxf.lldxf.validator import is_dxf_stream
from ezdxf.tools.codepage import codepage_to_encoding

DxfEncoding = Literal['auto', 'utf-8', 'gbk', 'cp950', 'cp1252', 'cp932', 'cp949']
ALLOWED_ENCODINGS = {'auto', 'utf-8', 'gbk', 'cp950', 'cp1252', 'cp932', 'cp949'}
MAX_DXF_BYTES = 5 * 1024 * 1024


def _newlines(text: str) -> str:
    return text.replace('\r\n', '\n').replace('\r', '\n')


def _declared_codepage(probe: str) -> str | None:
    # Read actual HEADER tags, not matches in comments, entity text, or a
    # truncated prefix. The caller already caps total upload size at 5 MiB.
    tags = iter(ascii_tags_loader(StringIO(probe)))
    if next(tags, None) != (0, 'SECTION') or next(tags, None) != (2, 'HEADER'):
        return None
    for tag in tags:
        if tag == (0, 'ENDSEC'):
            return None
        if tag == (9, '$DWGCODEPAGE'):
            value = next(tags, None)
            if value is None or value.code != 3:
                raise ValueError('Invalid $DWGCODEPAGE group')
            return str(value.value).strip()
    return None


def read_ascii_dxf(raw: bytes, encoding: DxfEncoding = 'auto'):
    """Return (Drawing, decoding metadata, non-lossy normalization warnings).

    Only UTF-8 BOM is accepted. UTF-16/32, DWG, binary DXF, archives and PDF
    receive distinct errors. Original input bytes are never modified on disk.
    The geometry importer retains all its existing quotas and validation.
    """
    if encoding not in ALLOWED_ENCODINGS:
        raise ValueError('[DXF_ENCODING_OPTION] Unsupported encoding selection')
    if not raw:
        raise ValueError('[DXF_EMPTY] The DXF file is empty; select the original drawing')
    if len(raw) > MAX_DXF_BYTES:
        raise ValueError('DXF exceeds 5 MiB')
    if raw.startswith(b'AutoCAD Binary DXF'):
        raise ValueError('[DXF_BINARY] Binary DXF is not supported; export text/ASCII DXF in CAD')
    if raw[:4] == b'AC10':
        raise ValueError('[DXF_DWG] This appears to be a DWG file. Use CAD Save As DXF; renaming the extension is not conversion')
    if raw.startswith(b'%PDF') or raw.startswith((b'PK\x03\x04', b'PK\x05\x06')):
        raise ValueError('[DXF_FORMAT] This is PDF/ZIP content, not a text DXF file')
    if raw.startswith((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE, codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        raise ValueError('[DXF_UNICODE_FORMAT] UTF-16/UTF-32 text is not supported; export a text DXF in CAD, preferably R2007 or later (UTF-8)')

    has_bom = raw.startswith(codecs.BOM_UTF8)
    body = raw[len(codecs.BOM_UTF8):] if has_bom else raw
    if b'\x00' in body:
        raise ValueError('[DXF_FORMAT] NUL bytes detected; check for binary DXF or UTF-16 instead of a text DXF')
    # latin-1 is only a reversible metadata probe, never the decoded document.
    probe = _newlines(body.decode('latin-1'))
    if not is_dxf_stream(StringIO(probe)):
        raise ValueError('[DXF_FORMAT] No valid ASCII DXF SECTION/group-code structure; export DXF from CAD, not by renaming another file')
    try:
        info = dxf_stream_info(StringIO(probe))
        codepage = _declared_codepage(probe)
    except (DXFError, ValueError, StopIteration, EOFError, IndexError) as e:
        raise ValueError('[DXF_HEADER] Invalid or incomplete DXF HEADER/group codes; re-export from CAD') from e

    warnings: list[str] = []
    if encoding != 'auto':
        selected = encoding
        origin = 'manual'
        if has_bom and selected != 'utf-8':
            raise ValueError('[DXF_ENCODING_CONFLICT] File has a UTF-8 BOM; select Auto or UTF-8 rather than a legacy encoding')
        warnings.append('Manual DXF text encoding: '+selected+'. Verify layer names and line-role mappings before confirming.')
    elif has_bom:
        selected = 'utf-8'
        origin = 'utf8-bom'
        warnings.append('UTF-8 BOM removed for parsing. Geometry and original file bytes are unchanged.')
        if info.encoding != 'utf-8':
            warnings.append('UTF-8 BOM takes precedence over the legacy DXF codepage; verify layer names.')
    else:
        selected = info.encoding
        origin = 'version-utf8' if info.version >= 'AC1021' else ('header-codepage' if codepage else 'legacy-default')
        if info.version < 'AC1021' and codepage:
            # ezdxf falls back to cp1252 for unknown declarations. Do not accept
            # that silently for manufacturing drawings with semantic layer names.
            if not any(codepage.upper().endswith(cp) for cp in codepage_to_encoding):
                raise ValueError('[DXF_CODEPAGE] Unrecognized legacy $DWGCODEPAGE; select the known source encoding or re-export as R2007+ text DXF')
        if origin == 'legacy-default' and any(byte >= 128 for byte in body):
            warnings.append('Legacy DXF has no $DWGCODEPAGE. Used the documented cp1252 default; if layer names are incorrect, choose the known source encoding and parse again.')

    try:
        text = _newlines(body.decode(selected, errors='strict'))
    except UnicodeDecodeError as e:
        raise ValueError(
            '[DXF_ENCODING] File bytes do not match '+selected+' ('+origin+'). '
            'No bytes were discarded. Select the known source encoding (for example GBK for a legacy Chinese export), '
            'or re-export text DXF in CAD. This message does not establish that geometry is damaged.'
        ) from e
    if b'\r' in body:
        warnings.append('CR/CRLF record endings normalized to LF for parsing; drawing coordinates are unchanged.')
    try:
        drawing = ezdxf.read(StringIO(text))
    except (DXFError, ValueError, StopIteration, EOFError, IndexError) as e:
        # Do not run recover automatically: recovery can remove entities or
        # alter structure. A successful parse is not manufacturing validation.
        raise ValueError(
            '[DXF_STRUCTURE] Text decoding succeeded with '+selected+', but the DXF group-code/section structure is invalid or unsupported. '
            'Re-export from CAD or provide the original DXF for diagnosis; changing encoding alone will not repair structure.'
        ) from e
    metadata = {
        'encoding': selected, 'detected_encoding': info.encoding, 'encoding_source': origin,
        'declared_codepage': codepage, 'source_version': info.version,
        'declared_units': info.insert_units,
        'utf8_bom_removed': has_bom, 'line_endings_normalized': b'\r' in body,
    }
    return drawing, metadata, warnings
