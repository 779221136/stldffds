"""Rendering-only layer separation for exactly coplanar imported carton panels.

This does NOT change the dieline, kinematic hinges, manufacturing dimensions or
solve assembly/collision constraints. Area order is a *preview proposal*, not a
claim to infer the physical assembly from a flat DXF. Kept deterministic by ID.
"""
from __future__ import annotations
import numpy as np
from shapely.geometry import Polygon
from .structure import pose


def assign_preview_layers(model: dict) -> dict:
    panels = model['panels']
    posed = pose(model, 1, 0)['panels']
    matrices = [np.asarray(p['matrix'], dtype=float) for p in posed]
    points = [np.asarray(p['points'], dtype=float) for p in posed]
    # -Z is the artwork/exterior normal for every authored, CCW local face.
    normals = [-m[:3, 2] / np.linalg.norm(m[:3, 2]) for m in matrices]
    areas = [Polygon(p['polygon'], p.get('holes', [])).area for p in panels]
    tolerance = max(1e-7, max(np.max(np.abs(v)) for v in points) * 1e-8)
    overlaps, opposed = [], []
    for i in range(len(panels)):
        n = normals[i]
        origin = points[i][0]
        u = points[i][1] - origin
        u = u / np.linalg.norm(u)
        v = np.cross(n, u)
        def projected_polygon(k):
            def ring(coords):
                q = np.asarray([[x, y, 0, 1] for x, y in coords], float)
                world = (matrices[k] @ q.T).T[:, :3] - origin
                return np.column_stack((world @ u, world @ v))
            return Polygon(ring(panels[k]['polygon']), [ring(h) for h in panels[k].get('holes', [])])
        a = None
        for j in range(i + 1, len(panels)):
            alignment = float(n @ normals[j])
            if abs(alignment) < 1 - 1e-8:
                continue
            if np.max(np.abs((points[j] - origin) @ n)) > tolerance:
                continue
            if a is None:
                a = projected_polygon(i)
            area = a.intersection(projected_polygon(j)).area
            if area <= max(1e-6, min(areas[i], areas[j]) * 1e-8):
                continue
            if alignment < 0:
                opposed.append([panels[i]['id'], panels[j]['id']])
            else:
                overlaps.append((i, j, area))
    # Larger panels are proposed as outer covers. Smaller dust/glue/tuck panels
    # are placed underneath only if their fully folded areas really overlap.
    order = sorted(range(len(panels)), key=lambda i: (-areas[i], panels[i]['id']))
    neighbors = {i: set() for i in range(len(panels))}
    for i, j, _ in overlaps:
        neighbors[i].add(j)
        neighbors[j].add(i)
    depths = {}
    for i in order:
        outer = [depths[j] for j in neighbors[i] if j in depths]
        depths[i] = max(outer, default=-1) + 1
        panels[i]['visualInset'] = -depths[i]
    info = {
        'method': 'closed-coplanar-area-order-preview-only',
        'stage': [.85, 1],
        'spacing': max(.01, float(model['spec']['thickness']) * 1.05),
        'pairs': [{'outer': panels[min((i,j), key=lambda k: (depths[k], -areas[k], panels[k]['id']))]['id'],
                   'panels': [panels[i]['id'], panels[j]['id']], 'area': round(area, 6)} for i,j,area in overlaps],
        'opposedNormals': opposed,
        'production_validated': False,
    }
    model['previewLayering'] = info
    model['motionRadius'] += max(depths.values(), default=0) * info['spacing']
    if overlaps:
        model['warnings'].append(
            f'{len(overlaps)} coplanar overlap pairs use preview-only layer spacing '
            '(larger panels outside). Verify assembly order; no dieline or manufacturing compensation is applied.')
    if opposed:
        model['warnings'].append(
            f'{len(opposed)} overlaps have opposing face normals: verify the fold directions; '
            'no physical assembly order was inferred for these faces.')
    return info
