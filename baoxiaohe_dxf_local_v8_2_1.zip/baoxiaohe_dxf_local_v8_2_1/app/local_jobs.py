"""Owner-scoped, single-worker local render queue.
Queue/state survive application restart; unfinished RUNNING work becomes FAILED.
This service does not call a cloud, download models, or require API keys.
"""
from __future__ import annotations
import hashlib
import json
import os
import re
import secrets
import shutil
import signal
import sqlite3
import subprocess
import sys
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import FileResponse
from .structure import StructureSpec, build_structure, export_svg, export_dxf
from .local_raster import LocalRenderRequest, dimensions
from .local_worker import ffmpeg_binary

router=APIRouter(prefix='/api/local',tags=['Local structures and rendering'])
COOKIE='bxh_local_render'
PROJECT=Path(__file__).resolve().parents[1]
EXT={'png':'png','frames':'zip','mp4':'mp4','webm':'webm'}
MIME={'png':'image/png','frames':'application/zip','mp4':'video/mp4','webm':'video/webm'}

def owner(request):
    token=request.cookies.get(COOKIE,'')
    if not re.fullmatch('[a-f0-9]{64}',token):
        raise HTTPException(401,'Open the local workbench to initialise its private session')
    return hashlib.sha256(token.encode()).hexdigest()

def manager(request):return request.app.state.local_renderer

class LocalJobManager:
    def __init__(self,root: Path):
        self.root=root.resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'queue.sqlite';self.stop_event=threading.Event();self.thread=None
        with self.db() as c:
            c.executescript('''PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,owner TEXT NOT NULL,status TEXT NOT NULL,
            format TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,error TEXT);
            CREATE INDEX IF NOT EXISTS jobs_owner ON jobs(owner,created);''')
            c.execute("UPDATE jobs SET status='failed',error='Local application stopped during rendering; resubmit the job',updated=? WHERE status='running'",(time.time(),))
    @contextmanager
    def db(self):
        c=sqlite3.connect(self.path,timeout=10);c.row_factory=sqlite3.Row
        try:yield c;c.commit()
        except Exception:c.rollback();raise
        finally:c.close()
    def start(self):
        self.thread=threading.Thread(target=self.loop,daemon=True,name='local-render-worker');self.thread.start()
    def close(self):
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=5)
    def view(self,row):
        r=dict(row);r.pop('owner',None);r['progress']=100 if r['status']=='succeeded' else 0
        if r['status']=='running':
            try:r['progress']=min(99,max(0,int(json.loads((self.root/r['id']/'progress.json').read_text(encoding='utf-8'))['progress'])))
            except (OSError,ValueError,KeyError):pass
        if r['status']=='succeeded':r['download']='/api/local/jobs/'+r['id']+'/result'
        return r
    def add(self,who,req):
        now=time.time();jid=secrets.token_hex(16);dest=self.root/jid
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT count(*) FROM jobs WHERE owner=? AND status IN ('queued','running')",(who,)).fetchone()[0]>=3:
                raise HTTPException(429,'At most 3 active local jobs per session')
            if c.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]>=8:
                raise HTTPException(429,'Local renderer queue is full (8 jobs)')
            if c.execute('SELECT count(*) FROM jobs').fetchone()[0]>=100:
                raise HTTPException(429,'Local history reached 100 jobs; delete old jobs first')
            disk=0
            for p in self.root.glob('*/*'):
                try:
                    if p.is_file():disk+=p.stat().st_size
                except FileNotFoundError:pass
            if disk>1024*1024*1024:raise HTTPException(429,'Local render storage exceeds 1 GiB; delete old jobs')
            dest.mkdir(mode=0o700)
            try:
                (dest/'input.json').write_text(req.model_dump_json(),encoding='utf-8')
                c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,NULL)',(jid,who,'queued',req.format,now,now))
            except Exception:shutil.rmtree(dest,ignore_errors=True);raise
        return self.get(who,jid)
    def get(self,who,jid):
        with self.db() as c:r=c.execute('SELECT * FROM jobs WHERE owner=? AND id=?',(who,jid)).fetchone()
        if not r:raise HTTPException(404,'Local job not found')
        return self.view(r)
    def list(self,who):
        with self.db() as c:rows=c.execute('SELECT * FROM jobs WHERE owner=? ORDER BY created DESC LIMIT 100',(who,)).fetchall()
        return [self.view(r) for r in rows]
    def cancel(self,who,jid):
        self.get(who,jid)
        with self.db() as c:
            c.execute("UPDATE jobs SET status='cancelled',updated=? WHERE owner=? AND id=? AND status IN ('queued','running')",(time.time(),who,jid))
        return self.get(who,jid)
    def delete(self,who,jid):
        r=self.get(who,jid)
        if r['status'] in {'queued','running'}:raise HTTPException(409,'Cancel the active job before deleting it')
        # A cancelled worker may still be shutting down; do not remove its cwd underneath it.
        if (self.root/jid/'working.lock').exists():raise HTTPException(409,'Worker is stopping; retry shortly')
        with self.db() as c:c.execute('DELETE FROM jobs WHERE id=? AND owner=?',(jid,who))
        shutil.rmtree(self.root/jid,ignore_errors=True)
    def finish(self,jid,status,error=None):
        with self.db() as c:c.execute("UPDATE jobs SET status=?,error=?,updated=? WHERE id=? AND status='running'",(status,error,time.time(),jid))
    def loop(self):
        while not self.stop_event.is_set():
            try:
                with self.db() as c:
                    c.execute('BEGIN IMMEDIATE')
                    row=c.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
                    if row:c.execute("UPDATE jobs SET status='running',updated=? WHERE id=?",(time.time(),row['id']))
                if not row:self.stop_event.wait(.15);continue
                self.execute(dict(row))
            except Exception as exc:
                # Do not silently claim a successful task after infrastructure failure.
                print('Local render controller:',type(exc).__name__,str(exc),file=sys.stderr)
                self.stop_event.wait(.3)
    def execute(self,row):
        jid=row['id'];dest=self.root/jid;proc=None
        try:
            (dest/'working.lock').touch();deadline=time.monotonic()+300
            with (dest/'worker.log').open('wb') as log:
                proc=subprocess.Popen([sys.executable,'-m','app.local_worker',str(dest)],cwd=PROJECT,
                                      stdout=log,stderr=log,start_new_session=os.name!='nt')
                while proc.poll() is None:
                    with self.db() as c:r=c.execute('SELECT status FROM jobs WHERE id=?',(jid,)).fetchone()
                    if self.stop_event.is_set() or not r or r['status']=='cancelled' or time.monotonic()>deadline:
                        if os.name!='nt':os.killpg(proc.pid,signal.SIGTERM)
                        else:proc.terminate()
                        try:proc.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            if os.name!='nt':os.killpg(proc.pid,signal.SIGKILL)
                            else:proc.kill()
                            proc.wait(timeout=3)
                        self.finish(jid,'failed','Application stopped or local render exceeded 300 seconds')
                        return
                    time.sleep(.12)
            result=dest/('result.'+EXT[row['format']])
            if proc.returncode==0 and result.is_file() and result.stat().st_size>50:
                self.finish(jid,'succeeded')
            else:
                err=(dest/'worker.log').read_text(errors='replace')[-1200:]
                self.finish(jid,'failed','Local render failed: '+err)
        except Exception as exc:self.finish(jid,'failed',str(exc)[:1000])
        finally:
            if proc and proc.poll() is None:proc.terminate()
            (dest/'working.lock').unlink(missing_ok=True)
            # The source texture and frame intermediates are not needed after completion.
            (dest/'input.json').unlink(missing_ok=True)
            shutil.rmtree(dest/'frames',ignore_errors=True)

@router.get('/capabilities')
def capabilities(request: Request,response: Response):
    token=request.cookies.get(COOKIE,'')
    if not re.fullmatch('[a-f0-9]{64}',token):
        response.set_cookie(COOKIE,secrets.token_hex(32),httponly=True,samesite='strict',max_age=30*86400,path='/api/local',secure=request.url.scheme=='https')
    return {'local_only':False,'cloud':False,'renderer':'CPU depth-buffer rasteriser',
            'structures':['tuck','hinged'],'image_long_edges':[256,512,1024,2048,3072,4096],
            'formats':['png','frames']+(['mp4','webm'] if ffmpeg_binary() else []),
            'video_long_edge_max':1024,'max_frames':120,'production_validated':False}

@router.post('/structure')
def structure(spec: StructureSpec,request: Request):
    return build_structure(spec)

@router.post('/dieline/{fmt}')
def dieline(fmt: str,spec: StructureSpec,request: Request):
    model=build_structure(spec)
    if fmt not in {'svg','dxf'}:raise HTTPException(404,'Use svg or dxf')
    data=export_svg(model) if fmt=='svg' else export_dxf(model)
    return Response(data,media_type='image/svg+xml' if fmt=='svg' else 'application/dxf',
                    headers={'Content-Disposition':f'attachment; filename="{spec.kind}-engineering-draft.{fmt}"'})

@router.post('/project/validate')
def validate_project(req: LocalRenderRequest,request: Request):
    return {'spec':req.spec.model_dump(),'view':req.view.model_dump(),
            'exterior':req.exterior,'interior':req.interior,'texture_panels':list(req.textures)}

@router.get('/jobs')
def jobs(request: Request):return {'items':manager(request).list(owner(request))}

@router.post('/jobs',status_code=202)
def submit(req: LocalRenderRequest,request: Request):
    who=owner(request)
    if req.format in {'mp4','webm'} and not ffmpeg_binary():raise HTTPException(503,'FFmpeg unavailable; choose PNG sequence ZIP')
    if req.format in {'mp4','webm'} and req.view.transparent:
        raise HTTPException(422,'MP4/WebM use opaque backgrounds here; use PNG/sequence for alpha')
    return manager(request).add(who,req)

@router.get('/jobs/{jid}')
def job(jid: str,request: Request):return manager(request).get(owner(request),jid)

@router.post('/jobs/{jid}/cancel')
def cancel(jid: str,request: Request):return manager(request).cancel(owner(request),jid)

@router.delete('/jobs/{jid}')
def delete(jid: str,request: Request):manager(request).delete(owner(request),jid);return {'deleted':True}

@router.get('/jobs/{jid}/result')
def result(jid: str,request: Request):
    m=manager(request);r=m.get(owner(request),jid)
    if r['status']!='succeeded':raise HTTPException(409,'The result is not ready')
    path=m.root/jid/('result.'+EXT[r['format']])
    if not path.is_file():raise HTTPException(410,'Local result was removed')
    return FileResponse(path,media_type=MIME[r['format']],filename='local-carton-'+jid[:8]+'.'+EXT[r['format']])
