"""RGB preview PDF, deliberately not represented as press-ready output."""
from __future__ import annotations
from html import escape
import cairosvg
import os
import re
import subprocess
from functools import lru_cache
from .domain import DesignPayload, box_layout


@lru_cache(maxsize=8)
def cjk_font(family: str) -> str:
    # Cairo's toy text renderer does not provide browser-like glyph fallback.
    # The font is a deployment dependency, not a bundled project asset.
    try:
        result = subprocess.run(['fc-match','-f','%{family}',family],capture_output=True,text=True,timeout=3,check=True)
    except (OSError,subprocess.SubprocessError) as exc:
        raise ValueError('CJK PDF preview needs fontconfig and an installed CJK font. See README; font files are not bundled.') from exc
    if family.lower() not in result.stdout.lower():
        raise ValueError('Configured CJK font is unavailable. Install Noto Sans CJK SC or set PDF_CJK_FONT to an installed CJK font.')
    return family


def preview_font(text: str, requested: str) -> str:
    if re.search(r'[\u2e80-\u9fff\uf900-\ufaff\u3000-\u303f\uff00-\uffef]',text):
        return cjk_font(os.environ.get('PDF_CJK_FONT','Noto Sans CJK SC'))
    return requested


def object_svg(o) -> str:
    if o.hidden:
        return ''
    cx, cy = o.x+o.w/2, o.y+o.h/2
    transform = f'rotate({o.rotation} {cx} {cy}) translate({cx} {cy}) scale({-1 if o.flipX else 1} {-1 if o.flipY else 1}) translate({-cx} {-cy})'
    attrs = f'transform="{transform}" opacity="{o.opacity}"'
    if o.type == 'rect':
        return f'<rect x="{o.x}" y="{o.y}" width="{o.w}" height="{o.h}" rx="{o.radius}" fill="{o.fill}" {attrs}/>'
    if o.type == 'image':
        fit = {'contain':'xMidYMid meet','cover':'xMidYMid slice','stretch':'none'}[o.fit]
        return f'<g {attrs}><svg x="{o.x}" y="{o.y}" width="{o.w}" height="{o.h}" overflow="hidden"><image href="{escape(o.src, quote=True)}" width="{o.w}" height="{o.h}" preserveAspectRatio="{fit}"/></svg></g>'
    anchor = {'left':'start','center':'middle','right':'end'}[o.align]
    x = o.x + (0 if o.align=='left' else o.w if o.align=='right' else o.w/2)
    common = f'font-family="{escape(preview_font(o.text, o.fontFamily), quote=True)}, sans-serif" font-size="{o.fontSize}" font-weight="{o.fontWeight}" font-style="{o.fontStyle}" fill="{o.fill}" letter-spacing="{o.letterSpacing}"'
    decoration = ' text-decoration="underline"' if o.underline else ''
    if o.vertical:
        spans = ''.join(f'<tspan x="{o.x+o.w/2}" y="{o.y+o.fontSize+i*o.fontSize*o.lineHeight}">{escape(ch)}</tspan>' for i,ch in enumerate(o.text))
        return f'<text {common} {attrs} text-anchor="middle"{decoration}>{spans}</text>'
    spans = ''.join(f'<tspan x="{x}" y="{o.y+o.fontSize+i*o.fontSize*o.lineHeight}">{escape(line) or "&#160;"}</tspan>' for i,line in enumerate(o.textLines if o.wrap and o.textLines is not None else o.text.split('\n')))
    return f'<text {common} {attrs} text-anchor="{anchor}"{decoration}>{spans}</text>'


def preview_svg(payload: DesignPayload, mode: str = 'print') -> tuple[str,float,float]:
    g = box_layout(payload.box); panels=g['panels']; s=g['scale']; margin=12*s
    x0,y0 = g['x']-margin, g['y']-margin
    vw,vh = g['w']+margin*2,g['h']+margin*2+12*s
    rects=''.join(f'<rect x="{p["x"]}" y="{p["y"]}" width="{p["w"]}" height="{p["h"]}"/>' for p in panels.values())
    art=''
    if mode == 'print':
        f=panels['front']
        art=f'<g clip-path="url(#net)"><g fill="{payload.bg}">{rects}</g><rect x="{f["x"]}" y="{f["y"]}" width="{f["w"]}" height="{4*s}" fill="{payload.accent}"/>'+''.join(object_svg(o) for o in payload.objects)+'</g>'
    guides=f'<g fill="none" stroke="#2366dd" stroke-width="{.2*s}">{rects}</g>'
    for name in ['back','left','front']:
        p=panels[name]; x=p['x']+p['w']
        guides+=f'<path d="M{x},{p["y"]}v{p["h"]}" fill="none" stroke="#e34545" stroke-width="{.2*s}" stroke-dasharray="{2*s},{s}"/>'
    f=panels['front']
    for yy in [f['y'],f['y']+f['h']]:
        guides+=f'<path d="M{f["x"]},{yy}h{f["w"]}" fill="none" stroke="#e34545" stroke-width="{.2*s}" stroke-dasharray="{2*s},{s}"/>'
    label=f'<text x="{x0+3*s}" y="{y0+vh-3*s}" font-family="sans-serif" font-size="{2.6*s}" fill="#555555">RGB PREVIEW ONLY - Six-face net; not a production dieline. No ICC / PDF-X validation.</text>'
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{vw}" height="{vh}" viewBox="{x0} {y0} {vw} {vh}"><defs><clipPath id="net">{rects}</clipPath></defs><rect x="{x0}" y="{y0}" width="{vw}" height="{vh}" fill="white"/>{art}{guides}{label}</svg>'
    return svg, vw/s, vh/s


def make_preview_pdf(payload: DesignPayload, mode: str = 'print') -> bytes:
    svg,wmm,hmm=preview_svg(payload,mode)
    return cairosvg.svg2pdf(bytestring=svg.encode('utf-8'), output_width=wmm*72/25.4, output_height=hmm*72/25.4, unsafe=False)
