import {reorderedLayers} from './layer_order.js';
import {layoutLines} from './text_layout.js';
import {getBoxLayout,normalizeBox,faceAt,clamp,netGuideMarkup} from './geometry.js';
import {artworkMarkup,artworkSVG,esc} from './artwork.js';

const copy=v=>structuredClone(v),uid=()=>globalThis.crypto?.randomUUID?.()||`o_${Date.now()}_${Math.random().toString(36).slice(2)}`;
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const rotatePoint=(p,c,deg)=>{const a=deg*Math.PI/180,dx=p.x-c.x,dy=p.y-c.y;return{x:c.x+dx*Math.cos(a)-dy*Math.sin(a),y:c.y+dx*Math.sin(a)+dy*Math.cos(a)};};

export function createPackagingEditor({mount,initial={},source={},onChange=()=>{},onSelection=()=>{}}) {
  const root=typeof mount==='string'?document.querySelector(mount):mount;if(!root)throw new Error('Editor mount not found');
  const box=normalizeBox(initial.box),front=getBoxLayout(box).panels.front;
  const defaults=[
    {id:uid(),type:'text',x:front.x+front.w*.08,y:front.y+front.h*.32,w:front.w*.84,h:front.h*.25,text:initial.text||source.title?.slice(0,8)||'PACKAGING',fontSize:Math.min(26,front.w/9),fontWeight:700,fill:initial.textColor||'#333333',align:'center',opacity:1,lineHeight:1.2},
    {id:uid(),type:'text',x:front.x+front.w*.08,y:front.y+front.h*.64,w:front.w*.84,h:30,text:'PACKAGING DESIGN',fontSize:Math.min(12,front.w/16),fill:initial.textColor||'#333333',align:'center',opacity:.75,lineHeight:1.2}
  ];
  let objects=copy(initial.objects||defaults);
  // Explicit one-time migration of v3 front-panel screen coordinates.
  if(initial.objects&&initial.schemaVersion!==4) {
    const oldScale=Math.min(1.55,700/(2*(box.length+box.width)+40),430/box.height),oldX=110+(box.length+box.width)*oldScale;
    const k=getBoxLayout(box).scale/oldScale;
    objects=objects.map(o=>({...o,x:front.x+(num(o.x)-oldX)*k,y:front.y+(num(o.y)-160)*k,w:num(o.w,100)*k,h:num(o.h,50)*k,fontSize:num(o.fontSize,28)*k}));
  }
  let state={schemaVersion:4,geometry:'six-face-box',box,bg:initial.bg||'#f4efe8',accent:initial.accent||'#c7a679',objects,
    selected:null,zoom:clamp(num(initial.zoom,1),.08,4),showDieline:initial.showDieline??true,showSafe:initial.showSafe??false,showBleed:initial.showBleed??false,snap:initial.snap??true};
  let history=[copy(state)],index=0,drag=null,destroyed=false,autoFit=true,resizeObserver=null,pan=null,spaceDown=false,snapGuides=[];
  root.innerHTML=`<div class="pro-editor-stage"><div class="stage-toolbar pro-stage-toolbar">
    <div class="tool-group"><button data-ed-undo title="\u64a4\u9500">\u21b6</button><button data-ed-redo title="\u91cd\u505a">\u21b7</button></div>
    <div class="tool-group"><button data-ed-zoomout>\u2212</button><span data-ed-zoom></span><button data-ed-zoomin>+</button><button data-ed-fit title="Ctrl/Cmd+0">\u9002\u5e94\u753b\u5e03</button></div>
    <div class="tool-group"><label><input data-ed-dieline type="checkbox">\u5c55\u5f00\u7ebf</label><label><input data-ed-safe type="checkbox">\u5b89\u5168\u53c2\u8003</label><label><input data-ed-bleed type="checkbox">3mm \u53c2\u8003</label><label><input data-ed-snap type="checkbox">\u5438\u9644</label></div></div>
    <div class="editor-scope-note">\u516d\u9762\u76d2\u4f53\u5c55\u793a\u6a21\u578b \u00b7 \u53ef\u8de8\u9762\u7f16\u8f91 \u00b7 \u975e\u751f\u4ea7\u5200\u7248</div>
    <div class="svg-workspace"><div class="svg-scroll"><svg class="packaging-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1180 760" aria-label="\u516d\u9762\u5305\u88c5\u7f16\u8f91\u753b\u5e03" tabindex="0"></svg></div></div></div>`;
  const svg=root.querySelector('svg'),$=s=>root.querySelector(s);
  function serialize(){const {selected,...payload}=state;return copy({...payload,objects:state.objects.map(o=>o.type==='text'?{...o,textLines:o.wrap&&!o.vertical?layoutLines(o):null}:o)});}
  function selected(){return state.objects.find(o=>o.id===state.selected)||null;}
  function notify(){onSelection(selected()?copy(selected()):null);}
  function emit(){if(!destroyed)onChange(serialize());}
  function pushHistory(){history=history.slice(0,index+1);history.push(copy(state));if(history.length>80)history.shift();index=history.length-1;}
  function commit(){pushHistory();render();emit();notify();}
  function selectionMarkup(o) {
    if(!o||o.hidden)return '';
    const rot=num(o.rotation),cx=o.x+o.w/2,cy=o.y+o.h/2;
    const corners={nw:[o.x,o.y],ne:[o.x+o.w,o.y],se:[o.x+o.w,o.y+o.h],sw:[o.x,o.y+o.h]};
    const handles=o.locked?'':Object.entries(corners).map(([key,[x,y]])=>`<rect data-handle="${key}" x="${x-5}" y="${y-5}" width="10" height="10" fill="white" stroke="#2f70fa" stroke-width="1.4"/>`).join('');
    return `<g class="selection-layer" transform="rotate(${rot} ${cx} ${cy})"><rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.h}" fill="none" stroke="${o.locked?'#84909c':'#2f70fa'}" stroke-width="1.4" pointer-events="none"/>${handles}${o.locked?'':`<line x1="${cx}" y1="${o.y}" x2="${cx}" y2="${o.y-24}" stroke="#2f70fa"/><circle data-handle="rotate" cx="${cx}" cy="${o.y-24}" r="6" fill="white" stroke="#2f70fa"/>`}</g>`;
  }
  function render() {
    if(destroyed)return;
    svg.innerHTML=`<defs><pattern id="stageGrid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="#eceff3" stroke-width=".5"/></pattern></defs><rect width="1180" height="760" fill="#f8fafc"/><rect width="1180" height="760" fill="url(#stageGrid)"/>${artworkMarkup(state,{interactive:true})}<g pointer-events="none">${state.showDieline?netGuideMarkup(state.box,{safe:state.showSafe,bleed:state.showBleed,labels:true}):''}</g>${snapGuides.map(g=>g.axis==='x'?`<line class="snap-guide" x1="${g.value}" x2="${g.value}" y1="0" y2="760"/>`:`<line class="snap-guide" y1="${g.value}" y2="${g.value}" x1="0" x2="1180"/>`).join('')}${selectionMarkup(selected())}`;
    svg.style.width=`${1180*state.zoom}px`;svg.style.height='auto';
    $('[data-ed-zoom]').textContent=`${Math.round(state.zoom*100)}%`;
    $('[data-ed-undo]').disabled=index<=0;$('[data-ed-redo]').disabled=index>=history.length-1;
    for(const [attr,key] of [['dieline','showDieline'],['safe','showSafe'],['bleed','showBleed'],['snap','snap']])$(`[data-ed-${attr}]`).checked=state[key];
  }
  function point(e){const p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;return p.matrixTransform(svg.getScreenCTM().inverse());}
  function snapMove(o,x,y) {
    snapGuides=[];if(!state.snap)return{x,y};
    const panels=Object.values(getBoxLayout(state.box).panels);
    const gx=panels.flatMap(p=>[p.x,p.x+p.w/2,p.x+p.w]);
    const gy=panels.flatMap(p=>[p.y,p.y+p.h/2,p.y+p.h]);
    for(const other of state.objects)if(other.id!==o.id&&!other.hidden){gx.push(other.x,other.x+other.w/2,other.x+other.w);gy.push(other.y,other.y+other.h/2,other.y+other.h);}
    const closest=(value,size,list,axis)=>{
      let distance=Math.min(12,5/state.zoom),result=value,guide=null;
      for(const g of list)for(const offset of [0,size/2,size]){const d=g-(value+offset);if(Math.abs(d)<distance){distance=Math.abs(d);result=value+d;guide=g;}}
      if(guide!==null)snapGuides.push({axis,value:guide});return result;
    };
    return{x:closest(x,o.w,gx,'x'),y:closest(y,o.h,gy,'y')};
  }
  function pointerDown(e) {
    if(e.button===1||(e.button===0&&spaceDown)){e.preventDefault();const w=$('.svg-scroll');pan={x:e.clientX,y:e.clientY,left:w.scrollLeft,top:w.scrollTop};svg.setPointerCapture(e.pointerId);return;}
    if(e.button!==0)return;
    const handle=e.target.closest('[data-handle]')?.dataset.handle,id=e.target.closest('[data-object]')?.dataset.object;
    if(!handle&&!id){state.selected=null;render();notify();return;}
    if(id)state.selected=id;
    const o=selected();render();notify();if(!o||o.locked)return;
    e.preventDefault();svg.setPointerCapture(e.pointerId);drag={mode:handle||'move',start:point(e),original:copy(o),moved:false};
  }
  function pointerMove(e) {
    if(pan){const w=$('.svg-scroll');w.scrollLeft=pan.left-(e.clientX-pan.x);w.scrollTop=pan.top-(e.clientY-pan.y);return;}
    if(!drag)return;const o=selected();if(!o)return;
    const p=point(e),a=drag.original,dx=p.x-drag.start.x,dy=p.y-drag.start.y;
    if(Math.abs(dx)+Math.abs(dy)<.5&&!drag.moved)return;drag.moved=true;
    if(drag.mode==='move')Object.assign(o,snapMove(a,a.x+dx,a.y+dy));
    else if(drag.mode==='rotate'){
      let degrees=Math.atan2(p.y-(a.y+a.h/2),p.x-(a.x+a.w/2))*180/Math.PI+90;
      const target=Math.round(degrees/45)*45;if(state.snap&&Math.abs(degrees-target)<4)degrees=target;o.rotation=degrees;
    } else {
      const c={x:a.x+a.w/2,y:a.y+a.h/2},local=rotatePoint(p,c,-num(a.rotation));
      const east=drag.mode.includes('e'),south=drag.mode.includes('s');
      const anchor={x:east?a.x:a.x+a.w,y:south?a.y:a.y+a.h};
      let w=Math.max(6,(local.x-anchor.x)*(east?1:-1)),h=Math.max(6,(local.y-anchor.y)*(south?1:-1));
      if(a.type==='text'||e.shiftKey){
        let factor=Math.abs(w/a.w-1)>Math.abs(h/a.h-1)?w/a.w:h/a.h;
        factor=clamp(factor,a.type==='text'?1/(a.fontSize||28):.05,a.type==='text'?500/(a.fontSize||28):100);
        w=a.w*factor;h=a.h*factor;
        if(a.type==='text'){o.fontSize=(a.fontSize||28)*factor;o.letterSpacing=clamp((a.letterSpacing||0)*factor,-20,100);}
      }
      const centerLocal={x:anchor.x+(east?1:-1)*w/2,y:anchor.y+(south?1:-1)*h/2};
      const center=rotatePoint(centerLocal,c,num(a.rotation));o.x=center.x-w/2;o.y=center.y-h/2;o.w=w;o.h=h;
    }
    render();emit();
  }
  function pointerUp(){pan=null;snapGuides=[];if(!drag)return;const moved=drag.moved;drag=null;if(moved)pushHistory();render();emit();notify();}
  svg.addEventListener('pointerdown',pointerDown);svg.addEventListener('pointermove',pointerMove);svg.addEventListener('pointerup',pointerUp);svg.addEventListener('pointercancel',pointerUp);
  function addObject(o){state.objects.push(o);state.selected=o.id;commit();return copy(o);}
  function currentPanel(){return getBoxLayout(state.box).panels.front;}
  function addText(text='\u65b0\u6587\u5b57') {const f=currentPanel();return addObject({id:uid(),type:'text',x:f.x+f.w*.1,y:f.y+f.h*.25,w:f.w*.8,h:55,text,fontSize:24,fontWeight:600,fontFamily:'Arial',fill:'#222222',rotation:0,opacity:1,align:'center',lineHeight:1.2,wrap:true,craft:'none'});}
  function addRect(){const f=currentPanel();return addObject({id:uid(),type:'rect',x:f.x+f.w*.15,y:f.y+f.h*.42,w:f.w*.7,h:f.h*.25,fill:state.accent,radius:8,rotation:0,opacity:1});}
  function addImage(src){const f=currentPanel();return addObject({id:uid(),type:'image',x:f.x+f.w*.1,y:f.y+f.h*.35,w:f.w*.8,h:f.h*.42,src,rotation:0,opacity:1,fit:'contain',flipX:false,flipY:false});}
  function updateSelected(patch){const o=selected();if(!o)return;if(o.locked&&!('locked' in patch)&&!('hidden' in patch))return;const previous=JSON.stringify(o);Object.assign(o,patch);if(o.type==='text'&&o.wrap&&('text' in patch||'wrap' in patch)){const lines=layoutLines(o);o.h=Math.min(10000,Math.max(o.fontSize||28,(lines.length-1)*(o.fontSize||28)*(o.lineHeight||1.2)+(o.fontSize||28)));}for(const key of ['x','y','w','h','fontSize','rotation','opacity','letterSpacing','lineHeight'])if(key in o)o[key]=num(o[key],key==='opacity'?1:0);o.w=Math.max(1,o.w);o.h=Math.max(1,o.h);o.opacity=clamp(o.opacity??1,0,1);if(JSON.stringify(o)!==previous)commit();}
  function selectObject(id){state.selected=state.objects.some(o=>o.id===id)?id:null;render();notify();}
  function removeSelected(){const o=selected();if(!o||o.locked)return;state.objects=state.objects.filter(x=>x.id!==o.id);state.selected=null;commit();}
  function duplicateSelected(){const o=selected();if(!o)return;addObject({...copy(o),id:uid(),x:o.x+12,y:o.y+12,locked:false});}
  function reorderLayer(id, targetVisualIndex) {
    const next = reorderedLayers(state.objects, id, targetVisualIndex);
    if (next === state.objects) return false;
    // Selection is not document content; retain the moved layer on undo/redo.
    history[index].selected = id;
    state.selected = id;
    state.objects = next;
    commit(); // One drop = one history entry + one change notification.
    return true;
  }
  function moveLayer(id, delta) {
    const i = state.objects.findIndex(o => o.id === id);
    if (i < 0 || !Number.isInteger(delta)) return false;
    const j = clamp(i + delta, 0, state.objects.length - 1);
    return reorderLayer(id, state.objects.length - 1 - j);
  }
  function setBox(input) {
    const before=state.box,after=normalizeBox({...before,...input});
    if(JSON.stringify(before)===JSON.stringify(after))return;
    const g0=getBoxLayout(before),g1=getBoxLayout(after);
    state.objects=state.objects.map(o=>{const name=faceAt(before,o.x+o.w/2,o.y+o.h/2),p0=g0.panels[name],p1=g1.panels[name],kx=p1.w/p0.w,ky=p1.h/p0.h;return {...o,x:p1.x+(o.x-p0.x)*kx,y:p1.y+(o.y-p0.y)*ky,w:o.w*kx,h:o.h*ky,fontSize:o.fontSize?o.fontSize*Math.min(kx,ky):undefined};});
    state.box=after;commit();
  }
  function undo(){if(index<=0)return;const zoom=state.zoom;state=copy(history[--index]);state.zoom=zoom;render();emit();notify();}
  function redo(){if(index>=history.length-1)return;const zoom=state.zoom;state=copy(history[++index]);state.zoom=zoom;render();emit();notify();}
  function setBackground(c){if(state.bg!==c){state.bg=c;commit();}}function setAccent(c){if(state.accent!==c){state.accent=c;commit();}}
  $('[data-ed-undo]').onclick=undo;$('[data-ed-redo]').onclick=redo;
  $('[data-ed-zoomin]').onclick=()=>{autoFit=false;state.zoom=clamp(state.zoom+.1,.08,4);render();};$('[data-ed-zoomout]').onclick=()=>{autoFit=false;state.zoom=clamp(state.zoom-.1,.08,4);render();};
  for(const [attr,key] of [['dieline','showDieline'],['safe','showSafe'],['bleed','showBleed'],['snap','snap']])$(`[data-ed-${attr}]`).onchange=e=>{state[key]=e.target.checked;commit();};
  function fitToView(){
    const workspace=$('.svg-scroll');if(destroyed||!workspace.clientWidth)return;
    autoFit=true;state.zoom=clamp(Math.min((workspace.clientWidth-36)/1180,(workspace.clientHeight-36)/760),.08,1);
    render();workspace.scrollLeft=0;workspace.scrollTop=0;
  }
  $('[data-ed-fit]').onclick=fitToView;
  if(globalThis.ResizeObserver){resizeObserver=new ResizeObserver(()=>{if(autoFit)fitToView();});resizeObserver.observe($('.svg-scroll'));}
  const keyup=e=>{if(e.code==='Space'){spaceDown=false;pan=null;svg.classList.remove('pan-mode');}};
  const blur=()=>{spaceDown=false;pan=null;svg.classList.remove('pan-mode');};
  const keydown=e=>{
    if(destroyed||e.defaultPrevented||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)||document.activeElement?.isContentEditable)return;
    const command=e.ctrlKey||e.metaKey,key=e.key.toLowerCase();
    if(command&&key==='0'){e.preventDefault();fitToView();return;}
    if(e.code==='Space'&&document.activeElement?.tagName!=='BUTTON'){e.preventDefault();spaceDown=true;svg.classList.add('pan-mode');return;}
    if(command&&key==='z'){e.preventDefault();e.shiftKey?redo():undo();return;}
    if(command&&key==='y'){e.preventDefault();redo();return;}
    if(command&&key==='d'){e.preventDefault();duplicateSelected();return;}
    if(e.key==='Escape'){selectObject(null);return;}
    const o=selected();if(!o||o.locked)return;
    if(['Delete','Backspace'].includes(e.key)){e.preventDefault();removeSelected();return;}
    const d={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];
    if(d){e.preventDefault();const step=e.shiftKey?10:1;updateSelected({x:o.x+d[0]*step,y:o.y+d[1]*step});}
  };
  window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('blur',blur);render();notify();requestAnimationFrame(fitToView);
  return {fitToView,addText,addRect,addImage,updateSelected,selectObject,removeSelected,duplicateSelected,moveLayer,reorderLayer,getObjects:()=>copy(state.objects),getSelected:()=>selected()?copy(selected()):null,setBox,setBackground,setAccent,undo,redo,serialize,
    exportSVG:()=>artworkSVG(serialize(),{guides:true}),
    destroy(){destroyed=true;resizeObserver?.disconnect();window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('blur',blur);}};
}
