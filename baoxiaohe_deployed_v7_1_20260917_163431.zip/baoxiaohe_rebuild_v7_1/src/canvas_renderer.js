/* Software fallback for disabled WebGL. This is a textured, projected six-face
 * preview, not photorealistic rendering or a manufacturing model. */
import {getBoxLayout,normalizeBox} from './geometry.js';
import {artworkSVG,svgToCanvas} from './artwork.js';
const ratios={'16:9':16/9,'9:16':9/16,'4:3':4/3,'3:4':3/4,'1:1':1};
const presets={rightFront:[16,-30],front:[0,0],leftFront:[16,30],topRight:[50,-30],top:[90,0],topLeft:[50,30]};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export function createBoxCanvasRenderer({mount,box={},colors=['#eeeeee','#cccccc'],background='#f2f3f5',onRotation=()=>{}}) {
  const root=typeof mount==='string'?document.querySelector(mount):mount;
  root.innerHTML='<canvas class="webgl-canvas" aria-label="Software six-face preview"></canvas><div class="webgl-hint">Canvas 2D \u8f6f\u4ef6\u9884\u89c8 \u00b7 \u62d6\u52a8\u65cb\u8f6c</div>';
  const canvas=root.querySelector('canvas'),ctx=canvas.getContext('2d',{alpha:true});
  if(!ctx)throw new Error('Canvas 2D is unavailable');
  const state={box:normalizeBox(box),rx:16*Math.PI/180,ry:-30*Math.PI/180,zoom:4.6,aspect:'4:3',background,transparent:false,light:1,lightRotation:30,lightHeight:55};
  let dead=false,atlas=null,last={box:state.box,bg:colors[0],accent:colors[1],objects:[]},generation=0,pending=Promise.resolve(),bgImage=null,frame=0,auto=false,lastTime=0,drag=null,recorder=null;
  function rotated([x,y,z]){const cy=Math.cos(state.ry),sy=Math.sin(state.ry),cx=Math.cos(state.rx),sx=Math.sin(state.rx),X=cy*x+sy*z,Z=-sy*x+cy*z;return[X,cx*y-sx*Z,sx*y+cx*Z];}
  function geometry(){const b=state.box,div=Math.max(b.length,b.width,b.height),x=b.length/div,y=b.height/div,z=b.width/div;
    return {front:[[-x,y,z],[x,y,z],[x,-y,z],[-x,-y,z]],back:[[x,y,-z],[-x,y,-z],[-x,-y,-z],[x,-y,-z]],left:[[-x,y,-z],[-x,y,z],[-x,-y,z],[-x,-y,-z]],right:[[x,y,z],[x,y,-z],[x,-y,-z],[x,-y,z]],top:[[-x,y,-z],[x,y,-z],[x,y,z],[-x,y,z]],bottom:[[-x,-y,z],[x,-y,z],[x,-y,-z],[-x,-y,-z]]};}
  const normals={front:[0,0,1],back:[0,0,-1],left:[-1,0,0],right:[1,0,0],top:[0,1,0],bottom:[0,-1,0]};
  const poly=(c,p)=>{c.beginPath();c.moveTo(p[0][0],p[0][1]);p.slice(1).forEach(v=>c.lineTo(v[0],v[1]));c.closePath();};
  function triangle(c,src,dst,image){
    const [s0,s1,s2]=src,[d0,d1,d2]=dst,ux=s1[0]-s0[0],uy=s1[1]-s0[1],vx=s2[0]-s0[0],vy=s2[1]-s0[1],det=ux*vy-uy*vx;
    if(Math.abs(det)<1e-8)return;
    const ex=d1[0]-d0[0],ey=d1[1]-d0[1],fx=d2[0]-d0[0],fy=d2[1]-d0[1];
    const a=(ex*vy-fx*uy)/det,b=(ey*vy-fy*uy)/det,cc=(fx*ux-ex*vx)/det,d=(fy*ux-ey*vx)/det,e=d0[0]-a*s0[0]-cc*s0[1],f=d0[1]-b*s0[0]-d*s0[1];
    const center=[(d0[0]+d1[0]+d2[0])/3,(d0[1]+d1[1]+d2[1])/3];
    const expanded=dst.map(p=>{const dx=p[0]-center[0],dy=p[1]-center[1],len=Math.hypot(dx,dy)||1;return[p[0]+dx/len*.65,p[1]+dy/len*.65];});
    c.save();poly(c,expanded);c.clip();c.setTransform(a,b,cc,d,e,f);c.drawImage(image,0,0);c.restore();
  }
  function paint(c,w,h,texture=atlas){
    c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,w,h);
    if(!state.transparent){if(bgImage){const scale=Math.max(w/bgImage.width,h/bgImage.height);c.drawImage(bgImage,(w-bgImage.width*scale)/2,(h-bgImage.height*scale)/2,bgImage.width*scale,bgImage.height*scale);}else{c.fillStyle=state.background;c.fillRect(0,0,w,h);}}
    const aspect=w/h,distance=state.zoom*Math.max(1,1/aspect),f=h/(2*Math.tan(Math.PI/8));
    const project=p=>[w/2+p[0]*f/(distance-p[2]),h/2-p[1]*f/(distance-p[2])];
    const faces=Object.entries(geometry()).map(([name,points])=>{const p=points.map(rotated),n=rotated(normals[name]),center=[0,1,2].map(k=>p.reduce((s,v)=>s+v[k],0)/4);return{name,p,n,center};}).filter(face=>face.n[0]*-face.center[0]+face.n[1]*-face.center[1]+face.n[2]*(distance-face.center[2])>0).sort((a,b)=>a.center[2]-b.center[2]);
    const panels=getBoxLayout(state.box).panels,a=state.lightRotation*Math.PI/180,light=[Math.sin(a),state.lightHeight/50,Math.cos(a)],ll=Math.hypot(...light);
    for(const face of faces){const dst=face.p.map(project),r=panels[face.name];c.save();poly(c,dst);c.clip();
      if(texture){const sx=texture.width/1180,sy=texture.height/760,steps=8;
        const point=(u,v)=>[0,1,2].map(k=>face.p[0][k]+(face.p[1][k]-face.p[0][k])*u+(face.p[3][k]-face.p[0][k])*v);
        for(let i=0;i<steps;i++)for(let j=0;j<steps;j++){
          const coords=[[i/steps,j/steps],[(i+1)/steps,j/steps],[(i+1)/steps,(j+1)/steps],[i/steps,(j+1)/steps]],d=coords.map(([u,v])=>project(point(u,v))),s=coords.map(([u,v])=>[(r.x+u*r.w)*sx,(r.y+v*r.h)*sy]);
          triangle(c,[s[0],s[1],s[2]],[d[0],d[1],d[2]],texture);triangle(c,[s[0],s[2],s[3]],[d[0],d[2],d[3]],texture);
        }
      }else{c.fillStyle=last.bg||'#eeeeee';c.fillRect(0,0,w,h);}
      const diffuse=Math.max(0,face.n.reduce((s,v,k)=>s+v*light[k]/ll,0)),level=(.70+.30*diffuse)*state.light;
      if(level<1){c.fillStyle=`rgba(0,0,0,${1-level})`;c.fillRect(0,0,w,h);}else if(level>1){c.fillStyle=`rgba(255,255,255,${clamp(level-1,0,.5)})`;c.fillRect(0,0,w,h);}c.restore();
    }
  }
  function fit(){const r=root.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),w=Math.max(1,Math.round(r.width*dpr)),h=Math.max(1,Math.round((r.height||r.width/(ratios[state.aspect]||1))*dpr));if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;}
  function draw(){if(dead)return;fit();paint(ctx,canvas.width,canvas.height);}
  function tick(ts){frame=0;if(dead)return;if(auto){if(lastTime)state.ry+=(ts-lastTime)*.0004;lastTime=ts;onRotation(state.rx,state.ry);}draw();if(auto)frame=requestAnimationFrame(tick);}
  function requestDraw(){if(!dead&&!frame)frame=requestAnimationFrame(tick);}
  function setAutoRotate(v){auto=!!v;lastTime=0;requestDraw();}
  function setDesign(payload){if(dead)return Promise.resolve();last=structuredClone(payload);state.box=normalizeBox(payload.box);const version=++generation;pending=svgToCanvas(artworkSVG(last),2048,Math.round(2048*760/1180)).then(c=>{if(!dead&&version===generation){atlas=c;requestDraw();}});pending.catch(()=>{});return pending;}
  async function ready(){let p;do{p=pending;await p;}while(p!==pending);if(dead)throw new Error('Renderer destroyed');}
  function setAspect(v){if(ratios[v])state.aspect=v;root.style.aspectRatio=String(ratios[state.aspect]);root.style.setProperty('--render-aspect',String(ratios[state.aspect]));requestDraw();}
  async function exportPNG({quality='1k',aspect=state.aspect}={}){await ready();const edge={'1k':1024,'2k':2048,'3k':3072,'4k':4096}[String(quality).toLowerCase()];if(!edge||!ratios[aspect])throw new Error('Unsupported output size');const ratio=ratios[aspect],out=document.createElement('canvas');out.width=ratio>=1?edge:Math.round(edge*ratio);out.height=ratio>=1?Math.round(edge/ratio):edge;const tex=await svgToCanvas(artworkSVG(last),Math.max(2048,edge),Math.round(Math.max(2048,edge)*760/1180));paint(out.getContext('2d'),out.width,out.height,tex);return out.toDataURL('image/png');}
  async function recordWebM(seconds=4) {
    await ready();if(recorder)throw new Error('Recording in progress');
    const mime=typeof MediaRecorder!=='undefined'&&['video/webm;codecs=vp8','video/webm;codecs=vp9','video/webm'].find(v=>MediaRecorder.isTypeSupported(v));
    if(!mime)throw new Error('WebM unavailable');
    const c=document.createElement('canvas');c.width=1024;c.height=Math.round(1024/ratios[state.aspect]);
    if(!c.captureStream)throw new Error('Canvas recording unavailable');
    const ctx=c.getContext('2d'),duration=clamp(Number(seconds)||4,1,15)*1000,oldAuto=auto,oldRY=state.ry;
    setAutoRotate(false);paint(ctx,c.width,c.height);
    // Explicit frame requests avoid zero-frame recordings on a detached canvas.
    let stream=c.captureStream(0),track=stream.getVideoTracks()[0];
    if(typeof track?.requestFrame!=='function'){stream.getTracks().forEach(t=>t.stop());stream=c.captureStream(24);track=stream.getVideoTracks()[0];}
    return new Promise((resolve,reject)=>{
      const parts=[];let timer=0,watchdog=0,done=false,frames=0,rec;
      const clean=()=>{clearTimeout(timer);clearTimeout(watchdog);stream.getTracks().forEach(t=>t.stop());recorder=null;state.ry=oldRY;setAutoRotate(oldAuto);requestDraw();};
      const fail=error=>{if(done)return;done=true;if(rec?.state==='recording')rec.stop();clean();reject(error);};
      try{rec=recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:4000000});}catch(e){clean();reject(e);return;}
      rec.ondataavailable=e=>{if(e.data.size)parts.push(e.data);};
      rec.onerror=e=>fail(e.error||new Error('Video recording failed'));
      rec.onstop=()=>{if(done)return;done=true;clean();const blob=new Blob(parts,{type:'video/webm'});if(frames<2||blob.size<500)reject(new Error('No usable video frames were encoded'));else resolve(blob);};
      rec.onstart=()=>{
        const began=performance.now();
        const tick=()=>{
          if(done)return;if(dead){fail(new Error('Renderer destroyed during recording'));return;}
          const progress=Math.min(1,(performance.now()-began)/duration);state.ry=oldRY+progress*Math.PI*2;
          try{paint(ctx,c.width,c.height);track?.requestFrame?.();frames++;}catch(e){fail(e);return;}
          if(progress>=1&&frames>=2)timer=setTimeout(()=>{if(rec.state==='recording')rec.stop();},150);
          else timer=setTimeout(tick,1000/24);
        };
        tick();
      };
      watchdog=setTimeout(()=>fail(new Error('Video capture timed out')),duration+15000);
      try{rec.start(200);}catch(e){fail(e);}
    });
  }
  canvas.onpointerdown=e=>{setAutoRotate(false);canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,rx:state.rx,ry:state.ry};};canvas.onpointermove=e=>{if(drag){state.rx=clamp(drag.rx+(e.clientY-drag.y)*.008,-Math.PI/2,Math.PI/2);state.ry=drag.ry+(e.clientX-drag.x)*.008;onRotation(state.rx,state.ry);requestDraw();}};canvas.onpointerup=canvas.onpointercancel=()=>drag=null;canvas.addEventListener('wheel',e=>{e.preventDefault();state.zoom=clamp(state.zoom+e.deltaY*.004,2.5,8);requestDraw();},{passive:false});
  const ro=new ResizeObserver(requestDraw);ro.observe(root);setAspect(state.aspect);setDesign(last);
  return {available:true,engine:'canvas2d',canvas,ready,setDesign,setAspect,setAutoRotate,exportPNG,recordWebM,
    setPreset(name){if(presets[name]){state.rx=presets[name][0]*Math.PI/180;state.ry=presets[name][1]*Math.PI/180;requestDraw();}},setRotation(rx,ry){state.rx=Number(rx)*Math.PI/180;state.ry=Number(ry)*Math.PI/180;requestDraw();},
    setLight(v){state.light=clamp(Number(v)||1,.35,1.5);requestDraw();},setLightRotation(v){state.lightRotation=Number(v)||0;requestDraw();},setLightHeight(v){state.lightHeight=Number(v)||0;requestDraw();},
    setBox(b){return setDesign({...last,box:{...state.box,...b}});},setColors(c){return setDesign({...last,bg:c[0],accent:c[1]});},setBackground(c){state.background=c;state.transparent=false;bgImage=null;requestDraw();},setTransparent(v=true){state.transparent=!!v;requestDraw();},
    async setBackgroundImage(data){if(!/^data:image\/(png|jpeg);base64,/.test(data))throw new Error('Local PNG/JPEG required');const im=new Image();im.src=data;await im.decode();if(dead)return;bgImage=im;state.transparent=false;requestDraw();},
    destroy(){dead=true;generation++;auto=false;if(frame)cancelAnimationFrame(frame);if(recorder&&recorder.state!=='inactive')recorder.stop();ro.disconnect();}};
}
