import {layoutLines} from './text_layout.js';
import {getBoxLayout, rectMarkup, netGuideMarkup} from './geometry.js';
export const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const n=(x,d=0)=>Number.isFinite(Number(x))?Number(x):d;
export const color=(x,d='#222222')=>/^#[0-9a-f]{6}$/i.test(x||'')?x:d;
const allowedImage=s=>/^data:image\/(png|jpeg|svg\+xml);base64,[a-z0-9+/=\r\n]+$/i.test(s||'');

export function objectMarkup(o,{interactive=false}={}) {
  if(o.hidden) return '';
  const x=n(o.x),y=n(o.y),w=Math.max(1,n(o.w,100)),h=Math.max(1,n(o.h,50)),cx=x+w/2,cy=y+h/2;
  const rot=`rotate(${n(o.rotation)} ${cx} ${cy}) translate(${cx} ${cy}) scale(${o.flipX?-1:1} ${o.flipY?-1:1}) translate(${-cx} ${-cy})`;
  const attrs=`transform="${rot}" opacity="${Math.max(0,Math.min(1,n(o.opacity,1)))}"`;
  let node;
  if(o.type==='rect') node=`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${Math.max(0,n(o.radius))}" fill="${color(o.fill)}"/>`;
  else if(o.type==='image') {
    const fit={contain:'xMidYMid meet',cover:'xMidYMid slice',stretch:'none'}[o.fit]||'xMidYMid meet';
    node=allowedImage(o.src)?`<svg x="${x}" y="${y}" width="${w}" height="${h}" overflow="hidden"><image href="${esc(o.src)}" width="${w}" height="${h}" preserveAspectRatio="${fit}"/></svg>`:'';
  } else {
    const anchor={left:'start',center:'middle',right:'end'}[o.align]||'middle';
    const tx=x+(anchor==='start'?0:anchor==='end'?w:w/2),fs=Math.max(1,n(o.fontSize,28)),lh=Math.max(.5,n(o.lineHeight,1.2));
    const attrs2=`font-family="${esc(o.fontFamily||'Arial')}, sans-serif" font-size="${fs}" font-weight="${n(o.fontWeight,500)}" font-style="${o.fontStyle==='italic'?'italic':'normal'}" letter-spacing="${n(o.letterSpacing)}" fill="${color(o.fill)}"${o.underline?' text-decoration="underline"':''}`;
    const content=o.vertical?[...String(o.text||'')].map((ch,i)=>`<tspan x="${x+w/2}" y="${y+fs+i*fs*lh}">${esc(ch)}</tspan>`).join(''):
      layoutLines(o).map((line,i)=>`<tspan x="${tx}" y="${y+fs+i*fs*lh}">${esc(line)||'&#160;'}</tspan>`).join('');
    node=`<text ${attrs2} text-anchor="${o.vertical?'middle':anchor}">${content}</text>`;
  }
  return `<g ${interactive?`data-object="${esc(o.id)}" class="art-object"`:''} ${attrs}>${node}${interactive?`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="transparent" pointer-events="all"/>`:''}</g>`;
}

export function artworkMarkup(payload={},{interactive=false}={}) {
  const g=getBoxLayout(payload.box),f=g.panels.front;
  const rects=Object.values(g.panels).map(p=>rectMarkup(p)).join('');
  return `<defs><clipPath id="artworkNet">${rects}</clipPath></defs><g clip-path="url(#artworkNet)"><g fill="${color(payload.bg,'#f4efe8')}">${rects}</g><rect x="${f.x}" y="${f.y}" width="${f.w}" height="${4*g.scale}" fill="${color(payload.accent,'#c7a679')}"/>${(payload.objects||[]).map(o=>objectMarkup(o,{interactive})).join('')}</g>`;
}

export function artworkSVG(payload,{guides=false,width=1180,height=760}={}) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 1180 760">${artworkMarkup(payload)}${guides?`<g pointer-events="none">${netGuideMarkup(payload.box,{labels:false})}</g>`:''}</svg>`;
}

export async function svgToCanvas(svg,width=2048,height=Math.round(2048*760/1180)) {
  if(document.fonts?.ready) await document.fonts.ready;
  const blob=new Blob([svg],{type:'image/svg+xml'}),url=URL.createObjectURL(blob);
  try {
    const image=new Image();image.src=url;await image.decode();
    const c=document.createElement('canvas');c.width=width;c.height=height;
    const ctx=c.getContext('2d');if(!ctx)throw new Error('2D canvas unavailable');
    ctx.drawImage(image,0,0,width,height);return c;
  } finally {URL.revokeObjectURL(url);}
}

export function safeSVG(text) {
  if(new Blob([text]).size>1024*1024)throw new Error('SVG \u9700\u5c0f\u4e8e 1MB');
  if(/<!DOCTYPE|<!ENTITY/i.test(text))throw new Error('SVG \u4e0d\u80fd\u5305\u542b DTD \u6216\u5b9e\u4f53');
  const doc=new DOMParser().parseFromString(text,'image/svg+xml');
  const allowed=new Set(['svg','g','path','rect','circle','ellipse','line','polyline','polygon','text','tspan','defs','clipPath','linearGradient','radialGradient','stop','title','desc','use']);
  if(doc.querySelector('parsererror')||doc.documentElement.localName!=='svg')throw new Error('SVG \u683c\u5f0f\u9519\u8bef');
  for(const node of doc.querySelectorAll('*')) {
    if(!allowed.has(node.localName))throw new Error('SVG \u5305\u542b\u4e0d\u652f\u6301\u7684\u5143\u7d20');
    for(const a of node.attributes) {
      const name=a.localName.toLowerCase(),v=a.value;
      if(name.startsWith('on')||name==='style')throw new Error('SVG \u4e8b\u4ef6\u811a\u672c\u6216\u5185\u8054\u6837\u5f0f\u672a\u5141\u8bb8');
      if((name==='href'||name==='src')&&!v.startsWith('#'))throw new Error('SVG \u4e0d\u80fd\u5f15\u7528\u5916\u90e8\u8d44\u6e90');
      if(/url\(/i.test(v)&&!/^url\(#[A-Za-z0-9_-]+\)$/.test(v))throw new Error('SVG \u4e0d\u80fd\u5f15\u7528\u5916\u90e8\u586b\u5145');
    }
  }
  return new XMLSerializer().serializeToString(doc.documentElement);
}

export async function fileToImage(file) {
  if(!file)throw new Error('No file selected');
  if(file.type==='image/svg+xml'||/\.svg$/i.test(file.name)) {
    const svg=safeSVG(await file.text());
    const src=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(new Blob([svg],{type:'image/svg+xml'}));});
    return {src,vector:true};
  }
  if(!['image/png','image/jpeg'].includes(file.type))throw new Error('\u4ec5\u652f\u6301 PNG / JPG / SVG');
  if(file.size>5*1024*1024)throw new Error('\u56fe\u7247\u9700\u5c0f\u4e8e 5MB');
  const src=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});
  const image=new Image();image.src=src;await image.decode();
  if(image.width*image.height>25_000_000)throw new Error('\u56fe\u7247\u4e0d\u80fd\u8d85\u8fc7 2500 \u4e07\u50cf\u7d20');
  return {src,width:image.width,height:image.height};
}
