import time
import zipfile
from io import BytesIO
from PIL import Image
from fastapi.testclient import TestClient
from app.main import app

def boot(client):
    r=client.get('/api/local/capabilities');assert r.status_code==200;assert r.json()['cloud'] is False

def wait(client,jid):
    for _ in range(180):
        r=client.get('/api/local/jobs/'+jid);assert r.status_code==200;job=r.json()
        if job['status'] not in {'queued','running'}:return job
        time.sleep(.12)
    raise AssertionError('Local job did not finish')

def test_local_structure_endpoint(client):
    r=client.post('/api/local/structure',json={'kind':'hinged','height':35});assert r.status_code==200;assert len(r.json()['panels'])==13
    r=client.get('/structure');assert r.status_code==200
    for fmt in ('svg','dxf'):
        r=client.post('/api/local/dieline/'+fmt,json={'kind':'tuck'});assert r.status_code==200;assert 'attachment' in r.headers['content-disposition']

def test_loopback_only(client):
    for url in ('http://evil.example/api/local/capabilities','http://192.168.1.2/api/local/capabilities'):
        assert client.get(url).status_code==403
    assert client.post('/api/local/structure',json={},headers={'origin':'https://evil.example'}).status_code==403

def test_owner_required(client):
    assert client.post('/api/local/jobs',json={}).status_code==401
    assert client.get('/api/local/jobs').status_code==401

def test_render_png_and_owner_isolation(client):
    boot(client);r=client.post('/api/local/jobs',json={'long_edge':256,'view':{'transparent':True}});assert r.status_code==202,r.text
    jid=r.json()['id'];job=wait(client,jid);assert job['status']=='succeeded',job
    image=client.get('/api/local/jobs/'+jid+'/result');assert image.status_code==200
    with Image.open(BytesIO(image.content)) as im:assert im.size==(256,192);assert im.getextrema()[3]==(0,255)
    cookies=dict(client.cookies);client.cookies.clear();boot(client)
    assert client.get('/api/local/jobs/'+jid).status_code==404
    assert client.get('/api/local/jobs/'+jid+'/result').status_code==404
    client.cookies.clear();client.cookies.update(cookies)
    assert client.request('DELETE','/api/local/jobs/'+jid,json={}).status_code==200
    assert client.get('/api/local/jobs/'+jid).status_code==404

def test_cancel_and_limits(client):
    boot(client)
    assert client.post('/api/local/jobs',json={'format':'mp4','long_edge':4096}).status_code==422
    assert client.post('/api/local/jobs',json={'format':'mp4','view':{'transparent':True}}).status_code==422
    r=client.post('/api/local/jobs',json={'format':'frames','long_edge':512,'fps':24,'seconds':5});assert r.status_code==202
    jid=r.json()['id'];assert client.post('/api/local/jobs/'+jid+'/cancel',json={}).status_code==200
    assert wait(client,jid)['status']=='cancelled'

def test_real_frame_sequence(client):
    boot(client);r=client.post('/api/local/jobs',json={'format':'frames','long_edge':256,'seconds':1,'fps':6,'motion':'open','spec':{'kind':'hinged','height':35}});assert r.status_code==202
    jid=r.json()['id'];job=wait(client,jid);assert job['status']=='succeeded',job
    r=client.get('/api/local/jobs/'+jid+'/result')
    with zipfile.ZipFile(BytesIO(r.content)) as z:
        names=[n for n in z.namelist() if n.endswith('.png')];assert len(names)==6
        assert z.read(names[0])!=z.read(names[-1])

def test_project_validation_is_atomic_boundary(client):
    assert client.post('/api/local/project/validate',json={'view':{'yaw':99999}}).status_code==422
    assert client.post('/api/local/project/validate',json={'textures':{'front':'https://example.org/image.png'}}).status_code==422
    r=client.post('/api/local/project/validate',json={'spec':{'kind':'hinged','height':20,'width':25}})
    assert r.status_code==200
    assert r.json()['spec']['width']==25

def test_queue_bound_without_worker(tmp_path):
    from app.local_jobs import LocalJobManager
    from app.local_raster import LocalRenderRequest
    from fastapi import HTTPException
    import pytest
    m=LocalJobManager(tmp_path/'queue');req=LocalRenderRequest(long_edge=256)
    jobs=[m.add('owner',req) for _ in range(3)]
    with pytest.raises(HTTPException) as e:m.add('owner',req)
    assert e.value.status_code==429
    m.cancel('owner',jobs[0]['id']);assert m.add('owner',req)['status']=='queued'
    m.delete('owner',jobs[0]['id'])

def test_restart_marks_running_failed_but_preserves_queue(tmp_path):
    from app.local_jobs import LocalJobManager
    from app.local_raster import LocalRenderRequest
    m=LocalJobManager(tmp_path/'queue');req=LocalRenderRequest(long_edge=256)
    a=m.add('owner',req);b=m.add('owner',req)
    with m.db() as c:c.execute("UPDATE jobs SET status='running' WHERE id=?",(a['id'],))
    n=LocalJobManager(tmp_path/'queue')
    assert n.get('owner',a['id'])['status']=='failed'
    assert n.get('owner',b['id'])['status']=='queued'

def test_cancel_running_worker(client):
    import app.main as main
    boot(client)
    r=client.post('/api/local/jobs',json={'format':'frames','long_edge':1024,'seconds':5,'fps':24});assert r.status_code==202
    jid=r.json()['id']
    for _ in range(100):
        state=client.get('/api/local/jobs/'+jid).json()['status']
        if state=='running':break
        time.sleep(.02)
    assert state=='running'
    r=client.post('/api/local/jobs/'+jid+'/cancel',json={});assert r.json()['status']=='cancelled'
    m=main.app.state.local_renderer
    for _ in range(100):
        if not (m.root/jid/'working.lock').exists():break
        time.sleep(.04)
    assert not (m.root/jid/'working.lock').exists()
    assert client.get('/api/local/jobs/'+jid+'/result').status_code==409
