"""Local carton nets and forward kinematics, in millimetres.

Two idealised authored structures, NOT an imported commercial box library.
Thickness is visual extrusion only; tooling allowances and collisions are not solved.
"""
from __future__ import annotations
import math
from io import StringIO
from typing import Literal
import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator
from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union

class StructureSpec(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)
    kind: Literal['tuck', 'hinged'] = 'tuck'
    length: float = Field(120, ge=40, le=500)
    width: float = Field(80, ge=25, le=350)
    height: float = Field(160, ge=20, le=500)
    glue: float = Field(12, ge=5, le=30)
    tuck: float = Field(12, ge=5, le=30)
    bleed: float = Field(3, ge=0, le=5)
    thickness: float = Field(.4, ge=.1, le=2)

    @model_validator(mode='after')
    def fit(self):
        if self.kind == 'tuck' and self.tuck > self.width * .45:
            raise ValueError('Tuck depth must be at most 45% of width')
        if self.glue > min(self.width, self.height) * .8:
            raise ValueError('Glue flap exceeds 80% of the adjacent wall')
        if self.kind == 'hinged' and self.height > min(self.length, self.width) * .8:
            raise ValueError('Hinged tray height must be at most 80% of min(length, width)')
        return self

def rect(x,y,w,h): return [[x,y],[x+w,y],[x+w,y+h],[x,y+h]]

def build_structure(spec: StructureSpec | dict) -> dict:
    s = spec if isinstance(spec, StructureSpec) else StructureSpec.model_validate(spec)
    L,W,H,G,T=s.length,s.width,s.height,s.glue,s.tuck
    panels=[]
    def add(id, points, parent=None, axis=None, angle=0, stage=(0,1), opening=0, release=(0,1), face=None):
        if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points,points[1:]+points[:1])) < 0:
            points=list(reversed(points))
        p={'id':id,'polygon':points,'parent':parent,'axis':axis,'angle':angle,
           'stage':list(stage),'openAngle':opening,'release':list(release),'sourceFace':face}
        p['visualInset']=(-1 if ('dust' in id or 'glue' in id or 'tuck' in id) else 1 if id.startswith('lid-ear') or id=='lid-lip' else 0)
        poly=Polygon(points)
        if not poly.is_valid or poly.area<=0: raise ValueError('Invalid panel polygon: '+id)
        p['bounds']=list(poly.bounds);panels.append(p)
    if s.kind=='tuck':
        add('front',rect(0,0,L,H),face='front')
        add('right',rect(L,0,W,H),'front',[[L,0],[L,H]],-90,(.05,.35),face='right')
        add('back',rect(L+W,0,L,H),'right',[[L+W,0],[L+W,H]],-90,(.3,.57),face='back')
        add('left',rect(-W,0,W,H),'front',[[0,0],[0,H]],90,(.05,.35),face='left')
        x=2*L+W
        add('glue',[[x,0],[x+G,2],[x+G,H-2],[x,H]],'back',[[x,0],[x,H]],-90,(.55,.72))
        D=min(L*.46,W*.72)
        for name,x in [('left',-W),('right',L)]:
            inset=min(4,W*.12)
            add(name+'-dust-top',[[x,0],[x+inset,-D],[x+W-inset,-D],[x+W,0]],name,[[x,0],[x+W,0]],-90,(.65,.8),85,(.28,.82))
            add(name+'-dust-bottom',[[x,H],[x+W,H],[x+W-inset,H+D],[x+inset,H+D]],name,[[x,H],[x+W,H]],90,(.62,.8))
        add('lid',rect(0,-W,L,W),'front',[[0,0],[L,0]],-90,(.78,.94),120,(.18,1),face='top')
        add('lid-tuck',[[0,-W],[3,-W-T],[L-3,-W-T],[L,-W]],'lid',[[0,-W],[L,-W]],-90,(.92,1),90,(0,.24))
        add('bottom',rect(0,H,L,W),'front',[[0,H],[L,H]],90,(.78,.94),face='bottom')
        add('bottom-tuck',[[0,H+W],[L,H+W],[L-3,H+W+T],[3,H+W+T]],'bottom',[[0,H+W],[L,H+W]],90,(.92,1))
    else:
        add('base',rect(0,0,L,W),face='bottom')
        add('front',rect(0,W,L,H),'base',[[0,W],[L,W]],90,(.25,.55),face='front')
        add('back',rect(0,-H,L,H),'base',[[0,0],[L,0]],-90,(.25,.55),face='back')
        add('left',rect(-H,0,H,W),'base',[[0,0],[0,W]],90,(.45,.68),face='left')
        add('right',rect(L,0,H,W),'base',[[L,0],[L,W]],-90,(.45,.68),face='right')
        for name,y in [('front',W),('back',-H)]:
            for side,x,d in [('left',0,-1),('right',L,1)]:
                add(name+'-glue-'+side,[[x,y],[x+d*G,y+2],[x+d*G,y+H-2],[x,y+H]],name,[[x,y],[x,y+H]],90 if d<0 else -90,(0,.24))
        add('lid',rect(0,-H-W,L,W),'back',[[0,-H],[L,-H]],-90,(.74,.95),115,(.18,1),face='top')
        lip=min(H*.7,25)
        add('lid-lip',[[0,-H-W],[3,-H-W-lip],[L-3,-H-W-lip],[L,-H-W]],'lid',[[0,-H-W],[L,-H-W]],-90,(.9,1),90,(0,.22))
        add('lid-ear-left',rect(-lip,-H-W,lip,W),'lid',[[0,-H-W],[0,-H]],90,(.68,.82),-40,(.12,.5))
        add('lid-ear-right',rect(L,-H-W,lip,W),'lid',[[L,-H-W],[L,-H]],-90,(.68,.82),40,(.12,.5))
    union=unary_union([Polygon(p['polygon']) for p in panels])
    if union.geom_type!='Polygon' or not union.is_valid:
        raise ValueError('Panel net is not one connected polygon')
    total=sum(Polygon(p['polygon']).area for p in panels)
    if abs(total-union.area)>1e-5:
        raise ValueError('Flat panels overlap; choose different dimensions')
    outline=list(map(list,union.exterior.coords))
    bleed=union.buffer(s.bleed,join_style=2)
    creases=[{'panel':p['id'],'points':p['axis']} for p in panels if p['parent']]
    model={'schema':'local-carton/1','spec':s.model_dump(),'panels':panels,
           'cut':[outline]+[list(map(list,r.coords)) for r in union.interiors],
           'creases':creases,'bleed':list(map(list,bleed.exterior.coords)),
           'bounds':list(union.bounds),'area_mm2':round(union.area,4),
           'warnings':['Idealised structure: no tooling tolerances, paper-grain rules or collision solver.',
                       'Thickness affects appearance only; it is NOT a manufacturing allowance.',
                       'SVG/DXF are engineering drafts. Validate a physical sample with your packaging engineer.']}
    # Shared stable framing bound sampled through BOTH motions, padded conservatively.
    radii=[]
    for f,o in [(i/20,0) for i in range(21)]+[(1,i/20) for i in range(21)]:
        a=np.concatenate([np.array(p['points']) for p in pose(model,f,o)['panels']])
        radii.append(float(np.linalg.norm(a,axis=1).max()))
    model['motionRadius']=max(radii)*1.15
    return model

def progress(value, interval):
    a,b=interval;t=max(0.,min(1.,(value-a)/(b-a)))
    return t*t*(3-2*t)

def hinge_matrix(axis, degrees):
    a=np.array([*axis[0],0.],dtype=float);b=np.array([*axis[1],0.],dtype=float)
    u=(b-a)/np.linalg.norm(b-a);x,y,z=u;c=math.cos(math.radians(degrees));sn=math.sin(math.radians(degrees))
    K=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
    R=c*np.eye(3)+(1-c)*np.outer(u,u)+sn*K
    M=np.eye(4);M[:3,:3]=R;M[:3,3]=a-R@a
    return M

def display_matrix(spec):
    L,W,H=spec['length'],spec['width'],spec['height']
    if spec['kind']=='tuck':
        return np.array([[1,0,0,-L/2],[0,-1,0,H/2],[0,0,-1,W/2],[0,0,0,1]],float)
    return np.array([[1,0,0,-L/2],[0,0,1,-H/2],[0,1,0,-W/2],[0,0,0,1]],float)

def pose(model,fold=1.,opening=0.):
    fold=max(0,min(1,float(fold)));opening=max(0,min(1,float(opening)))
    transforms={};out=[];D=display_matrix(model['spec'])
    for p in model['panels']:
        if p['parent']:
            angle=p['angle']*progress(fold,p['stage'])
            angle+=p['openAngle']*progress(opening,p['release'])*progress(fold,(.98,1))
            M=transforms[p['parent']]@hinge_matrix(p['axis'],angle)
        else: angle=0;M=np.eye(4)
        transforms[p['id']]=M
        q=np.array([[x,y,0,1] for x,y in p['polygon']],float)
        pts=(D@M@q.T).T[:,:3]
        out.append({'id':p['id'],'points':pts.tolist(),'matrix':(D@M).tolist(),'angle':angle})
    return {'panels':out}

def export_svg(model):
    x0,y0,x1,y1=model['bounds'];margin=model['spec']['bleed']+4
    def path(points):return 'M'+' L'.join(f'{x:.4f},{y:.4f}' for x,y in points)+' Z'
    # Physical mm units, separate groups for actual cut contour and internal hinges.
    content=f'<svg xmlns="http://www.w3.org/2000/svg" width="{x1-x0+2*margin:.4f}mm" height="{y1-y0+2*margin:.4f}mm" viewBox="{x0-margin} {y0-margin} {x1-x0+2*margin} {y1-y0+2*margin}"><title>Local parametric carton - engineering draft, not production validated</title>'
    content+='<g id="BLEED" fill="none" stroke="#19a66b" stroke-width="0.15" stroke-dasharray="2 1"><path d="'+path(model['bleed'])+'"/></g>'
    content+='<g id="CUT" fill="none" stroke="#e74747" stroke-width="0.2">'+''.join('<path d="'+path(p)+'"/>' for p in model['cut'])+'</g>'
    content+='<g id="CREASE" fill="none" stroke="#2979db" stroke-width="0.2" stroke-dasharray="2 1">'
    for c in model['creases']:
        a,b=c['points'];content+=f'<path d="M{a[0]},{a[1]} L{b[0]},{b[1]}"/>'
    return content+'</g></svg>'

def export_dxf(model):
    """Standards-aware R2010 DXF, millimetres, independently round-trip audited."""
    import ezdxf
    from ezdxf import units
    doc=ezdxf.new('R2010');doc.units=units.MM;doc.header['$MEASUREMENT']=1
    doc.linetypes.new('FOLD_DASH',dxfattribs={'description':'Fold guide','pattern':[3,2,-1]})
    for name,col in [('CUT',1),('CREASE',5),('BLEED',3)]:
        doc.layers.new(name,dxfattribs={'color':col,'linetype':'FOLD_DASH' if name=='CREASE' else 'Continuous'})
    space=doc.modelspace()
    for name,paths in [('CUT',model['cut']),('BLEED',[model['bleed']])]:
        for ring in paths:
            space.add_lwpolyline([(x,-y) for x,y in ring[:-1]],close=True,dxfattribs={'layer':name})
    for crease in model['creases']:
        a,b=crease['points'];space.add_line((a[0],-a[1]),(b[0],-b[1]),dxfattribs={'layer':'CREASE'})
    stream=StringIO();doc.write(stream);return stream.getvalue()
