# 最新完整版 v8.3 / DXF Reader Upgrade

**保留 ezdxf，未移除或替换。** The tested parser is pinned to ezdxf 1.4.4.
This is the full application, not a standalone reader or a patch.
Source baseline: DXF Local v8.2.1. The earlier cancelled instruction to remove
ezdxf was NOT applied. UI layout, larger previews, geometry/folding algorithms,
local rendering, file picker, template catalog and network/deployment policy are
retained. No website login, account secret, paid template or cloud service added.

## 更新内容 / What changed

- The CAD import endpoint now calls `app/dxf_reader.py::read_dxf`.
- ASCII/text and real Binary DXF containers; validated binary framing, finite
  numeric tags, source revision and EOF. ezdxf still loads the CAD document.
- R12, 2000, 2004, 2007, 2010, 2013 and 2018 generated text/binary sample matrix.
  Minimal AC1006/R13/R14 samples test the parser's in-memory revision upgrade;
  they do NOT certify real native drawings from every CAD vendor/version.
- Auto encoding uses BOM, DXF revision and declared codepage. No trial-and-error
  codec guessing, ignore/replacement decoding or silent byte deletion.
- Manual UTF-8, GBK, GB18030, GB2312, Big5/CP950, CP932/Shift-JIS, CP949,
  Windows 1250-1258/874, OEM 437/850, Latin-1 and ASCII selections.
- UTF-16 LE/BE and UTF-32 LE/BE text transports: automatic with BOM; explicit
  byte-order selection without BOM. These are compatibility transports, not a
  claim that CAD's standard DXF text encoding is UTF-16/32. Binary strings cannot
  use UTF-16/32 because the format uses NUL termination.
- Strict reading remains the default. Optional text structural recovery uses
  ezdxf.recover with strict decoding and audit. It may alter/drop entities;
  imported recovery data MUST be reviewed against the original drawing.
- Recovery preview has an acknowledgment checkbox. Validation, export, render,
  editing APIs and library save reject unacknowledged recovered documents.
- The original format/version/encoding, file hash and review flags are kept;
  the source file is NOT overwritten. CAD library still stores normalized data,
  not an untouched source-byte archive. Keep original DXF files separately.

## 启动 / Run a separate local test

### macOS / Linux

```bash
cd baoxiaohe_dxf_local_v8_3
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 server.py
```

### Windows PowerShell (activation is optional)

```powershell
cd baoxiaohe_dxf_local_v8_3
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe server.py
```

Open `http://127.0.0.1:8088/cad` (or your existing published host address).
No npm build is required. Native PDF preview still requires the previously
specified Cairo/fontconfig/CJK system dependencies; see README_DXF_V8.md.
Browser access from Windows does not require those packages on the client.

## 升级已部署的网站 / Upgrade carefully

1. Stop the old service and back up source AND persistent data before replacing
   application files. Never overwrite your `.env`, real database, uploaded assets
   or customized `runtime/catalog.json` with sample distribution files.
2. Full ZIPs are not conflict-aware patch installers. Merge custom source edits.
   Preserve the existing Compose project identity and the existing data volume.
3. In your ORIGINAL deployment directory, rebuild using the SAME environment
   overrides as before:

```bash
docker compose up -d --build --force-recreate web
```

**Do not run `docker compose down -v`.** Starting under a different project name
may create a new data volume and make existing data appear missing.
Network binding is unchanged: published port `0.0.0.0:8088:8088`.
Compose still defaults to production mode, where unconfigured SMS/OAuth fail
closed. This package does not silently enable development sign-in for the public.
Direct Python binding still follows the existing HOST environment setting.
Refresh after restart: Windows Ctrl+Shift+R, Mac Command+Shift+R.

## 使用 / Import workflow

Import CAD -> choose DXF -> Auto encoding + Strict -> Parse and Preview.
Verify storage, revision, encoding, units and line-role mappings. A malformed
structure is NOT solved by cycling through random encodings. For a known
structural defect in a copy, select recovery and parse again. Read the audit and
compare geometry with the original before ticking the review checkbox.

Limits retained: 5 MiB uploaded DXF, 4000 editable primitives, 16000 preview
segments, 100 faces. Reader adds a 250000-tag bound. Files with unknown revisions,
invalid numeric coordinates, unresolved audit errors or invalid containers still
fail clearly. DWG is not DXF. Recovery is NOT available for broken binary streams
or damaged text containing supplementary Unicode (strict reading supports the
characters); no lossy workaround is applied. General 3D solids, SPLINE/ELLIPSE,
all industrial assembly constraints, manufacturing offsets and ICC/PDF-X are NOT
implemented by this reader upgrade. No guarantee for every vendor DXF.

## 测试 / Reproduce

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest tests -q
npm run test:js
npm run check
python3 tools/acceptance_dxf_reader_v8_3.py
```

Observed in this release: 347 Python tests, including 88 new reader tests;
125 JS tests; 20 reader component checks; 16 prior encoding component checks;
10 real local HTTP checks. Groups overlap. Native Windows/macOS, GPU, Docker
build and the user's actual faulty DXF are NOT validated. No factory-production
or original-site pixel-perfect certification. Current evidence is under
`evidence/dxf_reader_v8_3/`; older reports belong to older releases.

See `AUDIT_DXF_READER_V8_3.html`, `RELEASE_V8_3.json` and `MANIFEST.sha256`.

Primary technical references used during implementation:
- https://ezdxf.readthedocs.io/en/stable/drawing/management.html
- https://ezdxf.readthedocs.io/en/stable/drawing/recover.html
- https://ezdxf.readthedocs.io/en/stable/dxfinternals/fileencoding.html
