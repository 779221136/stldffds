"""Local DXF workbench APIs and owner-isolated model library.
Library lives beside the configured application DB (therefore in the existing
Docker data volume). No remote storage, cloud account, or original-site login.
"""
from __future__ import annotations
import json, re, sqlite3, time, secrets, hashlib
from contextlib import contextmanager
from pathlib import Path
from typing import Literal
from fastapi import APIRouter, Request, HTTPException, Response, Query
from pydantic import Field, model_validator
from .cad_engine import (Strict,CadDocument,ImportRequest,ScaleRequest,parse_dxf,analyze,
                         cleaned_document,scale_document,export_dxf,export_svg)
from .local_jobs import owner,manager
from .local_raster import RenderView
from .domain import image_data
from .dxf_reader import ENCODINGS, VERSIONS

def require_review(document):
    if document.import_review_required and not document.import_review_accepted:
        raise ValueError("[DXF_REVIEW_REQUIRED] Confirm comparison with the original recovered drawing before use")

class CadRenderRequest(Strict):
    cad_document: CadDocument
    view: RenderView = Field(default_factory=RenderView)
    textures: dict[str,str] = Field(default_factory=dict,max_length=100)
    exterior: str = Field('#fff9ef',pattern=r'^#[0-9a-fA-F]{6}$')
    interior: str = Field('#dfd5bf',pattern=r'^#[0-9a-fA-F]{6}$')
    format: Literal['png','frames','mp4','webm'] = 'png'
    long_edge: Literal[256,512,1024,2048,3072,4096] = 1024
    aspect: Literal['1:1','4:3','3:4','16:9','9:16'] = '4:3'
    motion: Literal['fold','open','rotate'] = 'fold'
    seconds: int = Field(3,ge=1,le=6)
    fps: int = Field(12,ge=6,le=24)
    @model_validator(mode='after')
    def resources(self):
        if self.format!='png' and (self.long_edge>1024 or self.seconds*self.fps>120):
            raise ValueError('Local animation supports <=1024 px and <=120 frames')
        if self.format in {'mp4','webm'} and self.view.transparent:
            raise ValueError('Use PNG sequence for transparent animation')
        if sum(len(s) for s in self.textures.values())>9_000_000:raise ValueError('Textures exceed 9 MB base64')
        pixels=0
        for key,src in self.textures.items():
            if not re.fullmatch(r'f[a-f0-9]{12}',key):raise ValueError('Invalid panel id')
            mime,raw,size=image_data(src)
            if mime not in {'image/png','image/jpeg'} or not size:raise ValueError('Embedded PNG/JPEG textures only')
            if size[0]*size[1]>4_194_304:raise ValueError('Texture exceeds 4 megapixels')
            pixels+=size[0]*size[1]
        if pixels>16_777_216:raise ValueError('Combined textures exceed 16 megapixels')
        if len(self.model_dump_json().encode())>11*1024*1024:raise ValueError('CAD render request exceeds 11 MiB')
        return self

def render_model(req):
    require_review(req.cad_document)
    info=analyze(req.cad_document)
    if not info['foldable']:raise ValueError('; '.join(info['errors'][:5]))
    if req.format!='png' and req.motion=='open' and not any(abs(h['openAngle'])>1e-5 for h in info['hinges']):raise ValueError('Set at least one hinge opening increment before exporting an opening animation')
    known={p['id'] for p in info['model']['panels']}
    if set(req.textures)-known:raise ValueError('Texture ids do not match the current geometry')
    return info['model']

class SaveRequest(Strict):
    document: CadDocument
    folder: str = Field('',max_length=240)
    tags: list[str] = Field(default_factory=list,max_length=20)
    expected_version: int | None = Field(None,ge=1)
    @model_validator(mode='after')
    def folders(self):
        require_review(self.document)
        parts=self.folder.split('/') if self.folder else []
        if len(parts)>5 or any(not s.strip() or s in {'.','..'} or '\\' in s or len(s)>60 for s in parts):
            raise ValueError('Use up to 5 virtual folder levels; no empty or relative components')
        if any(len(t)>50 for t in self.tags):raise ValueError('Tags must be <=50 characters')
        self.tags=list(dict.fromkeys(t.strip() for t in self.tags if t.strip()))
        return self

class Library:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.db() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS cad_models(
            id TEXT PRIMARY KEY,owner TEXT NOT NULL,name TEXT NOT NULL,folder TEXT NOT NULL,
            tags TEXT NOT NULL,document TEXT NOT NULL,version INTEGER NOT NULL,created REAL NOT NULL,updated REAL NOT NULL)''')
            c.execute('CREATE INDEX IF NOT EXISTS cad_owner ON cad_models(owner,updated)')
    @contextmanager
    def db(self):
        c=sqlite3.connect(self.path,timeout=10);c.row_factory=sqlite3.Row
        try:yield c;c.commit()
        except Exception:c.rollback();raise
        finally:c.close()
    def _view(self,r,full=False):
        r=dict(r);r.pop('owner',None);d=json.loads(r.pop('document'));r['tags']=json.loads(r['tags'])
        if full:r['document']=d
        else:
            # A compact vector thumbnail, not a copy of an uploaded script or HTML.
            paths=d['paths'];r['thumbnail_paths']=[{k:p[k] for k in ['type','role','a','b','center','radius','start','sweep']} for p in paths[:400]]
            r['path_count']=len(paths);r['source_name']=d.get('source_name','')
        return r
    def get(self,who,mid):
        with self.db() as c:r=c.execute('SELECT * FROM cad_models WHERE owner=? AND id=?',(who,mid)).fetchone()
        if r is None:raise HTTPException(404,'CAD model not found')
        return self._view(r,True)
    def list(self,who,q='',folder='',tag='',page=1,page_size=20):
        clauses=['owner=?'];args=[who]
        # Literal substring matching, not wildcard/SQL interpretation.
        if q:clauses.append('(instr(lower(name),lower(?))>0 OR instr(lower(tags),lower(?))>0)');args.extend([q,q])
        if folder:clauses.append('(folder=? OR substr(folder,1,?)=?)');args.extend([folder,len(folder)+1,folder+'/'])
        if tag:clauses.append('EXISTS (SELECT 1 FROM json_each(cad_models.tags) WHERE value=?)');args.append(tag)
        where=' AND '.join(clauses)
        with self.db() as c:
            total=c.execute('SELECT count(*) FROM cad_models WHERE '+where,args).fetchone()[0]
            rows=c.execute('SELECT * FROM cad_models WHERE '+where+' ORDER BY updated DESC,id LIMIT ? OFFSET ?',args+[page_size,(page-1)*page_size]).fetchall()
            folders=[r[0] for r in c.execute('SELECT DISTINCT folder FROM cad_models WHERE owner=? ORDER BY folder',(who,)).fetchall() if r[0]]
        return {'items':[self._view(r) for r in rows],'total':total,'page':page,'page_size':page_size,'folders':folders}
    def save(self,who,req,mid=None):
        now=time.time();document=req.document.model_dump_json();tags=json.dumps(req.tags,ensure_ascii=False)
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            # Storage checks apply to updates as well as creates.
            prev=c.execute('SELECT length(cast(document AS BLOB)) FROM cad_models WHERE id=? AND owner=?',(mid or '',who)).fetchone()
            previous_bytes=prev[0] if prev else 0
            user_bytes=c.execute('SELECT coalesce(sum(length(cast(document AS BLOB))),0) FROM cad_models WHERE owner=?',(who,)).fetchone()[0]
            total_bytes=c.execute('SELECT coalesce(sum(length(cast(document AS BLOB))),0) FROM cad_models').fetchone()[0]
            size=len(document.encode())
            if user_bytes-previous_bytes+size>256*1024*1024 or total_bytes-previous_bytes+size>1024*1024*1024:
                raise HTTPException(429,'Local CAD storage quota reached')
            if mid:
                old=c.execute('SELECT * FROM cad_models WHERE id=? AND owner=?',(mid,who)).fetchone()
                if old is None:raise HTTPException(404,'CAD model not found')
                if req.expected_version!=old['version']:raise HTTPException(409,'CAD model changed; reload it or save a new copy')
                ver=old['version']+1
                c.execute('UPDATE cad_models SET name=?,folder=?,tags=?,document=?,version=?,updated=? WHERE id=? AND owner=?',(req.document.name,req.folder,tags,document,ver,now,mid,who))
            else:
                count,size=c.execute('SELECT count(*),coalesce(sum(length(document)),0) FROM cad_models WHERE owner=?',(who,)).fetchone()
                if count>=500 or size+len(document.encode())>256*1024*1024:raise HTTPException(429,'Local CAD library limit reached (500 models / 256 MiB per session)')
                total=c.execute('SELECT coalesce(sum(length(document)),0) FROM cad_models').fetchone()[0]
                if total+len(document.encode())>1024*1024*1024:raise HTTPException(429,'Local CAD library storage reached 1 GiB')
                mid=secrets.token_hex(16)
                c.execute('INSERT INTO cad_models VALUES(?,?,?,?,?,?,1,?,?)',(mid,who,req.document.name,req.folder,tags,document,now,now))
        return self.get(who,mid)
    def delete(self,who,mid,version):
        with self.db() as c:
            r=c.execute('SELECT version FROM cad_models WHERE owner=? AND id=?',(who,mid)).fetchone()
            if r is None:raise HTTPException(404,'CAD model not found')
            if r[0]!=version:raise HTTPException(409,'Model changed; reload before deleting')
            c.execute('DELETE FROM cad_models WHERE id=? AND owner=?',(mid,who))


def create_router(root_getter,user_getter=lambda request:None):
    router=APIRouter(prefix='/api/local/cad',tags=['local-cad'])
    def store():return Library(Path(root_getter())/'cad-library.sqlite')
    def library_owner(request):
        user=user_getter(request)
        if user:return 'account:'+hashlib.sha256(('cad-local-user:'+str(user['id'])).encode()).hexdigest()
        return owner(request)
    def safe(fn,*args):
        try:return fn(*args)
        except ValueError as e:raise HTTPException(422,str(e)) from e
    @router.get('/capabilities')
    def capabilities(request:Request):
        return {'library_scope':'local-account' if user_getter(request) else 'anonymous-session', ** {'cloud':False,'units':'mm','entities':['LINE','ARC','CIRCLE','LWPOLYLINE','2D POLYLINE','simple INSERT'],
                'reader':'ezdxf','dxf_versions':VERSIONS,'dxf_storage':['ascii','binary'],
                'dxf_encodings':list(ENCODINGS),'recovery':'Text only; strict by default, review required',
                'max_file_mib':5,'max_paths':4000,'max_faces':100,'max_curve_segments':16000,
                'storage':'Local SQLite in the application data volume','production_validated':False,
                'fold_solver':'Face adjacency tree with user-confirmed angles; not a collision or constraint solver'}}
    @router.post('/import')
    def imp(req:ImportRequest,request:Request):
        owner(request);return safe(parse_dxf,req)
    @router.post('/analyze')
    def anal(req:CadDocument,request:Request):owner(request);safe(require_review,req);return safe(analyze,req)
    @router.post('/cleanup')
    def cleanup(req:CadDocument,request:Request):owner(request);safe(require_review,req);return {'document':safe(cleaned_document,req).model_dump()}
    @router.post('/scale')
    def scale(req:ScaleRequest,request:Request):owner(request);safe(require_review,req.document);return {'document':safe(scale_document,req.document,req.x,req.y).model_dump()}
    @router.post('/validate')
    def validate(req:CadDocument,request:Request):owner(request);safe(require_review,req);return {'document':req.model_dump()}
    @router.post('/export/{fmt}')
    def export(fmt:str,req:CadDocument,request:Request):
        owner(request);safe(require_review,req)
        if fmt not in {'dxf','svg'}:raise HTTPException(404,'Use dxf or svg')
        if any(p.role=='unassigned' for p in req.paths):raise HTTPException(422,'Assign all line types before exporting; unknown lines will not be silently discarded')
        data=safe(export_dxf if fmt=='dxf' else export_svg,req)
        return Response(data,media_type='application/dxf' if fmt=='dxf' else 'image/svg+xml',headers={'Content-Disposition':f'attachment; filename="local-dieline-review.{fmt}"'})
    @router.get('/library')
    def listing(request:Request,q:str=Query('',max_length=120),folder:str=Query('',max_length=240),tag:str=Query('',max_length=50),page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=50)):
        return store().list(library_owner(request),q,folder,tag,page,page_size)
    @router.post('/library',status_code=201)
    def save(req:SaveRequest,request:Request):return store().save(library_owner(request),req)
    @router.get('/library/{mid}')
    def get(mid:str,request:Request):return store().get(library_owner(request),mid)
    @router.put('/library/{mid}')
    def update(mid:str,req:SaveRequest,request:Request):return store().save(library_owner(request),req,mid)
    @router.delete('/library/{mid}')
    def delete(mid:str,request:Request,version:int=Query(...,ge=1)):
        store().delete(library_owner(request),mid,version);return {'deleted':True}
    @router.post('/jobs',status_code=202)
    def job(req:CadRenderRequest,request:Request):
        who=owner(request);safe(render_model,req)
        if req.format in {'mp4','webm'}:
            from .local_worker import ffmpeg_binary
            if not ffmpeg_binary():raise HTTPException(503,'FFmpeg unavailable; choose PNG frames')
        return manager(request).add(who,req)
    return router
