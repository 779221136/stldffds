"""Bounded DXF container/encoding adapter; ezdxf remains the document parser.

No network access, ODA process, file overwrite, blind codec guessing or lossy
Unicode decoding. Recovery is opt-in, text-only, audited and requires review.
The old dxf_text_reader.read_ascii_dxf helper is retained for legacy callers;
the CAD API calls read_dxf below. Binary group decoding is bounded here so that
manual legacy codepages work and metadata is not restricted to a byte prefix.
"""
from __future__ import annotations

import codecs
import math
import struct
from io import StringIO, BytesIO
from typing import Literal

import ezdxf
from ezdxf import recover
from ezdxf.document import Drawing
from ezdxf.filemanagement import dxf_stream_info
from ezdxf.lldxf.const import DXFError
from ezdxf.lldxf.tagger import ascii_tags_loader, INT16, INT32, INT64, DOUBLE, BYTES, BINARY_DATA
from ezdxf.lldxf.types import DXFTag, DXFBinaryTag
from ezdxf.lldxf.validator import is_dxf_stream
from ezdxf.tools.codepage import codepage_to_encoding

DxfEncoding = Literal[
    'auto', 'ascii', 'utf-8', 'utf-16-le', 'utf-16-be', 'utf-32-le', 'utf-32-be',
    'gbk', 'gb18030', 'gb2312', 'cp950', 'big5', 'cp932', 'shift_jis', 'cp949',
    'cp874', 'cp1250', 'cp1251', 'cp1252', 'cp1253', 'cp1254', 'cp1255', 'cp1256',
    'cp1257', 'cp1258', 'cp437', 'cp850', 'latin-1',
]
ENCODINGS = tuple(DxfEncoding.__args__)
ReadMode = Literal['strict', 'recover']
MAX_DXF_BYTES = 5 * 1024 * 1024
MAX_TAGS = 250_000
BINARY_SIGNATURE = b'AutoCAD Binary DXF\r\n\x1a\x00'
VERSIONS = {
    'AC1002': 'R2.5', 'AC1003': 'R2.6', 'AC1004': 'R9', 'AC1006': 'R10',
    'AC1009': 'R11/R12', 'AC1012': 'R13', 'AC1014': 'R14', 'AC1015': '2000',
    'AC1018': '2004', 'AC1021': '2007', 'AC1024': '2010', 'AC1027': '2013', 'AC1032': '2018',
}
BOMS = ((codecs.BOM_UTF32_LE, 'utf-32-le'), (codecs.BOM_UTF32_BE, 'utf-32-be'),
        (codecs.BOM_UTF8, 'utf-8'), (codecs.BOM_UTF16_LE, 'utf-16-le'), (codecs.BOM_UTF16_BE, 'utf-16-be'))
PARSER_ERRORS = (DXFError, ValueError, StopIteration, EOFError, IndexError, KeyError, struct.error)


def _normal(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def _detail(exc):
    # Do not return tracebacks, paths, entity contents or credentials to clients.
    msg = str(exc).replace('\r', ' ').replace('\n', ' ')
    return type(exc).__name__ + ': ' + msg[:180]


def _header(tags):
    """Read real HEADER tags only. Never match comments/entity text as metadata."""
    version, codepage, unit = 'AC1009', None, 0
    inside, section_pending, pending = False, False, None
    for code, value in tags:
        if isinstance(value, bytes):
            if code in BINARY_DATA:
                continue
            value = value.decode('ascii', errors='strict') if code in (0, 2, 9) or pending in ('$ACADVER', '$DWGCODEPAGE', '$INSUNITS') else ''
        if code == 0:
            if value == 'ENDSEC' and inside:
                break
            section_pending = value == 'SECTION'
            inside = False
            pending = None
            continue
        if section_pending:
            inside = code == 2 and value == 'HEADER'
            section_pending = False
            continue
        if not inside:
            continue
        if code == 9:
            pending = value
            continue
        if pending == '$ACADVER':
            if code != 1:
                raise ValueError('Invalid $ACADVER group')
            version = str(value).strip()
        elif pending == '$DWGCODEPAGE':
            if code != 3:
                raise ValueError('Invalid $DWGCODEPAGE group')
            codepage = str(value).strip()
        elif pending == '$INSUNITS':
            if code != 70:
                raise ValueError('Invalid $INSUNITS group')
            unit = int(value)
        pending = None
    return version, codepage, unit


def _source_codec(version, codepage):
    if version >= 'AC1021':
        return 'utf-8', 'version-utf8'
    if not codepage:
        return 'cp1252', 'legacy-default'
    name = codepage.upper()
    if name.startswith('ANSI_') and name[5:] in codepage_to_encoding:
        return codepage_to_encoding[name[5:]], 'header-codepage'
    if name in ('DOS437', 'DOS_437', 'DOS850', 'DOS_850'):
        return ('cp437' if name.endswith('437') else 'cp850'), 'header-codepage'
    return None, 'unrecognized-header'


def _select_codec(version, codepage, encoding, bom_codec, warnings):
    if version not in VERSIONS:
        raise ValueError('[DXF_VERSION] Unsupported declared version: '+version[:24]+'. Export a supported DXF revision in CAD; do not edit only $ACADVER.')
    detected, origin = _source_codec(version, codepage)
    if bom_codec:
        if encoding != 'auto' and codecs.lookup(encoding).name != codecs.lookup(bom_codec).name:
            raise ValueError('[DXF_ENCODING_CONFLICT] Selected encoding conflicts with the file BOM; choose Auto or '+bom_codec)
        selected, origin = bom_codec, 'utf8-bom' if bom_codec == 'utf-8' else 'unicode-bom'
        warnings.append(bom_codec+' BOM removed for parsing. Geometry and original file bytes are unchanged.')
        if bom_codec != detected:
            warnings.append('BOM transport encoding overrides the DXF codepage. Verify layer names and units.')
    elif encoding != 'auto':
        selected, origin = encoding, 'manual'
        warnings.append('Manual DXF text encoding: '+selected+'. Verify layer names and line-role mappings before confirming.')
    else:
        if detected is None:
            raise ValueError('[DXF_CODEPAGE] Unrecognized $DWGCODEPAGE; select the known source encoding instead of guessing')
        selected = detected
    return selected, detected, origin


def _raw_binary_tags(raw):
    """Parse primitive tag framing, NOT CAD entities. Then use Drawing.load.

    R12 has one-byte codes with a 255 extended marker; R13+ two-byte codes.
    Embedded strings stay bytes until the actual HEADER encoding is known.
    All reads are bounds checked, including binary chunk length and EOF.
    """
    if not raw.startswith(BINARY_SIGNATURE) or len(raw) <= 24:
        raise ValueError('[DXF_BINARY] Invalid or truncated binary DXF signature/header')
    index = len(BINARY_SIGNATURE)
    modern = raw[index:index+2] == b'\0\0'
    if raw[index] != 0:
        raise ValueError('[DXF_BINARY] Binary DXF must start with a SECTION record')
    tags, ended = [], False
    n = len(raw)

    def need(count):
        if index + count > n:
            raise ValueError('[DXF_BINARY] Truncated tag near byte '+str(index))

    while index < n:
        need(2 if modern else 1)
        if modern:
            code = struct.unpack_from('<H', raw, index)[0];index += 2
        else:
            code = raw[index];index += 1
            if code == 255:
                need(2);code = struct.unpack_from('<H', raw, index)[0];index += 2
        if not 0 <= code <= 1071:
            raise ValueError('[DXF_BINARY] Invalid group code '+str(code)+' near byte '+str(index))
        if code in BINARY_DATA:
            need(1);size=raw[index];index+=1;need(size);value=raw[index:index+size];index+=size
        elif code in BYTES:
            need(1);value=raw[index];index+=1
        else:
            spec = ('<h',2) if code in INT16 else ('<i',4) if code in INT32 else ('<q',8) if code in INT64 else ('<d',8) if code in DOUBLE else None
            if spec:
                need(spec[1]);value=struct.unpack_from(spec[0],raw,index)[0];index+=spec[1]
                if isinstance(value,float) and not math.isfinite(value):
                    raise ValueError('[DXF_BINARY] Non-finite numeric tag')
            else:
                end=raw.find(b'\0',index)
                if end < 0:
                    raise ValueError('[DXF_BINARY] Unterminated string near byte '+str(index))
                value=raw[index:end];index=end+1
        tags.append((code,value))
        if len(tags) > MAX_TAGS:
            raise ValueError('[DXF_LIMIT] Tag count exceeds 250000')
        if code == 0 and value == b'EOF':
            ended=True
            if index != n:
                raise ValueError('[DXF_BINARY] Unexpected bytes after EOF')
            break
    if not ended:
        raise ValueError('[DXF_BINARY] Missing EOF; binary recovery is not applied')
    version, _, _ = _header(tags)
    if modern != (version > 'AC1009'):
        raise ValueError('[DXF_VERSION] Binary group-code width conflicts with declared revision')
    return tags


def _recover_text(text):
    # Escape already decoded Unicode rather than guessing the source encoding a
    # second time. dxfreplace is ezdxf's registered non-lossy DXF escape handler.
    if any(ord(char) > 0xFFFF for char in text):
        raise ValueError('[DXF_RECOVERY_UNICODE] Supplementary Unicode in a structurally damaged file cannot be recovered losslessly by this adapter; strict reading still supports it. Re-export from CAD.')
    escaped = text.encode('ascii', errors='dxfreplace')
    if len(escaped) > 40 * 1024 * 1024:
        raise ValueError('[DXF_LIMIT] Unicode recovery transport exceeds 40 MiB')
    drawing, auditor = recover.read(BytesIO(escaped), errors='strict')
    errors = [{'code':int(x.code), 'message':str(x.message)[:180]} for x in auditor.errors[:50]]
    fixes = [{'code':int(x.code), 'message':str(x.message)[:180]} for x in auditor.fixes[:50]]
    if auditor.has_errors:
        raise ValueError('[DXF_RECOVERY_UNRESOLVED] '+str(len(auditor.errors))+' unresolved audit errors; first: '+str(errors[0] if errors else 'unknown')+'. Import blocked to avoid silently accepting damaged geometry.')
    return drawing, fixes, len(auditor.fixes)


def read_dxf(raw: bytes, encoding: DxfEncoding = 'auto', mode: ReadMode = 'strict'):
    """Return Drawing, format/encoding/audit metadata, and bounded warnings."""
    if encoding not in ENCODINGS:
        raise ValueError('[DXF_ENCODING_OPTION] Unsupported encoding selection')
    if mode not in ('strict','recover'):
        raise ValueError('[DXF_READ_MODE] Use strict or recover')
    if not raw:
        raise ValueError('[DXF_EMPTY] The DXF file is empty')
    if len(raw) > MAX_DXF_BYTES:
        raise ValueError('DXF exceeds 5 MiB')
    if raw[:4] == b'AC10':
        raise ValueError('[DXF_DWG] This is a DWG signature, not DXF; renaming is not conversion')
    if raw.startswith((b'%PDF',b'PK\x03\x04',b'PK\x05\x06')):
        raise ValueError('[DXF_FORMAT] PDF/ZIP is not a DXF container')
    binary=raw.startswith(b'AutoCAD Binary DXF')
    warnings=[];bom_codec=None;has_cr=False;fixes=[];fix_count=0;recovered=False;strict_error=None
    if binary:
        tags=_raw_binary_tags(raw)
        version,codepage,unit=_header(tags)
        selected,detected,origin=_select_codec(version,codepage,encoding,None,warnings)
        if selected.startswith(('utf-16','utf-32')):
            raise ValueError('[DXF_ENCODING_OPTION] UTF-16/32 are not valid for NUL-terminated binary DXF strings')
        try:
            typed=[]
            for code,value in tags:
                if code in BINARY_DATA:
                    typed.append(DXFBinaryTag(code,value))
                else:
                    typed.append(DXFTag(code,value.decode(selected,errors='strict') if isinstance(value,bytes) else value))
            drawing=Drawing.load(iter(typed))
        except UnicodeDecodeError as exc:
            raise ValueError('[DXF_ENCODING] Binary strings do not match '+selected+'. No bytes discarded; select the known source codepage.') from exc
        except PARSER_ERRORS as exc:
            raise ValueError('[DXF_STRUCTURE] Binary DXF document load failed: '+_detail(exc)+'. Binary structural recovery is not supported.') from exc
        if mode == 'recover':
            warnings.append('Binary DXF was loaded strictly. Structural recovery is available only for text DXF.')
    else:
        body=raw
        for marker,name in BOMS:
            if raw.startswith(marker):
                bom_codec=name;body=raw[len(marker):];break
        transport=bom_codec or (encoding if encoding.startswith(('utf-16','utf-32')) else None)
        try:
            probe=_normal(body.decode(transport or 'latin-1', errors='strict'))
        except UnicodeDecodeError as exc:
            raise ValueError('[DXF_ENCODING] Invalid '+str(transport)+' transport bytes') from exc
        if '\x00' in probe:
            raise ValueError('[DXF_FORMAT] NULs in text DXF. For a known BOM-less UTF-16/32 file choose its exact byte order.')
        if not is_dxf_stream(StringIO(probe)):
            raise ValueError('[DXF_FORMAT] No valid text DXF SECTION/group-code prefix')
        if len(probe.splitlines()) > MAX_TAGS * 2 + 2:
            raise ValueError('[DXF_LIMIT] Tag count exceeds 250000')
        try:
            info=dxf_stream_info(StringIO(probe))
            version,codepage,unit=_header(ascii_tags_loader(StringIO(probe)))
        except PARSER_ERRORS as exc:
            raise ValueError('[DXF_HEADER] Invalid DXF HEADER: '+_detail(exc)) from exc
        selected,detected,origin=_select_codec(version,codepage,encoding,bom_codec,warnings)
        try:
            decoded=body.decode(selected,errors='strict')
        except UnicodeDecodeError as exc:
            raise ValueError('[DXF_ENCODING] File bytes do not match '+selected+' ('+origin+'). No bytes discarded. Select the known source encoding.') from exc
        has_cr='\r' in decoded;text=_normal(decoded)
        if has_cr:
            warnings.append('CR/CRLF record endings normalized to LF; coordinates unchanged.')
        if origin == 'legacy-default' and any(b>=128 for b in body):
            warnings.append('Legacy DXF has no $DWGCODEPAGE. Used cp1252 default; verify names or select the known source encoding.')
        try:
            drawing=ezdxf.read(StringIO(text))
        except PARSER_ERRORS as exc:
            strict_error=_detail(exc)
            if mode != 'recover':
                raise ValueError('[DXF_STRUCTURE] Decoded with '+selected+', but document structure failed: '+strict_error+'. Enable recovery only for a copy, then review geometry and audit changes.') from exc
            try:
                drawing,fixes,fix_count=_recover_text(text)
            except UnicodeDecodeError as err:
                raise ValueError('[DXF_ENCODING] Recovery encountered undecodable data; no replacement or byte dropping allowed') from err
            except PARSER_ERRORS as err:
                raise ValueError('[DXF_RECOVERY] Recovery failed or has unresolved errors: '+_detail(err)) from err
            recovered=True
            warnings.append('RECOVERY REVIEW REQUIRED: '+strict_error+'. '+str(fix_count)+' audit fixes reported. Compare all lines, dimensions and layer mappings against the original before accepting; not manufacturing validation.')
    if drawing.dxfversion != version:
        warnings.append('DXF in-memory revision normalized by ezdxf: '+version+' -> '+drawing.dxfversion+'. Original file unchanged.')
    metadata={
        'storage':'binary' if binary else 'ascii', 'encoding':selected,
        'detected_encoding':detected, 'encoding_source':origin,
        'declared_codepage':codepage, 'source_version':version,
        'version_label':VERSIONS[version], 'loaded_version':drawing.dxfversion,
        'declared_units':unit, 'utf8_bom_removed':bom_codec=='utf-8',
        'bom_encoding':bom_codec, 'line_endings_normalized':has_cr,
        'reader':'ezdxf', 'reader_version':ezdxf.__version__, 'mode':mode,
        'recovered':recovered, 'requires_review':recovered,
        'strict_error':strict_error, 'audit_fix_count':fix_count, 'audit_fixes':fixes,
    }
    return drawing,metadata,warnings
