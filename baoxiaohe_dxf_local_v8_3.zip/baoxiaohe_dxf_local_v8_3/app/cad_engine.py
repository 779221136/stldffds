"""Local DXF import, editable primitives, explicit topology and fold proposals.
Native LINE/ARC/CIRCLE geometry stays analytic for DXF export. Meshing is an
approximation with a declared sagitta tolerance, never manufacturing approval.
No network requests, external references, expressions or executable project data.
"""
from __future__ import annotations
import base64
import hashlib
import math
from collections import Counter, defaultdict, deque
from io import StringIO, BytesIO
from typing import Literal
import ezdxf
import numpy as np
from ezdxf import units
from pydantic import BaseModel, ConfigDict, Field, model_validator
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import unary_union, polygonize_full, linemerge, triangulate
from shapely.geometry.polygon import orient
from shapely.strtree import STRtree
from .domain import DesignObject
from .panel_layers import assign_preview_layers
from .dxf_reader import DxfEncoding, ReadMode, read_dxf

MAX_PATHS = 4000
MAX_SEGMENTS = 16000
MAX_FACES = 100
ROLE = Literal['cut', 'crease', 'perf', 'guide', 'ignore', 'unassigned']
VEC = tuple[float, float]

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)

class CadPath(Strict):
    id: str = Field(min_length=1, max_length=80, pattern=r'^[A-Za-z0-9_.:-]+$')
    type: Literal['LINE','ARC','CIRCLE']
    role: ROLE = 'unassigned'
    layer: str = Field('0', max_length=255)
    color: int = Field(7, ge=1, le=255)
    group: str = Field('', max_length=280)
    source: str = Field('', max_length=120)
    a: VEC = (0,0)
    b: VEC = (0,0)
    center: VEC = (0,0)
    radius: float = Field(1, gt=0, le=10000)
    start: float = Field(0, ge=-36000, le=36000)
    sweep: float = Field(90, gt=0, le=360)
    @model_validator(mode='after')
    def valid(self):
        if any(abs(v)>100000 for p in [self.a,self.b,self.center] for v in p):
            raise ValueError('Coordinates exceed the local CAD limit')
        if self.type=='LINE' and math.dist(self.a,self.b)<1e-8:
            raise ValueError('Zero-length line')
        return self

class CadOptions(Strict):
    curve_tolerance: float = Field(.08, ge=.005, le=1)
    snap_tolerance: float = Field(.05, ge=0, le=.5)
    thickness: float = Field(.4, ge=0, le=5)
    bleed: float = Field(3, ge=0, le=20)
    material: str = Field('paperboard', max_length=100)
    fold_allowance: float = Field(0, ge=-10, le=10)
    root: str | None = Field(None, max_length=80)

class HingeSetting(Strict):
    angle: float = Field(90, ge=-180, le=180)
    openAngle: float = Field(0, ge=-180, le=180)
    stage: tuple[float,float] = (0,1)
    confirmed: bool = False
    @model_validator(mode='after')
    def order(self):
        if not 0<=self.stage[0]<self.stage[1]<=1:raise ValueError('Fold interval must be ordered in [0,1]')
        return self

class Placement(Strict):
    # Millimetres -> the existing 1180 x 760 SVG design canvas. Independent net layer.
    scale: float = Field(1, gt=.0001, le=1000)
    x: float = Field(590, ge=-100000, le=100000)
    y: float = Field(380, ge=-100000, le=100000)
    rotation: float = Field(0, ge=-360, le=360)
    visible: bool = True
    locked: bool = True

class CadDocument(Strict):
    schema: Literal['local-dxf/1'] = 'local-dxf/1'
    name: str = Field('Imported dieline', min_length=1, max_length=120)
    paths: list[CadPath] = Field(default_factory=list, max_length=MAX_PATHS)
    options: CadOptions = Field(default_factory=CadOptions)
    hinges: dict[str,HingeSetting] = Field(default_factory=dict, max_length=MAX_FACES)
    placement: Placement = Field(default_factory=Placement)
    objects: list[DesignObject] = Field(default_factory=list, max_length=300)
    background: str = Field('#fff9ef', pattern=r'^#[0-9a-fA-F]{6}$')
    source_name: str = Field('', max_length=255)
    source_sha256: str = Field('', max_length=64, pattern=r'^(?:[a-f0-9]{64})?$')
    source_unit: str = Field('mm', max_length=32)
    source_version: str = Field('', max_length=32)
    source_storage: Literal['', 'ascii', 'binary'] = ''
    source_encoding: str = Field('', max_length=32)
    import_review_required: bool = False
    import_review_accepted: bool = False
    import_warnings: list[str] = Field(default_factory=list, max_length=200)
    @model_validator(mode='after')
    def unique(self):
        segment_budget=0
        for p in self.paths:
            if p.type=='LINE':segment_budget+=1
            else:
                sweep=360 if p.type=='CIRCLE' else p.sweep
                step=math.degrees(2*math.acos(max(-1,min(1,1-self.options.curve_tolerance/p.radius))))
                segment_budget+=max(4 if p.type=='CIRCLE' else 1,math.ceil(sweep/max(step,.01)))
            if segment_budget>MAX_SEGMENTS:raise ValueError('All drawing layers together exceed 16000 preview segments; increase tolerance or simplify the file')
        if len({p.id for p in self.paths})!=len(self.paths):raise ValueError('Duplicate path ids')
        if len({o.id for o in self.objects})!=len(self.objects):raise ValueError('Duplicate object ids')
        if len(self.model_dump_json().encode())>10*1024*1024:raise ValueError('CAD project exceeds 10 MiB')
        return self

class ImportRequest(Strict):
    filename: str = Field('drawing.dxf', max_length=255)
    data: str = Field(min_length=1, max_length=7_000_000)
    unit: Literal['auto','mm','cm','m','in'] = 'auto'
    encoding: DxfEncoding = 'auto'
    reader_mode: ReadMode = 'strict'
    mapping: dict[str,ROLE] = Field(default_factory=dict, max_length=500)
    curve_tolerance: float = Field(.08, ge=.005, le=1)


def sampled(p: CadPath, tolerance=.08):
    if p.type=='LINE':return [list(p.a),list(p.b)]
    sweep=360 if p.type=='CIRCLE' else p.sweep
    step=math.degrees(2*math.acos(max(-1,min(1,1-tolerance/p.radius))))
    count=max(4 if p.type=='CIRCLE' else 1,math.ceil(sweep/max(step,.01)))
    if count>MAX_SEGMENTS:raise ValueError('Curve has too many segments; increase tolerance')
    start=0 if p.type=='CIRCLE' else p.start
    points=[[p.center[0]+p.radius*math.cos(math.radians(start+sweep*i/count)),
             p.center[1]+p.radius*math.sin(math.radians(start+sweep*i/count))] for i in range(count+1)]
    if p.type=='CIRCLE':points[-1]=points[0][:]  # exact topological closure, not a trigonometric epsilon gap
    return points


def guess_role(layer, color, linetype):
    s=layer.casefold()
    if any(x in s for x in ['crease','fold','bend','score','\u6298','\u538b\u75d5']):return 'crease'
    if any(x in s for x in ['guide','reference','construction','bleed','safe','dimension','defpoints','\u51fa\u8840','\u6807\u6ce8']):return 'guide'
    if any(x in s for x in ['perf','\u865a\u7ebf']):return 'perf'
    if any(x in s for x in ['cut','knife','outline','\u5207','\u5200']):return 'cut'
    # Official help uses red crease / blue cut. Always exposed for confirmation.
    if color==1:return 'crease'
    if color==5:return 'cut'
    return 'unassigned'


def parse_dxf(req: ImportRequest):
    if not req.filename.lower().endswith('.dxf'):raise ValueError('Only .dxf files are accepted (not DWG)')
    try:raw=base64.b64decode(req.data,validate=True)
    except Exception as e:raise ValueError('DXF data must be base64') from e
    if len(raw)>5*1024*1024:raise ValueError('DXF exceeds 5 MiB')
    doc,encoding_info,decode_warnings=read_dxf(raw,req.encoding,req.reader_mode)
    # ezdxf may synthesize HEADER defaults for headerless R12 files; only
    # trust the unit read from the original stream, never a generated default.
    code=int(encoding_info['declared_units'])
    scales={'mm':1,'cm':10,'m':1000,'in':25.4}
    if req.unit=='auto':
        if code==0:raise ValueError('DXF has no declared units. Select mm, cm, m or in explicitly.')
        try:factor=units.conversion_factor(code,units.MM)
        except Exception as e:raise ValueError('Unsupported DXF unit; select units explicitly') from e
        unit_name=str(code)
    else:factor=scales[req.unit];unit_name=req.unit
    if not math.isfinite(factor) or factor<=0:raise ValueError('Invalid unit scale')
    paths=[];groups={};skipped=Counter();warnings=list(decode_warnings);count=0
    def emit(e,source,layer=None,byblock=7,depth=0):
        nonlocal count
        count+=1
        if count>8000:raise ValueError('Too many DXF entities (8000 including block contents)')
        if depth>6:raise ValueError('Block nesting exceeds 6')
        kind=e.dxftype();lname=e.dxf.get('layer','0')
        if lname=='0' and layer:lname=layer
        lay=doc.layers.get(lname) if lname in doc.layers else None
        if e.dxf.get('invisible',0) or (lay and (lay.is_off() or lay.is_frozen())):
            skipped['hidden']+=1;return
        col=int(e.dxf.get('color',256))
        if col==256:col=abs(lay.dxf.color) if lay else 7
        if col==0:col=byblock
        col=max(1,min(255,col))
        group=f'{lname}|{col}';role=req.mapping.get(group,req.mapping.get(lname,guess_role(lname,col,e.dxf.get('linetype','CONTINUOUS'))))
        if kind=='INSERT':
            if e.mcount>1:raise ValueError('MINSERT arrays are not supported; explode in CAD first')
            try:
                dropped=[]
                for sub in e.virtual_entities(skipped_entity_callback=lambda en,reason:dropped.append(reason)):
                    emit(sub,source+':block',lname,col,depth+1)
                if dropped:raise ValueError('Some block entities cannot be transformed: '+str(dropped[:3]))
            except Exception as exc:raise ValueError('Unsupported block transform; explode blocks before import') from exc
            return
        if kind in {'LWPOLYLINE','POLYLINE'}:
            if kind=='POLYLINE' and not e.is_2d_polyline:
                skipped[kind+'-3D']+=1;return
            if kind=='LWPOLYLINE' and e.has_width:warnings.append('Polyline widths are not knife offsets; the centreline was imported.')
            for j,sub in enumerate(e.virtual_entities()):emit(sub,source+':'+str(j),lname,col,depth+1)
            return
        if kind not in {'LINE','ARC','CIRCLE'}:skipped[kind]+=1;return
        def pt(v):
            if abs(v.z)>1e-5:raise ValueError('Only planar XY dielines are supported (non-zero Z detected)')
            return (float(v.x)*factor,float(v.y)*factor)
        values={'id':f'p{len(paths)+1}','type':kind,'role':role,'layer':lname,'color':col,'group':group,'source':source}
        if kind=='LINE':
            a,b=pt(e.dxf.start),pt(e.dxf.end)
            if math.dist(a,b)<1e-8:skipped['zero-length']+=1;return
            values.update(a=a,b=b)
        else:
            extrusion=e.dxf.get('extrusion',(0,0,1))
            if not np.allclose(extrusion,(0,0,1),atol=1e-8):
                raise ValueError('Non-default curve extrusion is not supported; flatten to world XY in CAD')
            values.update(center=pt(e.dxf.center),radius=float(e.dxf.radius)*factor)
            if kind=='ARC':
                sweep=(float(e.dxf.end_angle)-float(e.dxf.start_angle))%360
                if sweep<1e-8:skipped['zero-arc']+=1;return
                values.update(start=float(e.dxf.start_angle),sweep=sweep)
        paths.append(CadPath(**values));groups.setdefault(group,{'group':group,'layer':lname,'color':col,'role':role,'count':0})['count']+=1
        if len(paths)>MAX_PATHS:raise ValueError('More than 4000 editable primitives')
    for e in doc.modelspace():emit(e,str(e.dxf.get('handle','entity')))
    if not paths:raise ValueError('No supported, visible model-space geometry')
    for k,v in skipped.items():warnings.append(f'{k}: {v} omitted. Review omitted entities before use.')
    warnings=list(dict.fromkeys(warnings))[:150]
    points=[v for p in paths if p.role!='ignore' for v in sampled(p,req.curve_tolerance)]
    if len(points)>MAX_SEGMENTS+MAX_PATHS:raise ValueError('Too many flattened curve points')
    x0,y0,x1,y1=bounds(points)
    if max(x1-x0,y1-y0)>10000 or min(x1-x0,y1-y0)<.01:raise ValueError('Drawing extents outside 0.01 to 10000 mm')
    scale=min(960/(x1-x0),570/(y1-y0));cx=(x0+x1)/2;cy=(y0+y1)/2
    document=CadDocument(name=req.filename.rsplit('.',1)[0][:120] or 'DXF',paths=paths,
        options=CadOptions(curve_tolerance=req.curve_tolerance),
        placement=Placement(scale=scale,x=590-cx*scale,y=380+cy*scale),
        source_name=req.filename.replace('\\','/').rsplit('/',1)[-1],source_sha256=hashlib.sha256(raw).hexdigest(),
        source_unit=unit_name,source_version=encoding_info['source_version'],
        source_storage=encoding_info['storage'],source_encoding=encoding_info['encoding'],
        import_review_required=encoding_info['requires_review'],import_warnings=warnings)
    return {'document':document.model_dump(),'encoding_info':encoding_info,'groups':list(groups.values()),'stats':{'entities':count,'paths':len(paths),'skipped':dict(skipped),'millimetres_per_unit':factor},'warnings':warnings}


def bounds(points):
    return [min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points)]


def clean_lines(doc):
    """Endpoint clustering is ONLY for derived topology; native paths stay intact."""
    allpts=[];pieces=[];errors=[];groups=[]
    active=[p for p in doc.paths if p.role in {'cut','crease','perf','unassigned'}]
    for p in active:
        if p.role=='unassigned':errors.append('Unassigned line type: '+p.id);continue
        if p.role=='crease' and p.type!='LINE':errors.append('Curved crease is not foldable: '+p.id)
        pts=sampled(p,doc.options.curve_tolerance)
        pieces.append((p,pts))
        if len(pts)>2 and p.type=='CIRCLE':ends=[]
        else:ends=[(len(pieces)-1,0),(len(pieces)-1,len(pts)-1)]
        for i,j in ends:groups.append((i,j));allpts.append(pts[j])
    if sum(len(pts)-1 for _,pts in pieces)>MAX_SEGMENTS:raise ValueError('Topology exceeds 16000 segments; increase curve tolerance')
    tol=doc.options.snap_tolerance;clusters={};snaps=0;maxmove=0
    if tol:
        for (i,j),point in zip(groups,allpts):
            cell=(math.floor(point[0]/tol),math.floor(point[1]/tol));near=[]
            for dx in [-1,0,1]:
                for dy in [-1,0,1]:near.extend(clusters.get((cell[0]+dx,cell[1]+dy),[]))
            found=min(near,key=lambda v:math.dist(point,v)) if near else None
            dist=math.dist(point,found) if found else float('inf')
            if dist<=tol and dist>1e-10:pieces[i][1][j]=list(found);snaps+=1;maxmove=max(maxmove,dist)
            elif dist>tol:clusters.setdefault(cell,[]).append(list(point))
    lines=defaultdict(list);seen={};duplicates=0
    for p,pts in pieces:
        for a,b in zip(pts,pts[1:]):
            if math.dist(a,b)<1e-8:continue
            key=tuple(sorted((tuple(round(v,8) for v in a),tuple(round(v,8) for v in b))))
            if key in seen:
                if seen[key]!=p.role:errors.append('Conflicting line types overlap near '+p.id)
                else:duplicates+=1
                continue
            seen[key]=p.role;lines[p.role].append(LineString([a,b]))
    tagged=[(role,line) for role,ls in lines.items() for line in ls]
    if tagged:
        tree=STRtree([v[1] for v in tagged]);conflicts=0;candidate_pairs=0
        for i,(role,line) in enumerate(tagged):
            nearby=tree.query(line);candidate_pairs+=sum(int(j)>i for j in nearby)
            if candidate_pairs>25000:raise ValueError('Topology intersection complexity exceeds the local limit; isolate a simpler net')
            for j in nearby:
                if int(j)<=i or tagged[int(j)][0]==role:continue
                if line.intersection(tagged[int(j)][1]).length>1e-6:
                    conflicts+=1
                    if conflicts<=3:errors.append('Different line types partially overlap; separate CUT/CREASE/PERF paths.')
            if conflicts>20:break
    return lines,errors,{'snapped_endpoints':snaps,'max_snap_mm':maxmove,'duplicate_segments':duplicates}


def _geoms(g):return list(g.geoms) if hasattr(g,'geoms') else [g]
def _lines(g):return [p for p in _geoms(g) if p.geom_type=='LineString' and p.length>1e-8]
def face_id(poly):
    # Stable under path order changes, but not resizing; stale hinge settings are surfaced.
    pts=sorted((round(x,6),round(y,6)) for x,y in poly.exterior.coords[:-1])
    return 'f'+hashlib.sha256(repr(pts).encode()).hexdigest()[:12]


def analyze(document: CadDocument | dict, include_model=True):
    d=document if isinstance(document,CadDocument) else CadDocument.model_validate(document)
    lines,errors,stats=clean_lines(d);warnings=list(d.import_warnings)
    if stats['snapped_endpoints']:
        warnings.append('Endpoint snapping is used for preview topology only; use Apply cleanup to change exported geometry.')
    if any(p.role=='perf' for p in d.paths):warnings.append('Perforations are not assumed to be hinges; assign crease explicitly for folding.')
    if not lines['cut']:errors.append('No CUT geometry. Map the DXF layers or colours first.')
    faces=[];material=None
    try:
        if lines['cut']:
            cut_graph=unary_union(lines['cut']);cut_polys,cuts,dangles,invalid=polygonize_full(_lines(cut_graph))
            cp=list(cut_polys.geoms)
            shells=[p for p in cp if not any(q.area>p.area+1e-6 and Polygon(q.exterior).contains(p.representative_point()) for q in cp)]
            if len(shells)!=1:errors.append(f'Expected one closed material outline, found {len(shells)}. Close gaps or isolate one net.')
            else:material=shells[0]
            # Cutting slits can be intentional; preserve them, but block unsolved slit constraints.
            if not cuts.is_empty or not dangles.is_empty or not invalid.is_empty:
                errors.append('CUT paths contain open slits, dangles or invalid rings; fix/classify these before 3D.')
        active=lines['cut']+lines['crease']+lines['perf']
        if active:
            graph=unary_union(active);polys,cuts,dangles,invalid=polygonize_full(_lines(graph))
            stats['noded_segments']=sum(len(l.coords)-1 for l in _lines(graph))
            stats['dangling_segments']=len(_geoms(dangles)) if not dangles.is_empty else 0
            if not cuts.is_empty or not dangles.is_empty or not invalid.is_empty:errors.append('There are unresolved lines that do not bound a face.')
            if material:
                faces=[orient(p,sign=1) for p in polys.geoms if p.area>.001 and material.covers(p.representative_point())]
    except Exception as e:
        if isinstance(e,ValueError):raise
        errors.append('Topology could not be constructed. Check overlapping or self-intersecting contours.')
    if len(faces)>MAX_FACES:raise ValueError('More than 100 faces; isolate one simpler net')
    faces.sort(key=lambda p:(-round(p.area,6),p.centroid.x,p.centroid.y))
    face_info=[{'id':face_id(p),'polygon':list(map(list,p.exterior.coords[:-1])),
                'holes':[list(map(list,r.coords[:-1])) for r in p.interiors],
                'area':p.area,'bounds':list(p.bounds),'center':[p.centroid.x,p.centroid.y]} for p in faces]
    creases=unary_union(lines['crease']) if lines['crease'] else None;links=[];used=[]
    for i,p in enumerate(faces):
        for j in range(i+1,len(faces)):
            common=p.boundary.intersection(faces[j].boundary)
            if creases is None or common.length<1e-6:continue
            common=common.intersection(creases)
            segments=_lines(common)
            if not segments:continue
            merged=linemerge(segments) if len(segments)>1 else segments[0]
            pts=[pt for l in _lines(merged) for pt in l.coords]
            if len(pts)<2:continue
            a=min(pts);b=max(pts);axis=LineString([a,b])
            if axis.length<1e-6:continue
            if any(axis.distance(Point(pt))>1e-5 for pt in pts):
                errors.append('A face pair shares curved or multiple non-collinear hinges.');continue
            common_length=sum(l.length for l in segments)
            if abs(common_length-axis.length)>max(.02,axis.length*1e-5):
                errors.append('Separated hinge fragments require explicit structural resolution.');continue
            key='h_'+':'.join(sorted([face_info[i]['id'],face_info[j]['id']]))
            links.append({'id':key,'a':i,'b':j,'axis':[list(a),list(b)]});used.extend(segments)
    if creases is not None:
        covered=unary_union(used) if used else LineString()
        if creases.difference(covered.buffer(1e-6)).length>max(.02,d.options.snap_tolerance):
            errors.append('Some crease lines do not separate exactly two material faces.')
    adjacency=defaultdict(list)
    for h in links:adjacency[h['a']].append((h['b'],h));adjacency[h['b']].append((h['a'],h))
    root=next((i for i,f in enumerate(face_info) if f['id']==d.options.root),0)
    order=[];parents={root:None};parent_links={};depth={root:0};q=deque([root]) if faces else deque()
    while q:
        i=q.popleft();order.append(i)
        for j,h in adjacency[i]:
            if j not in parents:parents[j]=i;parent_links[j]=h;depth[j]=depth[i]+1;q.append(j)
    if faces and len(order)!=len(faces):errors.append('The crease graph is disconnected; detached parts cannot be folded as one net.')
    if faces and len(links)>len(faces)-1:errors.append('Closed-loop fold constraints are not solved; use a tree-structured net.')
    if not faces:errors.append('No material panels could be identified.')
    settings=[];panels=[]
    for i in order:
        f=face_info[i];parent=parents[i];h=parent_links.get(i)
        poly=orient(Polygon([(x,-y) for x,y in faces[i].exterior.coords],
                            [[(x,-y) for x,y in r.coords] for r in faces[i].interiors]),sign=1)
        try:
            from shapely import constrained_delaunay_triangles
            tris=list(constrained_delaunay_triangles(poly).geoms)
        except (ImportError,AttributeError):tris=[t for t in triangulate(poly) if poly.covers(t)]
        if abs(sum(t.area for t in tris)-poly.area)>max(1e-5,poly.area*1e-6):
            errors.append('Triangulation did not preserve face area: '+f['id'])
        triangle_pts=[list(map(list,orient(t,sign=1).exterior.coords[:-1])) for t in tris]
        axis=[[x,-y] for x,y in h['axis']] if h else None
        ang=0;opening=0;stage=[0,1];confirmed=True
        if h:
            a,b=axis;c=[f['center'][0],-f['center'][1]]
            side=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
            ang=90 if side>0 else -90
            setg=d.hinges.get(h['id']);confirmed=bool(setg and setg.confirmed)
            stage=[max(0,(depth[i]-1)*.1),min(1,.65+(depth[i]-1)*.1)]
            if stage[0]>=stage[1]:stage=[0,1]
            if setg:ang=setg.angle;opening=setg.openAngle;stage=list(setg.stage)
            settings.append({**h,'parent':face_info[parent]['id'],'child':f['id'],'angle':ang,'openAngle':opening,'stage':stage,'confirmed':confirmed})
        panels.append({'id':f['id'],'polygon':list(map(list,poly.exterior.coords[:-1])),
            'holes':[list(map(list,r.coords[:-1])) for r in poly.interiors],'triangles':triangle_pts,
            'parent':face_info[parent]['id'] if parent is not None else None,'axis':axis,'angle':ang,'openAngle':opening,
            'stage':stage,'release':[0,1],'bounds':list(poly.bounds),'sourceFace':None,'visualInset':0})
    stale=set(d.hinges)-{h['id'] for h in links}
    if stale:warnings.append(f'{len(stale)} previous hinge settings no longer match the edited geometry; confirm the new hinges.')
    if settings and any(not s['confirmed'] for s in settings):warnings.append('Proposed fold directions/angles require confirmation. A 2D drawing cannot uniquely specify all fold actions.')
    if d.options.fold_allowance:warnings.append('Fold allowance is stored as a process note only; no uncalibrated material compensation is applied.')
    model=None
    if panels and not errors:
        bb=bounds([p for f in panels for p in f['polygon']]);cx=face_info[root]['center'][0];cy=-face_info[root]['center'][1]
        span=math.hypot(bb[2]-bb[0],bb[3]-bb[1]);
        model={'schema':'local-carton/1','spec':{'kind':'imported','length':bb[2]-bb[0],'width':bb[3]-bb[1],'height':max(1,d.options.thickness),'thickness':d.options.thickness,'bleed':d.options.bleed},
               'panels':panels,'bounds':bb,'displayMatrix':[[1,0,0,-cx],[0,-1,0,cy],[0,0,-1,0],[0,0,0,1]],
               'motionRadius':max(span,1)*1.2,'cut':[], 'creases':[{'panel':h['child'],'points':[[x,-y] for x,y in h['axis']]} for h in settings],
               'warnings':warnings,'production_validated':False}
        assign_preview_layers(model)
    bb=list(material.bounds) if material else (bounds([x for p in d.paths for x in sampled(p,d.options.curve_tolerance)]) if d.paths else [0,0,1,1])
    bleed=[]
    if material and d.options.bleed:
        buffered=material.buffer(d.options.bleed,join_style=2)
        for p in _geoms(buffered):
            if p.geom_type=='Polygon':bleed.append(list(map(list,p.exterior.coords)))
    return {'faces':face_info,'hinges':settings,'root':face_info[root]['id'] if faces else None,
            'bounds':bb,'bleed':bleed,'stats':{**stats,'faces':len(faces),'hinges':len(links),'paths':len(d.paths)},
            'warnings':list(dict.fromkeys(warnings))[:200], 'errors':list(dict.fromkeys(errors))[:200],
            'foldable':model is not None,'angles_confirmed':bool(model) and all(h['confirmed'] for h in settings),
            'production_validated':False,'model':model if include_model else None}


def cleaned_document(d:CadDocument):
    """Explicit opt-in destructive approximation; caller retains source/undo copy."""
    lines,errors,stats=clean_lines(d)
    if errors:raise ValueError('; '.join(errors[:5]))
    paths=[]
    networks={role:unary_union(ls) for role,ls in lines.items() if ls}
    # Node intersections across roles while preserving their unambiguous type.
    for l in _lines(unary_union([g for g in networks.values()])):
        for a,b in zip(l.coords,list(l.coords)[1:]):
            segment=LineString([a,b]);mid=segment.interpolate(.5,normalized=True)
            candidates=[role for role,g in networks.items() if g.distance(mid)<1e-7]
            if len(candidates)!=1:raise ValueError('Cleanup cannot assign a unique line type')
            role=candidates[0]
            paths.append(CadPath(id=f'p{len(paths)+1}',type='LINE',role=role,layer=role.upper(),color=1 if role=='crease' else 5,a=a,b=b,source='explicit-cleanup'))
    paths.extend(p.model_copy(update={'id':f'extra_{i}'}) for i,p in enumerate(d.paths) if p.role in {'guide','ignore'})
    result=d.model_copy(update={'paths':paths,'hinges':{},'import_warnings':d.import_warnings+['Explicit cleanup applied: curves converted to line segments at the declared tolerance.']})
    return CadDocument.model_validate(result.model_dump())


class ScaleRequest(Strict):
    document: CadDocument
    x: float = Field(1, gt=.01, le=100)
    y: float = Field(1, gt=.01, le=100)


def scale_document(d,sx,sy):
    if abs(sx-sy)>1e-10 and any(p.type!='LINE' for p in d.paths):
        raise ValueError('Non-uniform scale of ARC/CIRCLE would create ellipses. Use uniform scale, or explicitly apply polygonal cleanup first.')
    paths=[]
    for p in d.paths:
        data=p.model_dump();data.update(a=(p.a[0]*sx,p.a[1]*sy),b=(p.b[0]*sx,p.b[1]*sy),center=(p.center[0]*sx,p.center[1]*sy),radius=p.radius*sx)
        paths.append(CadPath.model_validate(data))
    result=d.model_copy(update={'paths':paths,'hinges':{},'options':d.options.model_copy(update={'root':None})})
    return CadDocument.model_validate(result.model_dump())


def export_dxf(d:CadDocument):
    doc=ezdxf.new('R2010');doc.units=units.MM;m=doc.modelspace()
    for role,col in [('cut',5),('crease',1),('perf',6),('guide',8)]:doc.layers.new(role.upper(),dxfattribs={'color':col})
    for p in d.paths:
        if p.role in {'ignore','unassigned'}:continue
        attr={'layer':p.role.upper()}
        if p.type=='LINE':m.add_line(p.a,p.b,dxfattribs=attr)
        elif p.type=='ARC':m.add_arc(p.center,p.radius,p.start,p.start+p.sweep,dxfattribs=attr)
        else:m.add_circle(p.center,p.radius,dxfattribs=attr)
    # BLEED is a derived design guide, not an offset cutting knife.
    result=analyze(d,include_model=False)
    if result['bleed']:
        doc.layers.new('BLEED',dxfattribs={'color':3})
        for ring in result['bleed']:m.add_lwpolyline(ring[:-1],close=True,dxfattribs={'layer':'BLEED'})
    out=StringIO();doc.write(out);return out.getvalue()


def export_svg(d:CadDocument):
    from html import escape
    points=[pt for p in d.paths for pt in sampled(p,d.options.curve_tolerance)]
    if not points:raise ValueError('No paths to export')
    x0,y0,x1,y1=bounds(points);margin=d.options.bleed+2
    header=f'<svg xmlns="http://www.w3.org/2000/svg" width="{x1-x0+2*margin}mm" height="{y1-y0+2*margin}mm" viewBox="{x0-margin} {-y1-margin} {x1-x0+2*margin} {y1-y0+2*margin}"><title>{escape(d.name)} - structural preview, not manufacturing approved</title>'
    colors={'cut':'#2677e2','crease':'#e14f54','perf':'#ac51c7','guide':'#8f99a7'};out=[]
    for role,col in colors.items():
        out.append(f'<g id="{role.upper()}" stroke="{col}" fill="none" stroke-width="0.18"'+(' stroke-dasharray="2 1"' if role in {'crease','perf'} else '')+'>')
        for p in d.paths:
            if p.role!=role:continue
            if p.type=='LINE':out.append(f'<path d="M {p.a[0]} {-p.a[1]} L {p.b[0]} {-p.b[1]}"/>')
            elif p.type=='CIRCLE':out.append(f'<circle cx="{p.center[0]}" cy="{-p.center[1]}" r="{p.radius}"/>')
            else:
                pts=sampled(p,d.options.curve_tolerance);a,b=pts[0],pts[-1]
                out.append(f'<path d="M {a[0]} {-a[1]} A {p.radius} {p.radius} 0 {1 if p.sweep>180 else 0} 0 {b[0]} {-b[1]}"/>')
        out.append('</g>')
    result=analyze(d,include_model=False)
    out.append('<g id="BLEED" fill="none" stroke="#2ea174" stroke-width="0.18" stroke-dasharray="2 1">')
    for ring in result['bleed']:
        pts=' '.join(f'{x},{-y}' for x,y in ring);out.append(f'<polygon points="{pts}"/>')
    out.append('</g>')
    return header+''.join(out)+'</svg>'
