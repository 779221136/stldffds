"""New reader tests. Synthetic fixtures, NOT factory or source-site certification."""
from io import BytesIO, StringIO
import base64
import codecs
import hashlib
import re

import ezdxf
import pytest
from pydantic import ValidationError
from app.dxf_reader import read_dxf, _raw_binary_tags, ENCODINGS
from app.cad_engine import ImportRequest, parse_dxf, CadDocument

VERSIONS = ['R12','R2000','R2004','R2007','R2010','R2013','R2018']


def fixture(version='R2010', storage='ascii', layer='CUT', codec='cp1252'):
    doc=ezdxf.new(version);doc.units=4;doc.encoding=codec
    doc.layers.new(layer,dxfattribs={'color':5})
    for a,b in [((0,0),(60,0)),((60,0),(60,40)),((60,40),(0,40)),((0,40),(0,0))]:
        doc.modelspace().add_line(a,b,dxfattribs={'layer':layer})
    if storage=='binary':
        stream=BytesIO();doc.write(stream,fmt='bin');return stream.getvalue()
    stream=StringIO();doc.write(stream)
    return stream.getvalue().encode(doc.output_encoding,errors='dxfreplace')


def imported(data,**kw):
    return parse_dxf(ImportRequest(filename='test.DXF',data=base64.b64encode(data).decode(),**kw))


@pytest.mark.parametrize('version',VERSIONS)
@pytest.mark.parametrize('storage',['ascii','binary'])
def test_version_storage_geometry_roundtrip(version,storage):
    raw=fixture(version,storage)
    r=imported(raw,unit='mm')
    assert len(r['document']['paths'])==4
    assert r['encoding_info']['storage']==storage
    assert r['encoding_info']['reader']=='ezdxf'
    assert not r['encoding_info']['requires_review']
    assert r['document']['source_sha256']==hashlib.sha256(raw).hexdigest()
    assert max(v for p in r['document']['paths'] for v in [p['a'][0],p['b'][0]])==60
    assert {p['layer'] for p in r['document']['paths']}=={'CUT'}


@pytest.mark.parametrize('version',VERSIONS)
def test_binary_matches_text_geometry(version):
    a=imported(fixture(version,'ascii'),unit='mm')['document']['paths']
    b=imported(fixture(version,'binary'),unit='mm')['document']['paths']
    for x,y in zip(a,b):
        for key in ['type','role','layer','color','a','b']:
            assert x[key]==y[key]


@pytest.mark.parametrize('revision',['AC1012','AC1014','AC1006'])
def test_older_declared_revision_kept_in_provenance(revision):
    # Minimal representative tags, NOT a claim of native R13/R14 CAD coverage.
    raw=('0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\n'+revision+'\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nCUT\n10\n0\n20\n0\n11\n60\n21\n40\n0\nENDSEC\n0\nEOF\n').encode()
    r=imported(raw,unit='mm')
    assert r['document']['source_version']==revision
    assert r['encoding_info']['loaded_version']==('AC1009' if revision<'AC1009' else 'AC1015')


@pytest.mark.parametrize('codec,layer',[
    ('gbk','\u5200\u7ebf'),('cp950','\u5200\u7dda'),('cp932','\u5207\u65ad'),('cp949','CUT \ud55c\uae00'),
    ('cp1251','CUT \u0422\u0435\u0441\u0442'),('cp1250','CUT \u010d'),('cp1252','CUT Caf\u00e9'),
    ('cp1253','CUT \u03b1'),('cp1254','CUT \u0131'),('cp1255','CUT \u05d0'),
    ('cp1256','CUT \u0628'),('cp1257','CUT \u0100'),('cp1258','CUT \u0102'),('cp874','CUT \u0e01')])
@pytest.mark.parametrize('storage',['ascii','binary'])
def test_declared_legacy_codepages(codec,layer,storage):
    r=imported(fixture('R2000',storage,layer,codec))
    assert r['encoding_info']['encoding']==codec
    assert {p['layer'] for p in r['document']['paths']}=={layer}


@pytest.mark.parametrize('codec,layer',[
    ('gb18030','CUT \U00020000'),('gb2312','CUT \u5200'),('big5','CUT \u7dda'),
    ('shift_jis','CUT \u5207'),('cp437','CUT \u2502'),('cp850','CUT \u00f8'),('latin-1','CUT \u00e9')])
def test_manual_nonstandard_text_codecs(codec,layer):
    text=fixture('R2000',layer='REPLACE').decode('cp1252').replace('REPLACE',layer)
    raw=text.encode(codec)
    r=imported(raw,encoding=codec)
    assert r['encoding_info']['encoding_source']=='manual'
    assert r['document']['paths'][0]['layer']==layer


@pytest.mark.parametrize('storage',['ascii','binary'])
def test_r2007_utf8_ignores_legacy_codepage(storage):
    raw=fixture('R2010',storage,'CUT \u5200')
    raw=raw.replace(b'ANSI_1252',b'ANSI_936')
    r=imported(raw)
    assert r['encoding_info']['encoding']=='utf-8'
    assert r['document']['paths'][0]['layer']=='CUT \u5200'


def test_manual_binary_codec_overrides_misdeclared_legacy():
    raw=fixture('R2000','binary','CUT \u5200','gbk').replace(b'ANSI_936',b'ANSI_1252')
    r=imported(raw,encoding='gbk')
    assert r['document']['paths'][0]['layer']=='CUT \u5200'
    assert r['encoding_info']['encoding_source']=='manual'


@pytest.mark.parametrize('codec,bom',[
    ('utf-16-le',codecs.BOM_UTF16_LE),('utf-16-be',codecs.BOM_UTF16_BE),
    ('utf-32-le',codecs.BOM_UTF32_LE),('utf-32-be',codecs.BOM_UTF32_BE)])
@pytest.mark.parametrize('has_bom',[True,False])
def test_unicode_transports(codec,bom,has_bom):
    text=fixture(layer='CUT \u5200').decode('utf-8')
    raw=(bom if has_bom else b'')+text.encode(codec)
    r=imported(raw,encoding='auto' if has_bom else codec)
    assert r['encoding_info']['encoding']==codec
    assert r['document']['paths'][0]['layer']=='CUT \u5200'
    with pytest.raises(ValueError,match='DXF_ENCODING_CONFLICT' if has_bom else 'DXF_FORMAT'):
        imported(raw,encoding='gbk')


def test_binary_unrelated_unicode_header_does_not_break_metadata():
    d=ezdxf.new('R2010');d.units=4;d.header['$LASTSAVEDBY']='\u8bbe\u8ba1\u5e08'
    d.modelspace().add_line((0,0),(60,40));s=BytesIO();d.write(s,fmt='bin')
    assert len(imported(s.getvalue())['document']['paths'])==1


@pytest.mark.parametrize('raw',[
    b'AutoCAD Binary DXF\r\n\x1a\0',b'AutoCAD Binary DXF garbage',
    fixture(storage='binary')[:-1],fixture(storage='binary')[:-15],
    fixture(storage='binary')+b'garbage',b'AutoCAD Binary DXF\r\n\x1a\0\0\0SECTION\0\xff\xff',
])
def test_corrupt_binary_is_bounded_and_explicit(raw):
    with pytest.raises(ValueError,match='DXF_BINARY'):
        read_dxf(raw,mode='recover')


def test_binary_string_decoding_is_strict():
    raw=fixture(storage='binary',layer='CUT \u5200').replace('\u5200'.encode(),b'\xff')
    with pytest.raises(ValueError,match='DXF_ENCODING'):
        imported(raw)


def test_invalid_numeric_coordinate_is_not_silently_repaired():
    raw=fixture();a,b=raw.split(b'ENTITIES\n',1)
    b=re.sub(rb'(?m)^ *10\n0\.0\n',b' 10\nnot-a-number\n',b,count=1)
    with pytest.raises(ValueError,match='DXF_RECOVERY'):
        imported(a+b'ENTITIES\n'+b,reader_mode='recover')


def broken_fixture(codec=None):
    raw=fixture('R2000' if codec else 'R2010',layer='CUT \u5200',codec=codec or 'cp1252')
    return raw.replace(b'  0\nENDSEC\n',b'',1)


def test_recovery_preserves_chinese_geometry_and_original_hash():
    raw=broken_fixture()
    with pytest.raises(ValueError,match='DXF_STRUCTURE'):
        imported(raw)
    r=imported(raw,reader_mode='recover')
    assert r['encoding_info']['recovered']
    assert r['encoding_info']['audit_fix_count']>=1
    assert len(r['document']['paths'])==4
    assert r['document']['paths'][0]['layer']=='CUT \u5200'
    assert r['document']['source_sha256']==hashlib.sha256(raw).hexdigest()
    assert r['document']['import_review_required'] and not r['document']['import_review_accepted']


def test_recovery_manual_gbk_preserves_characters():
    raw=broken_fixture('gbk').replace(b'ANSI_936',b'ANSI_1252')
    r=imported(raw,encoding='gbk',reader_mode='recover')
    assert r['document']['paths'][0]['layer']=='CUT \u5200'


def test_recovery_review_gate_api_and_persistence(client):
    client.get('/api/local/capabilities')
    response=client.post('/api/local/cad/import',json={'filename':'recovery.dxf','reader_mode':'recover','data':base64.b64encode(broken_fixture()).decode()})
    assert response.status_code==200,response.text
    document=response.json()['document']
    for endpoint in ['validate','analyze','cleanup','export/dxf']:
        r=client.post('/api/local/cad/'+endpoint,json=document)
        assert r.status_code==422 and 'DXF_REVIEW_REQUIRED' in r.text
    assert client.post('/api/local/cad/library',json={'document':document}).status_code==422
    document['import_review_accepted']=True
    assert client.post('/api/local/cad/validate',json=document).status_code==200
    saved=client.post('/api/local/cad/library',json={'document':document})
    assert saved.status_code==201,saved.text
    mid=saved.json()['id']
    loaded=client.get('/api/local/cad/library/'+mid)
    assert loaded.json()['document']['import_review_required']
    assert loaded.json()['document']['import_review_accepted']


def test_unknown_future_version_not_claimed_supported():
    with pytest.raises(ValueError,match='DXF_VERSION'):
        imported(fixture().replace(b'AC1024',b'AC1099'))


def test_binary_future_version_not_claimed_supported():
    with pytest.raises(ValueError,match='DXF_VERSION'):
        imported(fixture(storage='binary').replace(b'AC1024',b'AC1099'))


def test_reader_limits_and_options():
    with pytest.raises(ValueError,match='5 MiB'):
        read_dxf(b'x'*(5*1024*1024+1))
    with pytest.raises(ValueError,match='DXF_ENCODING_OPTION'):
        read_dxf(fixture(),encoding='unicode_escape')
    with pytest.raises(ValueError,match='DXF_READ_MODE'):
        read_dxf(fixture(),mode='ignore-errors')
    with pytest.raises(ValidationError):
        ImportRequest(data='YQ==',encoding='utf-7')


def test_capabilities_report_actual_reader(client):
    r=client.get('/api/local/cad/capabilities');assert r.status_code==200
    assert r.json()['reader']=='ezdxf'
    assert r.json()['dxf_storage']==['ascii','binary']
    assert r.json()['dxf_encodings']==list(ENCODINGS)

@pytest.mark.parametrize('layer',['CUT \U0001f4e6','CUT \U00020000'])
def test_nonbmp_strict_succeeds_but_recovery_never_corrupts(layer):
    raw=fixture(layer=layer)
    assert imported(raw)['document']['paths'][0]['layer']==layer
    with pytest.raises(ValueError,match='DXF_RECOVERY_UNICODE'):
        imported(raw.replace(b'  0\nENDSEC\n',b'',1),reader_mode='recover')
