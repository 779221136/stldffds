"""Local authored-code + in-process API checks, not native browser/OS E2E."""
import asyncio
import os
import json
import tempfile
import sys
from pathlib import Path
from io import StringIO, BytesIO
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from fastapi.testclient import TestClient
from playwright.async_api import async_playwright
from tools.component_harness_v6 import boot
import ezdxf
import app.main as main
OUT=ROOT/'evidence/dxf_reader_v8_3/browser'
OUT.mkdir(parents=True,exist_ok=True)

def drawing(storage='binary'):
    d=ezdxf.new('R2010');d.units=4;d.layers.new('CUT \u5200\u7ebf',dxfattribs={'color':5})
    for a,b in [((0,0),(60,0)),((60,0),(60,40)),((60,40),(0,40)),((0,40),(0,0))]:
        d.modelspace().add_line(a,b,dxfattribs={'layer':'CUT \u5200\u7ebf'})
    s=BytesIO() if storage=='binary' else StringIO();d.write(s,fmt='bin' if storage=='binary' else 'asc')
    return s.getvalue() if storage=='binary' else s.getvalue().encode('utf-8')

async def run():
    checks=[]
    def ok(name,value):
        checks.append({'name':name,'passed':bool(value)});print(name,bool(value),flush=True);assert value,name
    os.environ['ENV']='test'
    with tempfile.TemporaryDirectory() as td:
        main.DB_PATH=Path(td)/'test.db'
        with TestClient(main.app) as client:
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                page,errors=await boot(browser,'/cad',client=client)
                page.set_default_timeout(15000)
                page.on('dialog',lambda d:d.accept())
                try:
                    await page.locator('[data-import]').click()
                    ok('Default strict mode',await page.locator('[data-reader-mode]').input_value()=='strict')
                    ok('Default automatic encoding',await page.locator('[data-encoding]').input_value()=='auto')
                    ok('Encoding options present',await page.locator('[data-encoding] option').count()==28)
                    async def choose(raw,name):
                        async with page.expect_file_chooser() as picked:
                            await page.locator('[data-drop]').click()
                        await (await picked.value).set_files({'name':name,'mimeType':'','buffer':raw})
                    await choose(drawing(),'binary-\u5200\u6a21.DXF')
                    await page.locator('[data-parse]').click()
                    await page.locator('[data-import-confirm]').wait_for()
                    text=await page.locator('[data-import-state]').inner_text()
                    ok('Binary storage shown','binary' in text)
                    ok('Source version shown','AC1024' in text)
                    ok('Actual encoding shown','utf-8' in text)
                    ok('Chinese layer preserved','\u5200\u7ebf' in await page.locator('[data-import-preview]').inner_text())
                    ok('Strict result does not demand recovery consent',await page.locator('[data-review-ack]').count()==0)
                    ok('Strict confirmation enabled',await page.locator('[data-import-confirm]').is_enabled())
                    await page.screenshot(path=str(OUT/'binary-preview.png'),full_page=True)
                    await page.locator('[data-import-confirm]').click()
                    await page.locator('.cad-modal').wait_for(state='hidden')
                    ok('Binary drawing accepted into canvas',await page.locator('[data-name]').input_value()=='binary-\u5200\u6a21')
                    await page.locator('[data-import]').click()
                    await choose(drawing('ascii').replace(b'  0\nENDSEC\n',b'',1),'repair.dxf')
                    await page.locator('[data-parse]').click()
                    await page.locator('.cad-modal-error').wait_for(state='visible')
                    ok('Strict mode gives structural error','DXF_STRUCTURE' in await page.locator('.cad-modal-error').inner_text())
                    ok('Failed read cannot confirm',await page.locator('[data-import-confirm]').count()==0)
                    await page.locator('[data-reader-mode]').select_option('recover')
                    await page.locator('[data-parse]').click()
                    await page.locator('[data-review-ack]').wait_for()
                    ok('Recovery confirmation initially blocked',await page.locator('[data-import-confirm]').is_disabled())
                    ok('Recovery warning visible','RECOVERY REVIEW' in await page.locator('[data-import-warnings]').inner_text())
                    await page.locator('[data-import-map]').first.select_option('guide')
                    ok('Mapping change does not bypass consent',await page.locator('[data-import-confirm]').is_disabled())
                    await page.locator('[data-import-map]').first.select_option('cut')
                    await page.locator('[data-review-ack]').check()
                    ok('Explicit review enables import',await page.locator('[data-import-confirm]').is_enabled())
                    await page.locator('[data-review-ack]').uncheck()
                    ok('Revoking consent blocks import again',await page.locator('[data-import-confirm]').is_disabled())
                    await page.locator('[data-reader-mode]').select_option('strict')
                    ok('Reader-mode change invalidates old preview',await page.locator('[data-import-confirm]').count()==0)
                    await page.locator('[data-reader-mode]').select_option('recover')
                    await page.locator('[data-parse]').click();await page.locator('[data-review-ack]').wait_for()
                    await page.locator('[data-review-ack]').check()
                    await page.locator('[data-import-preview] details summary').click()
                    await page.screenshot(path=str(OUT/'recovery-review.png'),full_page=True)
                    await page.locator('[data-import-confirm]').click()
                    await page.locator('.cad-modal').wait_for(state='hidden')
                    ok('Recovered drawing accepted only after review',await page.locator('[data-name]').input_value()=='repair')
                    ok('No uncaught browser script errors',not errors)
                    (OUT/'checks.json').write_text(json.dumps({'scope':'Offline local-code Chromium components + in-process FastAPI; NOT OS-native, source-site, GPU, or URL E2E','checks':checks,'browser':browser.version,'errors':errors},indent=2),encoding='utf-8')
                except Exception:
                    await page.screenshot(path=str(OUT/'failure.png'),full_page=True)
                    (OUT/'failure.json').write_text(json.dumps({'checks':checks,'errors':errors},indent=2),encoding='utf-8')
                    raise
                finally:
                    await page.close();await browser.close()
if __name__=='__main__':asyncio.run(run())
