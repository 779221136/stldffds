# v8.3 reader update: production approval remains BLOCKED

Expanded DXF loading does not imply support for all CAD entities, manufacturing
validation, complete original-site parity, or production security approval.
See README_LATEST.md for the precise reader matrix and release verification.
No credentials or external services were added.

---

# v7 status: local features implemented, original-platform parity BLOCKED

## Implemented and tested locally
- Two millimetre parametric drafts with tabs, shared creases, union cut and bleed.
- Staged rigid-panel folding and opening using hierarchical hinge matrices.
- SVG/DXF draft export; six-face editor texture transfer; local project JSON.
- Local CPU PNG and animation worker, persistent bounded queue, private results,
  progress, cancellation, deletion and explicit restart failure state.
- Desktop and 390px mobile component interaction checks, software preview.

## Release blockers still present
- Original template images, editable objects, model library and exact UI-state
  screenshots were not acquired. Sample catalog remains 20 templates / 12 models.
- Two idealised structures are not a physically validated carton CAD system.
  No collision solver, die rules, manufacturing tolerance or stock allowance.
  Visual extrusion/layer offsets are only preview aids.
- No generic DXF/GLB/PSD/AI importer, fold topology inference or arbitrary box library.
- Local raster output is not photorealistic PBR/path tracing. No cloud dependency
  is intended or required by this release. The legacy cloud endpoint stays disabled.
- No ICC, CMYK, spot-colour production plates or PDF/X acceptance.
- No production SMS/OAuth/payment/membership/team/factory/logistics implementation.
- Native browser E2E and GPU unavailable in this environment; no macOS/Windows,
  Docker/network-bridge, proxy, load, restore or multi-tenant security acceptance.

Local-only APIs intentionally reject LAN and public peers. Run one Python
application process on loopback. The inherited Docker bridge configuration
is not a verified path to these local-only routes.

Passing tests does NOT turn the full original-site production gate into PASS.
